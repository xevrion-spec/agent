// Xevrion websites Worker: one Worker serves three hosts from one static asset bundle.
//   xevrion.co.uk            -> /parent/…   (www.xevrion.co.uk redirects here)
//   ops.xevrion.co.uk        -> /ops/…
//   portal.ops.xevrion.co.uk -> /portal/…
// Shared files live under /shared/. Redirect maps are injected by build.py.
const REDIRECTS = /*@REDIRECTS@*/{};
const PORTAL_APP = /*@PORTAL_APP@*/{};

const HOST_MAP = {
  "xevrion.co.uk": "parent",
  "www.xevrion.co.uk": "www",
  "ops.xevrion.co.uk": "ops",
  "portal.ops.xevrion.co.uk": "portal",
};
const SITES = new Set(["parent", "ops", "portal"]);
// Other hosts attached to this Worker. portal.xevrion.co.uk is the address older invitation emails use: its root and
// /portal open the page that takes a private access code (the gateway's /portal), the app's own paths go to the app,
// and anything else goes to the portal hub (path and query kept). manage.xevrion.co.uk is a staff address: it opens
// the operator console, which checks the owner's sign-in on every request.
const HOST_REDIRECTS = {
  "portal.xevrion.co.uk": (key) => (key === "/" || key === "/portal" ? PORTAL_APP["/customer"] : PORTAL_APP[key] || null),
  "manage.xevrion.co.uk": () => PORTAL_APP["/console"],
};
const HOST_FALLBACK = { "portal.xevrion.co.uk": "https://portal.ops.xevrion.co.uk" };
const LOCAL = /^(localhost|127\.0\.0\.1|\[::1\])$/;

function resolveSite(host, url, env) {
  const h = (host || "").toLowerCase().split(":")[0];
  if (HOST_MAP[h]) return { site: HOST_MAP[h], pathname: url.pathname };
  // workers.dev preview: /parent/… and /portal/… select a site by path; everything else is DEFAULT_SITE
  // (the preview Worker sets it to "ops" so the product site's root-relative links work while reviewing)
  const m = url.pathname.match(/^\/(ops|portal|parent)(\/.*)?$/);
  if (m) return { site: m[1], pathname: m[2] || "/" };
  return { site: SITES.has(env.DEFAULT_SITE) ? env.DEFAULT_SITE : "parent", pathname: url.pathname };
}

function assetPath(site, pathname) {
  if (pathname.startsWith("/shared/")) return pathname;
  let path = pathname;
  if (path.endsWith("/")) path += "index.html";
  else if (!/\.[a-z0-9]+$/i.test(path)) path += ".html";
  return `/${site}${path}`;
}

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "font-src 'self'",
  "img-src 'self' data:",
  "connect-src 'self' https://api.xevrion.co.uk",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self' mailto:",
  "object-src 'none'",
].join("; ");
// HTTPS for a year on these hosts. includeSubDomains is left to the zone setting, once every subdomain is HTTPS-only.
const HSTS = "max-age=31536000";

function cacheControl(pathname, isHtml) {
  if (isHtml) return "public, max-age=300, must-revalidate";
  if (/^\/shared\/((css|js)\/[\w-]+|search|atlas)\.[0-9a-f]{10}\.(css|js|json)$/.test(pathname)) return "public, max-age=31536000, immutable";
  if (pathname.startsWith("/shared/fonts/")) return "public, max-age=2592000";
  if (pathname.endsWith(".xml") || pathname.endsWith(".txt")) return "public, max-age=3600";
  return "public, max-age=86400";
}

function withHeaders(response, { isHtml, pathname, status, env = {} }) {
  const headers = new Headers(response.headers);
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  headers.set("X-Frame-Options", "DENY");
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()");
  headers.set("Cross-Origin-Opener-Policy", "same-origin");
  headers.set("Strict-Transport-Security", HSTS);
  if (isHtml) headers.set("Content-Security-Policy", CSP);
  if (isHtml && env.NOINDEX === "1") headers.set("X-Robots-Tag", "noindex, nofollow"); // the preview is never indexed
  // the Xevrion app on api.xevrion.co.uk uses the same self-hosted Geist fonts (its CSP allows this origin's fonts)
  if (pathname.startsWith("/shared/fonts/")) headers.set("Access-Control-Allow-Origin", "https://api.xevrion.co.uk");
  // a 404 is never cached: during a rollout a new file can be briefly missing at one edge, and a cached "not found"
  // would outlive it
  headers.set("Cache-Control", status === 404 ? "no-store" : cacheControl(pathname, isHtml));
  return new Response(response.body, { status: status || response.status, statusText: response.statusText, headers });
}

// Absolute destinations come only from the maps above (REDIRECTS, PORTAL_APP, HOST_REDIRECTS). Anything else is a path
// on this origin: leading slashes and backslashes are collapsed first, because "//host/x" or "/\host/x" would otherwise
// be read as another host (an open redirect).
function redirect(to, url, status = 301) {
  const absolute = /^https:\/\/[a-z0-9.-]+(\/|$)/i.test(to);
  let dest = absolute ? new URL(to) : new URL("/" + String(to).replace(/^[\\/]+/, ""), url.origin);
  if (!absolute && dest.origin !== url.origin) dest = new URL("/", url.origin);
  if (!dest.search && url.search) dest.search = url.search;
  return new Response(null, { status, headers: { Location: dest.toString(), "Cache-Control": status === 301 ? "public, max-age=86400" : "no-store",
                                                 "Strict-Transport-Security": HSTS } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method !== "GET" && request.method !== "HEAD") {
      // the enquiry forms post only through the site script; a browser without it lands here, so say where to write
      return new Response("Method not allowed. To send an enquiry without JavaScript, email outreach@ops.xevrion.co.uk and we will reply in writing.\n",
                          { status: 405, headers: { Allow: "GET, HEAD", "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
    }
    const host = (request.headers.get("Host") || url.hostname).toLowerCase().split(":")[0];
    // HTTPS only: a plain-HTTP request is sent to the same address over HTTPS (local development is left alone).
    if (url.protocol === "http:" && !LOCAL.test(url.hostname)) {
      return new Response(null, { status: 301, headers: { Location: `https://${url.host}${url.pathname}${url.search}`, "Cache-Control": "public, max-age=86400" } });
    }
    if (HOST_REDIRECTS[host]) {
      const key = url.pathname.replace(/^[\\/]+/, "/").replace(/\/+$/, "") || "/";
      const to = HOST_REDIRECTS[host](key);
      return redirect(to || HOST_FALLBACK[host] + "/" + url.pathname.replace(/^[\\/]+/, ""), url, 301);
    }
    let { site, pathname } = resolveSite(host, url, env);

    if (site === "www") {
      const dest = new URL(url.toString());
      dest.protocol = "https:"; dest.hostname = "xevrion.co.uk"; dest.port = "";
      return Response.redirect(dest.toString(), 301);
    }
    if (!SITES.has(site)) site = "parent";

    // "//x" and "/\x": one leading slash only (same origin)
    if (/^\/[\\/]/.test(pathname)) return redirect(pathname, url);
    // tidy URLs: /page.html and /page/ both redirect to /page (except the root)
    if (pathname !== "/" && !pathname.startsWith("/shared/")) {
      if (pathname.endsWith(".html")) return redirect(pathname.replace(/(\/index)?\.html$/, "") || "/", url);
      if (pathname.endsWith("/")) return redirect(pathname.replace(/\/+$/, ""), url);
    }

    const key = pathname.replace(/\/$/, "") || "/";
    const map = REDIRECTS[site] || {};
    if (map[key]) return redirect(map[key], url, 301);
    if (site === "portal" && PORTAL_APP[key]) return redirect(PORTAL_APP[key], url, 302);

    const path = assetPath(site, pathname);
    let response = await env.ASSETS.fetch(new Request(new URL(path, url.origin), { method: request.method, headers: request.headers }));
    if (response.status === 404) {
      const nf = await env.ASSETS.fetch(new URL(`/${site}/404.html`, url.origin));
      if (nf.status === 200) return withHeaders(nf, { isHtml: true, pathname: "/404", status: 404, env });
      return new Response("Not found", { status: 404, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
    }
    const isHtml = (response.headers.get("Content-Type") || "").includes("text/html");
    return withHeaders(response, { isHtml, pathname: path, env });
  },
};
