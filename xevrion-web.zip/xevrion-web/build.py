"""Build the three Xevrion websites into dist/ for the Cloudflare Worker `xevrion-websites`.

    python build.py            build and report problems
    python build.py --strict   fail (exit 1) on any problem; used before deploying

Layout of dist/ (matches the Worker's asset mapping):
    dist/{parent,ops,portal}/…html    one file per page ("/pricing" -> ops/pricing.html, "/" -> ops/index.html)
    dist/shared/{css,js}/…            content-hashed, cached forever
    dist/shared/{fonts,brand,og}/…    stable names
    dist/_worker.js                   the Worker, with redirect maps injected
"""
from __future__ import annotations

import hashlib
import html
import importlib
import json
import re
import shutil
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC, DIST = ROOT / "src", ROOT / "dist"
sys.path.insert(0, str(ROOT))

from xw import shell  # noqa: E402
from xw.html import favicon_svg, mark_flat, mark_standalone  # noqa: E402
from xw.redirects import PORTAL_APP, REDIRECTS  # noqa: E402
from xw.sites import make_sites  # noqa: E402

PAGE_MODULES = [
    "ops_home", "ops_core", "ops_product", "ops_platform", "ops_solutions", "ops_integrations", "ops_commercial", "ops_portal", "ops_resources",
    "ops_company", "parent", "portal",
]
SITE_LABEL = {"parent": "Xevrion group", "ops": "Xevrion Ops", "portal": "Portal"}
PATH_GROUP = [("/product", "Product"), ("/platform", "Platform"), ("/solutions", "Solutions"), ("/use-cases", "Solutions"),
              ("/integrations", "Integrations"), ("/docs", "Documentation"), ("/guides", "Guides"), ("/legal", "Legal")]


def search_index(sites) -> bytes:
    """Everything findable from the command palette: pages (with their section headings), capabilities, use cases and
    glossary terms, across all three sites. Paths are site-relative; the palette makes cross-site links absolute."""
    from xw.catalog import CAPABILITIES, GLOSSARY, USE_CASES
    from xw.data import SYSTEMS
    items = []
    for sk, site in sites.items():
        for path, p in site.pages.items():
            if p.noindex:
                continue
            heads = [re.sub(r"<[^>]+>", "", h) for h in re.findall(r"<h2[^>]*>(.*?)</h2>", p.body)][:8]
            group = p.group or next((g for prefix, g in PATH_GROUP if path.startswith(prefix)), SITE_LABEL[sk])
            items.append({"k": "page", "s": sk, "u": path, "t": p.title, "d": p.description, "g": group, "h": " · ".join(heads)})
    sysname = {s["key"]: (s["name"], s["href"]) for s in SYSTEMS}
    for key, groups in CAPABILITIES.items():
        for g, caps in groups:
            for n, d in caps:
                items.append({"k": "capability", "s": "ops", "u": sysname[key][1] + "#capabilities", "t": n, "d": d, "g": f"Capability · {sysname[key][0]}"})
    for slug, name, key, problem, _steps, outcome in USE_CASES:
        items.append({"k": "use-case", "s": "ops", "u": f"/use-cases#{slug}", "t": name, "d": problem + " " + outcome, "g": "Use case"})
    for term, d in GLOSSARY:
        items.append({"k": "term", "s": "ops", "u": "/glossary#term-" + term.lower().replace(" ", "-"), "t": term, "d": d, "g": "Glossary"})
    return json.dumps({"origins": ORIGINS, "items": items}, separators=(",", ":"), ensure_ascii=False).encode()
ORIGINS = {"ops": shell.OPS, "parent": shell.PARENT, "portal": shell.PORTAL}


def _group(sk: str, path: str, page) -> str:
    return page.group or next((g for prefix, g in PATH_GROUP if path.startswith(prefix)), SITE_LABEL[sk])


def atlas_data(sites) -> tuple[list[dict], list[tuple[int, int]]]:
    """Pages as nodes (ordered by site, then section) and the links in each page's own content as edges. Navigation
    and footers link everywhere, so they are left out: the map shows how the content itself connects."""
    nodes, index = [], {}
    for sk in ("parent", "ops", "portal"):
        pages = [(path, p) for path, p in sites[sk].pages.items() if not p.noindex and path != "/404"]
        order = list(dict.fromkeys(_group(sk, path, p) for path, p in pages))
        for path, p in sorted(pages, key=lambda x: (order.index(_group(sk, x[0], x[1])), x[0] != "/", x[0])):
            index[(sk, path)] = len(nodes)
            nodes.append({"s": sk, "u": path, "t": p.title, "d": p.description, "g": _group(sk, path, p)})
    by_origin = {o: k for k, o in ORIGINS.items()}
    edges = set()
    for (sk, path), i in index.items():
        for href in re.findall(r'href="([^"]+)"', sites[sk].pages[path].body):
            tsk, target = sk, href
            for origin, key in by_origin.items():
                if href.startswith(origin):
                    tsk, target = key, href[len(origin):] or "/"
                    break
            else:
                if not href.startswith("/") or href.startswith("//"):
                    continue
            j = index.get((tsk, target.split("#")[0].split("?")[0] or "/"))
            if j is not None and j != i:
                edges.add((i, j))
    return nodes, sorted(edges)


def fill_atlas(sites, nodes, edges) -> None:
    """Write the Atlas page's statistics, map and full index from the same data."""
    from xw import webs
    from xw.html import esc
    from xw.pages.parent import ATLAS_INDEX, ATLAS_MAP, ATLAS_STATS
    page = sites["parent"].pages.get("/atlas")
    if not page:
        return
    cross = sum(1 for a, b in edges if nodes[a]["s"] != nodes[b]["s"])
    indeg = defaultdict(int)
    for _, b in edges:
        indeg[b] += 1
    top = max(indeg, key=indeg.get)
    stats = (f'<div class="proof-strip" data-reveal><div><span class="v num">{len(nodes)}</span><span class="l">pages across three sites</span></div>'
             f'<div><span class="v num">{len(edges)}</span><span class="l">links between pages, in their content</span></div>'
             f'<div><span class="v num">{cross}</span><span class="l">links that cross from one Xevrion site to another</span></div>'
             f'<div><span class="v">{esc(nodes[top]["t"])}</span><span class="l">the most linked-to page: {indeg[top]} pages point to it</span></div></div>')
    names = {"parent": ("Xevrion group", "xevrion.co.uk"), "ops": ("Xevrion Ops", "ops.xevrion.co.uk"), "portal": ("Portal", "portal.ops.xevrion.co.uk")}
    blocks = []
    for sk in ("parent", "ops", "portal"):
        mine = [n for n in nodes if n["s"] == sk]
        groups = list(dict.fromkeys(n["g"] for n in mine))
        cols = "".join(
            f'<div class="ai__group"><p class="label">{esc(g)}</p><ul>'
            + "".join(f'<li><a href="{esc(n["u"] if sk == "parent" else ORIGINS[sk] + n["u"])}">{esc(n["t"])}</a><span>{esc(n["u"])}</span></li>' for n in mine if n["g"] == g)
            + "</ul></div>" for g in groups)
        blocks.append(f'<section class="ai__site" data-reveal><header class="ai__head"><span class="label label--violet">{esc(names[sk][1])}</span><h3>{esc(names[sk][0])}</h3>'
                      f'<span class="quiet small">{len(mine)} pages</span></header><div class="ai__groups">{cols}</div></section>')
    atlas_map = webs.web(webs.atlas_web(nodes, edges, ORIGINS), "atlas",
                         "Every page is a point on the ring, grouped by site; every line is a real link in a page's content. Violet lines cross from one Xevrion site to another.",
                         height=820, kind="fact")
    page.body = page.body.replace(ATLAS_STATS, stats).replace(ATLAS_MAP, atlas_map).replace(ATLAS_INDEX, f'<div class="atlas-index">{"".join(blocks)}</div>')


# ------------------------------------------------------------------------------------------------ assets
def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:10]


def minify_css(css: str) -> str:
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    css = re.sub(r"\s+", " ", css)
    # spaces around ":" are kept: ".a :hover" and ".a:hover" mean different things
    css = re.sub(r"\s*([{};,>])\s*", r"\1", css)
    return css.replace(";}", "}").strip()


def build_assets() -> dict[str, str]:
    assets: dict[str, str] = {}
    out = DIST / "shared"
    # CSS: one file, tokens first
    css = "\n".join((SRC / "css" / n).read_text("utf-8") for n in ["xevrion.css"] + sorted(p.name for p in (SRC / "css").glob("*.css") if p.name != "xevrion.css"))
    css = minify_css(css).encode()
    name = f"xevrion.{_hash(css)}.css"
    (out / "css").mkdir(parents=True, exist_ok=True)
    (out / "css" / name).write_bytes(css)
    assets["xevrion.css"] = f"/shared/css/{name}"
    # the customer portal's own stylesheet (a copy of the gateway's, see tools/sync_portal.py): loaded only by the
    # /customer-portal presentation, so every other page stays as light as before
    portal_css = SRC / "portal" / "portal.css"
    if portal_css.exists():
        data = minify_css(portal_css.read_text("utf-8")).encode()
        pname = f"portal.{_hash(data)}.css"
        (out / "css" / pname).write_bytes(data)
        assets["portal.css"] = f"/shared/css/{pname}"
    # JS: hash leaves first, rewrite imports to hashed names
    sources = {p.name: p.read_text("utf-8") for p in (SRC / "js").glob("*.js")}
    imp = re.compile(r'''(from\s+|import\(\s*)(["'])\./([\w.-]+\.js)\2''')
    deps = {n: {m.group(3) for m in imp.finditer(s)} for n, s in sources.items()}
    done: dict[str, str] = {}
    (out / "js").mkdir(parents=True, exist_ok=True)
    while len(done) < len(sources):
        ready = [n for n in sources if n not in done and deps[n] <= done.keys()]
        if not ready:
            raise SystemExit(f"circular or missing JS imports: {sorted(set(sources) - set(done))}")
        for n in ready:
            code = imp.sub(lambda m: f'{m.group(1)}{m.group(2)}./{done[m.group(3)]}{m.group(2)}', sources[n]).encode()
            hashed = f"{n[:-3]}.{_hash(code)}.js"
            (out / "js" / hashed).write_bytes(code)
            done[n] = hashed
            assets[n] = f"/shared/js/{hashed}"
    # fonts, brand, og: stable names
    for sub in ("fonts", "brand", "og"):
        src = SRC / sub
        if src.exists():
            shutil.copytree(src, out / sub, dirs_exist_ok=True, ignore=shutil.ignore_patterns("*.range", "*.html"))
    (out / "brand").mkdir(exist_ok=True)
    (out / "brand" / "favicon.svg").write_text(favicon_svg(), "utf-8")
    (out / "brand" / "xevrion-mark.svg").write_text(mark_standalone("m"), "utf-8")
    (out / "brand" / "xevrion-mark-flat.svg").write_text(mark_flat("#0b0c11"), "utf-8")
    return assets


def archive_assets(keep_days: int = 21) -> None:
    """Keep earlier builds' hashed CSS/JS/search files published for a while. Cloudflare may serve a cached page from the
    previous deploy for a few minutes; the files it references must still exist, or that visitor sees an unstyled page."""
    import time
    archive = ROOT / "asset-archive"
    now = time.time()
    for sub, pattern in (("css", "*.css"), ("js", "*.js"), ("", "search.*.json"), ("", "atlas.*.json")):
        src_dir, arch_dir = DIST / "shared" / sub, archive / sub
        arch_dir.mkdir(parents=True, exist_ok=True)
        for f in src_dir.glob(pattern):                      # this build's files join the archive
            if not (arch_dir / f.name).exists():
                shutil.copy2(f, arch_dir / f.name)
        for f in arch_dir.glob(pattern):                     # recent earlier files are republished; old ones expire
            if now - f.stat().st_mtime > keep_days * 86400:
                f.unlink()
            elif not (src_dir / f.name).exists():
                shutil.copy2(f, src_dir / f.name)


# ------------------------------------------------------------------------------------------------ pages
def page_file(site_key: str, path: str) -> Path:
    if path == "/":
        return DIST / site_key / "index.html"
    return DIST / site_key / (path.strip("/") + ".html")


def tidy(doc: str) -> str:
    return re.sub(r"\n\s+", "\n", doc)


def sitemap(site) -> str:
    urls = []
    for p in sorted(site.pages.values(), key=lambda p: (-p.priority, p.path)):
        if p.noindex or p.path == "/404":
            continue
        urls.append(f"<url><loc>{html.escape(site.origin + p.path)}</loc><lastmod>{shell.BUILT.isoformat()}</lastmod><priority>{p.priority:.1f}</priority></url>")
    return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + "".join(urls) + "</urlset>\n"


def robots(site) -> str:
    return f"User-agent: *\nAllow: /\nDisallow: /404\n\nSitemap: {site.origin}/sitemap.xml\n"


def security_txt(site) -> str:
    """RFC 9116: where to report vulnerabilities. Expires one year after each build."""
    expires = shell.BUILT.replace(year=shell.BUILT.year + 1).isoformat()
    return (f"Contact: mailto:{shell.CONTACT_EMAIL}\nExpires: {expires}T00:00:00.000Z\nPreferred-Languages: en\n"
            f"Policy: {shell.OPS}/legal/responsible-disclosure\nCanonical: {site.origin}/.well-known/security.txt\n")


# ------------------------------------------------------------------------------------------------ checks
BANNED = [
    (re.compile(r"\b\d{2}-\d{2}-\d{2}\b"), "looks like a bank sort code"),
    (re.compile(r"(?i)(account (number|no)\.?|acct)\W{0,5}\d{6,10}"), "looks like a bank account number"),
    (re.compile(r"(?i)lorem ipsum|\bTODO\b|add copy here|placeholder text|\bTBD\b"), "placeholder text"),
    (re.compile(r"henrydavenhall", re.I), "personal email address"),
    # Xevrion sells self-serve and in writing: no demo booking, no sales calls
    (re.compile(r"(?i)book(ing)? (a|your|my|the) (demo|call|meeting)|book-demo|(schedule|arrange) a (demo|call|meeting)|\d+-minute (call|demo)"), "demo/call booking language"),
]


# The API's rule for analytics event names (platform_gateway/web_analytics.py, EVENT). A name that fails it is dropped
# without an error, so every name the pages and scripts send is checked here. Keep the two in step.
EVENT = re.compile(r"[a-z0-9_]{2,24}(:[A-Za-z0-9 _./#?=&%:+@-]{0,72})?")
TRACK_CALL = re.compile(r"""\b(?:track|xevTrack)(?:\?\.)?\(\s*(["'`])((?:(?!\1).)*)\1""")


def check_events(rendered: dict[tuple[str, str], str], rep: "Report") -> None:
    for (sk, path), doc in rendered.items():
        for name in {html.unescape(v)[:80] for v in re.findall(r'data-event="([^"]+)"', doc)}:   # the script sends 80 characters
            if not EVENT.fullmatch(name):
                rep.err(f"{sk}{path}", f"analytics event {name!r} would be dropped by the API (names are [a-z0-9_] before the first ':')")
    for f in sorted((SRC / "js").glob("*.js")):
        if f.name == "portal-app.js":                        # the gateway's portal, copied: it does not measure the website
            continue
        for m in TRACK_CALL.finditer(f.read_text("utf-8")):
            name = m.group(2)
            base, sep, rest = name.split("${", 1)[0].partition(":")   # only the literal part of a template is known
            if not sep and "${" in name:                               # e.g. `scroll_${m}`: the base itself continues
                ok = re.fullmatch(r"[a-z0-9_]{0,24}", base)
            else:
                ok = re.fullmatch(r"[a-z0-9_]{2,24}", base) and re.fullmatch(r"[A-Za-z0-9 _./#?=&%:+@-]*", rest)
            if not ok:
                rep.err(f"src/js/{f.name}", f"analytics event {name!r} would be dropped by the API")


class Report:
    def __init__(self):
        self.problems: list[str] = []
        self.warnings: list[str] = []

    def err(self, where: str, msg: str):
        self.problems.append(f"{where}: {msg}")

    def warn(self, where: str, msg: str):
        self.warnings.append(f"{where}: {msg}")


def check(sites, rendered: dict[tuple[str, str], str], rep: Report) -> None:
    known = {k: set(s.pages) for k, s in sites.items()}
    redirects = {k: set(v) for k, v in REDIRECTS.items()}
    redirects["portal"] |= set(PORTAL_APP)
    by_origin = {o: k for k, o in ORIGINS.items()}
    titles, descs = defaultdict(list), defaultdict(list)
    for (sk, path), doc in rendered.items():
        where = f"{sk}{path}"
        page = sites[sk].pages[path]
        titles[(sk, page.title)].append(path)
        descs[(sk, page.description)].append(path)
        if not 50 <= len(page.description) <= 175:
            rep.warn(where, f"meta description is {len(page.description)} characters (aim for 50-175)")
        main = doc.split('<main id="main"', 1)[1].split("</main>", 1)[0]
        text = re.sub(r"<script.*?</script>", " ", doc, flags=re.S)
        visible = re.sub(r"<[^>]+>", " ", text)
        for rx, why in BANNED:
            m = rx.search(visible)
            if m:
                rep.err(where, f"{why}: {m.group(0)!r}")
        if "book-demo" in doc or "cta_demo" in doc:
            rep.err(where, "links to the removed demo booking")
        h1 = re.findall(r"<h1[\s>]", main)
        if len(h1) != 1:
            rep.err(where, f"{len(h1)} h1 elements (need exactly 1)")
        levels = [int(x) for x in re.findall(r"<h([1-6])[\s>]", main)]
        for a, b in zip(levels, levels[1:]):
            if b > a + 1:
                rep.warn(where, f"heading level jumps from h{a} to h{b}")
                break
        ids = re.findall(r'\sid="([^"]+)"', doc)
        dup = {i for i in ids if ids.count(i) > 1}
        if dup:
            rep.err(where, f"duplicate ids: {sorted(dup)[:6]}")
        for ref in re.findall(r'aria-(?:labelledby|controls|describedby)="([^"]+)"', doc):
            for r in ref.split():
                if r not in ids:
                    rep.err(where, f"aria reference to missing id {r!r}")
        for img in re.findall(r"<img\b[^>]*>", doc):
            if " alt=" not in img:
                rep.err(where, "img without alt")
        for href in re.findall(r'href="([^"]+)"', main + doc.split("</main>", 1)[1]):
            target_site, target = sk, href
            for origin, key in by_origin.items():
                if href.startswith(origin):
                    target_site, target = key, href[len(origin):] or "/"
                    break
            else:
                if not href.startswith("/") or href.startswith("//") or href.startswith("/shared/"):
                    continue
            target = target.split("#")[0].split("?")[0] or "/"
            if target.startswith("/shared/"):
                continue
            if target not in known[target_site] and target not in redirects[target_site] and target not in ("/sitemap.xml", "/robots.txt"):
                rep.err(where, f"broken link {href}")
    for sk, rmap in REDIRECTS.items():                      # a redirect must never shadow a real page
        for path in rmap:
            if path in known[sk]:
                rep.err(f"{sk}{path}", "a redirect shadows this page; remove the redirect")
    for (sk, t), paths in titles.items():
        if len(paths) > 1:
            rep.err(sk, f"title used by {len(paths)} pages: {t!r} {paths}")
    for (sk, d), paths in descs.items():
        if len(paths) > 1:
            rep.warn(sk, f"description shared by {paths}")


# ------------------------------------------------------------------------------------------------ worker
def write_worker(sites) -> None:
    tpl = (ROOT / "worker" / "worker.js").read_text("utf-8")
    maps = {k: v for k, v in REDIRECTS.items()}
    code = tpl.replace("/*@REDIRECTS@*/{}", json.dumps(maps, indent=1)).replace("/*@PORTAL_APP@*/{}", json.dumps(PORTAL_APP, indent=1))
    if "@REDIRECTS@" in code or "@PORTAL_APP@" in code:
        raise SystemExit("worker template placeholders not replaced")
    # outside dist/: dist is the asset directory, and the Worker script must not be uploaded as a public asset
    out = ROOT / "worker-dist"
    out.mkdir(exist_ok=True)
    (out / "worker.js").write_text(code, "utf-8")


# ------------------------------------------------------------------------------------------------ main
def main(argv: list[str]) -> int:
    strict = "--strict" in argv
    if DIST.exists():
        shutil.rmtree(DIST)
    DIST.mkdir()
    assets = build_assets()
    sites = make_sites()
    for mod in PAGE_MODULES:
        try:
            m = importlib.import_module(f"xw.pages.{mod}")
        except ModuleNotFoundError as exc:
            if exc.name == f"xw.pages.{mod}":
                print(f"  (skipping {mod}: not written yet)")
                continue
            raise
        m.build(sites[mod.split("_")[0]] if mod.startswith(("ops", "parent", "portal")) else sites["ops"])
    from xw import seo
    seo.apply(sites)                                   # search titles and descriptions (xw/seo.py)
    nodes, edges = atlas_data(sites)
    fill_atlas(sites, nodes, edges)
    at = json.dumps({"origins": ORIGINS, "nodes": nodes, "edges": edges}, separators=(",", ":"), ensure_ascii=False).encode()
    at_name = f"atlas.{_hash(at)}.json"
    (DIST / "shared" / at_name).write_bytes(at)
    assets["atlas.json"] = f"/shared/{at_name}"
    idx = search_index(sites)
    idx_name = f"search.{_hash(idx)}.json"
    (DIST / "shared" / idx_name).write_bytes(idx)
    assets["search.json"] = f"/shared/{idx_name}"
    archive_assets()
    rendered: dict[tuple[str, str], str] = {}
    for sk, site in sites.items():
        for path, page in site.pages.items():
            doc = tidy(shell.render(site, page, assets))
            f = page_file(sk, path)
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(doc, "utf-8")
            rendered[(sk, path)] = doc
        if site.pages:
            (DIST / sk / "sitemap.xml").write_text(sitemap(site), "utf-8")
            (DIST / sk / "robots.txt").write_text(robots(site), "utf-8")
            if (SRC / "brand" / "favicon.ico").exists():    # /favicon.ico at every site's root: search engines ask for it there
                shutil.copy2(SRC / "brand" / "favicon.ico", DIST / sk / "favicon.ico")
            (DIST / sk / ".well-known").mkdir(exist_ok=True)
            (DIST / sk / ".well-known" / "security.txt").write_text(security_txt(site), "utf-8")
    write_worker(sites)
    rep = Report()
    check(sites, rendered, rep)
    check_events(rendered, rep)
    # the presentation must run the portal customers actually get: its copy must match the gateway's
    sync = importlib.import_module("tools.sync_portal")
    if sync.sources_present() and sync.stale():
        rep.err("ops/customer-portal", "the portal copy differs from the gateway's: run python tools/sync_portal.py")
    total = sum(1 for _ in DIST.rglob("*") if _.is_file())
    size = sum(p.stat().st_size for p in DIST.rglob("*") if p.is_file())
    print(f"built {len(rendered)} pages across {sum(1 for s in sites.values() if s.pages)} sites · {total} files · {size / 1024:.0f} KB")
    for w in rep.warnings[:60]:
        print("  warn ", w)
    for e in rep.problems[:120]:
        print("  ERROR", e)
    print(f"{len(rep.problems)} errors, {len(rep.warnings)} warnings")
    return 1 if (strict and rep.problems) else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
