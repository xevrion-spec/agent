// Illustrative data for the customer portal presentation (/customer-portal). A fictional company, generated
// deterministically so every visitor sees the same example; times are relative to now. Shapes match the real API
// (platform-gateway saas.py), so the presentation runs the real portal code unchanged. Nothing is sent anywhere:
// harmless actions update this in-memory example, anything that would move money, send email or delete data is
// declined with an explanation.
const MODS = ["revenue", "customer_operations", "business_operations", "business_intelligence"];
const DAY = 86400000;

function rng(seed) { return () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export function demoApi() {
  const r = rng(20260925), rc = rng(7), now = Date.now();   // rc: cycle reports only, so the rest of the example is unchanged
  const at = (days, hours = 0) => new Date(now - days * DAY - hours * 3600000).toISOString();
  const pick = (a) => a[Math.floor(r() * a.length)];
  const id = (p) => p + "_" + Math.floor(r() * 36 ** 6).toString(36).padStart(6, "0");
  const ORG = "hv-logistics";

  // ---------------------------------------------------------------- service activity, last 30 days
  const programmes = [
    { id: "prg_north", name: "North West operators", market: "Transport and storage", geography: "North West England", status: "active" },
    { id: "prg_build", name: "Construction partners", market: "Construction", geography: "Midlands", status: "paused" },
  ];
  const cases = [];
  const ACTIONS = {
    revenue: [["cycle", 7], ["status", 3], ["ingest_prospects", 2], ["start", 1]],
    customer_operations: [["health", 5], ["support_intake", 4], ["resolve", 5], ["churn", 2], ["customer_360", 3], ["feedback", 1], ["expansion", 1]],
    business_operations: [["work", 4], ["opportunity", 2], ["discover", 2], ["workflow", 2]],
    business_intelligence: [["kpi", 5], ["analyze", 2], ["forecast", 2], ["recommend", 2], ["decision", 1], ["diagnose", 1]],
  };
  const ops = [], openCases = [];
  programmes.forEach((p, i) => ops.push({ id: id("op"), module: "revenue", action: "create_program", status: "completed", completed_at: at(29 - i * 6, 3), receipt: { program: p } }));
  for (let d = 29; d >= 0; d--) {
    MODS.forEach((m) => {
      const n = Math.floor(r() * (m === "customer_operations" ? 4 : 3) + (d < 10 ? 1 : 0));
      for (let k = 0; k < n; k++) {
        const w = ACTIONS[m], total = w.reduce((a, x) => a + x[1], 0); let x = r() * total, action = w[0][0];
        for (const [a, weight] of w) { if ((x -= weight) <= 0) { action = a; break; } }
        const roll = r(), status = roll < 0.9 ? "completed" : roll < 0.97 ? "failed" : "reconciliation_required";
        const receipt = { summary: "Recorded by the " + m.replace(/_/g, " ") + " service", at: at(d, k) };
        if (m === "revenue") receipt.program_id = pick(programmes).id;
        if (action === "cycle") { const found = 14 + Math.floor(rc() * 30), qual = Math.round(found * (0.3 + rc() * 0.16)), sent = Math.round(qual * (0.72 + rc() * 0.2)), replies = Math.round(sent * (0.08 + rc() * 0.1));
          Object.assign(receipt, { prospects_discovered: found, prospects_qualified: qual, prospects_disqualified: Math.round((found - qual) * (0.55 + rc() * 0.3)), sends_attempted: sent, sends_succeeded: sent, replies_processed: replies, meetings_updated: Math.round(replies * (0.25 + rc() * 0.3)), purchases_detected: 0 }); }
        if (action === "support_intake") { const c = { id: id("case"), customer_id: pick(["CUS-1042", "CUS-2210", "CUS-3187", "CUS-0918"]), message: pick(["Invoice query on the last delivery", "Portal access for a new site manager", "Change of delivery address"]) }; cases.push(c); Object.assign(receipt, c); }
        if (action === "health") Object.assign(receipt, { customer_id: pick(["CUS-1042", "CUS-2210", "CUS-3187"]), health_score: Math.round(55 + r() * 40) });
        if (action === "decision") Object.assign(receipt, { decision: pick(["Move Salford drops to the early slot", "Add a second Leeds route", "Renegotiate the fuel card", "Pilot weekend deliveries", "Consolidate Manchester depots"]), evidence: "Recorded with its options and evidence" });
        if (action === "kpi") Object.assign(receipt, { metric: pick(["On-time delivery", "Cost per drop", "Fleet utilisation"]), value: Math.round(70 + r() * 25) });
        ops.push({ id: id("op"), module: m, action, status, completed_at: at(d, 2 + k * 2 + r() * 3), receipt, request_id: id("req") });
      }
    });
  }
  // a healthy support desk: every case is resolved 3 to 20 hours after it arrives, except the two newest (still inside
  // the 24 h target) and one kept overdue, so the response clock shows a realistic mix
  const intakes = ops.filter((x) => x.action === "support_intake" && x.status === "completed").sort((a, b) => a.completed_at.localeCompare(b.completed_at));
  intakes.forEach((c, i) => {
    if (i >= intakes.length - 2 || i === intakes.length - 4 || ops.some((x) => x.action === "resolve" && x.receipt.case_id === c.receipt.id)) return;
    const when = new Date(new Date(c.completed_at).getTime() + (3 + r() * 17) * 3600000);
    if (when.getTime() < now) ops.push({ id: id("op"), module: "customer_operations", action: "resolve", status: "completed", completed_at: when.toISOString(), receipt: { summary: "Recorded by the customer operations service", case_id: c.receipt.id, customer_id: c.receipt.customer_id, resolution: "Resolved and confirmed in writing" }, request_id: id("req") });
  });
  ops.sort((a, b) => a.completed_at.localeCompare(b.completed_at));

  // ---------------------------------------------------------------- value ledger
  const VAL = [
    ["Renewal kept at Northgate Freight", "customer_operations", "verified", 7300, 7300, 620, 0.82, "customer confirmation"],
    ["Approval process automated", "business_operations", "verified", 4800, 4820, 1150, 0.9, "before and after measurement"],
    ["Quote won from a buying signal", "revenue", "verified", 18400, 16200, 900, 0.71, "CRM opportunity source"],
    ["Late-payment chasing", "business_operations", "verified", 3200, 3650, 240, 0.86, "ledger comparison"],
    ["Churn risk caught early at Clearline", "customer_operations", "observed", 5400, 5100, null, 0.64, "health trend"],
    ["Second depot upsell", "revenue", "observed", 9600, 8800, null, 0.58, "CRM opportunity source"],
    ["Fuel cost forecast adopted", "business_intelligence", "verified", 2600, 2900, 180, 0.77, "forecast against actual"],
    ["Route planning review", "business_intelligence", "estimated", 4100, null, null, 0.45, null],
    ["Onboarding time reduced", "customer_operations", "estimated", 2200, null, null, 0.52, "unspecified"],
    ["Supplier invoice matching", "business_operations", "observed", 1900, 2050, null, 0.69, "ledger comparison"],
  ];
  const value_items = VAL.map((v, i) => ({ id: "val_" + (i + 1), version: 3, title: v[0], service: v[1], status: v[2], expected_value: String(v[3]), actual_value: v[4] === null ? null : String(v[4]), costs: v[5] === null ? null : { other: String(v[5]) }, currency: "GBP", confidence: v[6], attribution_method: v[7], created_at: at(28 - i * 2), verified_at: v[2] === "verified" ? at(20 - i * 2) : null }));
  const sumBy = (s) => value_items.filter((x) => x.status === s).reduce((a, x) => a + Number(s === "estimated" ? x.expected_value : x.actual_value), 0);
  const verified = value_items.filter((x) => x.status === "verified"), costed = verified.filter((x) => x.costs);
  const costs = costed.reduce((a, x) => a + Number(x.costs.other), 0);
  const valueSummary = () => ({ items: value_items.length, estimated_value_gbp: String(sumBy("estimated")), observed_value_gbp: String(sumBy("observed")), verified_value_gbp: String(sumBy("verified")),
    by_currency: { GBP: { estimated: String(sumBy("estimated")), observed: String(sumBy("observed")), verified: String(sumBy("verified")), verified_costs: String(costs), net_verified_with_recorded_costs: String(sumBy("verified") - costs), verified_items: verified.length, costed_verified_items: costed.length } },
    verified_items: verified.length, costed_verified_items: costed.length, cost_coverage: verified.length ? costed.length / verified.length : null,
    basis: "Currencies are never combined. Verified means recorded outcome evidence, not proven causation. Net value includes only verified entries with explicitly recorded costs; missing costs are unknown, not zero." });

  // ---------------------------------------------------------------- everything else
  const approvals = [
    { id: "apr_1", module: "revenue", action: "cycle", summary: "Send 38 first messages to North West operators", status: "pending", requested_at: at(0, 3), expires_at: new Date(now + 2 * DAY).toISOString() },
    { id: "apr_2", module: "business_operations", action: "approve_work", summary: "Pay supplier invoice INV-7741 matched to delivery", status: "pending", requested_at: at(0, 7), expires_at: new Date(now + DAY).toISOString() },
  ];
  const EVENTS = ["operations.completed", "operations.completed", "approval.requested", "approval.approved", "support.reply", "billing.payment_succeeded", "integration.verified", "operations.completed"];
  const notifications = Array.from({ length: 26 }, (_, i) => { const e = pick(EVENTS); return { id: "ntf_" + i, event: e, priority: e.startsWith("approval.requested") ? "high" : e.startsWith("billing") ? "normal" : pick(["normal", "normal", "low"]), status: "sent", at: at(i * 0.45, r() * 5) }; }).reverse();
  const members = [["acc_owner", "Sarah Vale", "OWNER", 120], ["acc_admin", "Tom Harbour", "ADMIN", 110], ["acc_ops1", "Priya Shah", "OPERATOR", 90], ["acc_ops2", "Dan Okafor", "OPERATOR", 60], ["acc_appr", "Grace Lin", "APPROVER", 58], ["acc_fin", "Mark Ellis", "BILLING", 40], ["acc_ana", "Zoe Clarke", "ANALYST", 21]]
    .map(([a, n, role, d]) => ({ id: a, account_id: a, display_name: n, role, status: "active", joined_at: at(d) }));
  const invitations = [{ id: "inv_1", email: "operations.lead@hv-logistics.example", role: "OPERATOR", status: "pending", expires_at: new Date(now + 5 * DAY).toISOString() }];
  const integrations = [
    { key: "gmail", status: "connected", health: "healthy", last_sync_at: at(0, 0.4) },
    { key: "hubspot", status: "connected", health: "healthy", last_sync_at: at(0, 1.2) },
    { key: "xero", status: "connected", health: "healthy", last_sync_at: at(0, 2.5) },
    { key: "slack", status: "authorised", health: "pending_verification", last_sync_at: null },
    { key: "zendesk", status: "connected", health: "healthy", last_sync_at: at(0, 5) },
  ];
  const CATALOG = [["gmail", "Gmail", "email"], ["microsoft", "Microsoft 365", "email"], ["hubspot", "HubSpot", "crm"], ["salesforce", "Salesforce", "crm"], ["xero", "Xero", "accounting"], ["quickbooks", "QuickBooks Online", "accounting"],
    ["slack", "Slack", "messaging"], ["zendesk", "Zendesk", "support"], ["intercom", "Intercom", "support"], ["notion", "Notion", "knowledge"], ["segment", "Segment", "analytics"], ["website", "Website", "web"]]
    .map(([key, name, category]) => ({ key, name, category, connects_with: key === "segment" ? "api_key" : "sign_in", permissions: ["read"], options: [], available: !["salesforce", "notion"].includes(key), own_app: key === "microsoft", supports_own_app: ["microsoft", "salesforce", "slack", "zendesk", "intercom", "notion", "xero", "quickbooks"].includes(key) }));
  const support = [
    { id: "sup_1", subject: "Xero connection shows pending", message: "Our Xero connection has said pending for two days. Is there anything we need to do on our side?", priority: "normal", status: "resolved", created_by: "acc_admin", created_at: at(6), response_due_hours: 24,
      messages: [{ id: "m1", by: "operator", message: "Thanks, Tom. Xero asks the organisation's adviser to approve new apps; we have sent the steps to your inbox. Once approved, verify access from Connections.", at: at(5.8) }, { id: "m2", by: "acc_admin", message: "Approved on our side now, thank you.", at: at(5.1) }],
      history: [{ at: at(5.9), by: "operator", status: "in_progress", note: "Checking the provider's approval state" }, { at: at(5), by: "operator", status: "resolved", note: "Connection verified with the provider" }] },
    { id: "sup_2", subject: "Add a second approver for supplier payments", message: "We would like both Grace and Sarah to be able to approve supplier payments over £5,000.", priority: "high", status: "in_progress", created_by: "acc_owner", created_at: at(1.2), response_due_hours: 4,
      messages: [{ id: "m3", by: "operator", message: "Understood. The approval policy can require a named approver per amount band. We are preparing the change and will confirm before it takes effect.", at: at(1.1) }], history: [{ at: at(1.15), by: "operator", status: "in_progress", note: "Drafting the policy change" }] },
    { id: "sup_3", subject: "Weekly value report format", message: "Could the weekly value summary show each depot separately?", priority: "low", status: "open", created_by: "acc_fin", created_at: at(0, 5), response_due_hours: 24, messages: [], history: [] },
  ];
  const sessions = [{ id: "ses_1", created_at: at(0, 0.3), expires_at: new Date(now + 11.7 * 3600000).toISOString(), revoked: false }, { id: "ses_2", created_at: at(1, 4), expires_at: new Date(now + 3600000).toISOString(), revoked: false }, { id: "ses_3", created_at: at(4), expires_at: at(3.5), revoked: true, revoked_at: at(3.6) }];
  const invoices = [0, 1, 2].map((i) => ({ id: "inv_" + (i + 1), reference: "XEV-HV-" + (1043 - i), kind: "subscription", amount_pence: 500000, currency: "GBP", status: "paid", period_end: new Date(now + (30 - i * 30) * DAY).toISOString(), plan: { plan: "SCALE" }, commercial_document: { number: "XEV-" + (2026091 - i * 31) } }));
  const processes = [
    { id: "proc_1", name: "Supplier invoice approval", department: "finance", description: "Match, approve and pay supplier invoices", version: 3, active: true, required_fields: ["supplier", "amount", "invoice_number"],
      steps: [{ name: "Validate invoice", type: "validate", required_fields: ["supplier", "amount"] }, { name: "Match to delivery", type: "decision", rules: [] }, { name: "Approval over £5,000", type: "approval", approval_reason: "Amount above threshold" }, { name: "Record in Xero", type: "action", connector: "xero", operation: "create_bill" }, { name: "Notify finance", type: "notify", connector: "slack" }, { name: "Close run", type: "close" }] },
    { id: "proc_2", name: "New customer onboarding", department: "operations", description: "From signed order to first delivery", version: 2, active: true, required_fields: ["customer", "first_delivery_date"],
      steps: [{ name: "Validate order", type: "validate" }, { name: "Create account", type: "action", connector: "hubspot", operation: "create_company" }, { name: "Welcome email", type: "notify", connector: "gmail" }, { name: "Record completion", type: "record" }, { name: "Close run", type: "close" }] },
  ];
  const WORK = ["completed", "completed", "completed", "completed", "awaiting_approval", "in_progress", "in_progress", "exception"];
  const work = WORK.map((s, i) => ({ id: "run_" + (201 + i), process_id: i % 3 ? "proc_1" : "proc_2", process_version: i % 3 ? 3 : 2, status: s, current_step: s === "completed" ? "Close run" : s === "awaiting_approval" ? "Approval over £5,000" : "Match to delivery", approval_required: s === "awaiting_approval", approval_status: s === "awaiting_approval" ? "pending" : null, missing_fields: s === "exception" ? ["invoice_number"] : [], result: { steps_completed: s === "completed" ? 6 : 2 }, decision: null }));
  const exceptions = [{ id: "exc_1", work_item_id: "run_208", kind: "missing_data", status: "open", reason: "The invoice number is missing from the supplier email", details: { supplier: "Pennine Fuel Ltd", amount: "2,140.00" } }, { id: "exc_2", work_item_id: "run_199", kind: "provider_timeout", status: "resolved", reason: "Xero took too long to respond; retried successfully", details: {} }];
  const usageRows = Array.from({ length: 50 }, (_, i) => ({ id: "use_" + i, service: pick(MODS), metric: pick(["workflow_executions", "agent_actions", "ai_tokens"]), quantity: 1 + Math.floor(r() * 40), source: "runtime", at: at(i * 0.5) }));
  const done = ops.filter((x) => x.status === "completed");
  const sub = { id: ORG, plan: "SCALE", status: "active", modules: MODS.slice(), billing_cycle: "monthly", paid_through: new Date(now + 26 * DAY).toISOString(), entitlements: { modules: 4, team: 50, integrations: 50, workflows: 50000, ai_tokens: 100000000, ai_calls_per_day: 3000, decision_scenarios: true, priority_onboarding: true } };
  const onboarding = { status: "ready", completed_steps: ["approvals", "automation", "business", "goals", "integrations", "metrics", "permissions", "services"], data: { business: { legal_name: "Harbour & Vale Logistics Ltd", industry: "Transport and storage" }, goals: { primary_outcome: "Keep every customer through renewal" }, metrics: { primary_metric: "Net revenue retention" }, integrations: { selected: ["gmail", "hubspot", "xero"] }, permissions: { confirmed: true }, services: { modules: MODS }, automation: { schedule: "Weekdays 08:00–18:00" }, approvals: { policy: "Every outbound message and any payment over £5,000" } } };
  const health = () => ({ score: 82, drivers: { subscription_active: true, onboarding_progress: 1, healthy_integrations: integrations.filter((x) => x.health === "healthy").length, workflow_success_rate: done.length / ops.length, recorded_value_items: value_items.length, actual_service_usage: usageRows.reduce((a, x) => a + x.quantity, 0), open_support: support.filter((x) => !["resolved", "confirmed", "closed"].includes(x.status)).length, verified_value_items: verified.length, notification_events: notifications.length }, churn_risk: "low", expansion_potential: "not_ready", calibration: "operational health indicator; not a calibrated probability" });
  const usageTotals = () => { const totals = {}, by = {}; usageRows.forEach((u) => { totals[u.metric] = (totals[u.metric] || 0) + u.quantity; (by[u.service] = by[u.service] || {})[u.metric] = ((by[u.service] || {})[u.metric] || 0) + u.quantity; }); totals.ai_tokens = (totals.ai_tokens || 0) * 1850; return { totals, by_service: by, reconciliation_pending: 0, basis: "Totals include only recorded measured quantities. Missing nested provider/token evidence remains unknown, not zero." }; };
  const pairs = [["dec_1", 4200, 3900, "business_intelligence"], ["dec_2", 2600, 2900, "business_intelligence"], ["dec_3", 9000, 8800, "revenue"], ["dec_4", 5000, 5400, "customer_operations"], ["dec_5", 1800, 2050, "business_operations"]].map(([d, e, a, s]) => ({ decision_id: d, expected: String(e), actual: String(a), error: String(a - e), abs_error: String(Math.abs(a - e)), service: s, attribution_method: "forecast against actual" }));
  const optimization = () => ({ generated_at: new Date(now).toISOString(), learning_calibration: { pairs: pairs.length, mean_absolute_error: String(pairs.reduce((a, p) => a + Number(p.abs_error), 0) / pairs.length), bias: String(pairs.reduce((a, p) => a + Number(p.error), 0) / pairs.length), items: pairs },
    attribution_quality: { by_method: value_items.reduce((m, x) => ((m[x.attribution_method || "unspecified"] = (m[x.attribution_method || "unspecified"] || 0) + 1), m), {}), verified_items: verified.length, costed_verified_items: costed.length, cost_coverage: costed.length / verified.length, unspecified_share: value_items.filter((x) => !x.attribution_method || x.attribution_method === "unspecified").length / value_items.length, basis: "Attribution methods are labels from recorded evidence. Unspecified share should fall as operators complete outcomes." },
    contribution: { plan: "SCALE", active_modules: MODS, verified_value_summary: valueSummary(), usage_totals: usageTotals().totals, net_verified_available: true, basis: "Contribution uses only verified ledger entries with recorded costs. Platform subscription price and live provider invoices are external; this endpoint does not invent COGS or ROI." },
    cross_service: { entitled_modules: MODS, modules_with_completed_work: MODS, unused_entitled: [], cross_service: true, completion_counts: MODS.reduce((m, k) => ((m[k] = done.filter((x) => x.module === k).length), m), {}), basis: "Adoption counts completed operation receipts, not logins. Expansion suggestions require unused entitled modules plus separate value evidence." },
    health: { score: 85, priority_band: "healthy", drivers: [{ driver: "subscription", state: "active", effect: "+25" }, { driver: "onboarding", state: "8_steps", effect: "+15" }, { driver: "integrations", state: "4_verified", effect: "+15" }, { driver: "workflows", state: "high_success", effect: "+20" }, { driver: "value", state: "verified_outcomes", effect: "+10" }, { driver: "support", state: "one_open", effect: "+0" }] },
    complete_erasure_claim: false, causal_roi_claim: false });

  const dashboard = () => ({ organization: { id: ORG, name: "Harbour & Vale Logistics", status: "active" }, subscription: sub, usage: usageRows, value_items, operation_results: ops.slice(-100), pending_approvals: approvals.filter((a) => a.status === "pending"), notifications: notifications.slice(-50), onboarding });
  const refuse = (what) => { throw Error("This is a presentation with illustrative data, so " + what + " is not sent anywhere. In your own portal it works exactly as shown."); };

  // ---------------------------------------------------------------- the API
  return async function api(path, options = {}) {
    await new Promise((res) => setTimeout(res, 90 + Math.random() * 120));
    const method = (options.method || "GET").toUpperCase(), body = options.body ? JSON.parse(options.body) : {};
    const p = path.replace("/v1/customer/saas/" + ORG, "/O").split("?")[0], q = new URLSearchParams(path.split("?")[1] || "");
    if (method === "GET") {
      if (path === "/v1/customer/saas/organizations") return { items: [{ id: ORG, name: "Harbour & Vale Logistics", role: "OWNER" }] };
      if (path === "/v1/customer/saas/sessions") return { items: sessions };
      const GET = { "/O/capabilities": () => ({ role: "OWNER", permissions: ["*"] }), "/O/dashboard": dashboard, "/O/health": health, "/O/ai-usage": () => ({ day: new Date(now).toISOString().slice(0, 10), used: 184, allowance: 3000, remaining: 2816, resets_at: new Date(Math.ceil(now / DAY) * DAY).toISOString() }),
        "/O/value-summary": valueSummary, "/O/integrations/health": () => ({ items: integrations, healthy: false }), "/O/integrations/catalog": () => ({ allowance: 50, connected: integrations.filter((x) => x.status !== "disconnected").length, items: CATALOG }),
        "/O/support": () => ({ items: support }), "/O/notifications": () => ({ items: notifications }), "/O/notification-preferences": () => ({ email: true, in_app: true, minimum_priority: "normal" }),
        "/O/product-analytics": () => ({ events: { "organization.created": 1, "subscription.checkout_created": 1, "billing.webhook": 3, "onboarding.updated": 8, "integration.verified": 4, "services.activated": 1, "operations.executed": done.length, "subscription.cancelled": 0 }, activation_rate: 1, module_adoption: 4, time_to_first_value_seconds: 9 * 86400 + 5 * 3600, time_to_first_value_available: true, basis: "Organisation creation to first currently verified ledger outcome with an explicit verification timestamp; execution alone is not customer value." }),
        "/O/optimization": optimization, "/O/usage-metering": usageTotals, "/O/analytics": () => ({ usage_totals: usageTotals().totals, audit_events: 1284, integrations: integrations.length, active_modules: MODS }),
        "/O/team": () => ({ members, invitations }), "/O/invoices": () => ({ items: invoices, provider: "monzo", standing_order_control: "payer" }),
        "/O/retention-policy": () => ({ financial_years: 6, operational_recovery_days: 30, backup_max_days: 35, approved: true, backup_erasure_verified: false, complete_erasure_claim: false }),
        "/O/privacy-inventory": () => ({ account_data: ["name", "email", "role"], operational_records: ["operation receipts", "approvals", "support conversations"], financial_records: ["invoices", "payments"], connection_references: ["opaque credential references"], tombstones: [] }) };
      if (GET[p]) return GET[p]();
      if (p === "/O/operations") { const m = q.get("module"), s = q.get("status"); return { items: ops.filter((x) => (!m || x.module === m) && (!s || x.status === s)).slice(-Number(q.get("limit") || 50)), filters: { module: m, status: s } }; }
      if (p.startsWith("/O/operations/")) { const x = ops.find((o) => o.id === decodeURIComponent(p.slice(14))); if (!x) throw Error("operation receipt unavailable"); return x; }
      if (p.startsWith("/O/business-workspace/")) return { items: { processes, work, exceptions }[p.slice(22)] || [] };
      if (p.startsWith("/O/integrations/") && p.endsWith("/own-app")) return { key: p.split("/")[3], configured: false, required_options: p.includes("microsoft") ? ["tenant"] : [], redirect_uri: "https://api.xevrion.co.uk/v1/public/saas/integrations/callback", steps: ["Open your provider's developer settings and create an app.", "Add the redirect URI shown below.", "Copy the client ID and secret into this form."] };
      throw Error("Not part of this presentation");
    }
    // ---------------------------------------------------------------- actions the example can show safely
    let m;
    if ((m = /^\/O\/operations\/(\w+)\/authorize$/.exec(p))) {
      const row = { id: id("op"), module: m[1], action: body.action, status: "completed", completed_at: new Date().toISOString(), receipt: { summary: "Illustrative receipt: in your portal this holds the service's real result", request: body.payload } };
      if (body.action === "create_program") { const pr = { id: id("prg"), status: "draft", ...(body.payload.program || {}) }; programmes.push(pr); row.receipt = { program: pr }; }
      if (body.action === "support_intake") { const c = { id: id("case"), customer_id: body.payload.customer_id, message: body.payload.message }; row.receipt = c; }
      ops.push(row); return row;
    }
    if ((m = /^\/O\/approvals\/(\w+)$/.exec(p))) { const a = approvals.find((x) => x.id === m[1]); if (a) { a.status = body.approved ? "approved" : "rejected"; notifications.push({ id: id("ntf"), event: "approval." + a.status, priority: "normal", status: "sent", at: new Date().toISOString() }); } return a; }
    if (p === "/O/support" && method === "POST") { const s = { id: id("sup"), subject: body.subject, message: body.message, priority: body.priority || "normal", status: "open", created_by: "acc_owner", created_at: new Date().toISOString(), response_due_hours: ["high", "urgent"].includes(body.priority) ? 4 : 24, messages: [], history: [] }; support.unshift(s); return s; }
    if ((m = /^\/O\/support\/(\w+)\/messages$/.exec(p))) { const s = support.find((x) => x.id === m[1]); s.messages.push({ id: id("m"), by: "acc_owner", message: body.message, at: new Date().toISOString() }); return s; }
    if ((m = /^\/O\/support\/(\w+)$/.exec(p))) { const s = support.find((x) => x.id === m[1]); s.status = body.status; (s.history = s.history || []).push({ at: new Date().toISOString(), by: "acc_owner", status: body.status, note: body.note }); return s; }
    if (p === "/O/notification-preferences") return body;
    if (p === "/O/integrations/begin") return { provider: body.key, authorization_url: "#", status: "awaiting_authorization" };
    if ((m = /^\/O\/integrations\/(\w+)\/verify$/.exec(p))) { const x = integrations.find((i) => i.key === m[1]); if (x) Object.assign(x, { status: "connected", health: "healthy", last_sync_at: new Date().toISOString() }); return x; }
    if (p === "/O/value-ledger") { const v = { id: id("val"), version: 1, status: "estimated", title: body.title, service: body.service, expected_value: String(body.expected_value || 0), actual_value: null, costs: null, currency: body.currency || "GBP", confidence: Number(body.confidence) || 0.5, attribution_method: body.attribution_method, created_at: new Date().toISOString() }; value_items.push(v); return v; }
    if (p === "/O/team/invitations") { invitations.push({ id: id("inv"), email: body.email, role: body.role, status: "pending", expires_at: new Date(now + 7 * DAY).toISOString() }); return { invite_id: "demo", expires_in_days: 7 }; }
    if (p.endsWith("/resend")) return { resent: true };
    if (p === "/O/onboarding") return onboarding;
    if (p === "/v1/customer/saas/logout") return { logged_out: true };
    if (/cancel|offboarding|deletion|transfer-ownership|subscription/.test(p) || method === "DELETE") refuse("a change to billing, ownership or your data");
    if (/credential|own-app|mfa|password|sessions/.test(p)) refuse("a credential");
    refuse("this action");
  };
}
