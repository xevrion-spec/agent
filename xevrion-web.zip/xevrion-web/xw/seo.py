"""Search titles and descriptions, one per page, each built around the search a buyer would type for that page.

Titles stay under about 60 characters (Google truncates longer ones) with the keyword first and the brand last;
descriptions stay between 120 and 158 characters and answer the search in plain British English. The page's own
title (menus, breadcrumbs, site search) is unchanged: these only replace the <title> tag and the meta description.

Target keywords by page (UK business buyers):
  home           AI business operations platform, AI operations software UK, business automation for SMEs
  revenue        AI sales prospecting, lead prioritisation, B2B sales automation UK
  customer ops   customer retention software, churn prediction, customer health score
  business ops   business process automation software UK, workflow automation, process mining
  decision int.  decision intelligence software, business forecasting, scenario planning
  value ledger   automation ROI, measure AI ROI
  pricing        AI automation pricing UK
  integrations   Gmail / HubSpot / Xero / Salesforce ... automation integration
Refine these from the Search Console queries once it has a few weeks of data.
"""
from __future__ import annotations

SEO: dict[str, dict[str, tuple[str, str]]] = {
    "ops": {
        "/": ("AI Business Operations Platform for UK SMEs | Xevrion Ops",
              "Xevrion Ops connects your tools, finds revenue and risk, automates routine work with your approval and proves every result in pounds. From £2,500 a month."),
        "/platform": ("AI Operations Platform: How It Fits Together | Xevrion Ops",
                      "One AI operations platform for sales, customers, operations and decisions, built on the tools you already use, with people in control of every action."),
        "/how-it-works": ("How AI Business Automation Works, Step by Step | Xevrion",
                          "How Xevrion turns your business data into measured results: connect, understand, find what matters, act with approval, verify and value every outcome."),
        "/product/revenue": ("AI Sales Prospecting & Lead Prioritisation | Xevrion Ops",
                             "AI sales prospecting for UK businesses: find companies that fit, spot real buying signals, rank leads by expected value and send approved outreach."),
        "/product/customer-operations": ("Customer Retention & Churn Risk Software | Xevrion Ops",
                                         "Customer retention software that joins every ticket, email and invoice, explains customer health scores and flags churn risk weeks before renewal."),
        "/product/business-operations": ("Business Process Automation Software UK | Xevrion Ops",
                                         "Business process automation that measures every step, finds the bottleneck costing you most and automates it, with approvals kept and savings proven."),
        "/product/decision-intelligence": ("Decision Intelligence & Forecasting Software | Xevrion",
                                           "Decision intelligence software for UK businesses: trusted KPIs, forecasts and scenario planning with honest ranges, and every decision recorded."),
        "/product/value-ledger": ("Measure Automation ROI in Pounds | Xevrion Value Ledger",
                                  "See the real ROI of automation and AI: every result recorded in pounds with its evidence, method and confidence, and compared with what Xevrion costs."),
        "/product/learning-and-memory": ("AI That Learns From Your Business Results | Xevrion Ops",
                                         "Xevrion remembers what happened in your business, scores every forecast and recommendation against reality and adjusts, within fixed limits."),
        "/solutions": ("AI Solutions for Growth, Efficiency and Retention | Xevrion",
                       "Four outcomes Xevrion Ops delivers for UK businesses: revenue growth, operational efficiency, customer retention and better decisions, measured in pounds."),
        "/solutions/revenue-growth": ("Grow Revenue Without Hiring More Salespeople | Xevrion",
                                      "Grow B2B revenue without growing the sales team: focus on the prospects most likely to buy, reply while the signal is fresh and see what actually worked."),
        "/solutions/operational-efficiency": ("Improve Operational Efficiency & Cut Admin | Xevrion Ops",
                                              "Improve operational efficiency: measure where your team's time goes, automate the worst step with approvals kept, and prove the saving against your baseline."),
        "/solutions/customer-retention": ("Reduce Customer Churn Before Renewal | Xevrion Ops",
                                          "Reduce customer churn: an explained health score for every customer, risk flagged weeks before renewal, and each save approved, carried out and measured."),
        "/solutions/decision-quality": ("Data-Driven Decision Making for UK SMEs | Xevrion Ops",
                                        "Make data-driven decisions with KPIs you can trust, forecasts and scenarios with honest ranges, and a record of every decision scored against results."),
        "/use-cases": ("14 AI Automation Use Cases for UK Businesses | Xevrion",
                       "Fourteen AI automation use cases, step by step: quote follow-up, renewal risk, support triage, invoice matching, purchase approvals, reporting and more."),
        "/pricing": ("Pricing: AI Operations Platform from £2,500/month | Xevrion",
                     "Published pricing for Xevrion Ops: Start £2,500, Growth £5,000 and Scale £10,000 a month. Every limit shown, no overage charges, prices exclude VAT."),
        "/get-started": ("Get Started With Xevrion Ops: No Sales Call Needed",
                         "Start using Xevrion Ops today: choose a plan, create your workspace, pay the setup fee and complete onboarding in your portal. No sales call needed."),
        "/demo": ("Product Tour: See Xevrion Ops in Action, No Sign-up",
                  "Take a guided, no-sign-up tour of Xevrion Ops and watch AI sales prospecting, customer retention, process automation and forecasting work step by step."),
        "/customer-portal": ("Try the Xevrion Ops Customer Portal (Live Demo)",
                             "Explore the real Xevrion Ops customer portal running on an example company: what needs you, each service, every action and the value it records."),
        "/integrations": ("Integrations: Gmail, HubSpot, Xero & Salesforce | Xevrion",
                          "Connect Xevrion Ops to Gmail, Microsoft 365, HubSpot, Salesforce, Slack, Zendesk, Intercom, Xero, QuickBooks, Notion and your website, with your own accounts."),
        "/integrations/other-email": ("IMAP/SMTP Email Integration for AI Automation | Xevrion",
                                      "Connect any IMAP/SMTP mailbox to Xevrion Ops with your own account: read-only or read and send, with every send approved and logged."),
        "/platform/capabilities": ("102 AI Business Automation Capabilities | Xevrion Ops",
                                   "Every Xevrion Ops capability across sales, customer operations, business operations and decision intelligence, searchable and in plain English."),
        "/platform/architecture": ("Platform Architecture and Infrastructure | Xevrion Ops",
                                   "How Xevrion Ops is built: Cloudflare edge and an encrypted tunnel, a gateway that checks every request, and services with their own databases."),
        "/security": ("Security for AI Business Automation | Xevrion Ops",
                      "How Xevrion Ops protects your business: tenant isolation, two-factor sign-in, sealed credentials, no open ports, human approvals and a full audit trail."),
        "/ai": ("Human-in-the-Loop AI: How Xevrion Uses AI | Xevrion Ops",
                "How Xevrion Ops uses AI responsibly: which model runs where, what data it sees, the path every task follows and the approvals that keep people in control."),
        "/customers": ("Customer Results and Our Evidence Standard | Xevrion Ops",
                       "How Xevrion proves results: the ten-part evidence standard every customer result must meet before it is published, and how your own value is measured."),
        "/faq": ("Xevrion Ops FAQ: Pricing, Security, AI and Setup",
                 "Answers about Xevrion Ops: what it does, pricing and payment, security, AI, integrations, onboarding and cancellation, in plain English."),
        "/glossary": ("AI Operations Glossary: Every Term Explained | Xevrion Ops",
                      "Plain-English definitions of the terms used in AI business automation: approvals, attribution, calibration, expected value, idempotency and more."),
        "/guides": ("Guides to AI Business Automation for SMEs | Xevrion Ops",
                    "Plain-English guides to getting value from AI business automation: choosing your first system, preparing your tools, approval rules and reading results."),
        "/about": ("About Xevrion Ops: UK AI Business Operations Software",
                   "Xevrion Ops is UK-built AI business operations software that has to prove it is worth paying for: published prices, human control and measured value."),
        "/contact": ("Contact Xevrion Ops: Written Replies, No Sales Calls",
                     "Ask Xevrion Ops a question in writing and get a precise written reply with a reference number. No sales calls, no meetings, no pressure."),
        "/help": ("Help Centre | Xevrion Ops",
                  "Get help with Xevrion Ops: signing in, your team, connections, billing and your data, with the quickest route to an answer for each."),
        "/status": ("System Status | Xevrion Ops",
                    "Live status of the Xevrion Ops platform, checked from your browser, with the latest release and how incidents are reported."),
        "/updates": ("Product Updates | Xevrion Ops",
                     "What changed in Xevrion Ops and when: new connectors, bring-your-own-app connections, payment matching, reliability and the new websites."),
    },
    "parent": {
        "/": ("Xevrion: UK Technology Group Building Focused Ventures",
              "Xevrion is a UK technology group building focused ventures on one shared foundation. Xevrion Ops, the AI business operations platform, is live."),
        "/ventures": ("Xevrion Ventures: Ops (Live) and Cyber (Planned)",
                      "The Xevrion family of ventures: Xevrion Ops, the AI business operations platform, is live; Xevrion Cyber, security for growing businesses, is planned."),
        "/ventures/ops": ("Xevrion Ops: AI Business Operations Platform | Xevrion",
                          "Xevrion Ops, the live Xevrion venture: an AI business operations platform for sales, customer operations, process automation and decisions."),
        "/ventures/cyber": ("Xevrion Cyber: Cyber Security for Growing UK Businesses",
                            "Xevrion Cyber is a planned venture: cyber security for growing UK businesses, with plain-English evidence and measurable risk reduction. Register interest."),
        "/about": ("About Xevrion: A UK Group of Focused Technology Ventures",
                   "About Xevrion, the UK group behind Xevrion Ops and the planned Xevrion Cyber, and the principles every venture works by."),
        "/approach": ("Our Approach: Transparent by Design | Xevrion",
                      "How Xevrion builds ventures transparently: published prices, a no-sign-up tour, a public capability index, readable security and auditable value."),
        "/foundation": ("The Xevrion Foundation: What Every Venture Is Built On",
                        "The shared foundation every Xevrion venture inherits: infrastructure, identity and security, AI governance, reliability, measurement and brand."),
    },
}


def apply(sites) -> None:
    """Give each listed page its search title and description (the page's own title stays for menus and search)."""
    for key, pages in SEO.items():
        site = sites[key]
        for path, (title, description) in pages.items():
            page = site.pages.get(path)
            if page is None:
                raise KeyError(f"seo.py lists {key}{path}, which is not a page")
            page.seo_title, page.description = title, description
    for site in sites.values():                      # integrations: "<Tool> Integration for AI Automation"
        for path, page in site.pages.items():
            if site.key == "ops" and path.startswith("/integrations/") and not page.seo_title:
                page.seo_title = f"{page.title.replace(' integration', '')} Integration for AI Automation | Xevrion Ops"
