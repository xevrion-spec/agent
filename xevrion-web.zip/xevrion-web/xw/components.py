"""Reusable page pieces. Components carry information; none of them is a decorative box.

Claim labels follow the spec's four classes and are never visually blurred:
  illustrative  - an example built to explain the product (never presented as a result)
  capability    - what the product does, verifiable in the product
  fact          - a verified company fact (published prices, what is implemented)
  result        - a verified customer result (none are published yet)
"""
from __future__ import annotations

import json
from typing import Iterable, Sequence

from .html import attrs, esc, icon

CLAIMS = {"illustrative": "Illustrative example", "capability": "Product capability", "fact": "Verified company fact",
          "result": "Customer result", "stat": "Published statistic"}


def claim(kind: str, text: str | None = None) -> str:
    return f'<span class="claim claim--{kind}">{esc(text or CLAIMS[kind])}</span>'


def button(label: str, href: str, kind: str = "primary", *, event: str | None = None, small: bool = False, icon_name: str | None = None,
           extra: dict | None = None) -> str:
    cls = f"btn btn--{kind}" + (" btn--small" if small else "")
    ico = icon(icon_name, 18) if icon_name else ""
    data = {"data-event": event} if event else {}
    return f'<a class="{cls}" href="{esc(href)}"{attrs({**data, **(extra or {})})}>{esc(label)}{ico}</a>'


def primary_ctas(start_label: str = "Get started", see_label: str = "See Xevrion in action", *, where: str = "page",
                 base: str = "") -> str:
    """The site-wide CTA pair: self-serve start (primary) and the no-sign-up guided tour (secondary).
    Xevrion sells without calls or meetings, so there is deliberately no 'book a demo' anywhere."""
    return (f'<div class="hero__cta">{button(start_label, base + "/get-started", "primary", event=f"cta_start:{where}")}'
            f'{button(see_label, base + "/demo", "secondary", event=f"cta_tour:{where}", icon_name="play")}</div>')


def arrow_link(label: str, href: str, event: str | None = None) -> str:
    data = f' data-event="{esc(event)}"' if event else ""
    return f'<a class="arrow-link" href="{esc(href)}"{data}>{esc(label)}{icon("arrow", 18)}</a>'


def eyebrow(text: str) -> str:
    return f'<p class="eyebrow">{esc(text)}</p>'


def section_head(eyebrow_text: str | None, title: str, lead: str | None = None, *, level: int = 2, centered: bool = False,
                 id_: str | None = None, title_html: bool = False) -> str:
    cls = "section-head" + (" centered" if centered else "")
    t = title if title_html else esc(title)
    return (f'<header class="{cls}" data-reveal>{eyebrow(eyebrow_text) if eyebrow_text else ""}'
            f'<h{level}{attrs({"id": id_})}>{t}</h{level}>{f"<p class=lead>{esc(lead)}</p>" if lead else ""}</header>')


def metric(value: str, label: str, note: str | None = None, *, kind: str = "", small: bool = False, count: str | None = None) -> str:
    """count: a numeric target the value animates to once, when first revealed (the text is already final without JS)."""
    data = f' data-count="{esc(count)}"' if count else ""
    return (f'<div class="metric{" metric--" + kind if kind else ""}">'
            f'<span class="metric__value{" metric__value--s" if small else ""} num"{data}>{esc(value)}</span>'
            f'<span class="metric__label">{esc(label)}</span>{f"<span class=metric__note>{esc(note)}</span>" if note else ""}</div>')


def explain(body: str, title: str = "What Xevrion is doing") -> str:
    return (f'<div class="explain"><span class="explain__icon">{icon("spark", 16)}</span>'
            f'<div><p class="explain__title">{esc(title)}</p><p class="explain__body">{esc(body)}</p></div></div>')


def answer_block(question: str, answer: str) -> str:
    """A direct, factual answer near its heading: for people scanning and for search and AI answer engines."""
    return f'<div class="answer-block" data-reveal><span class="label">{esc(question)}</span><p>{esc(answer)}</p></div>'


def crumbs(items: Sequence[tuple[str, str | None]]) -> str:
    lis = []
    for label, href in items:
        lis.append(f'<li><a href="{esc(href)}">{esc(label)}</a></li>' if href else f'<li aria-current="page">{esc(label)}</li>')
    return f'<nav aria-label="Breadcrumb"><ol class="crumbs">{"".join(lis)}</ol></nav>'


def faq(items: Sequence[tuple[str, str]], *, open_first: bool = False) -> str:
    out = []
    for i, (q, a) in enumerate(items):
        paras = "".join(f"<p>{esc(p)}</p>" for p in a.split("\n\n"))
        out.append(f'<details{" open" if open_first and i == 0 else ""}><summary>{esc(q)}</summary><div class="answer">{paras}</div></details>')
    return f'<div class="faq">{"".join(out)}</div>'


def faq_schema(items: Sequence[tuple[str, str]]) -> dict:
    return {"@context": "https://schema.org", "@type": "FAQPage",
            "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a.replace("\n\n", " ")}} for q, a in items]}


def flow(steps: Sequence[dict], *, id_: str, label: str) -> str:
    """A continuous path of stages. Each step: name, what, inputs, output, control. Selecting a stage updates the detail
    panel; without JS every stage's detail is still present in the document (the panels simply stack)."""
    tabs, panels = [], []
    for i, s in enumerate(steps):
        sel = "true" if i == 0 else "false"
        tabs.append(f'<button class="flow__step" role="tab" id="{id_}-t{i}" aria-controls="{id_}-p{i}" aria-selected="{sel}" tabindex="{0 if i == 0 else -1}">'
                    f'<span class="flow__num">{i + 1:02d}</span><span class="flow__name">{esc(s["name"])}</span></button>')
        rows = "".join(f"<dt>{esc(k)}</dt><dd>{esc(s[key])}</dd>" for k, key in (("Input", "inputs"), ("Xevrion", "system"), ("Output", "output"), ("You control", "control")) if s.get(key))
        panels.append(f'<div class="flow-detail" role="tabpanel" id="{id_}-p{i}" aria-labelledby="{id_}-t{i}"{"" if i == 0 else " data-flow-hidden"}>'
                      f'<div><h3 class="h3">{esc(s["title"])}</h3><p class="lead" style="margin-top:16px">{esc(s["what"])}</p></div><dl>{rows}</dl></div>')
    return (f'<div class="flow-block" data-flow><div class="flow" role="tablist" aria-label="{esc(label)}">{"".join(tabs)}</div>'
            f'{"".join(panels)}</div>')


def walkthrough(steps: Sequence[dict], start: tuple[str, str] | None = None, finish: tuple[str, str] | None = None, *, label: str) -> str:
    """Steps joined by arrows: optionally what you bring (start) and what you get (finish), and for each step who does
    it (Xevrion, or you approving or deciding) and what it produces. Reads left to right on wide screens and top to
    bottom on narrow ones; the arrows are drawn in CSS and carry a slow light along them."""
    def end(kind: str, tag: str, body: tuple[str, str]) -> str:
        return (f'<li class="stf__node stf__node--end stf__node--{kind}"><span class="stf__tag">{icon("approval" if kind == "finish" else "arrow", 14)}{esc(tag)}</span>'
                f'<b>{esc(body[0])}</b><span class="stf__sub">{esc(body[1])}</span></li>')
    nodes = [end("start", "Start", start)] if start else []
    for i, s in enumerate(steps):
        who = s.get("who", "x")
        role = s.get("role") or ("Xevrion" if who == "x" else "You approve")
        out = f'<p class="stf__out"><span>Result</span>{esc(s["out"])}</p>' if s.get("out") else ""
        nodes.append(f'<li class="stf__node" data-who="{who}" style="--i:{i + 1}"><span class="stf__head"><span class="stf__num">{i + 1:02d}</span>'
                     f'<span class="stf__who">{icon("spark" if who == "x" else "check", 13)}{esc(role)}</span></span>'
                     f'<h3>{esc(s["title"])}</h3><p>{esc(s["what"])}</p>{out}</li>')
    if finish:
        nodes.append(end("finish", "Finish", finish))
    return (f'<div class="stf" data-reveal><ol class="stf__track" aria-label="{esc(label)}">{"".join(nodes)}</ol>'
            f'<p class="stf__key"><span data-who="x">Xevrion does this step</span><span data-who="you">You approve or decide</span>'
            f'<span class="stf__note">Nothing leaves your business without the approvals you set.</span></p></div>')


def table(headers: Sequence[str], rows: Iterable[Sequence[str]], *, caption: str | None = None, first_col_header: bool = True, html_cells: bool = False) -> str:
    head = "".join(f'<th scope="col">{esc(h)}</th>' for h in headers)
    body = []
    for row in rows:
        cells = []
        for i, cell in enumerate(row):
            content = cell if html_cells else esc(cell)
            cells.append(f'<th scope="row">{content}</th>' if i == 0 and first_col_header else f"<td>{content}</td>")
        body.append(f"<tr>{''.join(cells)}</tr>")
    cap = f"<caption>{esc(caption)}</caption>" if caption else ""
    return f'<div class="table-wrap"><table class="table">{cap}<thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def index_list(items: Sequence[tuple[str, str, str]], *, event_prefix: str = "") -> str:
    """Numbered editorial links: (title, description, href)."""
    out = []
    for i, (title, desc, href) in enumerate(items, 1):
        ev = f' data-event="{esc(event_prefix)}{esc(href)}"' if event_prefix else ""
        out.append(f'<a href="{esc(href)}"{ev}><span class="num">{i:02d}</span><span><strong>{esc(title)}</strong><span class="desc">{esc(desc)}</span></span>{icon("arrow", 20)}</a>')
    return f'<nav class="index-list">{"".join(out)}</nav>'


def caps(items: Sequence[tuple[str, str, str]]) -> str:
    """Capability matrix: (label, title, text). Hairline-ruled typography, not floating cards."""
    return '<div class="cap-grid">' + "".join(
        f'<div class="cap" data-reveal><span class="label">{esc(l)}</span><h3>{esc(t)}</h3><p>{esc(x)}</p></div>' for l, t, x in items) + "</div>"


def ledger_list(items: Sequence[tuple[str, str, str]]) -> str:
    """Editorial rows: (heading, explanation, aside)."""
    return '<ul class="ledger-list">' + "".join(
        f'<li data-reveal><h3>{esc(h)}</h3><p>{esc(p)}</p><span class="label">{esc(a)}</span></li>' for h, p, a in items) + "</ul>"


def cta_final(title: str, lead: str, *, where: str, base: str = "") -> str:
    return (f'<section class="cta-final" aria-labelledby="cta-{esc(where)}"><div class="wrap">'
            f'<h2 id="cta-{esc(where)}" data-reveal>{esc(title)}</h2><p class="lead" data-reveal>{esc(lead)}</p>'
            f'{primary_ctas(where=where, base=base)}<p class="hero__note" style="justify-content:center">'
            f'<span>{icon("check", 16)} No sales calls</span><span>{icon("pricing", 16)} Every price published</span>'
            f'<span>{icon("lock", 16)} Your tools, your permissions</span></p></div></section>')


def brief_form(*, source: str, service: str = "") -> str:
    """A written enquiry, handled by the Xevrion backend (POST /v1/public/briefs). Field names, lengths and the
    service values match the backend model exactly; it rejects anything else. Replies come in writing, never a call.
    The site script sends it as JSON. method="post" means that, without the script, nothing typed can ever end up in
    the address bar, history or request logs; the note above the form gives the email address instead."""
    services = [("Revenue", "Revenue"), ("Customer Operations", "Customer Operations"), ("Business Operations", "Business Operations"),
                ("Business Intelligence", "Decision Intelligence"), ("Not sure yet", "Not sure yet")]
    opts = '<option value="">Choose one</option>' + "".join(
        f'<option value="{esc(v)}"{" selected" if v == service else ""}>{esc(label)}</option>' for v, label in services)
    return f'''<noscript><p class="quiet small" style="margin-bottom:var(--s-4)">This form needs JavaScript. Email <a class="link" href="mailto:outreach@ops.xevrion.co.uk">outreach@ops.xevrion.co.uk</a> instead and we will reply in writing.</p></noscript>
<form class="form" data-brief-form data-source="{esc(source)}" method="post" novalidate>
  <div class="form__row">
    <div class="field"><label for="bf-name">Full name</label><input class="input" id="bf-name" name="name" autocomplete="name" required minlength="2" maxlength="120"><p class="error">Please enter your name.</p></div>
    <div class="field"><label for="bf-email">Work email</label><input class="input" id="bf-email" name="email" type="email" inputmode="email" autocomplete="email" required maxlength="254"><p class="error">Please enter a valid work email.</p></div>
  </div>
  <div class="form__row">
    <div class="field"><label for="bf-company">Company</label><input class="input" id="bf-company" name="company" autocomplete="organization" required minlength="2" maxlength="200"><p class="error">Please enter your company name.</p></div>
    <div class="field"><label for="bf-service">System you are interested in</label><select class="select" id="bf-service" name="service" required>{opts}</select><p class="error">Please choose one, or “Not sure yet”.</p></div>
  </div>
  <div class="field"><label for="bf-brief">What do you want to improve?</label><textarea class="input textarea" id="bf-brief" name="brief" rows="5" required minlength="20" maxlength="6000" aria-describedby="bf-brief-hint"></textarea><p class="hint" id="bf-brief-hint">A few sentences is plenty: the problem, the tools you use and roughly how big it is.</p><p class="error">Please write at least 20 characters.</p></div>
  <div class="field"><label for="bf-outcome">What would a good result look like? <span class="quiet">(optional)</span></label><input class="input" id="bf-outcome" name="outcome" maxlength="2000"></div>
  <div class="hp" aria-hidden="true"><label for="bf-website">Leave this empty</label><input id="bf-website" name="website" tabindex="-1" autocomplete="off"></div>
  <label class="check"><input type="checkbox" name="consent" required><span>I agree Xevrion may store this enquiry and reply to me by email, as described in the <a class="link" href="/legal/privacy">privacy notice</a>.</span></label>
  <p class="error" data-consent-error hidden style="color:#ff8f9a;font-size:13.5px">Please confirm we may store your enquiry and reply.</p>
  <button class="btn btn--primary" type="submit" data-event="form_submit:{esc(source)}" style="--h:52px">Send enquiry</button>
  <div class="form__status" role="status" aria-live="polite" tabindex="-1" hidden></div>
</form>'''


def json_ld(data: dict | list) -> str:
    return f'<script type="application/ld+json">{json.dumps(data, separators=(",", ":"), ensure_ascii=False)}</script>'
