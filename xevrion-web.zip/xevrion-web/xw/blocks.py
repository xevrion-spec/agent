"""Content blocks built from data.py, reused across pages so every page tells the same, consistent story."""
from __future__ import annotations

import json

from . import data as D
from .components import claim
from .html import esc, icon
from .shell import APP


def conf(level: str) -> str:
    return f'<span class="conf conf--{level.lower()}"><i aria-hidden="true"><b></b><b></b><b></b></i>{esc(level)} confidence</span>'


def ledger(lines: list[dict] | None = None, *, open_first: bool = True, show_totals: bool = True) -> str:
    lines = lines or D.LEDGER
    rows = []
    for i, x in enumerate(lines):
        excluded = x["confidence"] == "Low"
        chain = "".join(f'<div><span class="label">{esc(k)}</span><p>{esc(v)}</p></div>' for k, v in (
            ("Xevrion action", x["action"]), ("Business outcome", x["outcome"]), ("Economic effect", f'£{x["value"]:,} · {x["method"]}'),
            ("Attribution", x["attribution"]), ("Evidence", x["source"])))
        rows.append(f'<details{" open" if open_first and i == 0 else ""}{" data-excluded" if excluded else ""}>'
                    f'<summary><span><span class="l-sys">{esc(x["system"])}</span><span class="l-action">{esc(x["action"])}</span></span>'
                    f'<span class="l-cat">{esc(x["category"])}</span><span class="l-conf">{conf(x["confidence"])}</span>'
                    f'<span class="l-val num">£{x["value"]:,}</span></summary><div class="chain">{chain}</div></details>')
    totals = ""
    if show_totals:
        excluded = sum(x["value"] for x in lines if x["confidence"] == "Low")
        counted = sum(x["value"] for x in lines if x["confidence"] != "Low")
        roi = counted / D.LEDGER_COST
        totals = (f'<div class="ledger-total" data-reveal>'
                  f'<div><span class="label">Counted value this month</span><span class="v v--value num">£{counted:,}</span><span class="n">High and medium confidence only</span></div>'
                  f'<div><span class="label">Shown, not counted</span><span class="v num" style="color:var(--text-3)">£{excluded:,}</span><span class="n">Low confidence: attribution unclear</span></div>'
                  f'<div><span class="label">Xevrion cost</span><span class="v num">£{D.LEDGER_COST:,}</span><span class="n">Growth plan, per month</span></div>'
                  f'<div><span class="label">Measured return</span><span class="v v--roi num">{roi:.1f}×</span><span class="n">Counted value ÷ cost</span></div></div>')
    return f'<div class="ledger">{"".join(rows)}</div>{totals}'


def price_row() -> str:
    cells = []
    for p in D.PLANS:
        if p["monthly"]:
            price = f'£{p["monthly"]:,}<small> /month</small>'
            setup = f'£{p["setup"]:,} one-time setup'
        else:
            price = "Tailored"
            setup = "Scoped to your organisation"
        sys = "All four systems" if p["modules"] == 4 else ("One system" if p["modules"] == 1 else "Two systems")
        cells.append(f'<a href="/pricing#{p["key"]}" class="{"featured" if p.get("featured") else ""}" data-event="pricing_preview:{p["key"]}">'
                     f'<span class="nm">{esc(p["name"])}</span><span class="pr num">{price}</span><span class="su">{setup}</span>'
                     f'<span class="ds">{sys} · up to {p["team"]:,} people · {p["integrations"]:,} connected tools</span></a>')
    return f'<div class="price-row">{"".join(cells)}</div>'


LADDER = [
    ("Assist", "Summarises, drafts and explains. Changes nothing.", "Always on"),
    ("Recommend", "Suggests an action with its expected value and confidence.", "You decide"),
    ("Act with approval", "Carries out an action only after a named person approves it.", "Approver required"),
    ("Act within policy", "Handles routine, low-risk work inside limits you set, and logs every action.", "Your limits"),
]


def ladder() -> str:
    items = "".join(f'<li style="--lv:{i}"><span class="lv">L{i}</span><span><strong>{esc(t)}</strong><span>{esc(d)}</span></span><span class="who">{esc(w)}</span></li>'
                    for i, (t, d, w) in enumerate(LADDER))
    return f'<ol class="ladder" aria-label="Levels of AI autonomy, lowest to highest">{items}</ol>'


def facts(keys: list[str] | None = None, *, one_column: bool = False) -> str:
    chosen = [f for f in D.SECURITY if keys is None or f[0] in keys]
    return f'<div class="facts{" facts--one" if one_column else ""}">' + "".join(
        f'<div data-reveal><span class="ic">{icon(ic, 18)}</span><div><h3>{esc(t)}</h3><p>{esc(x)}</p></div></div>' for t, ic, x in chosen) + "</div>"


def story(steps: list[dict], *, panel_title: str, account: str, final: dict) -> str:
    """Scroll story: a sticky state panel (showing `final` without JS) and steps carrying their state."""
    lis = []
    for s in steps:
        state = {k: v for k, v in s["state"].items()}
        kind = s.get("kind", "")
        lis.append(f'<li data-state="{esc(json.dumps(state))}"{f" data-kind={kind}" if kind else ""}>'
                   f'<span class="when">{esc(s["when"])}</span><h3>{esc(s["title"])}</h3><p>{esc(s["text"])}</p>'
                   f'<span class="stage-tag label label--violet">{esc(s["stage"])}</span></li>')
    rows = "".join(f'<div class="row"><span class="k">{esc(k)}</span><span class="v" data-f="{esc(f)}">{esc(final[f])}</span></div>'
                   for k, f in (("Status", "status"), ("Next action", "action"), ("Owner", "owner"), ("Value Ledger", "ledger")))
    tone = final.get("tone", "neutral")
    return f'''<div class="story" data-viz="journey">
  <aside class="story__panel glass glass--elevated glass--edge" data-story-panel data-health="{tone}" aria-label="{esc(panel_title)}">
    <span class="label">{esc(account)}</span>
    <div class="big"><b class="num" data-f="health">{esc(final["health"])}</b><span class="quiet">customer health</span></div>
    <div class="story__meter" aria-hidden="true"><i style="--w:{esc(final["health"])}%"></i></div>
    <div class="rows">{rows}</div>
    <p class="note" style="margin-top:12px">{claim("illustrative")}</p>
  </aside>
  <ol class="story__steps">{"".join(lis)}</ol>
</div>'''


def app_link(plan: str | None = None, *, signup: bool = True) -> str:
    """A link into the Xevrion app. Sign-up links open its Create account tab (#signup) with the chosen plan
    (?plan=start|growth|scale), which the app keeps through sign-up and organisation creation."""
    return f"{APP}{f'?plan={plan}' if plan else ''}{'#signup' if signup else ''}"


def page_hero(crumb_items, eyebrow: str, title: str, lead: str, *, ctas: bool = True, visual: str = "", note: str = "",
              where: str = "page", title_html: bool = False, base: str = "") -> str:
    """Standard page opening: breadcrumbs, one h1, a plain-English lead, the CTA pair and (optionally) the page's visual."""
    from .components import crumbs, primary_ctas
    t = title if title_html else esc(title)
    copy = (f'<div class="hero__copy"><p class="eyebrow">{esc(eyebrow)}</p><h1 class="display" style="margin:var(--s-5) 0">{t}</h1>'
            f'<p class="lead">{esc(lead)}</p>{primary_ctas(where=where, base=base) if ctas else ""}'
            f'{f"<p class=hero__note>{note}</p>" if note else ""}</div>')
    body = f'<div class="duo">{copy}<div class="hero__visual" style="min-height:0">{visual}</div></div>' if visual else copy
    return f'<section class="page-hero"><div class="wrap">{crumbs(crumb_items)}{body}</div></section>'


def stats_block(key: str, heading: str) -> str:
    """Published statistics as context for a problem, each with its source; never presented as Xevrion results."""
    from .components import claim
    items = "".join(f'<div data-reveal><span class="v num">{esc(v)}</span><span class="l">{esc(t)}</span>'
                    f'<a class="src" href="{esc(src[1])}" rel="noopener" target="_blank">{esc(src[0])}{icon("external", 13)}</a></div>'
                    for v, t, src in D.STATS[key])
    return (f'<div class="stats"><div class="stats__head"><p class="label">{esc(heading)}</p>{claim("stat")}</div><div class="proof-strip stats__row">{items}</div>'
            f'<p class="note">Sector-wide figures from UK surveys and regulators. They describe the size of the problem across a sector, not any particular business, and are not Xevrion results.</p></div>')


VIZ_HINTS = {  # what the visitor can do with each interactive visual (shown once it is live)
    "architecture": "Click a check to test it", "trust": "Click a ring to test it", "aipath": "Choose a task · hover a step",
    "memory": "Hover a memory", "constellation": "Hover or click a venture", "atlas": "Point at a page · click to open",
    "core": "Drag to turn the core",
}


def viz_stage(name: str, caption: str, *, height: int = 520, extra: str = "", panel: str = "", side: bool = False,
              kind: str = "illustrative", hint: str | None = None) -> str:
    """Host for a lazy-loaded canvas visual. The canvas box holds only the drawing; anything made of words (readouts,
    controls, legends) sits in a panel beside it (side=True) or below it, so no box ever covers what the canvas draws.
    The caption carries the figure code, the explanation and, for interactive visuals, a short hint."""
    from .components import claim
    hint = VIZ_HINTS.get(name) if hint is None else hint
    tip = f'<span class="viz-hint" data-viz-hint>{esc(hint)}</span>' if hint else ""
    return (f'<figure class="viz" style="margin:0"><div class="stage stage--frame viz__stage{" viz__stage--side" if side else ""}" data-viz="{esc(name)}">'
            f'<div class="viz__canvas" style="height:{height}px">{extra}</div><div class="viz__panel" data-viz-panel>{panel}</div></div>'
            f'<figcaption class="stage__caption"><span class="fig-code">Fig · {esc(name)}</span><span class="stage__text">{esc(caption)}</span>{tip}{claim(kind)}</figcaption></figure>')


def ask() -> str:
    """The public assistant (backend: POST /v1/public/guide on Cloudflare Workers AI). Hidden until JavaScript loads it."""
    return f'''<div class="ask glass glass--intel" data-viz="ask">
  <p class="label label--violet">{icon("spark", 14)} Ask a question</p>
  <p class="ask__intro">Answers come only from Xevrion's published information. The assistant cannot see any account, confirm payments or start work.</p>
  <p class="quiet small" data-ask-nojs>The assistant needs JavaScript. You can <a class="link" href="/contact">send a written question</a> instead.</p>
  <form class="form" hidden novalidate>
    <div class="field"><label for="ask-q">Your question</label><textarea class="input textarea" id="ask-q" name="question" rows="3" minlength="3" maxlength="1200" style="min-height:96px"></textarea></div>
    <label class="check"><input type="checkbox" name="ai_consent"><span>I understand the answer is automated and my question is processed by Xevrion's AI assistant.</span></label>
    <p class="error" data-consent-error hidden style="color:#ff8f9a;font-size:13.5px">Please tick the box to use the assistant.</p>
    <button class="btn btn--secondary" type="submit">Ask</button>
  </form>
  <div class="ask__answer" data-answer aria-live="polite" hidden></div>
</div>'''


def capability_index(system_key: str, *, heading_level: int = 3, only: list[str] | None = None) -> str:
    """Everything a system does, as a readable specification: each group opens with what it is for, then its
    capabilities one per row (reference, name, plain explanation). Complete without JavaScript; viz-capx.js adds a
    filter and group switches. Each item maps to an implemented service endpoint."""
    from .catalog import CAPABILITIES, GROUP_NOTES, capability_code
    groups = [(gi, g, items) for gi, (g, items) in enumerate(CAPABILITIES[system_key], 1) if only is None or g in only]
    total = sum(len(items) for _, _, items in groups)
    widest = max(len(items) for _, _, items in groups)
    blocks, chips = [], []
    for gi, g, items in groups:
        slug = f"cx-{system_key}-{gi}"
        rows = "".join(
            f'<li class="cx__item" data-cx-text="{esc((n + " " + d + " " + g).lower())}"><span class="cx__code">{capability_code(system_key, gi, ii)}</span>'
            f'<span class="cx__name">{esc(n)}</span><span class="cx__desc">{esc(d)}</span></li>'
            for ii, (n, d) in enumerate(items, 1))
        segs = "".join(f'<i{" data-on" if k < len(items) else ""}></i>' for k in range(widest))
        blocks.append(
            f'<section class="cx__group" data-cx-group="{slug}" aria-labelledby="{slug}">'
            f'<header class="cx__head"><span class="cx__idx">{gi:02d}</span><h{heading_level} class="cx__title" id="{slug}">{esc(g)}</h{heading_level}>'
            f'<p class="cx__sum">{esc(GROUP_NOTES.get(g, ""))}</p>'
            f'<span class="cx__n"><span class="cx__segs" aria-hidden="true">{segs}</span>{len(items)} capabilities</span></header>'
            f'<ol class="cx__list">{rows}</ol></section>')
        chips.append(f'<button class="cx__chip" type="button" data-cx-g="{slug}" aria-pressed="false">{esc(g)}<span>{len(items)}</span></button>')
    bar = (f'<div class="cx__bar" data-cx-bar hidden><label class="cx__find">{icon("search", 16)}<span class="sr-only">Filter these capabilities</span>'
           f'<input type="search" data-cx-q placeholder="Filter {total} capabilities" autocomplete="off"></label>'
           f'<div class="cx__chips" role="group" aria-label="Show one group"><button class="cx__chip" type="button" data-cx-g="all" aria-pressed="true">All<span>{total}</span></button>{"".join(chips)}</div>'
           f'<p class="cx__out" aria-live="polite"><b data-cx-count>{total}</b> of {total}</p></div>')
    empty = '<p class="cx__empty" data-cx-empty hidden>Nothing here matches. Try another word, or <a class="link" href="/platform/capabilities">search every capability</a>.</p>'
    return f'<div class="cx" data-viz="capx" data-count-total="{total}">{bar}<div class="cx__groups">{"".join(blocks)}</div>{empty}</div>'


def capability_total(system_key: str) -> int:
    from .catalog import CAPABILITIES
    return sum(len(items) for _, items in CAPABILITIES[system_key])


def related(links: list[tuple[str, str, str]], title: str = "Related") -> str:
    """A short 'where to go next' list: (label, description, href)."""
    items = "".join(f'<a class="rel__item" href="{esc(h)}"><span><strong>{esc(t)}</strong><span>{esc(d)}</span></span>{icon("arrow", 16)}</a>' for t, d, h in links)
    return f'<div class="rel"><p class="label">{esc(title)}</p><div class="rel__grid">{items}</div></div>'


def platform_stack() -> str:
    """The platform as layers, bottom (your tools) to top (value), each with what lives there."""
    layers = [
        ("Value", "value", "Value Ledger", ["Revenue generated", "Revenue protected", "Costs reduced", "Confidence on every line"]),
        ("Control", "approval", "Policies, approvals and audit", ["Approval rules", "Autonomy levels", "Roles and permissions", "Full audit trail"]),
        ("Systems", "spark", "Four systems", ["Revenue", "Customer Operations", "Business Operations", "Decision Intelligence"]),
        ("Understanding", "ledger", "One model of your business", ["Customers", "Deals and orders", "Processes", "Money in and out"]),
        ("Connection", "key", "Sealed, permission-scoped connections", ["Your own accounts", "Read and write separately", "Idempotent writes", "Health checks"]),
        ("Your tools", "integrations", "The systems you already run", ["Email", "CRM", "Support desk", "Accounting", "Chat", "Knowledge"]),
    ]
    rows = []
    for i, (lvl, ic, title, chips) in enumerate(layers):
        chip_html = "".join(f'<span class="chip" style="min-height:30px;font-size:13px">{esc(c)}</span>' for c in chips)
        rows.append(f'<li class="stack__layer" style="--d:{i}" data-reveal><span class="stack__lvl label">{esc(lvl)}</span>'
                    f'<span class="stack__ic">{icon(ic, 18)}</span><span class="stack__body"><strong>{esc(title)}</strong>'
                    f'<span class="chip-list" style="margin-top:10px">{chip_html}</span></span></li>')
    return f'<ol class="stack" aria-label="The Xevrion platform, from your tools at the bottom to measured value at the top">{"".join(rows)}</ol>'
