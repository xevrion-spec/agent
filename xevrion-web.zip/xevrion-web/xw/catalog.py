"""The content catalogue: every capability per system (from each service's real API), use cases, glossary, architecture and the Xevrion ventures.

Capabilities are written in plain English but each maps to an implemented endpoint in services/* or
internal-platform/*; nothing here is aspirational except where a venture is explicitly marked "In development".
"""
from __future__ import annotations

from . import data as D

# ------------------------------------------------------------------------------------------------ capabilities
# system key -> [(group, [(capability, plain explanation)])]
CAPABILITIES: dict[str, list[tuple[str, list[tuple[str, str]]]]] = {
    "revenue": [
        ("Programs", [
            ("Revenue programs", "Set up a program for a market, an offer and a weekly volume, written down before anything starts."),
            ("Start, pause and stop", "Control every program at any moment; pausing stops all outreach immediately."),
            ("Program cycles", "Each cycle finds, qualifies and prepares the next batch of prospects."),
            ("Program export", "Download everything a program has done, for your records."),
        ]),
        ("Finding the right prospects", [
            ("Ideal-customer profile", "Learned from the customers you already win and written in plain English for you to approve."),
            ("Prospect import", "Bring prospects in from your CRM, your website or approved research sources."),
            ("Company research", "Gathers what a company does, its size and its recent activity before anyone contacts it."),
            ("Buying-signal detection", "Spots hiring, expansion, published tenders and direct enquiries that suggest a company needs you now."),
            ("Expected-value ranking", "Ranks every prospect by likely value × chance of converting, with the reasoning shown."),
        ]),
        ("Reaching them well", [
            ("Tailored first messages", "Drafts written in your tone that refer to the signal found, never a generic template."),
            ("Approval before sending", "Every message waits for a person unless you set a policy for a specific low-risk case."),
            ("Follow-ups that never slip", "Timed follow-ups that stop when someone replies."),
            ("Reply handling", "Replies are detected, classified and routed to the right person with the context attached."),
            ("Mailbox connections", "Sends from your own Gmail, Microsoft 365 or other mailbox, with its own limits."),
            ("Deliverability protection", "Tracks bounces and spam complaints against Google's published limits and warns before harm is done."),
        ]),
        ("Measuring what works", [
            ("Funnel with honest ranges", "Every conversion rate comes with its sample size and a confidence interval."),
            ("Bottleneck detection", "Finds the funnel stage that is holding growth back, only when the sample is big enough to say so."),
            ("Sales velocity and payback", "Deal speed, lifetime value against acquisition cost and the months to pay back."),
            ("Revenue attribution", "Traces won revenue to the signal and message that started it, into the Value Ledger."),
        ]),
    ],
    "customer-operations": [
        ("Starting well", [
            ("Purchase handoff", "Sales hands a new customer over with everything promised written down."),
            ("Welcome", "A welcome that sets out the next steps, owners and dates."),
            ("Onboarding questions", "Structured questions that capture how the customer works and what success means."),
            ("Onboarding configuration and review", "Turns the answers into a configuration a person reviews before it is used."),
            ("Implementation plan and go-live", "A dated plan with owners, tracked to a confirmed go-live."),
        ]),
        ("Knowing every customer", [
            ("Identity resolution", "Recognises the same customer across email, CRM, support and billing, even when names differ."),
            ("Identity verification", "Confirms who someone is before sensitive changes are made."),
            ("Account view", "One record per customer with its history, contacts, contracts and changes."),
            ("Communication history", "Every message in one timeline; new messages sent from the same place."),
        ]),
        ("Support", [
            ("Support intake", "Requests from email, website and support tools triaged by urgency and topic."),
            ("Drafted, grounded replies", "Replies drafted from your approved knowledge, for a person to confirm."),
            ("Confirmation and resolution", "Every request is confirmed, resolved and measured against your service levels."),
        ]),
        ("Health and risk", [
            ("Health scores with drivers", "Health built from usage, support, billing and sentiment, always with its reasons."),
            ("Success assessment", "Checks whether each customer is getting the outcome they bought."),
            ("Churn risk assessment", "Flags customers likely to leave, early enough to act."),
            ("Value reports", "Shows each customer, in their terms, what they have gained."),
        ]),
        ("Keeping and growing", [
            ("Renewal preparation", "Renewals prepared weeks ahead with the evidence of value attached."),
            ("Renewal processing", "Renewals recorded and invoiced once agreed."),
            ("Cancellation assessment", "Understands why a customer wants to leave and what might change their mind."),
            ("Expansion detection", "Spots customers ready for more, with evidence, for approval before any offer."),
            ("Expansion attribution", "Records which actions led to growth."),
            ("Win-back", "Identifies former customers worth approaching again and prepares an offer for approval."),
            ("Advocacy", "Checks who is happy enough to be a reference, then asks them politely."),
        ]),
        ("Listening", [
            ("Feedback capture", "Collects feedback from every channel in one place."),
            ("Voice of the customer", "Themes from feedback, ranked by how many customers raise them."),
            ("Optimisation recommendations", "Suggests what to change in service, with its expected effect."),
            ("Service scorecard", "First response and resolution times as percentiles against your targets, first-contact resolution and satisfaction with ranges."),
        ]),
    ],
    "business-operations": [
        ("Understanding the work", [
            ("Process discovery", "Guided sessions and assessment that map how work really moves."),
            ("Process library", "Every process documented with its steps, owners and rules, versioned."),
            ("Industry templates", "Ready-made processes for common industries, installed and then adapted."),
            ("Measurements", "Time, waiting, cost and errors for every step, from real records."),
            ("Opportunity analysis", "Finds the steps where automation or redesign will pay back most."),
        ]),
        ("Doing the work", [
            ("Work items", "Each request becomes a tracked item: understood, approved, executed and audited."),
            ("Email intake and replies", "Requests arriving by email become work items, and replies go out once approved."),
            ("Approvals", "Named approvers for the steps that need judgement, with limits."),
            ("Scheduling", "Schedules work and appointments with the people involved."),
            ("Admin tasks", "Routine administration handled and logged."),
            ("Chasing missing information", "Politely chases what is missing so work does not stall."),
        ]),
        ("Documents and knowledge", [
            ("Document analysis", "Reads documents and pulls out what matters."),
            ("Document comparison", "Spots differences between versions, such as a changed clause or figure."),
            ("Document generation", "Produces documents from templates and data, for review."),
            ("Operational knowledge", "Answers questions from your approved procedures and keeps them up to date."),
        ]),
        ("Finance operations", [
            ("Financial records", "Keeps operational financial records in order."),
            ("Invoice generation", "Creates invoices from completed work, as drafts until approved."),
            ("Payment matching", "Matches payments to invoices by reference and amount."),
            ("Overdue chasing", "Chases overdue invoices politely and on schedule."),
            ("Finance reporting", "Receivables, payables and ageing at a glance."),
        ]),
        ("Buying and suppliers", [
            ("Procurement requests", "Purchase requests with the right approvals for their value."),
            ("Quote requests", "Requests quotes from suppliers and compares them."),
            ("Purchase orders", "Raises purchase orders once approved."),
            ("Vendor records", "One record per supplier with its terms and history."),
        ]),
        ("People and compliance", [
            ("Employee cases", "Joiner, mover and leaver tasks tracked to completion."),
            ("Compliance readiness", "Checks that required evidence and controls are in place."),
            ("Data updates", "Controlled updates to operational data, with an audit trail."),
        ]),
        ("Reliability", [
            ("Exceptions and recovery", "Anything unusual is caught, explained and recovered with a person's help."),
            ("Dead-letter recovery", "Work that failed repeatedly is kept safe and can be requeued after a fix."),
            ("Operations scorecard", "Flow, predictable cycle times, flow efficiency, first-pass yield and payables ageing."),
        ]),
    ],
    "decision-intelligence": [
        ("Data you can trust", [
            ("Data sources and sync", "Connect accounting, CRM and operational sources and keep them in sync."),
            ("File ingestion", "Bring in spreadsheets and exports when there is no connector."),
            ("Source health", "Shows when each source last synced and whether it is healthy."),
            ("Entity matching", "Joins the same customer, product or supplier across sources into one business model."),
            ("Data-quality audit", "Finds gaps, duplicates and inconsistencies, and tracks each one to resolution."),
        ]),
        ("Measures", [
            ("KPI definitions", "Each measure defined once, in words and in its formula."),
            ("Standard KPIs", "A starter set of well-known business measures, ready to use."),
            ("KPI history", "How each measure has moved over time."),
            ("Executive and department dashboards", "The few numbers each audience needs, calculated the same way everywhere."),
            ("Daily, weekly and monthly reports", "Written summaries of what changed and why."),
        ]),
        ("Understanding", [
            ("Diagnostic root cause", "Explains why a number moved, with the drivers and their evidence."),
            ("Anomaly detection", "Flags unusual movements early, using robust statistics that ignore one-off spikes."),
            ("Business health monitoring", "A continuous check on the vital signs of the business."),
            ("Intelligence by area", "Focused analysis of revenue, customers, finance, operations and marketing."),
            ("Questions in plain English", "Ask about your business and get an answer grounded in your data."),
        ]),
        ("Looking ahead", [
            ("Forecasts with ranges", "The forecasting method is chosen by testing it on your own history, and every forecast has a range."),
            ("Scenario simulation", "Thousands of simulated futures show the spread of outcomes and which drivers matter most."),
            ("Opportunity detection", "Finds where value is being left on the table."),
            ("Recommendations", "What to do, with expected benefit, cost and confidence."),
        ]),
        ("Decisions and learning", [
            ("Decision records", "What was decided, by whom and why, kept for review."),
            ("Execution tracking", "Follows each decision through to what was actually done."),
            ("Forecast vs reality", "Every forecast is scored against what happened."),
            ("Recommendation outcomes", "Every recommendation is scored against its real benefit and cost."),
            ("Self-improvement", "Trust in models and confidence in recommendations adjust to their track record."),
            ("Business memory", "A timeline of important events, decisions and lessons, kept per organisation."),
            ("Decision quality", "Calibration scores that show how far forecasts can be trusted."),
        ]),
    ],
}

# What each group of capabilities is for, in one sentence: the reader should know why a group matters before reading
# its items.
GROUP_NOTES: dict[str, str] = {
    "Programs": "Every outreach program is written down before it starts and can be paused at any moment.",
    "Finding the right prospects": "Decide who is worth contacting, and why, before anyone is contacted.",
    "Reaching them well": "Tailored, approved messages from your own mailboxes, with follow-ups that stop when someone replies.",
    "Measuring what works": "Honest funnel numbers with their sample sizes, and won revenue traced back to what started it.",
    "Starting well": "A new customer goes from purchase to a confirmed go-live, with every promise written down.",
    "Knowing every customer": "One recognised record per customer, across every tool they appear in.",
    "Support": "Requests triaged, answered from approved knowledge and measured against your service levels.",
    "Health and risk": "Know which customers are healthy, which are at risk, and why.",
    "Keeping and growing": "Renewals, expansion and win-back, each prepared with evidence and approved by a person.",
    "Listening": "Feedback from every channel turned into ranked themes and measured service quality.",
    "Understanding the work": "Map how work really moves, then find where a change will pay back most.",
    "Doing the work": "Requests become tracked work items that are approved, carried out and audited.",
    "Documents and knowledge": "Read, compare and produce documents, and answer from your approved procedures.",
    "Finance operations": "Invoices, payments and overdue chasing kept in order, as drafts until approved.",
    "Buying and suppliers": "Purchases approved at the right level, quotes compared and suppliers on record.",
    "People and compliance": "Joiner, mover and leaver tasks and compliance evidence, tracked to completion.",
    "Reliability": "Nothing unusual is lost: exceptions are caught, explained and recovered.",
    "Data you can trust": "Connect your sources, join them into one model and fix what is wrong with the data.",
    "Measures": "Each number defined once and calculated the same way everywhere.",
    "Understanding": "Why a number moved, what is unusual, and answers to plain-English questions.",
    "Looking ahead": "Forecasts and scenarios as ranges, and recommendations with their expected benefit.",
    "Decisions and learning": "Decisions recorded and followed through, and every forecast scored against reality.",
}
# Short system codes for capability references, e.g. RV-2.3 = Revenue, group 2, item 3.
SYSTEM_CODES = {"revenue": "RV", "customer-operations": "CO", "business-operations": "BO", "decision-intelligence": "DI"}


def capability_code(system_key: str, group_index: int, item_index: int) -> str:
    return f"{SYSTEM_CODES[system_key]}-{group_index}.{item_index}"


# ------------------------------------------------------------------------------------------------ use cases
USE_CASES = [
    ("quote-follow-up", "Quote follow-up", "revenue", "Quotes go out and nobody follows up in time.",
     ["A quote is sent from your inbox or CRM", "Xevrion tracks it and drafts a follow-up at the right moment", "A person approves it", "Replies stop the sequence automatically", "Won work is traced back to the quote"],
     "More quotes answered, fewer lost to silence"),
    ("tender-follow-up", "Tender and commercial enquiry follow-up", "revenue", "Tenders and enquiries are qualified late or not at all.",
     ["New tenders and enquiries are collected", "Each is scored against your ideal customer and capacity", "Worthwhile ones get a drafted response plan", "Deadlines are tracked", "Outcomes feed the scoring"],
     "Effort focused on the bids you can win"),
    ("inbound-qualification", "Inbound enquiry qualification", "revenue", "Website and email enquiries wait too long for a reply.",
     ["An enquiry arrives by website or email", "Xevrion researches the company and scores it", "A tailored reply is drafted within minutes", "A person approves and sends", "The conversation is tracked to an outcome"],
     "Faster first replies to the enquiries that matter"),
    ("renewal-risk", "Renewal risk", "customer-operations", "Customers leave without much warning.",
     ["Signals are joined per customer", "Health falls and the drivers are shown", "An intervention is recommended with its expected effect", "The owner approves and it is carried out", "The renewal outcome is recorded in the Value Ledger"],
     "Renewals saved while there is still time"),
    ("complaint-intake", "Complaint intake and escalation", "customer-operations", "Complaints lack evidence, status and a clear owner.",
     ["A complaint arrives in any channel", "Identity is checked and the case is created with its evidence", "It is routed and escalated by your rules", "The customer gets clear status updates", "Resolution times are measured"],
     "Complaints handled consistently and on time"),
    ("support-triage", "Support triage and drafted replies", "customer-operations", "Support queues mix the urgent with the routine.",
     ["Requests are triaged by urgency and topic", "Answers are drafted from approved knowledge", "A person confirms each reply", "Resolution is tracked against service levels", "Recurring issues are surfaced"],
     "Quicker, more consistent answers"),
    ("onboarding", "Onboarding and go-live", "customer-operations", "New customers stall between signing and value.",
     ["Sales hands over what was promised", "Onboarding questions capture how the customer works", "A dated implementation plan is agreed", "Progress is tracked with owners", "Go-live is confirmed and value reported"],
     "Shorter time to first value"),
    ("invoice-matching", "Invoice and payment matching", "business-operations", "Matching invoices and payments by hand takes hours.",
     ["Invoices and payments are read from your accounting tool", "Each payment is matched by reference and amount", "Mismatches become exceptions for a person", "Matched items are recorded", "Hours removed are measured"],
     "43 hours a month removed in the example used on this site"),
    ("overdue-chasing", "Overdue invoice chasing", "business-operations", "Late payments are chased inconsistently.",
     ["Overdue invoices are identified", "Polite reminders go out on schedule once approved", "Replies and promises to pay are tracked", "Escalations follow your rules", "Cash collected is recorded"],
     "Cash in sooner, without awkward calls"),
    ("purchase-approvals", "Purchase approvals", "business-operations", "Purchase requests wait days for the right approval.",
     ["A request arrives with its details", "The right approver is chosen by value and category", "Quotes are requested and compared", "Approval is recorded and a purchase order raised", "Cycle time and cost are measured"],
     "£4,820 a month saved in the example used on this site"),
    ("document-collection", "Document collection and completeness", "business-operations", "Work stalls waiting for missing documents.",
     ["Required documents are listed for each case", "Documents are read and checked for completeness", "Missing items are chased politely", "A person reviews exceptions", "An evidence trail is kept"],
     "Fewer stalled cases, a complete audit trail"),
    ("job-margin-reporting", "Job and product margin reporting", "decision-intelligence", "Margins are only known after it is too late to act.",
     ["Costs and revenue are joined per job or product", "Margins are calculated as work progresses", "Anomalies are flagged early", "Drivers of margin change are explained", "A weekly summary goes to the owner"],
     "Margin problems spotted while they can be fixed"),
    ("weekly-reporting", "Weekly and monthly reporting", "decision-intelligence", "Reports take days to assemble and arrive stale.",
     ["Data is synced and quality-checked", "KPIs are computed the same way every time", "What changed and why is written up", "Reports are delivered on schedule", "Questions can be asked in plain English"],
     "Reliable reports without the assembly work"),
    ("scenario-planning", "Forecasts and scenario planning", "decision-intelligence", "Plans rest on single-number forecasts.",
     ["The forecasting method is tested on your history", "A forecast with a range is produced", "Scenarios are simulated side by side", "A decision is recorded with its reasoning", "The forecast is scored against reality"],
     "Decisions made with honest ranges"),
]
USE_CASE = {u[0]: u for u in USE_CASES}

# ------------------------------------------------------------------------------------------------ glossary
GLOSSARY = [
    ("Approval", "A named person agreeing to an action before Xevrion carries it out. Your policies decide which actions need one."),
    ("Attribution", "Working out how much of a result an action caused. Shared attribution means people or other changes also contributed."),
    ("Audit trail", "A permanent record of who did what, when, and what happened next."),
    ("Autonomy level", "How far Xevrion may act on its own for a given task: assist, recommend, act with approval or act within policy."),
    ("Baseline", "Your numbers before a change, usually over the previous 90 days, used to measure what changed."),
    ("Bottleneck", "The step in a process that limits how fast the whole process can go."),
    ("Brier score", "A score for probability forecasts that rewards being right and being honestly uncertain; lower is better."),
    ("Calibration", "Whether stated confidence matches reality: things said to be 70% likely should happen about 70% of the time."),
    ("Confidence interval", "A range that shows how precise a measured rate is, given how much data it is based on."),
    ("Connector", "A connection to one of your tools, made with your own account and permissions."),
    ("Dead letter", "A piece of work that failed repeatedly and was set aside safely so it can be fixed and retried."),
    ("Entity resolution", "Recognising that records in different tools describe the same customer, supplier or product."),
    ("Expected value", "Likely value multiplied by the chance it happens. Used to rank opportunities fairly."),
    ("Forecast range", "The spread of likely outcomes around a forecast. Wider means less certain."),
    ("Health score", "A 0–100 summary of how a customer is doing, always shown with the drivers behind it."),
    ("Idempotency", "A guarantee that repeating the same request, for example after a network error, never applies it twice."),
    ("Ideal-customer profile", "A written description of the customers you win most often and most profitably."),
    ("KPI", "Key performance indicator: one of the few measures that show how the business is doing."),
    ("MAPE", "Mean absolute percentage error: how far forecasts were from reality on average, as a percentage."),
    ("Policy", "A rule you set, such as which actions need approval and what limits apply."),
    ("Scenario", "A possible future you can compare with others, each with its own expected value, range and confidence."),
    ("Tenant isolation", "Each organisation's data kept separate and checked on every request, so no one can see another's."),
    ("Value Ledger", "Xevrion's line-by-line record of value created, in pounds, with evidence and confidence."),
    ("Workflow run", "One run of an automated workflow from start to finish. Plans include a monthly number of runs."),
]

# ------------------------------------------------------------------------------------------------ architecture
ARCHITECTURE = [
    ("Edge", "Cloudflare", [("Websites", "Static pages served from Cloudflare's global network, with strict security headers."),
                            ("Tunnel", "The only way in to the platform: an encrypted tunnel, with no ports open on the server."),
                            ("AI bridge", "A private, token-protected Worker that runs the AI model on Cloudflare Workers AI.")]),
    ("Gateway", "OVHcloud", [("Platform gateway", "Every request enters here: sign-in, organisation and role checks, plans and limits, rate limits and routing."),
                             ("Customer app", "The portal your team uses, served by the gateway with a strict content security policy.")]),
    ("Systems", "OVHcloud", [("Revenue", "Programs, prospects, outreach and revenue measurement."),
                             ("Customer Operations", "Onboarding, support, health, renewals and expansion."),
                             ("Business Operations", "Processes, work items, documents, finance and procurement."),
                             ("Decision Intelligence", "Data, KPIs, forecasts, scenarios, learning and memory.")]),
    ("Shared services", "OVHcloud", [("Governance, security and reliability", "Identity, secrets, approvals, audit, error budgets and recovery."),
                                     ("Integrations and communications", "Connectors, email, webhooks, retries and circuit breakers per customer."),
                                     ("Automation and agent control", "Runs workflows and agents within policy, with hand-offs to people."),
                                     ("Business data and knowledge", "The shared business model, approved knowledge and document retention."),
                                     ("Customer service management", "Portfolio, renewals and value across all customers."),
                                     ("Finance and performance", "Revenue, cost, cash and SaaS metrics."),
                                     ("Quality, analytics and optimisation", "Experiments, control charts and delivery performance."),
                                     ("Executive control", "Objectives, decisions and company health.")]),
    ("Data", "OVHcloud", [("PostgreSQL", "Each service owns its own database, with reviewed, checksummed migrations."),
                          ("Backups", "A full backup and a tagged rollback image before every upgrade.")]),
]

# ------------------------------------------------------------------------------------------------ ventures (the Xevrion group)
VENTURES = [
    {"key": "ops", "name": "Xevrion Ops", "short": "Ops", "status": "Live", "url": "https://ops.xevrion.co.uk/",
     "one": "The business operating platform: connects a company's tools, finds valuable opportunities, helps its team act on them and measures the value in pounds.",
     "facts": [("4", "systems"), ("13", "ways to connect"), ("£2,500", "a month, from")],
     "areas": ["Revenue", "Customer Operations", "Business Operations", "Decision Intelligence"]},
    {"key": "cyber", "name": "Xevrion Cyber", "short": "Cyber", "status": "Planned", "url": None,
     "one": "A cyber security venture for growing businesses, built on the same principles: plain-English evidence, people in control and results you can measure.",
     "facts": [("UK", "focus"), ("Planned", "status"), ("1", "shared foundation with Ops")],
     "areas": ["Security posture", "Identity and access", "Incident readiness", "Measured risk reduction"]},
]
