"""Build-time SVG charts. Static, crisp at any size, readable by screen readers (title + desc), zero JavaScript.

Colour carries meaning here exactly as in the canvas visuals: grey = information, violet = Xevrion acting or
recommending, white = verified value, red = risk. Bars that should grow on reveal carry class "grow".
"""
from __future__ import annotations

import math
from itertools import count

from .html import esc

_ids = count(1)


def _svg(w: int, h: int, title: str, desc: str, body: str, cls: str = "") -> str:
    n = next(_ids)
    return (f'<svg class="chart {cls}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="ct{n} cd{n}" preserveAspectRatio="xMidYMid meet">'
            f'<title id="ct{n}">{esc(title)}</title><desc id="cd{n}">{esc(desc)}</desc>{body}</svg>')


def _t(x, y, text, cls="", anchor="start", extra=""):
    return f'<text x="{x:.1f}" y="{y:.1f}" class="{cls}" text-anchor="{anchor}"{extra}>{esc(text)}</text>'


# ------------------------------------------------------------------------------------------------ funnel as companies
def funnel_dots(stages: list[tuple[str, int, str]]) -> str:
    """Each dot is one company. Rows narrow from everything discovered to the one that became a customer."""
    per_line, gap, r = 24, 11.5, 3.6
    x0, W, y, rows = 222, 560, 8, []
    tones = ["d0", "d1", "d2", "d3", "d4", "d5"]
    for i, (name, n, note) in enumerate(stages):
        lines = math.ceil(n / per_line)
        block = max((lines - 1) * gap + 2 * r, 36)          # the label needs two lines of text
        top = y + (block - (lines - 1) * gap) / 2            # centre the dots in the row
        dots = []
        for k in range(n):
            cx = x0 + (k % per_line) * gap
            cy = top + (k // per_line) * gap
            dots.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r if i < 5 else 5.4}" class="dot {tones[i]}" style="--i:{k % per_line + i * 3}"/>')
        mid = y + block / 2
        word = "company" if n == 1 else "companies"
        rows.append(f'<g class="funnel-row" data-tip="{esc(f"{name}: {n:,} {word} · {note}")}">{_t(0, mid - 4, name, "t-strong")}{_t(0, mid + 15, note, "t-small")}'
                    f'{"".join(dots)}{_t(W, mid + 8, f"{n:,}", "t-num t-big", "end")}</g>')
        y += block + 12
        if i < len(stages) - 1:
            rows.append(f'<line x1="0" x2="{W}" y1="{y - 6:.1f}" y2="{y - 6:.1f}" class="hair"/>')
    desc = "; ".join(f"{name}: {n}" for name, n, _ in stages)
    return _svg(W, int(y), "From 120 discovered companies to 1 customer (illustrative example)", desc, "".join(rows), "chart--funnel")


# ------------------------------------------------------------------------------------------------ customer health
def health_gauge(before: int, after: int, drivers: list[tuple[str, str, str]]) -> str:
    """A ring showing health falling from `before` to `after`, with the drivers that explain it."""
    cx, cy, R = 120, 124, 92
    def arc(v, cls, width):
        a0, a1 = math.radians(135), math.radians(135 + 270 * v / 100)
        x0, y0, x1, y1 = cx + R * math.cos(a0), cy + R * math.sin(a0), cx + R * math.cos(a1), cy + R * math.sin(a1)
        large = 1 if 270 * v / 100 > 180 else 0
        return f'<path d="M{x0:.1f} {y0:.1f} A{R} {R} 0 {large} 1 {x1:.1f} {y1:.1f}" class="{cls}" stroke-width="{width}" fill="none" stroke-linecap="round"/>'
    track = arc(100, "ring-track", 10)
    was = arc(before, "ring-was", 10)
    now = arc(after, "ring-now grow-arc", 10)
    ticks = []
    for v in (0, 25, 50, 75, 100):
        a = math.radians(135 + 270 * v / 100)
        ticks.append(f'<line x1="{cx + (R + 12) * math.cos(a):.1f}" y1="{cy + (R + 12) * math.sin(a):.1f}" x2="{cx + (R + 18) * math.cos(a):.1f}" y2="{cy + (R + 18) * math.sin(a):.1f}" class="hair-strong"/>')
    # the big number, what it was and the caption each get their own line, with clear space between them
    centre = (_t(cx, cy + 4, str(after), "t-num t-huge", "middle") + _t(cx, cy + 36, f"was {before}", "t-small", "middle")
              + _t(cx, cy + 64, "HEALTH SCORE", "t-mono", "middle"))
    rows, y = [], 34
    for label, value, state in drivers:
        shape = {"risk": f'<path d="M262 {y - 9} l5 9 h-10z" class="s-risk"/>', "ok": f'<rect x="258" y="{y - 9}" width="8" height="8" rx="1.5" class="s-ok"/>',
                 "watch": f'<circle cx="262" cy="{y - 5}" r="4" class="s-watch"/>'}[state]
        meaning = {"risk": "pulling health down", "ok": "healthy", "watch": "worth watching"}[state]
        rows.append(f'<g data-tip="{esc(f"{label}: {value} · {meaning}")}"><rect x="252" y="{y - 22}" width="312" height="36" class="hit"/>{shape}{_t(276, y, label, "t-body")}{_t(560, y, value, "t-num t-strong", "end")}'
                    f'<line x1="256" x2="560" y1="{y + 13}" y2="{y + 13}" class="hair"/></g>')
        y += 38
    desc = f"Health fell from {before} to {after}. Drivers: " + "; ".join(f"{l} {v}" for l, v, _ in drivers)
    return _svg(560, max(250, y), f"Customer health {before} to {after}", desc, track + was + now + "".join(ticks) + centre + "".join(rows), "chart--health")


# ------------------------------------------------------------------------------------------------ before / after
def before_after(rows: list[tuple[str, float, float, str]]) -> str:
    """rows: (label, before, after, format) with format 'hrs' | 'pct' | 'gbp'."""
    def fmt(v, f):
        return {"hrs": f"{v:g} hrs", "pct": f"{v:g}%", "gbp": f"£{v:,.0f}"}[f]
    out, y, W = [], 16, 400
    for label, b, a, f in rows:
        wb, wa = W, W * a / b
        change = (a - b) / b * 100
        out.append(f'<g data-tip="{esc(f"{label}: {fmt(b, f)} before, {fmt(a, f)} after ({change:+.0f}%)")}"><rect x="0" y="{y - 4}" width="560" height="66" class="hit"/>'
                   + _t(0, y + 10, label.upper(), "t-mono") + _t(560, y + 10, f"{change:+.0f}%", "t-num t-violet", "end")
                   + f'<rect x="0" y="{y + 22}" width="{wb}" height="14" rx="3" class="bar-before grow"/>' + _t(wb + 10, y + 34, fmt(b, f) + " before", "t-small")
                   + f'<rect x="0" y="{y + 44}" width="{wa:.1f}" height="14" rx="3" class="bar-after grow"/>' + _t(wa + 10, y + 56, fmt(a, f) + " after", "t-strong") + "</g>")
        y += 86
    desc = "; ".join(f"{l}: {fmt(b, f)} before, {fmt(a, f)} after" for l, b, a, f in rows)
    return _svg(560, y - 8, "Before and after automation (illustrative example)", desc, "".join(out), "chart--ba")


# ------------------------------------------------------------------------------------------------ scenario ranges
def scenario_ranges(scenarios: list[dict], *, lo: int = 330000, hi: int = 470000) -> str:
    X0, X1 = 200, 620
    sx = lambda v: X0 + (v - lo) / (hi - lo) * (X1 - X0)
    out, y = [], 40
    grid = []
    for v in range(lo, hi + 1, 20000):
        grid.append(f'<line x1="{sx(v):.1f}" x2="{sx(v):.1f}" y1="22" y2="{40 + 64 * len(scenarios) - 18}" class="hair"/>'
                    + _t(sx(v), 14, f"£{v // 1000}K", "t-small", "middle"))
    base = scenarios[0]["expected"]
    for i, s in enumerate(scenarios):
        conf = s["confidence"].lower()
        tip = f'{s["name"]}: expected £{s["expected"]:,}, range £{s["low"]:,} to £{s["high"]:,} · {s["confidence"]} confidence'
        out.append(f'<g data-tip="{esc(tip)}"><rect x="0" y="{y - 22}" width="680" height="54" class="hit"/>'
                   + _t(0, y + 4, s["name"], "t-strong") + _t(0, y + 22, f'{s["confidence"]} confidence', "t-small")
                   + f'<rect x="{sx(s["low"]):.1f}" y="{y - 7}" width="{sx(s["high"]) - sx(s["low"]):.1f}" height="14" rx="7" class="range range--{conf} grow"/>'
                   + f'<circle cx="{sx(s["expected"]):.1f}" cy="{y}" r="6" class="{"pt-now" if i == 0 else "pt"}"/>'
                   + _t(sx(s["high"]) + 10, y + 5, f'£{s["expected"] // 1000}K', "t-num t-strong") + "</g>")
        y += 64
    now = f'<line x1="{sx(base):.1f}" x2="{sx(base):.1f}" y1="22" y2="{y - 30}" class="now-line"/>'
    desc = "; ".join(f'{s["name"]}: expected £{s["expected"]:,}, range £{s["low"]:,} to £{s["high"]:,}, {s["confidence"]} confidence' for s in scenarios)
    return _svg(680, y - 20, "Next-quarter revenue scenarios with ranges (illustrative example)", desc, "".join(grid) + now + "".join(out), "chart--scen")


# ------------------------------------------------------------------------------------------------ connected business map
def hub(connectors: list[dict], *, w: int = 760, h: int = 520) -> str:
    cx, cy = w / 2, h / 2
    n = len(connectors)
    parts, labels = [], []
    for i, c in enumerate(connectors):
        a = -math.pi / 2 + i * 2 * math.pi / n
        rx, ry = w * 0.4, h * 0.38
        x, y = cx + rx * math.cos(a), cy + ry * math.sin(a)
        writes = bool(c["writes"])
        reads = bool(c["reads"])
        cls = "link-rw" if (writes and reads) else ("link-w" if writes else "link-r")
        mx, my = cx + (x - cx) * 0.5, cy + (y - cy) * 0.5 - 18
        parts.append(f'<path d="M{cx:.1f} {cy:.1f} Q{mx:.1f} {my:.1f} {x:.1f} {y:.1f}" class="{cls}" fill="none" style="--i:{i}"/>')
        tw = max(78, 7.4 * len(c["name"]) + 26)
        anchor_x = x - tw / 2
        labels.append(f'<a href="/integrations/{esc(c["key"])}" class="hub-node" aria-label="{esc(c["name"])}: {esc(c["category"])}">'
                      f'<rect x="{anchor_x:.1f}" y="{y - 17:.1f}" width="{tw:.1f}" height="34" rx="9" class="node-box"/>'
                      f'{_t(x, y - 1, c["name"], "t-node", "middle")}{_t(x, y + 11, c["category"].upper(), "t-mono t-tiny", "middle")}</a>')
    core = (f'<circle cx="{cx}" cy="{cy}" r="74" class="core-halo"/><circle cx="{cx}" cy="{cy}" r="46" class="core-ring"/>'
            f'<circle cx="{cx}" cy="{cy}" r="30" class="core-disc"/>{_t(cx, cy + 4, "XEVRION", "t-mono t-core", "middle")}')
    desc = "Xevrion connects to: " + "; ".join(
        f'{c["name"]} ({"reads and writes" if c["reads"] and c["writes"] else "writes only" if c["writes"] else "reads only"})' for c in connectors)
    return _svg(w, h, "The connected business map", desc, "".join(parts) + core + "".join(labels), "chart--hub")


# ------------------------------------------------------------------------------------------------ the fragmented business
def fragmented() -> str:
    """Where information lives today: tools that do not talk to each other and a decision made without context."""
    tools = [("CRM", 90, 70), ("Inbox", 250, 40), ("Support desk", 420, 78), ("Accounting", 560, 150),
             ("Spreadsheets", 70, 210), ("Team chat", 260, 250), ("Approvals by email", 470, 270)]
    boxes, links = [], []
    for name, x, y in tools:
        w = 8 * len(name) + 30
        boxes.append(f'<g class="frag-tool" style="--i:{len(boxes)}"><rect x="{x - w / 2:.0f}" y="{y - 16}" width="{w:.0f}" height="32" rx="8" class="node-box"/>'
                     f'{_t(x, y + 5, name, "t-node", "middle")}</g>')
    pairs = [(0, 1), (1, 2), (2, 3), (0, 4), (4, 5), (5, 6), (3, 6), (1, 5)]
    for a, b in pairs:
        (_, x1, y1), (_, x2, y2) = tools[a], tools[b]
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        links.append(f'<line x1="{x1}" y1="{y1}" x2="{mx - 8:.0f}" y2="{my - 4:.0f}" class="broken"/><line x1="{mx + 8:.0f}" y1="{my + 4:.0f}" x2="{x2}" y2="{y2}" class="broken"/>'
                     f'<path d="M{mx - 3:.0f} {my - 6:.0f} l6 6 M{mx + 3:.0f} {my - 6:.0f} l-6 6" class="gap-x"/>')
    decision = (f'<g class="frag-decision"><circle cx="330" cy="160" r="30" class="decision-disc"/>{_t(330, 157, "?", "t-q", "middle")}'
                f'{_t(330, 208, "A DECISION", "t-mono", "middle")}{_t(330, 222, "made without the full picture", "t-small", "middle")}</g>')
    return _svg(640, 310, "Business information split across disconnected tools",
                "Seven tools (CRM, inbox, support desk, accounting, spreadsheets, team chat and email approvals) hold separate parts of the picture, with broken links between them, so a decision is made without full context.",
                "".join(links) + "".join(boxes) + decision, "chart--frag")


# ------------------------------------------------------------------------------------------------ causal value chains
def causal(lines: list[dict]) -> str:
    """Action -> outcome -> economic effect -> attribution -> confidence, one chain per ledger line.
    Low-confidence chains are drawn dashed and are not counted in the total on the right."""
    cols = ["XEVRION ACTION", "BUSINESS OUTCOME", "ECONOMIC EFFECT", "ATTRIBUTION", "CONFIDENCE"]
    W, colw, gapx, top, rowh = 1000, 168, 40, 40, 92
    xs = [i * (colw + gapx) for i in range(5)]
    out = [_t(x, 14, c, "t-mono") for x, c in zip(xs, cols)]
    counted = 0
    for r, x in enumerate(lines):
        y = top + r * rowh
        low = x["confidence"] == "Low"
        if not low:
            counted += x["value"]
        attrib = {"High": "Direct", "Medium": "Shared", "Low": "Unclear"}[x["confidence"]]
        cells = [x["short"][0], x["short"][1], f'£{x["value"]:,}', attrib, x["confidence"]]
        cls = "cz-low" if low else ("cz-hi" if x["confidence"] == "High" else "cz-med")
        g = [f'<g class="cz {cls}" style="--i:{r}">']
        for i, (cx, text) in enumerate(zip(xs, cells)):
            box = "cz-box cz-box--value" if i == 2 else "cz-box"
            g.append(f'<rect x="{cx}" y="{y}" width="{colw}" height="52" rx="10" class="{box}"/>')
            g.append(_t(cx + 14, y + (22 if i < 2 else 32), text, "t-strong" if i == 2 else "t-node"))
            if i < 2:
                g.append(_t(cx + 14, y + 40, (x["system"] if i == 0 else x["category"]).upper(), "t-mono t-tiny"))
            if i < 4:
                x1, x2, ym = cx + colw, cx + colw + gapx, y + 26
                g.append(f'<path d="M{x1} {ym} H{x2 - 6}" class="cz-link"/><path d="M{x2 - 7} {ym - 4} l6 4 -6 4" class="cz-arrow"/>')
        g.append("</g>")
        out.append("".join(g))
    h = top + len(lines) * rowh
    desc = "; ".join(f'{x["short"][0]} led to {x["short"][1]}, worth £{x["value"]:,}, attribution {x["confidence"].lower()} confidence'
                     + (" (shown, not counted)" if x["confidence"] == "Low" else "") for x in lines)
    return _svg(W, h - 30, "How each result is traced from action to value", desc, "".join(out), "chart--causal")


# ------------------------------------------------------------------------------------------------ learning curve
def learning_curve(errors: list[float], trust: list[float]) -> str:
    """Forecast error falling cycle by cycle (bars) and the resulting trust multiplier rising (line)."""
    W, H, X0, top, bottom = 560, 264, 44, 40, 220
    n = len(errors)
    step = (W - X0 - 20) / n
    ymax = 40
    Y = lambda v: bottom - v / ymax * (bottom - top)
    # the two thresholds are named in a key above the plot and marked on the axis, so their words never sit where a
    # bar or its value is drawn
    out = [f'<line x1="{X0}" x2="{X0 + 18}" y1="8" y2="8" class="cost-line"/>' + _t(X0 + 26, 12, "25%: recalibrate above", "t-small"),
           f'<line x1="{X0 + 230}" x2="{X0 + 248}" y1="8" y2="8" class="hair-strong"/>' + _t(X0 + 256, 12, "10%: a strong model below", "t-small")]
    for v in (10, 25):
        out.append(f'<line x1="{X0}" x2="{W - 10}" y1="{Y(v):.1f}" y2="{Y(v):.1f}" class="{"cost-line" if v == 25 else "hair-strong"}"/>'
                   + _t(X0 - 8, Y(v) + 4, f"{v}%", "t-small", "end"))
    pts = []
    for i, (e, t) in enumerate(zip(errors, trust)):
        x = X0 + i * step + step * 0.2
        bw = step * 0.6
        verdict = "recalibrate" if e > 25 else "strong model" if e < 10 else "keep collecting results"
        out.append(f'<g data-tip="{esc(f"Cycle {i + 1}: error {e:g}% · trust {t:.2f} · {verdict}")}"><rect x="{x - step * 0.2:.1f}" y="{top}" width="{step:.1f}" height="{bottom - top + 24}" class="hit"/>'
                   f'<rect x="{x:.1f}" y="{Y(e):.1f}" width="{bw:.1f}" height="{bottom - Y(e):.1f}" rx="3" class="{"bar-before" if e > 25 else "bar-value"} grow-y" style="--i:{i}"/>'
                   + _t(x + bw / 2, Y(e) - 8, f"{e:g}%", "t-num t-tiny2", "middle") + _t(x + bw / 2, bottom + 18, f"Cycle {i + 1}", "t-small", "middle") + "</g>")
        pts.append((x + bw / 2, top + (1 - t) * (bottom - top)))
    out.append('<polyline points="' + " ".join(f"{x:.1f},{y:.1f}" for x, y in pts) + '" class="trust-line" fill="none"/>')
    out += [f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" class="pt-now"/>' for x, y in pts]
    out.append(_t(pts[-1][0], pts[-1][1] - 12, f"trust {trust[-1]:.2f}", "t-violet", "middle"))
    desc = "Forecast error by cycle: " + ", ".join(f"{e:g}%" for e in errors) + ". Trust in the forecast rises as error falls: " + ", ".join(f"{t:.2f}" for t in trust) + "."
    return _svg(W, H + 10, "Forecast error falling and trust rising over five learning cycles (illustrative example)", desc, "".join(out), "chart--learn")


# ------------------------------------------------------------------------------------------------ published statistic bars
def connector_flow(c: dict) -> str:
    """Your tool on the left, Xevrion on the right; read arrows flow in, write arrows flow out (only if permitted)."""
    W, H = 640, 250
    reads, writes = c["reads"], c["writes"]
    out = [f'<rect x="10" y="70" width="170" height="110" rx="16" class="node-box"/>' + _t(95, 118, c["name"], "t-strong", "middle") + _t(95, 140, c["category"].upper(), "t-mono", "middle"),
           f'<rect x="460" y="70" width="170" height="110" rx="16" class="node-box node-box--x"/>' + _t(545, 118, "Xevrion", "t-strong", "middle") + _t(545, 140, "YOUR ORGANISATION ONLY", "t-mono", "middle")]
    tool = c["name"]
    for i, r in enumerate(reads[:3]):
        y = 92 + i * 22
        out.append(f'<g data-tip="{esc(f"Reads from {tool}: {r}")}"><rect x="184" y="{y - 18}" width="268" height="22" class="hit"/>'
                   f'<path d="M184 {y} H452" class="flow-read"/><path d="M446 {y - 4} l6 4 -6 4" class="flow-read-arrow"/>' + _t(318, y - 5, r[:44], "t-tiny2", "middle") + "</g>")
    for i, w_ in enumerate(writes[:3]):
        y = 164 + i * 22 - (len(writes[:3]) - 1) * 6
        out.append(f'<g data-tip="{esc(f"Writes to {tool}, only with permission: {w_}")}"><rect x="188" y="{y - 4}" width="268" height="22" class="hit"/>'
                   f'<path d="M456 {y} H188" class="flow-write"/><path d="M194 {y - 4} l-6 4 6 4" class="flow-write-arrow"/>' + _t(318, y + 15, w_[:44], "t-tiny2", "middle") + "</g>")
    out.append(_t(318, 30, "READS" if reads else "NO READS", "t-mono", "middle") + _t(318, 236, "WRITES, WITH PERMISSION" if writes else "READ-ONLY: NOTHING IS WRITTEN", "t-mono", "middle"))
    desc = f"{c['name']} to Xevrion: reads " + ("; ".join(reads) if reads else "nothing") + ". Xevrion to " + c["name"] + ": writes " + ("; ".join(writes) if writes else "nothing") + "."
    return _svg(W, H, f"What flows between {c['name']} and Xevrion", desc, "".join(out), "chart--flow")


# ------------------------------------------------------------------------------------------------ small multiples: value by month
def value_bars(months: list[tuple[str, int]], cost: int) -> str:
    W, H, X0, top = 560, 220, 40, 16
    mx = max(v for _, v in months) * 1.12
    bw = (W - X0) / len(months) * 0.56
    out = []
    ycost = top + (1 - cost / mx) * (H - top - 30)
    for i, (m, v) in enumerate(months):
        x = X0 + i * (W - X0) / len(months) + 8
        bh = v / mx * (H - top - 30)
        out.append(f'<g data-tip="{esc(f"{m}: £{v:,} counted value · {v / cost:.1f}× the monthly cost")}"><rect x="{x - 8:.1f}" y="{top}" width="{bw + 16:.1f}" height="{H - top}" class="hit"/>'
                   f'<rect x="{x:.1f}" y="{H - 30 - bh:.1f}" width="{bw:.1f}" height="{bh:.1f}" rx="3" class="bar-value grow-y" style="--i:{i}"/>'
                   + _t(x + bw / 2, H - 12, m, "t-small", "middle") + _t(x + bw / 2, H - 36 - bh, f"£{v / 1000:.1f}K", "t-num t-tiny2", "middle") + "</g>")
    out.append(f'<line x1="{X0}" x2="{W}" y1="{ycost:.1f}" y2="{ycost:.1f}" class="cost-line"/>' + _t(X0, ycost - 8, f"Xevrion cost £{cost:,}/month", "t-small"))
    desc = "Counted value by month: " + "; ".join(f"{m} £{v:,}" for m, v in months) + f". Xevrion cost £{cost:,} per month."
    return _svg(W, H, "Counted value each month against Xevrion's cost (illustrative example)", desc, "".join(out), "chart--vbars")
