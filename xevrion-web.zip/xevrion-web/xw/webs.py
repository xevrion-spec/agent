"""Relationship webs: the Atlas visual applied to the platform itself. Each builder turns catalogue data into a ring of
points (grouped) and the real relationships between them; web() renders the stage with the data inlined as JSON, and
viz-web.js draws it. Nothing is invented: every line comes from the catalogue."""
from __future__ import annotations

import json
import re
from itertools import combinations

from . import data as D
from .catalog import CAPABILITIES, GROUP_NOTES, USE_CASES, capability_code
from .html import esc, icon

SYS = {s["key"]: s for s in D.SYSTEMS}

# Business objects a capability can work on, recognised from its name and plain-English explanation. Two capabilities
# in different systems that work on the same object are linked: that shared object is the connection.
OBJECTS = {
    "customers": r"\bcustomer|\baccount\b|\bclient|onboarding|welcome|go-live|handoff|identity|feedback|advocacy|reference",
    "prospects": r"prospect|\blead|buying-signal|ideal-customer|compan",
    "messages": r"message|\bemail|repl(y|ies)|inbox|communication|conversation|outreach|mailbox|deliverab|follow-up|chas",
    "approvals": r"approv|a person|named",
    "invoices and payments": r"invoice|payment|billing|receivable|payable|overdue|financial|finance",
    "renewals": r"renewal|cancellation|churn|win-back",
    "revenue": r"revenue|pipeline|\bdeal|expansion|\bsales|program",
    "forecasts": r"forecast|scenario|likely|expected|predict|early",
    "decisions": r"decision|recommend|what to do|\bact\b",
    "measures": r"\bkpi|measure|dashboard|report|scorecard|metric|funnel|bottleneck|velocity|health|anomal|root cause|monitor|risk",
    "processes": r"process|work item|workflow|\bwork\b|task|scheduling|schedule|exception|recover|requeue|joiner|mover|leaver",
    "documents": r"document|contract|template|compliance|evidence|export|records",
    "suppliers": r"supplier|vendor|procurement|purchase|quote",
    "knowledge": r"knowledge|procedure|question|answer|plain english",
    "data": r"\bsource|\bsync|import|ingestion|\bcrm\b|\bdata\b|quality|matching|history|timeline",
    "value": r"\bvalue\b|benefit|pay ?back|attribution|outcome",
    "support": r"support|ticket|service level|request",
}


def _objects(text: str) -> set[str]:
    t = text.lower()
    return {name for name, rx in OBJECTS.items() if re.search(rx, t)}


def capability_web(per_node: int = 4) -> dict:
    """All capabilities on one ring, grouped by system; lines join capabilities in different systems that work on the
    same business object. Each capability keeps its strongest few links so the picture stays readable."""
    groups = [{"label": s["name"], "href": s["href"]} for s in D.SYSTEMS]
    nodes, objs = [], []
    for gi, s in enumerate(D.SYSTEMS):
        for g_i, (g, items) in enumerate(CAPABILITIES[s["key"]], 1):
            for i_i, (n, d) in enumerate(items, 1):
                nodes.append({"t": n, "g": gi, "s": g, "d": d, "c": capability_code(s["key"], g_i, i_i), "u": s["href"] + "#capabilities"})
                objs.append(_objects(n + " " + d))
    cand = []
    for a, b in combinations(range(len(nodes)), 2):
        if nodes[a]["g"] == nodes[b]["g"]:
            continue
        shared = objs[a] & objs[b]
        if shared:
            cand.append((len(shared), a, b, sorted(shared)))
    cand.sort(key=lambda x: (-x[0], x[1], x[2]))
    count = [0] * len(nodes)
    edges = []
    for w, a, b, shared in cand:
        if count[a] < per_node or count[b] < per_node:
            edges.append([a, b, 0, ", ".join(shared)])
            count[a] += 1; count[b] += 1
    return {"groups": groups, "nodes": nodes, "edges": edges, "kinds": [{"label": "Shared business object", "tone": "violet"}],
            "centre": f"{len(nodes)} CAPABILITIES", "unit": "capability", "link": "{n} links to other systems"}


def integration_web() -> dict:
    """Every connector, grouped by category, joined to the systems it serves; violet where Xevrion can also write back."""
    cats = sorted({c["category"] for c in D.CONNECTORS})
    groups = [{"label": c} for c in cats] + [{"label": "Xevrion systems"}]
    nodes, edges = [], []
    for c in sorted(D.CONNECTORS, key=lambda c: (cats.index(c["category"]), c["name"])):
        nodes.append({"t": c["name"], "g": cats.index(c["category"]), "s": c["category"], "d": "Reads: " + "; ".join(c["reads"]) + (". Writes, with permission: " + "; ".join(c["writes"]) if c["writes"] else ". Read-only."),
                      "u": f"/integrations/{c['key']}", "key": c["key"]})
    sys_index = {}
    for s in D.SYSTEMS:
        sys_index[s["key"]] = len(nodes)
        nodes.append({"t": s["name"], "g": len(cats), "s": "System", "d": s["one"], "u": s["href"], "hub": 1})
    for i, c in enumerate(n for n in nodes if "key" in n):
        conn = next(x for x in D.CONNECTORS if x["key"] == c["key"])
        for sk in conn["systems"]:
            edges.append([i, sys_index[sk], 0 if conn["writes"] else 1, "reads and writes" if conn["writes"] else "reads only"])
    return {"groups": groups, "nodes": nodes, "edges": edges,
            "kinds": [{"label": "Reads and writes (with permission)", "tone": "violet"}, {"label": "Reads only", "tone": "white"}],
            "centre": f"{len(D.CONNECTORS)} CONNECTORS", "unit": "connector", "link": "{n} connections"}


def atlas_web(nodes: list[dict], edges: list[tuple[int, int]], origins: dict[str, str], current: str = "parent") -> dict:
    """The Atlas as a web: every page, grouped by site (sections as sub-labels), every content link; links that cross
    between sites are violet."""
    sites = [("parent", "Group"), ("ops", "Ops"), ("portal", "Portal")]
    index = {k: i for i, (k, _) in enumerate(sites)}
    out = [{"t": n["t"], "g": index[n["s"]], "s": n["g"], "d": n["d"], "u": (n["u"] if n["s"] == current else origins[n["s"]] + n["u"]), "c": n["u"]} for n in nodes]
    ed = [[a, b, 0 if nodes[a]["s"] != nodes[b]["s"] else 1, "a link between sites" if nodes[a]["s"] != nodes[b]["s"] else ""] for a, b in edges]
    return {"groups": [{"label": l} for _, l in sites], "nodes": out, "edges": ed,
            "kinds": [{"label": "Links between Xevrion sites", "tone": "violet", "alpha": 0.34}, {"label": "Links within a site", "tone": "white", "alpha": 0.07}],
            "centre": f"{len(nodes)} PAGES · {len(edges)} LINKS", "unit": "page", "link": "{n} links"}


def web(data: dict, name: str, caption: str, *, focus: int = -1, height: int = 760, tools: bool = True, kind: str = "capability", base: str = "") -> str:
    """The stage for a relationship web, with its data inlined (JSON is not executed, so the page CSP is unaffected).
    `base` makes the points' links absolute, for a web shown on another site."""
    from .blocks import viz_stage
    payload = dict(data, focus=focus)
    if base:
        payload["nodes"] = [dict(n, u=base + n["u"]) if n.get("u") else n for n in data["nodes"]]
    js = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    chips = ""
    if tools:
        chips = (f'<div class="atlas__tools" data-web-tools hidden><label class="cx__find">{icon("search", 16)}<span class="sr-only">Find in this map</span>'
                 f'<input type="search" data-web-q placeholder="Find, for example “invoice” or “renewal”" autocomplete="off"></label>'
                 f'<div class="cx__chips" role="group" aria-label="Show one group"><button class="cx__chip" type="button" data-web-g="-1" aria-pressed="true">All</button>'
                 + "".join(f'<button class="cx__chip" type="button" data-web-g="{i}" aria-pressed="false">{esc(g["label"])}</button>' for i, g in enumerate(data["groups"]))
                 + "</div></div>")
    legend = '<div class="web__legend">' + "".join(f'<span><i data-tone="{esc(k["tone"])}"></i>{esc(k["label"])}</span>' for k in data["kinds"]) + "</div>"
    stage = viz_stage("web", caption, height=height, kind=kind, hint="Point at a node · click to open", side=True,
                      extra=f'<script type="application/json" data-web-data>{js}</script>',
                      panel='<div class="atlas__readout" data-web-readout aria-live="polite"></div>')
    return f'<div class="web" data-web="{esc(name)}">{chips}{stage}{legend}</div>'
