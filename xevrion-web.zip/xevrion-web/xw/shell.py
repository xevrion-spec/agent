"""Page assembly: head (SEO, OpenGraph, structured data), navigation, mega menus, mobile drawer, footer."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from .components import json_ld
from .html import MARK_SPRITE, attrs, brand_mark, esc, icon

OPS = "https://ops.xevrion.co.uk"
PARENT = "https://xevrion.co.uk"
PORTAL = "https://portal.ops.xevrion.co.uk"
APP = "https://api.xevrion.co.uk/app"
CONTACT_EMAIL = "outreach@ops.xevrion.co.uk"
# Google Search Console ownership (the same public token for every Xevrion site on the owner's Search Console account)
GOOGLE_SITE_VERIFICATION = "G4tV4PLzrJbK4bRiFB6QjUQiTt1Yf7mwR1RwwRys0L8"
BUILT = date.today()


@dataclass
class Page:
    path: str
    title: str
    description: str
    body: str
    env: str = "default"
    crumbs: list[tuple[str, str | None]] = field(default_factory=list)
    schema: list[dict] = field(default_factory=list)
    noindex: bool = False
    priority: float = 0.6
    nav_current: str | None = None
    og_type: str = "website"
    toc: list[tuple[str, str]] = field(default_factory=list)   # (section id, label): the sticky "on this page" bar
    group: str = ""                                            # search grouping, e.g. "Product", "Solutions"
    seo_title: str = ""                                        # the <title> for search results (xw/seo.py); the page's own title otherwise


@dataclass
class Site:
    key: str            # parent | ops | portal
    origin: str
    name: str
    product: str | None
    nav: list[dict]
    footer: list[tuple[str, list[tuple[str, str]]]]
    blurb: str
    cta: tuple[str, str] | None = None                      # the nav's primary button (label, href); default: Get started
    pages: dict[str, Page] = field(default_factory=dict)

    def add(self, page: Page) -> Page:
        if page.path in self.pages:
            raise ValueError(f"duplicate page {self.key}{page.path}")
        self.pages[page.path] = page
        return page


# ---------------------------------------------------------------------------------------------------------------- nav

def _mega(item: dict, idx: int) -> str:
    cols = "".join(
        f'<a class="mega__item" href="{esc(href)}" data-event="nav:{esc(href)}"><span class="mega__icon">{icon(ic, 18)}</span>'
        f'<span><span class="mega__title">{esc(title)}</span><span class="mega__desc">{esc(desc)}</span></span></a>'
        for title, desc, href, ic in item["items"])
    foot = ""
    if item.get("foot"):
        foot = '<div class="mega__foot">' + "".join(
            f'<a class="arrow-link" href="{esc(h)}">{esc(t)}{icon("arrow", 16)}</a>' for t, h in item["foot"]) + "</div>"
    wide = " mega--wide" if len(item["items"]) > 6 else ""
    return (f'<div class="nav__item"><button class="nav__link" type="button" aria-expanded="false" aria-controls="mega-{idx}" data-menu>'
            f'{esc(item["label"])}{icon("chevron", 14)}</button>'
            f'<div class="mega glass glass--elevated glass--edge{wide}" id="mega-{idx}" data-open="false" role="region" aria-label="{esc(item["label"])}">'
            f'<div class="mega__grid">{cols}</div>{foot}</div></div>')


def nav(site: Site, page: Page) -> str:
    parts = []
    for i, item in enumerate(site.nav):
        if item.get("items"):
            parts.append(_mega(item, i))
        else:
            cur = ' aria-current="page"' if page.path == item["href"] or page.nav_current == item["href"] else ""
            parts.append(f'<div class="nav__item"><a class="nav__link" href="{esc(item["href"])}"{cur}>{esc(item["label"])}</a></div>')
    home = "/" if site.key != "portal" else "/"
    product = f'<span class="brand__product">{esc(site.product)}</span>' if site.product else ""
    signin = f'<a class="btn btn--ghost btn--small nav-signin" href="{esc(PORTAL)}/" data-event="nav:sign-in">Sign in</a>' if site.key != "portal" else ""
    cta_label, start_href = site.cta or ("Get started", "/get-started" if site.key == "ops" else f"{OPS}/get-started")
    # cta_start is a conversion (a click towards buying); a site whose primary button goes elsewhere counts it apart
    cta_event = "nav_primary" if site.cta else "cta_start"
    search = (f'<button class="nav__search" type="button" data-palette-open aria-label="Search Xevrion (Control K)">{icon("search", 16)}'
              f'<span class="nav__search-label">Search</span><kbd>Ctrl K</kbd></button>')
    subnav = ""   # pages are short enough to read top to bottom; no 'on this page' bar
    return f'''<header class="nav" data-nav>
  <div class="wrap nav__inner">
    <a class="brand" href="{home}" aria-label="{esc(site.name)} home">{brand_mark("n")}<span>XEVRION</span>{product}</a>
    <nav class="nav__links" aria-label="Primary">{"".join(parts)}</nav>
    <div class="nav__actions">{search}{signin}<a class="btn btn--primary btn--small" href="{esc(start_href)}" data-event="{cta_event}:nav">{esc(cta_label)}</a></div>
    <button class="nav__toggle" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-open aria-label="Open menu">{icon("menu", 22)}</button>
  </div>
</header>
{subnav}
{drawer(site, start_href, cta_label, cta_event)}'''


def _abs(site: Site, origin: str, path: str) -> str:
    """A link that stays relative within its own site and absolute across sites."""
    return path if site.origin == origin else origin + path


# Contextual links into the other sites, chosen by where the reader is. (label, site tag, origin, path)
_ACROSS = {
    "ops:Product": [("The shared foundation", "Group", PARENT, "/foundation"), ("Trust centre", "Group", PARENT, "/trust"), ("How the ventures work together", "Group", PARENT, "/ventures")],
    "ops:Platform": [("The shared foundation", "Group", PARENT, "/foundation"), ("Trust centre", "Group", PARENT, "/trust"), ("Sign in to your workspace", "Portal", PORTAL, "/")],
    "ops": [("The Xevrion group", "Group", PARENT, "/"), ("Xevrion's approach", "Group", PARENT, "/approach"), ("Access and roles", "Portal", PORTAL, "/access")],
    "parent": [("Every Xevrion Ops capability", "Ops", OPS, "/platform/capabilities"), ("How Xevrion Ops works", "Ops", OPS, "/how-it-works"), ("Security and architecture", "Ops", OPS, "/platform/architecture")],
    "portal": [("Xevrion Ops documentation", "Ops", OPS, "/docs"), ("The shared foundation", "Group", PARENT, "/foundation"), ("Trust centre", "Group", PARENT, "/trust")],
}


def across(site: Site, page: Page) -> str:
    if page.path == "/404":
        return ""
    picks = _ACROSS.get(f"{site.key}:{page.group}") or _ACROSS[site.key]
    picks = [p for p in picks if not (p[2] == site.origin and p[3] == page.path)]
    atlas = ("Atlas: every page, mapped", "Group", PARENT, "/atlas")
    items = "".join(f'<a class="across__item" href="{esc(_abs(site, o, p))}" data-event="across:{esc(p)}"><span class="across__tag">{esc(tag)}</span>'
                    f'<span class="across__label">{esc(label)}</span>{icon("arrow-up-right" if o != site.origin else "arrow", 16)}</a>'
                    for label, tag, o, p in picks + ([atlas] if not (site.key == "parent" and page.path == "/atlas") else []))
    return f'<aside class="across" aria-label="Across Xevrion"><div class="wrap across__inner"><p class="label">Across Xevrion</p><div class="across__grid">{items}</div></div></aside>'


def drawer(site: Site, start_href: str, cta_label: str = "Get started", cta_event: str = "cta_start") -> str:
    groups = []
    for i, item in enumerate(site.nav):
        if item.get("items"):
            links = "".join(f'<li><a href="{esc(h)}">{esc(t)}</a></li>' for t, _, h, _ in item["items"])
            links += "".join(f'<li><a href="{esc(h)}">{esc(t)}</a></li>' for t, h in item.get("foot", []))
            groups.append(f'<div class="drawer__group"><button type="button" aria-expanded="false" aria-controls="dg-{i}" data-drawer-group>'
                          f'{esc(item["label"])}{icon("chevron", 18)}</button><ul id="dg-{i}" hidden>{links}</ul></div>')
        else:
            groups.append(f'<a class="drawer__single" href="{esc(item["href"])}">{esc(item["label"])}</a>')
    signin = f'<a class="btn btn--secondary" href="{esc(PORTAL)}/">Sign in</a>' if site.key != "portal" else ""
    return f'''<div class="drawer" id="drawer" data-open="false" role="dialog" aria-modal="true" aria-label="Menu" data-drawer>
  <div class="drawer__head"><span class="brand">{brand_mark("d")}<span>XEVRION</span></span>
    <button class="nav__toggle" style="display:inline-flex" type="button" data-drawer-close aria-label="Close menu">{icon("close", 22)}</button></div>
  <div class="drawer__body">{"".join(groups)}
    <div class="drawer__cta"><button class="btn btn--secondary" type="button" data-palette-open>{icon("search", 18)} Search</button><a class="btn btn--primary" href="{esc(start_href)}" data-event="{cta_event}:drawer">{esc(cta_label)}</a>{signin}</div></div>
</div>'''


def footer(site: Site) -> str:
    cols = "".join(f'<div><h2>{esc(title)}</h2><ul>{"".join(f"<li><a href={chr(34)}{esc(h)}{chr(34)}>{esc(t)}</a></li>" for t, h in links)}</ul></div>'
                   for title, links in site.footer)
    status_href = f"{OPS}/status" if site.key != "ops" else "/status"
    bottom = {"parent": "A UK group of focused ventures.",
              "ops": f'Xevrion Ops is a <a href="{PARENT}/">Xevrion</a> venture, built and operated in the United Kingdom.',
              "portal": f'The sign-in hub for Xevrion Ops, a <a href="{PARENT}/">Xevrion</a> venture.'}[site.key]
    family = "".join(
        f'<a href="{esc(_abs(site, o, p))}"{" aria-current=true" if k == site.key else ""}><span class="ff__name">{esc(n)}</span><span class="ff__host">{esc(host)}</span>'
        f'<span class="ff__state" data-state="{esc(st.lower())}">{esc(st)}</span></a>'
        for n, host, o, p, st, k in (("Xevrion Group", "xevrion.co.uk", PARENT, "/", "Group", "parent"), ("Xevrion Ops", "ops.xevrion.co.uk", OPS, "/", "Live", "ops"),
                                     ("Xevrion Cyber", "xevrion.co.uk/ventures/cyber", PARENT, "/ventures/cyber", "Planned", ""),
                                     ("Portal", "portal.ops.xevrion.co.uk", PORTAL, "/", "Sign in", "portal"), ("Atlas", "xevrion.co.uk/atlas", PARENT, "/atlas", "Map", "")))
    return f'''<footer class="footer">
  <div class="wrap">
    <div class="footer__top" style="--cols:{len(site.footer)}">
      <div class="footer__brand"><a class="brand" href="/" aria-label="{esc(site.name)} home">{brand_mark("f")}<span>XEVRION</span></a><p>{esc(site.blurb)}</p>
        <p style="margin-top:16px"><a class="link" href="mailto:{CONTACT_EMAIL}">{CONTACT_EMAIL}</a></p></div>
      {cols}
    </div>
    <div class="footer__bottom"><span>© {BUILT.year} Xevrion. {bottom}</span>
      <span class="cluster" style="--gap:20px"><a href="{esc(status_href)}">{icon("status", 14)} System status</a><a href="{esc(OPS)}/accessibility">Accessibility</a><a href="{esc(OPS)}/legal/privacy">Privacy</a></span></div>
  </div>
</footer>'''


# ---------------------------------------------------------------------------------------------------------------- head

ORG = {"@context": "https://schema.org", "@type": "Organization", "name": "Xevrion", "url": PARENT, "logo": f"{PARENT}/shared/brand/xevrion-mark-512.png",
       "email": CONTACT_EMAIL, "areaServed": "GB", "description": "Xevrion builds Xevrion Ops, a business operating platform that connects business data, finds opportunities, helps execute the work and measures the value created.",
       "sameAs": [OPS]}


def render(site: Site, page: Page, assets: dict[str, str]) -> str:
    url = site.origin + (page.path if page.path != "/" else "/")
    title = page.seo_title or (page.title if page.title.endswith(("Xevrion", "Xevrion Ops")) or page.path == "/" else f"{page.title} · {site.name}")
    schema: list[Any] = [ORG] if site.key != "portal" else []
    if page.path == "/":
        schema.append({"@context": "https://schema.org", "@type": "WebSite", "name": site.name, "url": site.origin + "/"})
    if page.crumbs:
        schema.append({"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": label, **({"item": site.origin + href} if href else {})}
            for i, (label, href) in enumerate(page.crumbs)]})
    schema += page.schema
    robots = "noindex,follow" if page.noindex else "index,follow,max-image-preview:large"
    og_image = f"{site.origin}/shared/og/{site.key}.png"
    # scripts and data a page may load later; portal.css is the one stylesheet loaded on demand (by viz-portal.js)
    manifest = json.dumps({k: v for k, v in assets.items() if k.endswith((".js", ".json")) or k == "portal.css"}, separators=(",", ":"))
    return f'''<!doctype html>
<html lang="en-GB" data-site="{site.key}" data-env="{esc(page.env)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{esc(title)}</title>
<meta name="description" content="{esc(page.description)}">
<link rel="canonical" href="{esc(url)}">
<meta name="robots" content="{robots}">
<meta name="theme-color" content="#08090d">
<meta name="google-site-verification" content="{GOOGLE_SITE_VERIFICATION}">
<meta property="og:type" content="{esc(page.og_type)}"><meta property="og:site_name" content="{esc(site.name)}">
<meta property="og:title" content="{esc(page.seo_title or page.title)}"><meta property="og:description" content="{esc(page.description)}">
<meta property="og:url" content="{esc(url)}"><meta property="og:image" content="{esc(og_image)}"><meta property="og:image:width" content="2400"><meta property="og:image:height" content="1260">
<meta property="og:locale" content="en_GB"><meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/favicon.ico" sizes="48x48"><link rel="icon" href="/shared/brand/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/shared/brand/favicon-192.png" sizes="192x192" type="image/png"><link rel="apple-touch-icon" href="/shared/brand/apple-touch-180.png">
<link rel="preload" href="/shared/fonts/geist-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{esc(assets["xevrion.css"])}">
<script type="module" src="{esc(assets["core.js"])}"></script>
<script type="application/json" id="xw-assets">{manifest}</script>
{"".join(json_ld(s) for s in schema)}
</head>
<body>
{MARK_SPRITE}
<a class="skip" href="#main">Skip to content</a>
<div class="env" aria-hidden="true"><i class="env__light"></i></div>
{nav(site, page)}
<main id="main" tabindex="-1">
{page.body}
</main>
{footer(site)}
</body>
</html>'''
