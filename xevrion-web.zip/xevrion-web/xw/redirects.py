"""Permanent redirects for every URL the old sites published, so links and search rankings keep working."""
from __future__ import annotations

from .shell import APP, OPS, PARENT

OPS_REDIRECTS = {
    "/product": "/platform",
    "/product/customer-ops": "/product/customer-operations",
    "/product/business-ops": "/product/business-operations",
    "/product/business-intelligence": "/product/decision-intelligence",
    "/product/optimization": "/how-it-works#learn",
    "/product/learning": "/how-it-works#learn",
    "/value": "/pricing#calculator",
    "/roi": "/pricing#calculator",
    "/checkout": "/get-started",
    "/compare": "/pricing#compare",
    "/blog": "/resources",
    "/integrations/warehouse": "/integrations",
    "/integrations/microsoft": "/integrations/microsoft-365",
    "/solutions/decision-making": "/solutions/decision-quality",
    "/solutions/leadership-signal": "/solutions",
    "/solutions/operator-cadence": "/solutions/operational-efficiency",
    "/solutions/post-sale": "/solutions/customer-retention",
    "/solutions/scale-ops": "/solutions/operational-efficiency",
    "/onboarding": "/get-started",
    "/workflow": "/how-it-works",
    "/compliance": "/security",
    "/architecture": "/platform",
    "/company": "/about",
    "/support": "/help",
    "/changelog": "/updates",
    "/book-demo": "/get-started",
    "/demo-request": "/get-started",
    "/atlas": PARENT + "/atlas",
    "/sitemap": PARENT + "/atlas",
    # the Industries section was retired on 2026-09-26
    "/industries": "/solutions",
    "/industries/transport-and-logistics": "/solutions",
    "/industries/construction": "/solutions",
    "/industries/telecoms-and-broadband": "/solutions",
    "/industries/rail-and-parcel-delivery": "/solutions",
    "/industries/finance-and-real-estate": "/solutions",
    "/industries/manufacturing": "/solutions",
    "/industries/primary-sector": "/solutions",
}

PARENT_REDIRECTS = {
    "/values": "/about#principles",
    "/team": "/about",
    "/careers": "/contact",
    "/partners": "/contact",
    "/press": "/news",
    "/insights": "/news",
    "/security": "/trust",
    "/cybersecurity": "/ventures/cyber",
    "/cyber": "/ventures/cyber",
    "/ops": "/ventures/ops",
    "/architecture": OPS + "/platform/architecture",
    "/sitemap": "/atlas",
    "/map": "/atlas",
    "/brand": "/about",
    "/customers": OPS + "/customers",
    "/product": OPS + "/",
    "/accessibility": OPS + "/accessibility",
    "/legal/privacy": OPS + "/legal/privacy",
    "/legal/terms": OPS + "/legal/terms",
    "/legal/cookies": OPS + "/legal/cookies",
}

# Portal paths handed to the application (temporary: the app owns these URLs).
PORTAL_APP = {
    "/console": APP.rsplit("/", 1)[0] + "/console",
    "/customer": APP.rsplit("/", 1)[0] + "/portal",
    "/delivery": APP.rsplit("/", 1)[0] + "/delivery",
    "/app": APP,
}

REDIRECTS = {"ops": OPS_REDIRECTS, "parent": PARENT_REDIRECTS, "portal": {}}
