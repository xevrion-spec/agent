"""About, contact, sign-in, accessibility, legal pages and the 404 page for ops.xevrion.co.uk."""
from __future__ import annotations

from .. import blocks as B
from ..components import answer_block, brief_form, cta_final, explain, index_list, ledger_list, section_head, table
from ..html import esc, icon
from ..shell import APP, PORTAL, Page, Site

UPDATED = "24 September 2026"
EMAIL = "outreach@ops.xevrion.co.uk"

SUBPROCESSORS = [
    ["Cloudflare", "Serves the websites, DNS and the encrypted tunnel to the platform; runs the AI model (Workers AI)", "Global network"],
    ["OVHcloud", "Hosts the Xevrion platform and its databases on Xevrion's own server", "OVHcloud data centre"],
    ["Resend", "Sends account emails: verification codes, password resets, invitations and billing notices", "Email delivery"],
    ["Google Workspace", "Xevrion's company email, used to reply to enquiries and customers", "Email"],
    ["Monzo", "Xevrion's business bank, used to receive payments", "Banking"],
]


def _legal(site: Site, slug: str, title: str, desc: str, sections: list[tuple[str, str]]) -> None:
    crumbs = [("Home", "/"), ("Legal", "/legal"), (title, None)]
    secs = "".join(f"<h2>{esc(h)}</h2>" + "".join(f"<p>{esc(p)}</p>" if not p.startswith("<") else p for p in body.split("\n\n")) for h, body in sections)
    nav = "".join(f'<a href="/legal/{s}"{" aria-current=page" if s == slug else ""}>{esc(t)}</a>' for s, t in LEGAL_INDEX)
    body = f'''{B.page_hero(crumbs, "Legal", title, desc, ctas=False, note=f"<span>{icon('clock', 16)} Last updated {UPDATED}</span>")}
<section class="section section--tight"><div class="wrap doc-layout"><nav class="doc-nav" aria-label="Legal pages">{nav}</nav><article class="prose">{secs}
<h2>Contact</h2><p>Questions about this page: <a href="mailto:{EMAIL}">{EMAIL}</a>. We reply in writing.</p></article></div></section>'''
    site.add(Page(f"/legal/{slug}", title, desc, body, crumbs=crumbs, priority=0.3))


LEGAL_INDEX = [("privacy", "Privacy notice"), ("cookies", "Cookies and storage"), ("terms", "Terms of service"), ("data-processing", "Data processing"),
               ("subprocessors", "Subprocessors"), ("acceptable-use", "Acceptable use"), ("responsible-disclosure", "Responsible disclosure")]


def legal(site: Site) -> None:
    crumbs = [("Home", "/"), ("Legal", None)]
    body = f'''{B.page_hero(crumbs, "Legal", "The legal pages, in plain English.", "How we handle personal data, what we store in your browser, the terms of the service and how to report a security issue.", ctas=False)}
<section class="section section--tight"><div class="wrap">{index_list([(t, "", f"/legal/{s}") for s, t in LEGAL_INDEX])}</div></section>'''
    site.add(Page("/legal", "Legal", "Xevrion's legal pages: privacy notice, cookies and storage, terms of service, data processing, subprocessors, acceptable use and responsible disclosure.",
                  body, crumbs=crumbs, priority=0.3))

    _legal(site, "privacy", "Privacy notice", "What personal data Xevrion collects through its websites and platform, why, how long it is kept and your rights.", [
        ("Who we are", f"Xevrion is a software business based in the United Kingdom. We build and operate Xevrion Ops. For personal data collected through our websites, enquiries and customer accounts, we are the controller. Contact: {EMAIL}."),
        ("Customer data inside Xevrion Ops", "When a customer connects its tools, Xevrion processes that customer's data on the customer's instructions, as a processor. That processing is covered by our data processing terms, and the customer decides what is connected, read and changed."),
        ("Website visits", "Our websites set no cookies. To understand which pages help people, we count page views and a small number of named interactions, such as opening a guided-tour step. Each count records the event, the page and, once per visit, how you arrived (for example a search engine or a link). It records no name, email, account or device identifier. It is switched off automatically if your browser sends Do Not Track or Global Privacy Control, and you can switch it off on the cookies page."),
        ("Enquiries", "If you send a written enquiry, we store your name, work email, company, the system you are interested in and what you wrote, with a reference number, so we can reply. Our legal basis is our legitimate interest in answering you and, where relevant, taking steps at your request before a contract. We keep enquiries for as long as needed to respond and follow up, and no longer than 24 months after our last contact unless you become a customer."),
        ("The website assistant", "If you use the assistant, your question is sent to our platform and answered by an AI model running on Cloudflare Workers AI, using only our published information. Do not include personal or confidential details in questions. Questions are not used to train AI models."),
        ("Customer accounts", "For people who sign in to Xevrion Ops we hold their name, work email, a salted hash of their password (never the password itself), two-factor settings, a digest of each session token, their organisation role and an audit trail of actions. We use these to provide the service securely."),
        ("Payments", "Invoices record the paying organisation, amounts and a payment reference. To confirm payments we match our own bank statement to invoices by reference and amount. Financial records are kept for as long as accounting and tax rules require."),
        ("Abuse prevention", "To stop automated abuse of public forms, we keep short-lived counters keyed by a one-way, keyed hash of the requesting network address. The address itself is not stored with your enquiry."),
        ("Who we share data with", "Only the service providers listed on our subprocessors page, each for the purpose shown there, plus anyone we are legally required to share with. We do not sell personal data."),
        ("International transfers", "Some providers, such as Cloudflare, operate internationally. Where personal data leaves the UK, we rely on the safeguards those providers offer under UK data protection law."),
        ("How long we keep data", "Operational data is deleted or anonymised after a customer completes offboarding and deletion. Financial records follow accounting retention rules. A minimal record that a deletion took place is kept as evidence."),
        ("Your rights", "You can ask for access to, correction of or deletion of your personal data, object to or restrict its use, and ask for a portable copy. Write to us and we will respond within one month. You can also complain to the Information Commissioner's Office (ico.org.uk)."),
    ])
    _legal(site, "cookies", "Cookies and storage", "What Xevrion's websites store in your browser, and how to switch usage measurement off.", [
        ("Cookies", "The Xevrion websites (xevrion.co.uk, ops.xevrion.co.uk and portal.ops.xevrion.co.uk) set no cookies. When you sign in to the Xevrion app, a strictly necessary session cookie keeps you signed in; it is not used for anything else."),
        ("Session storage", "To count how visitors arrive, the websites keep one small value in your browser's session storage for the current visit only, such as “search” or the page you landed on. It contains no identifier and is deleted when you close the tab. When you follow a link from one Xevrion website to another, the same arrival channel (for example “search”, never an identifier) is carried in that link, so the move is counted as one visit; it is removed from the address as soon as the page opens."),
        ("Your choice", '<div class="answer-block"><span class="label">Usage measurement in this browser</span><p data-analytics-state>On (cookieless, no identifiers).</p><p style="margin-top:12px"><button class="btn btn--secondary btn--small" type="button" data-analytics-toggle>Turn off usage measurement</button></p></div>'),
        ("Signals we respect", "If your browser sends Do Not Track or Global Privacy Control, usage measurement is switched off automatically and nothing is stored."),
    ])
    _legal(site, "terms", "Terms of service", "The terms for using Xevrion Ops and its websites, in plain English.", [
        ("The service", "Xevrion Ops is provided on the plan you choose, with the systems, people, connected tools and usage limits published on our pricing page. Limits are enforced by the platform; there are no overage charges."),
        ("Fees and payment", "The setup fee is paid once and the monthly fee by standing order, in pounds sterling, excluding VAT where it applies. Each invoice carries a payment reference. Onboarding starts once the setup payment is confirmed; access to the portal on its own does not confirm payment."),
        ("Your responsibilities", "You are responsible for the accounts you connect, for having the right to share the data you connect, for the approval rules you set and for approving consequential actions. The subscriptions for your own tools remain yours."),
        ("AI and recommendations", "Recommendations, forecasts and drafts are aids to decisions, not guarantees. You decide what to approve. Xevrion does not guarantee any level of revenue, savings or other results; results are measured and recorded in your Value Ledger."),
        ("Acceptable use", "You must use Xevrion lawfully and in line with our acceptable use policy, including the terms of the tools you connect."),
        ("Your data", "Your organisation's data remains yours. You can export it from the portal. When you cancel, entitlements end, queued work stops and connections are revoked; an owner can then complete deletion as described in our privacy notice."),
        ("Changes and cancellation", "You can change plan or cancel from the portal. We will tell you in advance, in writing, about material changes to these terms or to prices."),
        ("Liability", "Nothing in these terms limits liability that cannot be limited by law. Otherwise, our total liability in any 12 months is limited to the fees you paid us in that period, and neither of us is liable for indirect or consequential loss."),
        ("Law", "These terms are governed by the law of England and Wales, and the courts of England and Wales have jurisdiction. If your signed order or written scope says something different, that document takes precedence."),
    ])
    _legal(site, "data-processing", "Data processing", "How Xevrion processes customer data on customers' behalf, as a processor.", [
        ("Roles", "Each customer is the controller of the data it connects to Xevrion Ops. Xevrion processes that data only to provide the service and only on the customer's documented instructions, which include the connections, permissions and approval rules the customer sets."),
        ("Confidentiality and security", "Access is limited to people who need it and are bound by confidentiality. Security measures are described on our security page, including tenant isolation, sealed credentials, two-factor sign-in, approvals and audit logging."),
        ("Subprocessors", "We use the subprocessors listed on our subprocessors page and will give notice of changes in writing."),
        ("Assistance", "We help customers respond to data subject requests, carry out assessments and meet their security obligations, using the export, deletion and audit features of the platform."),
        ("Incidents", "We will notify affected customers without undue delay after becoming aware of a personal data breach affecting their data, with the information they need."),
        ("End of service", "On cancellation, customers can export their data. An owner can then complete deletion; operational data is deleted or anonymised, financial records follow retention rules and a minimal record of the deletion is kept."),
        ("Signed agreement", f"A signed data processing agreement is available on request: write to {EMAIL}."),
    ])
    rows = "".join(f"<tr><th scope=row>{esc(a)}</th><td>{esc(b)}</td><td>{esc(c)}</td></tr>" for a, b, c in SUBPROCESSORS)
    _legal(site, "subprocessors", "Subprocessors", "The service providers that process personal data for Xevrion, and what each one does.", [
        ("Current subprocessors", f'<div class="table-wrap"><table class="table"><thead><tr><th scope="col">Provider</th><th scope="col">Purpose</th><th scope="col">Service</th></tr></thead><tbody>{rows}</tbody></table></div>'),
        ("Changes", "We update this page before adding or replacing a subprocessor that handles customer data, and tell customers in writing."),
    ])
    _legal(site, "acceptable-use", "Acceptable use", "What Xevrion Ops may and may not be used for, including spam, connected tools and security.", [
        ("Use it lawfully", "Do not use Xevrion for anything unlawful, including breaching data protection, marketing or consumer law."),
        ("No spam", "Do not use Xevrion to send unsolicited bulk messages, to contact people from purchased or scraped lists without a lawful basis, or to hide who a message is from."),
        ("Respect connected tools", "Follow the terms of every tool you connect. Do not use Xevrion to get around a tool's limits or permissions."),
        ("Keep people in the loop", "Do not use Xevrion to make decisions with legal or similarly significant effects on people without meaningful human review."),
        ("Do not attack the service", "Do not probe, overload or try to break Xevrion's security, or access another organisation's data. To report a vulnerability, follow our responsible disclosure page."),
        ("What happens if this is broken", "We may suspend actions or access that break this policy and will explain why in writing."),
    ])
    _legal(site, "responsible-disclosure", "Responsible disclosure", "How to report a security vulnerability in Xevrion's websites or platform.", [
        ("Report it privately", f"Email {EMAIL} with “Security” in the subject. Include what you found, where, how to reproduce it and the impact you believe it has."),
        ("In scope", "xevrion.co.uk, ops.xevrion.co.uk, portal.ops.xevrion.co.uk and api.xevrion.co.uk."),
        ("Please do not", "Access, change or delete data that is not yours, degrade the service, use social engineering or physical attacks, or publish details before we have fixed the issue."),
        ("What we will do", "Acknowledge your report, keep you informed, fix confirmed issues as quickly as their severity requires and, if you wish, credit you once it is resolved."),
    ])


def about(site: Site) -> None:
    crumbs = [("Home", "/"), ("About", None)]
    principles = [("Evidence over claims", "Every number we publish is labelled: an example, a product capability, a verified fact or a verified customer result.", "Honesty"),
                  ("People stay in control", "Xevrion recommends and helps; people approve what matters. Everything is logged.", "Control"),
                  ("In writing", "No sales calls. Everything is published, and questions are answered by email, precisely and on the record.", "Clarity"),
                  ("Measured in pounds", "Value is recorded line by line in the Value Ledger, with its confidence, so you can judge us.", "Accountability"),
                  ("Our own infrastructure", "The websites run on Cloudflare; the platform runs on our own server at OVHcloud, with no open ports.", "Control")]
    body = f'''{B.page_hero(crumbs, "About", "We build software that has to prove it is worth paying for.", "Xevrion is a UK software house. We build Xevrion Ops, a business operating platform that connects a company's tools, finds valuable opportunities, helps its team act on them and measures the value created.", where="about")}
<section class="section section--tight"><div class="wrap duo duo--top">
  {answer_block("Who is behind Xevrion?", "Xevrion is a software business based in the United Kingdom. It designs, builds and operates Xevrion Ops, and answers customers directly and in writing.")}
  <div>{explain("Most business software is judged on features. We would rather be judged on results, so we built the Value Ledger to record them, and we publish our prices so you can do the maths.", "Why we built Xevrion")}</div>
</div></section>
<section class="section" id="principles"><div class="wrap duo duo--top">
  {section_head("Principles", "How we work.")}
  {ledger_list(principles)}
</div></section>
{cta_final("See what Xevrion would do for your business.", "Start with one system, or take the guided tour first.", where="about")}'''
    site.add(Page("/about", "About Xevrion", "Xevrion is a UK software house building Xevrion Ops: software that connects your tools, finds opportunities, keeps people in control and measures value.",
                  body, crumbs=crumbs, priority=0.6))


def contact(site: Site) -> None:
    crumbs = [("Home", "/"), ("Contact", None)]
    routes = [["A question before buying", "Use the form on this page", "Written reply by email"], ["Already a customer", "Raise a support request in your portal", "Prioritised by urgency"],
              ["A security issue", "Email with “Security” in the subject", "See responsible disclosure"], ["Anything else", EMAIL, "Written reply by email"]]
    body = f'''{B.page_hero(crumbs, "Contact", "Write to us. We reply in writing.", "Xevrion does not do sales calls or meetings. Tell us what you want to improve and you will get a precise, written answer on fit, scope and price.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  <div class="panel glass glass--elevated glass--edge">{brief_form(source="contact")}</div>
  <div>{table(["You have", "Where", "What happens"], routes)}
    <p class="note">Email: <a class="link" href="mailto:{EMAIL}">{EMAIL}</a></p>
    <div style="margin-top:var(--s-6)">{B.ask()}</div></div>
</div></section>'''
    site.add(Page("/contact", "Contact", "Contact Xevrion in writing: send an enquiry with its own reference number, raise a support request, or report a security issue.",
                  body, crumbs=crumbs, priority=0.6))


def sign_in(site: Site) -> None:
    crumbs = [("Home", "/"), ("Sign in", None)]
    body = f'''{B.page_hero(crumbs, "Sign in", "Sign in to Xevrion Ops.", "Your team signs in to the Xevrion app. New here? Create an account and choose a plan.", ctas=False)}
<section class="section section--tight"><div class="wrap">
  <div class="start__plans" style="grid-template-columns:repeat(2,minmax(0,1fr))">
    <a class="start__plan glass glass--intel" href="{APP}" data-event="signin:app"><span class="label">Customers</span><span style="font:500 26px/1.1 var(--font);letter-spacing:-.02em;margin-top:6px">Open the Xevrion app</span><span class="quiet small">Sign in with your work email, password and two-factor code.</span><span class="go">Sign in {icon("arrow", 16)}</span></a>
    <a class="start__plan glass glass--ambient" href="{PORTAL}/" data-event="signin:portal"><span class="label">All sign-in options</span><span style="font:500 26px/1.1 var(--font);letter-spacing:-.02em;margin-top:6px">Portal</span><span class="quiet small">Customer app, access and roles, and help with signing in.</span><span class="go">Go to the portal {icon("arrow", 16)}</span></a>
  </div>
</div></section>'''
    site.add(Page("/sign-in", "Sign in", "Sign in to Xevrion Ops, or create an account and choose a plan.", body, crumbs=crumbs, priority=0.4))


def accessibility(site: Site) -> None:
    crumbs = [("Home", "/"), ("Accessibility", None)]
    body = f'''{B.page_hero(crumbs, "Accessibility", "Built to be used by everyone.", "Xevrion's websites aim to meet WCAG 2.2 at level AA. Here is what we do, where we know we fall short and how to tell us about a problem.", ctas=False)}
<section class="section section--tight"><div class="wrap prose">
  <h2>What we do</h2>
  <ul><li>Text contrast of at least 4.5:1, and 3:1 for large text and meaningful graphics.</li><li>Every page works with a keyboard, with visible focus, a skip link and accessible menus.</li>
  <li>Interactive visuals are decorative layers over real content: every figure has a text description and the data is also given in tables.</li>
  <li>Colour is never the only signal: states also use shape (a triangle for risk, a square for fine).</li><li>Animation stops if you ask your system for reduced motion, and pauses when off screen.</li>
  <li>Pages work at 200% zoom and with your own text-spacing settings.</li></ul>
  <h2>Known limitations</h2>
  <p>Some interactive visuals, such as the Opportunity Field, are easiest with a mouse or touch. Everything they show is also available as text on the same page.</p>
  <h2>Tell us about a problem</h2>
  <p>Email <a href="mailto:{EMAIL}">{EMAIL}</a> with “Accessibility” in the subject, the page and what went wrong. We will reply in writing and fix what we can.</p>
  <p class="quiet">Last reviewed {UPDATED}.</p>
</div></section>'''
    site.add(Page("/accessibility", "Accessibility statement", "How Xevrion's websites meet WCAG 2.2 AA, known limitations and how to report an accessibility problem.", body, crumbs=crumbs, priority=0.3))


def not_found(site: Site) -> None:
    items = [("Home", "What Xevrion does, in one page", "/"), ("See Xevrion in action", "A guided tour, no sign-up", "/demo"), ("Pricing", "Published prices and limits", "/pricing"),
             ("Help centre", "Where to go for help", "/help")]
    body = f'''<section class="page-hero"><div class="wrap duo duo--top">
  <div class="hero__copy"><p class="eyebrow">404 · Page not found</p><h1 class="display" style="margin:var(--s-5) 0">This page does not exist, or has moved.</h1>
  <p class="lead">The link may be old. These are the places most people are looking for.</p></div>
  {index_list(items, event_prefix="404:")}
</div></section>'''
    site.add(Page("/404", "Page not found", "The page you were looking for does not exist on the Xevrion Ops website.", body, noindex=True, priority=0.0))


def build(site: Site) -> None:
    about(site)
    contact(site)
    sign_in(site)
    accessibility(site)
    legal(site)
    not_found(site)
