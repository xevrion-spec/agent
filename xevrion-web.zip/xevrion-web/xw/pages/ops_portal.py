"""The customer portal presentation (/customer-portal).

The frame runs the real portal (src/js/portal-app.js and src/portal/portal.css, copied from the gateway by
tools/sync_portal.py) against an illustrative example company (src/js/portal-demo.js), so what visitors see is the
portal their team would sign in to, not a picture of it. Every figure is invented and labelled so; nothing is sent.
"""
from __future__ import annotations

from .. import blocks as B
from ..components import claim, cta_final, section_head
from ..html import esc, icon
from ..shell import APP, Page, Site

# every screen in the portal, in its side-panel order: (portal page id, name, what it shows, icon)
SCREENS = [
    ("Overview", [
        ("home", "Command centre", "Health score, completed actions, success rate, verified value, approvals waiting, connected tools, AI use and setup, with live activity by service.", "status"),
        ("systems", "Systems map", "Every system in the workspace on one live map: the four services, the controls and evidence around them, and every connected tool.", "integrations"),
    ]),
    ("Services", [
        ("revenue", "Revenue", "Programmes with one-click start, pause, cycle and stop; every action, its outcome and its receipt.", "revenue"),
        ("customer_operations", "Customer Operations", "Customer health, churn risk, retention and expansion, with recorded support cases ready to resolve.", "customers"),
        ("business_operations", "Business Operations", "A process designer drawn as a flow, workflow runs grouped by state, approvals and exception recovery.", "operations"),
        ("business_intelligence", "Decision Intelligence", "Metrics, KPIs, forecasts, scenarios and recorded decisions, each with its evidence.", "decisions"),
    ]),
    ("Evidence", [
        ("value", "Results and value", "The Value Ledger: estimated, observed and verified value, costs, confidence and time to first value.", "value"),
        ("optimisation", "Optimisation", "Forecast against actual, attribution methods, service adoption and the drivers of health.", "spark"),
        ("usage", "Usage and limits", "AI calls today, plan limits, recorded usage and usage by service, against what the plan allows.", "status"),
    ]),
    ("Workspace", [
        ("setup", "Setup", "Eight setup steps with progress, and service activation once they are done.", "check"),
        ("connections", "Connections", "Every connected tool with its health, one-click and app-password connections, and your own apps.", "integrations"),
        ("team", "Team and access", "Members, roles, invitations and exactly what each role can do.", "user"),
        ("billing", "Billing", "Plan, entitlements, invoices and documents, and plan changes.", "pricing"),
        ("notifications", "Notifications", "A timeline of what happened, with your own delivery preferences.", "updates"),
        ("support", "Support", "Conversations answered in writing, with replies and resolution confirmed by you.", "help"),
    ]),
    ("Account", [
        ("security", "Account security", "Two-factor sign-in, recovery codes and every session signed in as you.", "lock"),
        ("data", "Data and closure", "Exports, retention periods and organisation closure, under your control.", "backup"),
    ]),
]


def build(site: Site) -> None:
    crumbs = [("Home", "/"), ("Customer portal", None)]
    hero = B.page_hero(crumbs, "Customer portal", "The workspace your team signs in to.",
                       "The real Xevrion portal, running on an example company. The company and its figures are invented, and nothing you do here is sent anywhere.", ctas=True, where="portal")
    host = APP.split("//", 1)[1]
    frame = (f'<figure class="portal-frame" id="live"><div class="portal-frame__bar" aria-hidden="true"><i></i><i></i><i></i>'
             f'<span class="portal-frame__url">{icon("lock", 13)}{esc(host)}</span><span class="portal-frame__tag">{claim("illustrative")}</span></div>'
             f'<div class="portal-frame__screen" data-viz="portal"><noscript><p class="portal-frame__nojs">The portal presentation needs JavaScript. '
             f'The list below describes every screen.</p></noscript></div>'
             f'<figcaption class="portal-frame__cap">Harbour &amp; Vale Logistics is an illustrative example. Use the side panel to move between screens; '
             f'anything that would send email, move money or delete data explains itself instead.</figcaption></figure>')
    groups = "".join(
        f'<div class="portal-screens__group"><p class="label">{esc(g)}</p><div class="portal-screens__grid">'
        + "".join(f'<button type="button" class="portal-screen" data-portal-go="{pid}"><span class="portal-screen__ic">{icon(ic, 18)}</span>'
                  f'<span class="portal-screen__t">{esc(name)}</span><span class="portal-screen__d">{esc(desc)}</span>'
                  f'<span class="portal-screen__go">Show this screen {icon("arrow", 14)}</span></button>' for pid, name, desc, ic in items)
        + "</div></div>" for g, items in SCREENS)
    principles = [("Every number has its evidence", "Open any record for its receipt. Value is verified against evidence, not claimed."),
                  ("Nothing consequential runs alone", "Messages, payments and changes wait for a named person's approval, in the same place."),
                  ("Roles, not trust", "Each person sees and does only what their role allows; the permissions table is on the Team screen."),
                  ("Works where your team is", "The side panel becomes a drawer on a phone; every screen and chart adapts.")]
    body = f'''{hero}
<section class="section section--tight"><div class="wrap">{frame}</div></section>
<section class="section section--tight"><div class="wrap"><div class="portal-principles">{"".join(f'<div><h2 class="h4">{esc(t)}</h2><p class="muted">{esc(d)}</p></div>' for t, d in principles)}</div></div></section>
{cta_final("Put your own business in it.", "Choose a plan and create your workspace. Your team signs in to exactly this portal, with your own services, tools and results.", where="portal")}'''
    site.add(Page("/customer-portal", "Customer portal", "See the Xevrion Ops customer portal: the real workspace running on an illustrative company, with every screen, metric and control your team uses.",
                  body, env="decisions", crumbs=crumbs, priority=0.8))
