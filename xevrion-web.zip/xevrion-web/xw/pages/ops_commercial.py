"""Pricing, Get started, the guided tour, Customers (honest proof), Security and AI transparency."""
from __future__ import annotations

from .. import blocks as B
from .. import data as D
from ..components import (answer_block, arrow_link, brief_form, button, caps, claim, cta_final, explain, faq, faq_schema,
                          ledger_list, section_head, table)
from ..html import esc, icon
from ..shell import Page, Site
from . import tour

# ------------------------------------------------------------------------------------------------ pricing
PRICING_FAQ = [
    ("What does the setup fee cover?", "Onboarding: agreeing your goals, metrics, permissions and approval rules, connecting your first tools and configuring the systems in your plan. It is paid once."),
    ("What happens if we reach a limit?", "Xevrion tells you before you get there. There are no overage charges: new work of that kind waits until the next period, or until you choose to upgrade."),
    ("How do we pay?", "The setup fee once, then a monthly standing order. Your invoice, amount and payment reference are shown in your portal. Bank details are never published on the website: if you are sent payment details any other way, check with us first."),
    ("Can we cancel?", "Yes. Cancelling removes access, stops queued work and revokes connections straight away. You can export your data before an owner completes deletion."),
]


def _plan_card(p: dict) -> str:
    feats = [f'{"All four systems" if p["modules"] == 4 else ("One system" if p["modules"] == 1 else "Two systems")}',
             f'Up to {p["team"]:,} people', f'{p["integrations"]:,} connected tools', f'{p["workflows"]:,} workflow runs a month',
             f'{p["ai_calls"]:,} AI calls a day', "Scenario planning" if p["scenarios"] else None, "Priority onboarding" if p["priority"] else None,
             "Value Ledger and full audit trail", p["support"]]
    lis = "".join(f"<li>{esc(f)}</li>" for f in feats if f)
    if p["monthly"]:
        price = f'<p class="plan__price num">£{p["monthly"]:,}<small> /month</small></p><p class="plan__setup">+ £{p["setup"]:,} one-time setup</p>'
        cta = button(f'Choose {p["name"]}', B.app_link(p["key"]), "primary" if p.get("featured") else "secondary", event=f"plan_select:{p['key']}")
    else:
        price = '<p class="plan__price">Tailored</p><p class="plan__setup">Scoped to your organisation</p>'
        cta = button("Ask about Custom", "/contact?topic=custom", "secondary", event="plan_select:custom")
    badge = '<span class="plan__badge claim claim--capability">Two systems together</span>' if p.get("featured") else ""
    return (f'<article class="plan glass {"glass--intel plan--featured" if p.get("featured") else "glass--ambient"}" id="{p["key"]}" data-reveal>{badge}'
            f'<h3 class="plan__name">{esc(p["name"])}</h3>{price}<p class="plan__fit">{esc(p["fit"])}</p><ul class="plan__list">{lis}</ul>{cta}</article>')


def pricing(site: Site) -> None:
    crumbs = [("Home", "/"), ("Pricing", None)]
    hero = B.page_hero(crumbs, "Pricing", "Published prices. No overage surprises.",
                       "Four plans, every limit shown. Prices are in pounds and exclude VAT.",
                       ctas=False, where="pricing")
    rows = [["Systems", "1", "2", "4", "4"], ["People", "3", "15", "50", "250"], ["Connected tools", "3", "12", "50", "250"],
            ["Workflow runs a month", "500", "5,000", "50,000", "500,000"], ["AI calls a day", "300", "1,000", "3,000", "10,000"],
            ["Value Ledger", "Yes", "Yes", "Yes", "Yes"], ["Approvals, roles and audit trail", "Yes", "Yes", "Yes", "Yes"],
            ["Two-factor sign-in", "Yes", "Yes", "Yes", "Yes"], ["Scenario planning", "No", "No", "Yes", "Yes"],
            ["Priority onboarding", "No", "No", "Yes", "Yes"], ["Setup (once)", "£2,000", "£3,500", "£7,000", "Scoped"],
            ["Monthly", "£2,500", "£5,000", "£10,000", "Tailored"]]
    roi = f'''<div class="roi glass glass--ambient" data-viz="roi" id="calculator-tool">
  <div class="roi__inputs">
    <label class="range-input roi__in"><span>Hours a week your team spends on repetitive admin</span><input type="range" min="5" max="200" step="5" value="40" data-in="hours"><output data-out="hours">40</output></label>
    <label class="range-input roi__in"><span>Loaded hourly cost of that time (£)</span><input type="range" min="15" max="90" step="1" value="35" data-in="rate"><output data-out="rate">£35</output></label>
    <label class="range-input roi__in"><span>Share of that work Xevrion could remove</span><input type="range" min="10" max="80" step="5" value="40" data-in="share"><output data-out="share">40%</output></label>
    <label class="range-input roi__in"><span>Average first-year value of a customer (£)</span><input type="range" min="2000" max="60000" step="1000" value="18000" data-in="value"><output data-out="value">£18,000</output></label>
    <label class="range-input roi__in"><span>Extra customers won or kept each quarter</span><input type="range" min="0" max="6" step="1" value="1" data-in="wins"><output data-out="wins">1</output></label>
    <div class="pill-nav" role="group" aria-label="Plan">{"".join(f'<button type="button" data-plan="{p["key"]}" aria-pressed="{str(p["key"] == "growth").lower()}">{esc(p["name"])}</button>' for p in D.PLANS if p["monthly"])}</div>
  </div>
  <div class="roi__out" aria-live="polite">
    <div><span class="label">Estimated monthly value</span><span class="roi__big num" data-r="value">£8,427</span></div>
    <dl class="kv"><dt>Time given back</dt><dd data-r="hours">69 hrs a month</dd><dt>Cost removed</dt><dd data-r="cost">£2,427 a month</dd>
      <dt>Revenue won or kept</dt><dd data-r="rev">£6,000 a month</dd><dt>Plan cost</dt><dd data-r="plan">£5,000 a month</dd>
      <dt>Setup paid back in</dt><dd data-r="payback">about 2 months</dd><dt>Estimated return</dt><dd data-r="roi">1.7×</dd></dl>
    <p class="note">An estimate from your own inputs, not a promise. Real value is measured against your baseline and recorded, with confidence, in the Value Ledger.</p>
  </div>
</div>'''
    body = f'''{hero}
<section class="section section--tight" aria-labelledby="plans-title"><div class="wrap"><h2 class="sr-only" id="plans-title">Plans</h2><div class="plans">{"".join(_plan_card(p) for p in D.PLANS)}</div>
  <p class="note" style="margin-top:var(--s-5)">Prices in GBP excluding VAT. {claim("fact", "Published prices")}</p></div></section>
<section class="section" id="compare"><div class="wrap duo duo--top">
  {section_head("Compare", "Every limit, side by side.", "No hidden tiers, add-ons or per-seat charges. A workflow run is one automated job from start to finish; an AI call is one request to the model.")}
  <div data-reveal>{table(["Included", "Start", "Growth", "Scale", "Custom"], rows, caption="Custom limits shown are the platform maximum; Custom terms are agreed in writing.")}</div>
</div></section>
<section class="section" id="calculator"><div class="wrap">
  {section_head("Estimate your return", "Will Xevrion pay for itself?", "Move the sliders to match your business. The estimate uses only your inputs and the plan price.")}
  {roi}
  <div class="section-foot"><span class="cluster">{claim("illustrative", "Estimate only")}<span class="quiet small">Monthly value = hours removed × hourly cost + (extra customers × first-year value ÷ 3).</span></span>{arrow_link("How real value is measured", "/product/value-ledger", "pricing:ledger")}</div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Questions", "About pricing and payment.")}
  <div>{faq(PRICING_FAQ, open_first=True)}</div>
</div></section>
{cta_final("Choose a plan and start today.", "Create your workspace in a few minutes. Onboarding begins as soon as your setup payment is confirmed.", where="pricing")}'''
    site.add(Page("/pricing", "Pricing", "Xevrion Ops pricing: Start £2,500/month, Growth £5,000/month, Scale £10,000/month and Custom. Every limit published, no overage charges, VAT excluded.",
                  body, env="pricing", crumbs=crumbs, priority=0.95, nav_current="/pricing", schema=[faq_schema(PRICING_FAQ), {
                      "@context": "https://schema.org", "@type": "Product", "name": "Xevrion Ops", "brand": {"@type": "Brand", "name": "Xevrion"},
                      "description": "Business operating platform for revenue, customer operations, business operations and decision intelligence.",
                      "offers": [{"@type": "Offer", "name": p["name"], "price": str(p["monthly"]), "priceCurrency": "GBP", "url": site.origin + f"/pricing#{p['key']}"} for p in D.PLANS if p["monthly"]]}]))


# ------------------------------------------------------------------------------------------------ get started
def get_started(site: Site) -> None:
    crumbs = [("Home", "/"), ("Get started", None)]
    hero = B.page_hero(crumbs, "Get started", "Start today. No sales call needed.",
                       "Choose a plan, create your workspace and pay the setup fee. Onboarding starts as soon as payment is confirmed.",
                       ctas=False, where="start")
    steps = [
        ("Choose your plan", "Start, Growth or Scale. Each is published with its limits, so you know exactly what you are buying.", "/pricing", "Compare plans"),
        ("Create your account", "Your name, work email and a password of at least 12 characters. We email a code to verify your address.", B.app_link(), "Create account"),
        ("Pick your plan in the portal", "Your invoice is created with its amount and a payment reference, shown in the portal and sent by email.", None, None),
        ("Pay the setup fee and set up the monthly payment", "Pay the one-time setup fee and set up a standing order for the monthly fee, quoting your payment reference. Payment details are only ever given in your portal and invoice, never on this website.", None, None),
        ("Complete onboarding", "Eight save-and-resume steps: your business, goals, metrics, integrations, permissions, systems, automation and approvals. Nothing runs until all eight are done.", None, None),
        ("Connect your tools and run your first loop", "Connect with your own accounts, approve what Xevrion may read and change, and see the first results in your Value Ledger.", "/integrations", "See integrations"),
    ]
    lis = "".join(f'<li class="start__step" data-reveal><span class="start__n num">{i + 1:02d}</span><div><h3>{esc(t)}</h3><p>{esc(d)}</p>'
                  f'{f"<p style=margin-top:10px>{arrow_link(l, h, f'start:step{i + 1}')}</p>" if h else ""}</div></li>' for i, (t, d, h, l) in enumerate(steps))
    choose = "".join(f'<a class="start__plan glass glass--ambient" href="{esc(B.app_link(p["key"]))}" data-event="start_plan:{p["key"]}"><span class="label">{esc(p["name"])}</span>'
                     f'<span class="num" style="font:500 28px/1 var(--font);letter-spacing:-.03em;margin-top:8px">£{p["monthly"]:,}<small class="quiet" style="font-size:14px"> /month</small></span>'
                     f'<span class="quiet small">+ £{p["setup"]:,} setup · {esc(p["fit"].split(".")[0])}</span><span class="go">Start with {esc(p["name"])} {icon("arrow", 16)}</span></a>'
                     for p in D.PLANS if p["monthly"])
    body = f'''{hero}
<section class="section section--tight"><div class="wrap">
  <div class="start__plans">{choose}</div>
  <p class="note">Each button opens the Xevrion app at api.xevrion.co.uk to create your account. Need more than Scale? <a class="link" href="/contact?topic=custom">Ask about Custom</a>.</p>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("What happens next", "Six steps from here to your first measured result.")}
  <ol class="start">{lis}</ol>
</div></section>
<section class="section" id="ask"><div class="wrap duo duo--top">
  <div>{section_head("Prefer to ask first?", "Send us a written question.", "Tell us what you want to improve. We reply in writing from outreach@ops.xevrion.co.uk with a straight answer on fit and scope. No calls, no meetings.")}
    {explain("Your enquiry goes straight to Xevrion's own system and gets a reference number. We only use it to reply to you.", "Where this goes")}</div>
  <div class="panel glass glass--elevated glass--edge">{brief_form(source="get-started")}</div>
</div></section>'''
    site.add(Page("/get-started", "Get started", "Start with Xevrion Ops without a sales call: choose a plan, create your workspace, pay the setup fee and complete onboarding in your portal.",
                  body, env="pricing", crumbs=crumbs, priority=0.9))


# ------------------------------------------------------------------------------------------------ guided tour
def demo(site: Site) -> None:
    crumbs = [("Home", "/"), ("See Xevrion in action", None)]
    hero = B.page_hero(crumbs, "Guided tour", "See Xevrion in action.",
                       "Pick a system and watch it work, step by step at reading pace, with the product on screen. Go back or forward whenever you like. No sign-up, no sales call.",
                       ctas=False, where="tour")
    body = f'''{hero}
<section class="section section--tight"><div class="wrap">{tour.render()}</div></section>
{cta_final("Ready to try it on your own business?", "Choose a plan and create your workspace. You will connect your own tools during onboarding.", where="tour")}'''
    site.add(Page("/demo", "See Xevrion in action", "A guided, no-sign-up tour of Xevrion Ops: watch Revenue, Customer Operations, Business Operations and Decision Intelligence work step by step.",
                  body, env="decisions", crumbs=crumbs, priority=0.85))


# ------------------------------------------------------------------------------------------------ customers
def customers(site: Site) -> None:
    crumbs = [("Home", "/"), ("Customers", None)]
    hero = B.page_hero(crumbs, "Customers", "Proof you can check, before we ask you to believe it.",
                       "Xevrion is a young company, so there are no borrowed logos or invented case studies here. A customer result is published only when it meets the standard below.",
                       where="customers")
    standard = [("Context", "Who the customer is, their size and sector, and what they needed.", "01"), ("Problem", "What was going wrong, in their words.", "02"),
                ("Baseline", "The numbers before Xevrion, over a stated period.", "03"), ("Configuration", "Which systems, tools and approval rules were set up.", "04"),
                ("Action", "What Xevrion did, and what people approved.", "05"), ("Outcome", "What changed, read from the customer's own systems.", "06"),
                ("Economic effect", "The value in pounds, from the Value Ledger.", "07"), ("Time to value", "How long from starting to the first verified result.", "08"),
                ("Quote", "What the customer says, attributed with permission.", "09"), ("Method", "How value was calculated and its confidence level.", "10")]
    body = f'''{hero}
<section class="section"><div class="wrap">
  {section_head("Our evidence standard", "Ten things every published result must show.")}
  <ol class="standard">{"".join(f"<li><strong>{esc(a)}</strong><span>{esc(b)}</span></li>" for a, b, _ in standard)}</ol>
  <p class="note">{claim("result")} This label is reserved for verified customer results. None is published yet.</p>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Your first result", "How your own results will be measured.", "Start on one system. Xevrion records a baseline from your own data first, then every result goes into your Value Ledger with its method and confidence, so you can judge it yourself.")}
  {ledger_list([("Baseline", "Taken from your own records before anything changes, usually the last 90 days.", "Before"),
                ("Measured result", "Read from your own tools, not estimated.", "After"),
                ("Confidence", "High, medium or low. Low is shown but never counted.", "Honesty"),
                ("Your judgement", "Every line can be questioned and excluded.", "Control")])}
</div></section>
{cta_final("Be measured, not marketed to.", "Start on one system and judge Xevrion on your own Value Ledger.", where="customers")}'''
    site.add(Page("/customers", "Customers and proof", "How Xevrion proves results: the ten-part evidence standard every customer result must meet before it is published, and how your own value is measured.",
                  body, crumbs=crumbs, priority=0.7))


# ------------------------------------------------------------------------------------------------ security
def security(site: Site) -> None:
    crumbs = [("Home", "/"), ("Security", None)]
    hero = B.page_hero(crumbs, "Security", "Security you can read, not just badges.",
                       "How Xevrion protects your organisation, your connections and every action it takes. We do not claim certifications we do not hold.",
                       where="security", visual=B.viz_stage("trust", "Every request must pass five layers to reach your data. Requests that fail a check are refused at that layer.", height=500, kind="capability"))
    layers = [("Identity", "Who you are", ["Sign-in", "Two-factor authentication"]), ("Access", "What you can do", ["Roles and permissions", "Tenant isolation"]),
              ("Connections", "What Xevrion can reach", ["Secrets and connections", "No open doors"]), ("Actions", "What Xevrion does", ["Human approval", "Safe retries", "Audit trail"]),
              ("Lifecycle", "What happens over time", ["Backups and recovery", "Cancellation and deletion"])]
    blocks = []
    for name, sub, keys in layers:
        blocks.append(f'<section class="trust__layer" aria-labelledby="tl-{name.lower()}"><div class="trust__head"><span class="label">{esc(sub)}</span><h2 id="tl-{name.lower()}" class="h3">{esc(name)}</h2></div>{B.facts(keys, one_column=True)}</section>')
    hosting = [["Websites", "Cloudflare", "Served from Cloudflare's network with strict security headers"],
               ["Application and database", "OVHcloud", "Xevrion's own server, reachable only through a Cloudflare Tunnel, with no ports open to the internet"],
               ["AI model", "Cloudflare Workers AI", "An open model reached through a private, authenticated bridge"],
               ["Connections to your tools", "Each vendor's own sign-in", "OAuth with PKCE where the vendor supports it"]]
    body = f'''{hero}
<section class="section section--tight"><div class="wrap duo duo--top">
  {section_head("Where it runs", "Four parts, each in a known place.")}
  <div data-reveal>{table(["Part", "Runs on", "Detail"], hosting)}</div>
</div></section>
<section class="section"><div class="wrap"><div class="trust">{"".join(blocks)}</div></div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Talk to us", "A vulnerability, or a security questionnaire?", "Tell us in writing. We answer precisely, including where the honest answer is not yet.")}
  <div class="cluster" style="--gap:var(--s-5)">{arrow_link("Responsible disclosure", "/legal/responsible-disclosure", "security:disclosure")}{arrow_link("Send a questionnaire", "/contact?topic=security", "security:contact")}{arrow_link("How Xevrion uses AI", "/ai", "security:ai")}</div>
</div></section>'''
    site.add(Page("/security", "Security", "How Xevrion Ops protects your organisation: tenant isolation, two-factor sign-in, roles, sealed credentials, no open ports, approvals, audit and deletion.",
                  body, env="security", crumbs=crumbs, priority=0.8))


# ------------------------------------------------------------------------------------------------ AI transparency
def ai(site: Site) -> None:
    crumbs = [("Home", "/"), ("AI and human control", None)]
    hero = B.page_hero(crumbs, "AI transparency", "What the AI does, and what it never does alone.",
                       "Xevrion uses AI where language or judgement is needed and plain code everywhere else. People stay in control of anything consequential.",
                       where="ai", visual=B.viz_stage("aipath", "Three kinds of task on the nine-step path: code where code is enough, the model where language is needed, a person wherever policy requires.", height=520, kind="capability",
                                                      panel='<div class="viz__readout"><span class="label">Now on the path</span><span class="big" style="font-size:20px" data-o="task">Match a payment to an invoice</span><span class="sub" data-o="note">Deterministic code; allowed by policy; no approval needed.</span></div>'))
    path = [("Task", "Something needs doing: draft a reply, score a prospect, summarise a thread."),
            ("Risk and complexity", "How much could go wrong, and how hard is it? This decides everything that follows."),
            ("Rule, code or model", "Deterministic code first. The AI model only where judgement or language is genuinely needed."),
            ("Recommendation or action", "The output is evidence: a draft, a score, a suggestion, with its confidence."),
            ("Policy", "Your rules decide whether this kind of action may run on its own."),
            ("Approval where required", "Anything consequential waits for a named person to approve it."),
            ("Execution", "Carried out once, in your tools, with an idempotency key and your permissions."),
            ("Audit", "Who approved what, what ran, and what the model produced, recorded."),
            ("Outcome", "Checked against reality, valued in the Value Ledger and used to improve.")]
    steps = "".join(f'<li data-reveal><span class="path__n num">{i + 1:02d}</span><div><strong>{esc(a)}</strong><span>{esc(b)}</span></div></li>' for i, (a, b) in enumerate(path))
    model = [["Model", "Llama 3.1 8B Instruct, an open-weight model from Meta"], ["Where it runs", "Cloudflare Workers AI, reached through a private bridge that requires Xevrion's own access token"],
             ["Settings", "Low temperature (0.1) and structured JSON output, for consistent, checkable answers"], ["Input limits", "At most 20 KB and 6 messages per request"],
             ["Daily limits", "300, 1,000, 3,000 or 10,000 AI calls a day depending on your plan"], ["If it is unavailable", "The action fails safely and is reported; nothing is guessed"]]
    qa = [("Is my data used to train AI models?", "Xevrion sends a request to the model only to complete a task for your organisation, and runs it on Cloudflare Workers AI rather than a general AI chatbot service. We do not use your data to train models."),
          ("Can the AI send emails or change records by itself?", "Only if you have set a policy that allows a specific, low-risk action to run on its own. By default, anything consequential is a draft or recommendation that a person approves."),
          ("What if the AI is wrong?", "Its output is treated as evidence, not authority. Consequential actions need a person's approval, and every outcome is checked afterwards.")]
    body = f'''{hero}
<section class="section section--tight"><div class="wrap duo duo--top">
  {section_head("The model", "Which model, and where it runs.")}
  <div data-reveal>{table(["Item", "Detail"], model)}</div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("The path of every task", "Nine steps from task to outcome.", "No step can be skipped. The model sits in step three, and only when code is not enough.")}
  <ol class="path">{steps}</ol>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Autonomy", "You decide how far it may go.", "Four levels. Most organisations start at recommend and move individual, low-risk tasks up as trust is earned.")}
  <div data-reveal>{B.ladder()}</div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Questions", "About AI in Xevrion.")}
  <div>{faq(qa, open_first=True)}</div>
</div></section>'''
    site.add(Page("/ai", "AI and human control", "How Xevrion Ops uses AI: which model, where it runs, what data it sees, the nine-step path from task to outcome and the four levels of autonomy you control.",
                  body, env="decisions", crumbs=crumbs, schema=[faq_schema(qa)], priority=0.8))


def build(site: Site) -> None:
    pricing(site)
    get_started(site)
    demo(site)
    customers(site)
    security(site)
    ai(site)
