"""Platform overview and How it works: what Xevrion is made of, and how it turns data into measured value."""
from __future__ import annotations

from .. import blocks as B
from .. import data as D
from ..components import answer_block, arrow_link, caps, cta_final, explain, faq, faq_schema, section_head, table
from ..html import esc, icon
from ..shell import Page, Site

WALK_EXAMPLES = {
    "Connect": "A finance lead connects Xero with read access only, and Zendesk with read and write. Xevrion checks both connections work before using them.",
    "Understand": "The 14 emails, 9 tickets and 1 renewal invoice that mention Northwind Logistics are recognised as the same customer, even though each tool spells the name differently.",
    "Identify": "Northwind's health drops from 82 to 61. Xevrion flags it with its three drivers: tickets tripled, replies slowed to 2 days, renewal in 45 days.",
    "Decide": "Three options are compared: a discount, doing nothing, or fixing the recurring issue and booking a success call. The third is recommended with medium confidence.",
    "Act": "After the account manager approves, Xevrion drafts the email, opens the engineering ticket and posts the plan to the team channel.",
    "Verify": "Two weeks later tickets are back to 2 a week and the customer confirms the renewal. The action is marked as having worked.",
    "Value": "The renewal invoice (£7,300) is matched to the intervention and recorded at medium confidence, because the account manager was also involved.",
    "Learn": "The pattern of more tickets plus slower replies before renewal now raises an alert two weeks earlier for every customer. Learning and memory explains exactly how.",
}
SUMMARIES = {"Connect": "Your tools, your permissions", "Understand": "One picture of the business", "Identify": "What is worth acting on",
             "Decide": "Options, ranges, a recommendation", "Act": "Approved work, done in your tools", "Verify": "Did it actually work?",
             "Value": "The result, in pounds", "Learn": "Better next cycle"}


def platform(site: Site) -> None:
    hero = B.page_hero([("Home", "/"), ("Platform", None)], "Platform overview",
                       "One platform for revenue, customers, operations and decisions.",
                       "Xevrion sits on top of the tools you already use, joins their data into one picture and runs four systems on it, with people in control and every result valued in pounds.",
                       where="platform")
    systems = "".join(
        f'<a href="{s["href"]}" data-reveal><span class="ic">{icon(s["icon"], 20)}</span><h3>{esc(s["name"])}</h3><p>{esc(s["one"])}</p>'
        f'<p class="small" style="color:var(--text-1);margin-top:4px">{esc(s["outcome"])}</p><span class="go">Explore {esc(s["name"])} {icon("arrow", 16)}</span></a>'
        for s in D.SYSTEMS)
    shared = caps([
        ("Shared", "One customer record", "Every system sees the same customer, with every email, ticket, invoice and deal attached."),
        ("Shared", "The Value Ledger", "Results from all four systems land in one ledger, in pounds, with evidence and confidence."),
        ("Shared", "Approvals and audit", "One set of rules decides what needs approval, and every action is logged."),
        ("Shared", "Plans and limits", "Usage is metered against your plan, and you are told before any limit is reached."),
    ])
    body = f'''{hero}
<section class="section section--tight"><div class="wrap duo duo--top">
  {section_head("How it fits together", "Six layers, from your tools to measured value.", "Read it from the bottom up: your tools stay where they are, Xevrion connects to them safely, runs four systems on one picture of your business and measures what changed.")}
  {B.platform_stack()}
</div></section>
<section class="section"><div class="wrap">
  {section_head("Four systems", "Each system solves one problem well.", "Start with the one that matters most. Every system you add shares the same data.")}
  <nav class="orient" aria-label="The four systems">{systems}</nav>
</div></section>
<section class="section"><div class="wrap">
  {section_head("Shared by every system", "What makes four systems one platform.")}
  {shared}
  <div class="section-foot"><span class="cluster" style="--gap:var(--s-5)">{arrow_link("Every capability", "/platform/capabilities", "platform:capx")}{arrow_link("Architecture", "/platform/architecture", "platform:arch")}{arrow_link("Learning and memory", "/product/learning-and-memory", "platform:learning")}</span>{arrow_link("Plans and prices", "/pricing", "platform:pricing")}</div>
</div></section>
{cta_final("Start with one system. Add the rest when it pays.", "Create your workspace and connect your first tools, or take the guided tour first.", where="platform")}'''
    site.add(Page("/platform", "Platform overview", "How Xevrion Ops fits together: your tools, one model of your business, four systems, human control and a Value Ledger of every result.",
                  body, env="decisions", crumbs=[("Home", "/"), ("Platform", None)], priority=0.9, nav_current="/platform"))


def how_it_works(site: Site) -> None:
    hero = B.page_hero([("Home", "/"), ("How it works", None)], "How it works", "From connected data to measured value, in eight stages.",
                       "Every result goes through the same loop. Each stage below says what happens, with one example customer running through all eight.",
                       where="how")
    stages = []
    for i, s in enumerate(D.LOOP):
        stages.append(f'''<section class="walk__stage" id="{s["name"].lower()}" data-stage="{esc(s["name"])}" data-summary="{esc(SUMMARIES[s["name"]])}" aria-labelledby="st-{i}">
  <span class="label label--violet">Stage {i + 1:02d} · {esc(s["name"])}</span>
  <h2 id="st-{i}">{esc(s["title"])}</h2>
  <p class="lead">{esc(s["what"])}</p>
  {explain(WALK_EXAMPLES[s["name"]], "In the example")}
</section>''')
    first = D.LOOP[0]
    body = f'''{hero}
<section class="section section--tight"><div class="wrap">
  <div class="walk">
    <div class="walk__visual stage" data-viz="pipeline" aria-hidden="true">
      <div class="walk__centre"><div><span class="n" data-n>STAGE 01 OF 08</span><span class="t" data-t>{esc(first["name"])}</span><span class="s" data-s>{esc(SUMMARIES[first["name"]])}</span></div></div>
    </div>
    <div class="walk__stages">{"".join(stages)}</div>
  </div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Why a loop", "The last stage feeds the first.", "Xevrion checks whether each action worked, values it and uses the result to make the next decision better.")}
  <div data-reveal>{caps([("Stages 1-3", "See", "Connect, understand and identify: turn scattered records into a short list of what matters."),
                          ("Stages 4-5", "Act", "Decide and act: recommend with honest confidence, then do the approved work in your tools."),
                          ("Stages 6-8", "Prove", "Verify, value and learn: check the outcome, measure it in pounds and improve.")])}</div>
</div></section>
{cta_final("See the loop run on your own tools.", "Start with one system and your first connected tools, or take the guided tour first.", where="how")}'''
    site.add(Page("/how-it-works", "How Xevrion works", "The eight stages from connected data to measured value: connect, understand, identify, decide, act, verify, value and learn, with one worked example.",
                  body, env="decisions", crumbs=[("Home", "/"), ("How it works", None)], priority=0.9, nav_current="/how-it-works",
                  schema=[{"@context": "https://schema.org", "@type": "HowTo", "name": "How Xevrion turns business data into measured value",
                           "step": [{"@type": "HowToStep", "position": i + 1, "name": s["name"], "text": s["what"]} for i, s in enumerate(D.LOOP)]}]))


def build(site: Site) -> None:
    platform(site)
    how_it_works(site)
