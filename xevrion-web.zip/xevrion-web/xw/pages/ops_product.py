"""The five product pages: Revenue, Customer Operations, Business Operations, Decision Intelligence, Value Ledger.
Every page follows one shape, so each reads in a minute: what it does (the hero), what it does step by step, one
worked example, what stays in your control, three questions and the next step."""
from __future__ import annotations

from .. import blocks as B
from .. import charts
from .. import data as D
from ..components import arrow_link, claim, cta_final, faq, faq_schema, ledger_list, section_head, table, walkthrough
from ..html import esc, icon
from ..shell import Page, Site


def _tools(system_key: str) -> str:
    chips = "".join(f'<a class="chip" href="/integrations/{c["key"]}">{esc(c["name"])}<small>{"read + write" if c["reads"] and c["writes"] else "write" if c["writes"] else "read"}</small></a>'
                    for c in D.CONNECTORS if system_key in c["systems"])
    return f'<div class="chip-list">{chips}</div>'


def _control(items: list[tuple[str, str, str]]) -> str:
    return table(["Action", "Default", "Can be changed to"], items, caption="Set per organisation. Every action is logged either way.")


def _sec(inner: str, tight: bool = False) -> str:
    return f'<section class="section{" section--tight" if tight else ""}"><div class="wrap">{inner}</div></section>'


SYS_OF = {"revenue": "revenue", "customers": "customer-operations", "operations": "business-operations", "decisions": "decision-intelligence"}


def _walk(title: str, key: str) -> str:
    """The start-to-finish walkthrough section for one service, with the way to its full capability list."""
    start, steps, finish = WALKS[key]
    capx = arrow_link(f"All {B.capability_total(SYS_OF[key])} {title} capabilities", "/platform/capabilities", "product:capx")
    return _sec(section_head("Start to finish", f"What {title} does, step by step.")
                + walkthrough(steps, start, finish, label=f"What {title} does, from start to finish") + f'<div class="section-foot">{capx}</div>')


def _example(eyebrow: str, title: str, lead: str, figure: str, note: str = "") -> str:
    """One worked example: a short explanation beside the picture that shows it."""
    return _sec(f'''<div class="duo">{section_head(eyebrow, title, lead)}
      <figure class="panel glass glass--ambient" data-reveal style="margin:0">{figure}{f'<p class="note">{note}</p>' if note else ""}</figure></div>''')


def _in_control(system_key: str, title: str, controls: list[tuple[str, str, str]]) -> str:
    return _sec(f'''<div class="two-col"><div>{section_head("Control", "You approve what matters.", level=2)}{_control(controls)}</div>
      <div>{section_head("Tools", f"Works with the tools you already use.", level=2)}{_tools(system_key)}<p class="note">Each connects with your own account. {arrow_link("What each one reads and writes", "/integrations", f"product:{system_key}:integrations")}</p></div></div>''')


KICKER = {"revenue": "AI sales prospecting", "customer-operations": "Customer retention software", "business-operations": "Business process automation",
          "decision-intelligence": "Decision intelligence and forecasting", "value-ledger": "Automation ROI, measured"}


def _page(site, path, key, env, title, h1, lead, meta, visual, sections, qa, cta):
    crumbs = [("Home", "/"), ("Platform", "/platform"), (title, None)]
    hero = B.page_hero(crumbs, title + (" · " + KICKER[key] if key in KICKER else ""), h1, lead, visual=visual, where=key)
    qa = qa[:3]
    body = hero + "".join(sections) + f'''
<section class="section" id="questions"><div class="wrap duo duo--top">
  {section_head("Questions", f"About {title}.")}
  <div>{faq(qa, open_first=True)}</div>
</div></section>''' + cta_final(*cta, where=key)
    site.add(Page(path, title, meta, body, env=env, crumbs=crumbs, schema=[faq_schema(qa)], priority=0.9, group="Product"))


# (what you bring, the steps, what you get). who: "x" is Xevrion; "you" is a step where you approve or decide.
WALKS = {
    "revenue": (("Your market and your best customers", "Won deals, your CRM and website enquiries"), [
        {"who": "x", "title": "Learns who you sell to", "what": "Reads the deals you have won and writes an ideal-customer profile.", "out": "A profile you can edit"},
        {"who": "x", "title": "Finds companies that fit", "what": "Searches the sources you allow, plus enquiries from your website and inbox.", "out": "A clean list, each with its source"},
        {"who": "x", "title": "Spots buying signals and ranks them", "what": "Scores each company on fit, signal and expected value, and says why.", "out": "A short list, best first"},
        {"who": "you", "role": "You approve", "title": "Reaches out with a relevant message", "what": "Drafts a first message about the signal it found. Nothing is sent until you say so.", "out": "Approved messages and follow-ups"},
        {"who": "x", "title": "Tracks replies and learns", "what": "Traces each won deal back to the signal and message that started it.", "out": "Revenue in the Value Ledger"},
    ], ("More of the right customers", "With every pound of new revenue traced to its source")),
    "customers": (("Your customers' emails, tickets and invoices", "From your inbox, support tool and billing"), [
        {"who": "x", "title": "Joins every customer record", "what": "Brings emails, tickets, invoices and notes into one view of each customer.", "out": "One record per customer"},
        {"who": "x", "title": "Answers and routes requests", "what": "Sorts each request by urgency and drafts a reply from your approved answers.", "out": "Replies ready, targets tracked"},
        {"who": "x", "title": "Scores health and spots risk", "what": "Builds health from usage, support, billing and tone, and shows why it moved.", "out": "An early warning, weeks ahead"},
        {"who": "you", "role": "You approve", "title": "Recommends the right action", "what": "The account owner gets a suggested next step with its expected effect.", "out": "An approved intervention"},
        {"who": "x", "title": "Checks that it worked", "what": "Measures what changed for the customer and records the revenue kept.", "out": "Retention proven in the ledger"},
    ], ("Customers answered on time, and kept", "With renewals protected before they are at risk")),
    "operations": (("Your everyday work", "Requests, approvals and records across your tools"), [
        {"who": "x", "title": "Maps how work really moves", "what": "Follows real requests through your tools, step by step, with owners and times.", "out": "A process map from real data"},
        {"who": "x", "title": "Measures every step", "what": "Time taken, time waiting, errors and cost, for each step and each month.", "out": "The true cost of the process"},
        {"who": "x", "title": "Finds the bottleneck", "what": "Shows the one step causing most of the delay and cost.", "out": "The step to fix first"},
        {"who": "you", "role": "You approve", "title": "Redesigns and automates it", "what": "Routine steps run by themselves; approvals and exceptions go to the right person.", "out": "An approved workflow, running"},
        {"who": "x", "title": "Proves the saving", "what": "Measures the new process against your own 90-day baseline.", "out": "A verified saving in pounds"},
    ], ("Hours back and fewer mistakes", "Measured against your own before-and-after numbers")),
    "decisions": (("Your business numbers", "From accounting, CRM and operations tools"), [
        {"who": "x", "title": "Checks and joins your data", "what": "Runs quality checks first and shows any gaps instead of filling them in.", "out": "Data you can trust"},
        {"who": "x", "title": "Tracks the measures that matter", "what": "Defines each KPI once and calculates it the same way everywhere.", "out": "Live KPIs"},
        {"who": "x", "title": "Explains and forecasts", "what": "Shows why a number moved and where it is heading, with an honest range.", "out": "Reasons and ranges"},
        {"who": "you", "role": "You decide", "title": "Compares options, you decide", "what": "Scenarios side by side with their expected effect; you record the decision.", "out": "A decision with its evidence"},
        {"who": "x", "title": "Checks how accurate it was", "what": "Scores each forecast against what really happened.", "out": "Numbers you know how far to trust"},
    ], ("Better decisions, with the reasoning kept", "And a track record showing how good the forecasts are")),
}


# ------------------------------------------------------------------------------------------------ Revenue
def revenue(site: Site) -> None:
    top6 = [["Harbour Freight Ltd", "Opening a second depot", "£24,000", "62%", "£14,900"],
            ["Aldgate Build Partners", "Published a tender", "£31,000", "41%", "£12,700"],
            ["Northgate Logistics", "Asked for a quote", "£18,400", "55%", "£10,100"],
            ["Clearline Networks", "Hiring an operations manager", "£16,000", "48%", "£7,700"],
            ["Brightwell Civils", "Won a council contract", "£22,000", "33%", "£7,300"],
            ["Tamar Data Services", "Asked about pricing", "£12,000", "52%", "£6,200"]]
    qa = [("Does Xevrion send emails on its own?", "Not unless you allow it. By default every message is a draft for a person to approve. You can later allow, for example, follow-ups to prospects who have already replied."),
          ("How is expected value calculated?", "Likely deal value multiplied by the chance of converting, both from your own history where it exists. Each score shows its inputs, and your team can override it."),
          ("Will it replace my CRM?", "No. Salesforce or HubSpot stay your record of deals. Xevrion reads from them and, where you allow it, writes leads, tasks and updates back.")]
    visual = B.viz_stage("opportunity", "Each dot is a company: bigger means more likely value, violet means a buying signal. Hover for the reason.", height=520)
    sections = [
        _walk("Revenue", "revenue"),
        _sec(f'''<div class="duo duo--top">{section_head("Example", "The six prospects worth your time this week.", "120 companies narrowed to the six with the highest expected value: likely deal value times the chance of winning it.")}
          <div data-reveal>{table(["Company (fictional)", "Signal", "Likely value", "Chance", "Expected value"], top6, caption="Illustrative example: fictional companies.")}</div></div>'''),
        _in_control("revenue", "Revenue", [["Send a first message", "Draft for approval", "Send within policy"], ["Send a follow-up", "Draft for approval", "Send after a reply"], ["Create a lead in your CRM", "Automatic, logged", "Draft for approval"]]),
    ]
    _page(site, "/product/revenue", "revenue", "revenue", "Revenue", "Spend your time on the customers most likely to buy.",
          "Xevrion finds companies that fit, spots real buying signals, ranks every prospect by expected value and helps your team reach the best ones first.",
          "Xevrion Revenue finds and ranks the prospects most likely to buy, explains why, drafts relevant outreach for approval and records the revenue that results.",
          visual, sections, qa, ("Find the prospects worth your time.", "Start with Revenue, or take the guided tour first."))


# ------------------------------------------------------------------------------------------------ Customer Operations
def customer_operations(site: Site) -> None:
    drivers = [("Support tickets this month", "3 → 9", "risk"), ("Average reply time", "4 hrs → 2 days", "risk"), ("Renewal due", "45 days", "watch"),
               ("Product usage", "−12%", "watch"), ("Invoices paid on time", "Yes", "ok")]
    qa = [("How is customer health calculated?", "From usage, support volume and reply times, billing and the tone of conversations. The score always shows its drivers, so you can see why it moved, and you can change the weights."),
          ("Does Xevrion reply to customers automatically?", "By default it drafts replies for your team to approve. You can allow specific, low-risk replies to go out within a policy, and every reply is logged."),
          ("What happens when a risk is flagged?", "The account owner gets the risk, its drivers and a recommended action with its expected effect. They approve, change or dismiss it, and Xevrion later checks whether it worked.")]
    visual = B.viz_stage("orbit", "Press play to watch 45 days of one customer: health falls, an action is approved and the outcome is measured.", height=520,
                         panel='<div class="viz__readout" data-readout data-tone="neutral"><span class="label" data-o="day">Day 0</span><span class="big num" data-o="health">82</span><span class="sub" data-o="event">Healthy. Nothing needs attention.</span></div>'
                               '<div class="viz__controls"><button class="play" type="button" data-play>' + icon("play", 16) + '<span>Play 45 days</span></button><label class="range-input">Day <input type="range" min="0" max="45" value="0" data-day aria-label="Day of the example"><output data-day-out>0</output></label></div>')
    sections = [
        _walk("Customer Operations", "customers"),
        _example("Example", "A health score that shows why it moved.", "Health fell from 82 to 61. Each driver is listed with its direction, so the account owner knows exactly what to fix.",
                 charts.health_gauge(82, 61, drivers)),
        _in_control("customer-operations", "Customer Operations", [["Reply to a customer", "Draft for approval", "Send within policy"], ["Alert the team in Slack", "Automatic, logged", "Off"], ["Offer a discount or upgrade", "Suggest only", "Always needs approval"]]),
    ]
    _page(site, "/product/customer-operations", "customer-operations", "customers", "Customer Operations", "See the customers you might lose while there is still time.",
          "Xevrion joins every conversation, ticket and invoice into one view of each customer, explains their health and warns you weeks before a renewal is at risk.",
          "Xevrion Customer Operations builds one view of each customer, explains health scores, flags renewal risk early and recommends approved interventions.",
          visual, sections, qa, ("Keep the customers you have worked hard to win.", "Start with Customer Operations, or take the guided tour first."))


# ------------------------------------------------------------------------------------------------ Business Operations
def business_operations(site: Site) -> None:
    qa = [("Which processes suit it best?", "Repetitive, rules-based work that moves between people and tools: purchase approvals, invoice matching, document collection and handovers. Work that needs judgement keeps a person in the loop."),
          ("What if an automated step fails?", "Every step can be retried without doing the work twice. If the outcome is unclear, Xevrion marks it for review and routes it to a person instead of guessing."),
          ("How is the saving measured?", "Against a baseline from your own records, usually the previous 90 days, using hourly costs you set. The calculation is shown on the Value Ledger line.")]
    visual = B.viz_stage("process", "A purchase-approval process. Work flows left to right; queues show where it waits. Switch between before and after.", height=500,
                         panel='<div class="viz__readout" data-readout><span class="label" data-o="mode">Before automation</span><span class="big num" data-o="cost">£6,840/mo</span><span class="sub" data-o="detail">61 hours a month · 8.2% error rate</span></div>'
                               '<div class="viz__controls"><div class="pill-nav" role="group" aria-label="Show the process"><button type="button" aria-pressed="true" data-mode="before">Before</button><button type="button" aria-pressed="false" data-mode="after">After</button></div></div>')
    sections = [
        _walk("Business Operations", "operations"),
        _example("Example", "One process, before and after.", "A purchase-approval process where finance review was the bottleneck. Fixing that one step cut the hours, the errors and the cost.",
                 charts.before_after([("Hours per month", 61, 18, "hrs"), ("Error rate", 8.2, 2.1, "pct"), ("Monthly cost", 6840, 2020, "gbp")]),
                 f'Saving: <strong>£4,820 a month</strong>. {claim("illustrative")}'),
        _in_control("business-operations", "Business Operations", [["Run a routine step", "Automatic, logged", "Draft for approval"], ["Approve spend over your limit", "Always a person", "Cannot be automated"], ["Handle an exception", "Routed to its owner", "Routed to a named team"]]),
    ]
    _page(site, "/product/business-operations", "business-operations", "operations", "Business Operations", "Find the process quietly costing you most, then fix it.",
          "Xevrion measures every step of your processes, finds the bottleneck and automates what should be automatic, keeping people on the decisions that matter.",
          "Xevrion Business Operations maps real processes, measures cost and delay per step, finds the bottleneck and automates it with approvals, proving the saving.",
          visual, sections, qa, ("Give your team its hours back.", "Start with Business Operations, or take the guided tour first."))


# ------------------------------------------------------------------------------------------------ Decision Intelligence
def decision_intelligence(site: Site) -> None:
    qa = [("Does Xevrion predict the future?", "No one can. Xevrion gives ranges and confidence levels, explains what drives them and tracks how accurate its forecasts turn out to be."),
          ("Where do the numbers come from?", "From your connected accounting, CRM and operations tools. Data-quality checks run first, and any gaps are shown to you rather than filled in silently."),
          ("Is scenario planning in every plan?", "Scenario planning is included in Scale and Custom. KPIs, diagnosis and forecasts come with Decision Intelligence on any plan.")]
    visual = B.viz_stage("scenario", "Four possible next quarters. Move the slider to change one input and watch every scenario update.", height=520,
                         panel='<div class="viz__controls"><label class="range-input">Pipeline conversion <input type="range" min="12" max="24" value="18" step="1" data-conv aria-label="Pipeline conversion rate, percent"><output data-conv-out>18%</output></label></div>')
    sections = [
        _walk("Decision Intelligence", "decisions"),
        _example("Example", "Four possible quarters, side by side.", "Each scenario has an expected value, a range and a confidence level. The least certain one has the widest range, which is the honest way to show it.",
                 charts.scenario_ranges(D.SCENARIOS)),
        _in_control("decision-intelligence", "Decision Intelligence", [["Publish a KPI dashboard", "Automatic", "Owner approval"], ["Send a forecast to the board", "Draft for approval", "Always needs approval"], ["Record a decision", "Owner records", "Cannot be automated"]]),
    ]
    _page(site, "/product/decision-intelligence", "decision-intelligence", "decisions", "Decision Intelligence", "Plan with ranges, not guesses.",
          "Xevrion turns your numbers into forecasts and scenarios with honest ranges, recommends what to do and records what you decided, then checks how accurate it was.",
          "Xevrion Decision Intelligence delivers KPIs, diagnosis, forecasts and scenarios with honest ranges, recommendations and calibrated accuracy tracking.",
          visual, sections, qa, ("Make the next big decision with the full picture.", "Start with Decision Intelligence, or take the guided tour first."))


# ------------------------------------------------------------------------------------------------ Value Ledger
def value_ledger(site: Site) -> None:
    qa = [("Who decides what counts as value?", "The method for each category is agreed with you during onboarding, including your prices, hourly costs and baseline period. Every line shows its method, and you can exclude any line."),
          ("Why is low-confidence value not counted?", "Because a return you cannot defend is worthless. Showing it keeps you informed; excluding it keeps the headline number conservative."),
          ("Can I export the ledger?", "Yes. Owners and administrators can export the ledger from the portal at any time, to share with a finance team or board.")]
    months = [("Apr", 9800), ("May", 14200), ("Jun", 17600), ("Jul", 21900), ("Aug", 25300), ("Sep", D.LEDGER_COUNTED)]
    hero_visual = f'<figure class="panel glass glass--intel" style="margin:0" data-reveal><div class="viz-head" style="display:flex;justify-content:space-between;gap:12px;margin-bottom:var(--s-4)"><span class="label">Counted value vs Xevrion cost, by month</span>{claim("illustrative")}</div>{charts.value_bars(months, D.LEDGER_COST)}</figure>'
    sections = [
        _sec(section_head("Cause and effect", "Every pound traced to what caused it.", "Read each row left to right: what Xevrion did, what changed in your business, what it was worth, and how sure we are.")
             + f'<div class="causal-wrap panel glass glass--ambient" data-reveal>{charts.causal(D.LEDGER)}</div>'),
        _sec(f'''<div class="duo duo--top">{section_head("What counts", "Four kinds of value. Nothing else.", "Strict categories keep the total believable.")}
          {ledger_list([("Revenue generated", "New revenue from deals Xevrion helped find or progress.", "Revenue"),
                        ("Revenue protected", "Revenue kept because a risk was caught in time.", "Retention"),
                        ("Costs reduced", "Money no longer spent, including hours at your own hourly cost.", "Cost"),
                        ("Time saved", "Hours given back, shown for context and already inside costs reduced.", "Hours")])}</div>'''),
    ]
    _page(site, "/product/value-ledger", "value-ledger", "pricing", "Value Ledger", "Every result in pounds, with the evidence behind it.",
          "The Value Ledger records what each action achieved, what it was worth, how that was worked out and how sure we are, so you can check the return every month.",
          "The Xevrion Value Ledger records every result in pounds with its evidence, method and confidence, and compares counted value with what Xevrion costs.",
          hero_visual, sections, qa, ("Know exactly what Xevrion is worth to you.", "The Value Ledger is included in every plan."))


def build(site: Site) -> None:
    revenue(site)
    customer_operations(site)
    business_operations(site)
    decision_intelligence(site)
    value_ledger(site)
