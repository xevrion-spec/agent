"""Resources: guides, product updates, FAQ, help, live status and documentation."""
from __future__ import annotations

from .. import blocks as B
from .. import data as D
from ..components import answer_block, arrow_link, cta_final, explain, faq, faq_schema, index_list, section_head, table
from ..html import esc, icon
from ..shell import APP, BUILT, Page, Site
from .ops_commercial import PRICING_FAQ
from .ops_home import FAQ as HOME_FAQ

# ------------------------------------------------------------------------------------------------ guides
GUIDES = [
    ("choosing-your-first-system", "Choosing your first system", "How to pick the one system that will pay back fastest, using three questions about your business.", [
        ("Start where the money is leaking", "The best first system is the one closest to a problem you can already put a rough number on. If you know deals are going cold, start with Revenue. If renewals surprise you, start with Customer Operations. If a process eats hours every week, start with Business Operations. If big decisions keep being argued over conflicting numbers, start with Decision Intelligence."),
        ("Ask three questions", "First: which problem costs us the most each month? Second: do we have the data for it in tools Xevrion connects to? Third: who would own the result? The system where all three answers are clear is your first system."),
        ("Keep the first goal small and measurable", "Pick one goal you could check in 90 days: reply to high-intent leads within an hour, flag renewal risk 30 days out, cut a named process from 61 to 20 hours a month. A small goal that is measured beats a big one that is not."),
        ("Plan the second system", "Because every system shares the same data, the second one starts faster. Most businesses add it once the Value Ledger shows the first is paying for itself. Growth includes two systems; Scale includes all four."),
    ]),
    ("preparing-your-tools", "Preparing your tools and data", "What to check before onboarding so your first connections work first time.", [
        ("List the tools that hold the problem", "Write down where the information for your first goal lives: your inbox, your CRM, your support desk, your accounting software. Those are the tools to connect first; your plan allows 3, 12 or 50."),
        ("Make sure the right person can sign in", "Each connection is made by someone who can sign in to that tool and approve access for your organisation. For Microsoft 365, that may be your IT administrator; for Xero, someone with access to the right organisation."),
        ("Decide read or write for each tool", "Every tool can be connected read-only. Give write access only where Xevrion needs to act, for example creating tickets in Zendesk or draft invoices in Xero. Sending email is always a separate permission."),
        ("Expect a data-quality report", "Xevrion checks duplicates, gaps and inconsistencies before relying on your data, and shows you what it found. Fixing the worst issues early makes every later result more reliable."),
    ]),
    ("setting-approval-rules", "Setting approval rules that work", "How to keep people in control without slowing everything down.", [
        ("Start at recommend", "At first, let Xevrion recommend and draft while people approve. You will quickly see which kinds of action are always approved unchanged."),
        ("Promote one task at a time", "When a specific, low-risk task has been approved unchanged many times, such as posting an alert in Slack or creating a draft invoice, allow it to run within a policy. Keep a person on anything that spends money, changes a price or speaks for you in a new way."),
        ("Set limits, not just switches", "Good policies have limits: amounts, recipients, times of day or volumes. Anything outside the limit goes back to a person."),
        ("Review the audit trail monthly", "Every action is logged with who approved it. A short monthly review shows whether any rule is too loose or too strict."),
    ]),
    ("reading-your-value-ledger", "Reading your Value Ledger", "How to judge whether Xevrion is worth what it costs, from evidence rather than claims.", [
        ("Read the counted total first", "The headline is counted value: high and medium-confidence lines only. Compare it with your plan cost to see the measured return."),
        ("Open the largest lines", "For each big line, check the evidence (the record in your own tools), the method (how the pound value was calculated) and the attribution (how much Xevrion can claim)."),
        ("Look at what is not counted", "Low-confidence value is shown but excluded. If a line you believe in is marked low, the method explains why, and better data often moves it up."),
        ("Question anything", "Every line can be questioned and excluded. A ledger you trust is worth more than a big number you do not."),
    ]),
]


def guides(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("Guides", None)]
    body = f'''{B.page_hero(crumbs, "Guides", "Plain-English guides to getting value quickly.", "Short, practical guides for the people who will run Xevrion day to day. No jargon, no fluff.", ctas=False)}
<section class="section section--tight"><div class="wrap">{index_list([(t, d, f"/guides/{s}") for s, t, d, _ in GUIDES], event_prefix="guides:")}</div></section>'''
    site.add(Page("/guides", "Guides", "Practical guides to Xevrion Ops: choosing your first system, preparing your tools, setting approval rules and reading your Value Ledger.", body, crumbs=crumbs, priority=0.6))
    for slug, title, desc, parts in GUIDES:
        c = [("Home", "/"), ("Resources", "/resources"), ("Guides", "/guides"), (title, None)]
        secs = "".join(f"<h2>{esc(h)}</h2><p>{esc(p)}</p>" for h, p in parts)
        others = [(t, d, f"/guides/{s}") for s, t, d, _ in GUIDES if s != slug]
        body = f'''{B.page_hero(c, "Guide", title, desc, ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top"><article class="prose">{secs}</article>
<aside><p class="label" style="margin-bottom:12px">More guides</p>{index_list(others)}</aside></div></section>'''
        site.add(Page(f"/guides/{slug}", title, desc, body, crumbs=c, priority=0.5, og_type="article",
                      schema=[{"@context": "https://schema.org", "@type": "Article", "headline": title, "description": desc, "datePublished": BUILT.isoformat(),
                               "author": {"@type": "Organization", "name": "Xevrion"}, "publisher": {"@type": "Organization", "name": "Xevrion"}}]))


# ------------------------------------------------------------------------------------------------ updates
UPDATES = [
    ("2026-09-24", "24 September 2026", "New Xevrion websites", ["Rebuilt xevrion.co.uk, ops.xevrion.co.uk and the portal from scratch: plain-English explanations, interactive examples and published prices.",
                                                                "A guided tour of every system with no sign-up.", "Cookieless, first-party usage measurement that respects Do Not Track and Global Privacy Control."]),
    ("2026-09-23", "23 September 2026", "Xevrion 1.7.0: more connections, more control", ["Eight new connectors: Salesforce, Slack, Zendesk, Intercom, Segment, Xero, QuickBooks Online and Notion.",
                                                                                          "Microsoft 365 now connects to your organisation's own directory.",
                                                                                          "Bring your own app: connect any tool through an app your IT team registers, with its secret sealed.",
                                                                                          "Bank payments are matched to invoices automatically by exact reference and amount.",
                                                                                          "Reliability and quality measures for every service, with alerts before problems reach you.",
                                                                                          "Stronger data deletion: erasing an organisation now removes its data from every service."]),
    ("2026-09", "September 2026", "Xevrion 1.6: the professional platform", ["Customer portal with team management, roles, invitations and ownership transfer.",
                                                                               "Two-factor sign-in with authenticator apps and one-time recovery codes.",
                                                                               "Plans and limits enforced by the platform; usage metered per organisation.",
                                                                               "Onboarding in eight save-and-resume steps; cancellation, export and deletion built in."]),
]


def updates(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("Product updates", None)]
    items = "".join(f'<li data-reveal><time datetime="{d}">{esc(label)}</time><div><h2>{esc(t)}</h2><ul class="prose">{"".join(f"<li>{esc(x)}</li>" for x in pts)}</ul></div></li>'
                    for d, label, t, pts in UPDATES)
    body = f'''{B.page_hero(crumbs, "Product updates", "What changed, and when.", "Every meaningful change to Xevrion, newest first, in plain English.", ctas=False)}
<section class="section section--tight"><div class="wrap"><ol class="updates">{items}</ol></div></section>'''
    site.add(Page("/updates", "Product updates", "Xevrion Ops product updates: new connectors, bring-your-own-app connections, automatic payment matching, reliability measures and the new websites.",
                  body, crumbs=crumbs, priority=0.6))


# ------------------------------------------------------------------------------------------------ faq / help / status
MORE_FAQ = [
    ("Do you offer calls or meetings?", "No. Xevrion works in writing: everything you need is published here, the guided tour shows the product and questions are answered by email. That keeps answers precise and on the record."),
    ("Which tools does Xevrion connect to?", "Gmail, Microsoft 365, any IMAP/SMTP mailbox, HubSpot, Salesforce, Slack, Zendesk, Intercom, Segment, Xero, QuickBooks Online, Notion and your website. Each integration page lists exactly what is read and written."),
    ("Where does Xevrion run?", "The websites are served by Cloudflare. The platform and its database run on Xevrion's own servers at OVHcloud. The AI model runs on Cloudflare Workers AI."),
]


def faq_page(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("FAQ", None)]
    allq = HOME_FAQ + [q for q in PRICING_FAQ if q[0] not in {x[0] for x in HOME_FAQ} and q[0] != "Can we cancel?"] + MORE_FAQ
    body = f'''{B.page_hero(crumbs, "FAQ", "Straight answers to common questions.", "Cannot find yours? Ask the assistant or write to us.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  <div>{B.ask()}</div>
  <div>{faq(allq, open_first=True)}</div>
</div></section>'''
    site.add(Page("/faq", "Frequently asked questions", "Answers about Xevrion Ops: what it does, pricing and payment, security, AI, integrations, onboarding and cancellation.",
                  body, crumbs=crumbs, schema=[faq_schema(allq)], priority=0.7))


def help_page(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("Help", None)]
    paths = [["Signing in, passwords and two-factor", "Your account settings in the portal. Resetting a password signs out every session.", "Portal"],
             ["Adding or removing team members", "The team area of the portal (owners and administrators). Invitations are single-use and expire.", "Portal"],
             ["Connecting or reconnecting a tool", "The integrations area of the portal. If a tool reports a permission problem, reconnect and approve the missing permission.", "Portal"],
             ["Invoices and payment references", "The billing area of the portal. Your payment reference is on every invoice.", "Portal"],
             ["Something is not working", "Raise a support request from the portal. Urgent requests alert the team straight away.", "Portal"],
             ["A question before buying", "Ask the assistant here, or send a written question.", "Website"]]
    body = f'''{B.page_hero(crumbs, "Help centre", "Get help, fast.", "Most answers are one click away in your portal. For anything else, raise a support request or write to us: every request is prioritised by urgency and answered in writing.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top duo--wide-first">
  <div data-reveal>{table(["I need help with", "Where to go", "Where"], paths)}
    <div class="cluster" style="margin-top:var(--s-5);--gap:var(--s-5)">{arrow_link("Open the portal", APP, "help:portal")}{arrow_link("System status", "/status", "help:status")}{arrow_link("Documentation", "/docs", "help:docs")}</div></div>
  <div>{B.ask()}</div>
</div></section>'''
    site.add(Page("/help", "Help centre", "Get help with Xevrion Ops: signing in, team members, connecting tools, invoices and support requests, plus an assistant for quick questions.",
                  body, crumbs=crumbs, priority=0.6))


def status(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("System status", None)]
    watched = [["API and portal", "Availability and response time, checked continuously"], ["Background work", "Queues, retries and dead-letter handling"],
               ["Connections", "Health checks and error rates per connected tool"], ["Error budgets", "Alerts that fire when reliability targets are at risk, before customers notice"]]
    body = f'''{B.page_hero(crumbs, "System status", "Is Xevrion working right now?", "When you open this page, your browser asks the Xevrion platform to check every service behind it, so the answer is live, not a status someone typed.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  <div class="live glass glass--elevated" data-live-status data-state="unknown" role="status" aria-live="polite"><span class="live__dot" aria-hidden="true"></span><div><strong>Xevrion platform</strong><span data-status-text>Checking from your browser…</span></div></div>
  <div data-reveal>{section_head("What we watch", "Monitoring behind the scenes.", level=2)}{table(["Area", "What is monitored"], watched)}</div>
</div></section>'''
    site.add(Page("/status", "System status", "Live status of the Xevrion Ops platform, checked directly from your browser, and what is monitored behind the scenes.",
                  body, crumbs=crumbs, priority=0.5))


# ------------------------------------------------------------------------------------------------ docs
DOCS = [
    ("getting-started", "Getting started", "Create your account, choose a plan and complete onboarding.", [
        ("1. Create your account", f"Open the app at {APP}. Enter your name, work email and a password of at least 12 characters, then enter the verification code we email you."),
        ("2. Choose your plan", "In the portal, choose Start, Growth or Scale. An invoice with a payment reference is created and emailed to you."),
        ("3. Pay", "Pay the setup fee and set up the monthly standing order using the reference on your invoice. Payment details are only ever provided in your portal and invoice."),
        ("4. Complete onboarding", "Eight steps, saved as you go: business, goals, metrics, integrations, permissions, systems, automation and approvals. Nothing runs until all eight are recorded."),
        ("5. Connect your tools", "From Integrations, connect each tool with your own account and approve read and write separately."),
    ]),
    ("workspaces", "Workspaces, teams and roles", "How organisations, members and permissions work.", [
        ("Organisations", "Everything in Xevrion belongs to one organisation. Every request is checked against that organisation's membership and roles."),
        ("Roles", "Owners manage billing, deletion and ownership transfer. Administrators manage members other than owners. Members use the systems they are given."),
        ("Invitations", "Owners and administrators invite by email. Invitations are single-use, expire and only work for the invited address. They can be resent or revoked."),
        ("Sessions and two-factor", "Sessions last 12 hours and can be revoked. Turn on two-factor sign-in with any standard authenticator app; recovery codes are shown once."),
    ]),
    ("integrations", "Connecting integrations", "How connections are made, verified and removed.", [
        ("Connecting", "Choose a tool in Integrations, sign in on the tool's own page and approve the permissions. Some tools ask for one detail first: your Zendesk subdomain, Intercom region or Microsoft directory."),
        ("Verification", "Before a connection is used, Xevrion checks it works. The credential is stored in a separate secret store; the application keeps only a reference."),
        ("Your own app", "If your IT team prefers, register your own app with the vendor and enter its client ID and secret under Integrations. The secret is sealed and never shown again."),
        ("Errors", "If a tool rejects the connection you are asked to reconnect; a missing permission is named. Rate limits are respected using the vendor's own retry timing."),
        ("Disconnecting", "Disconnect any tool from Integrations. Cancelling your subscription revokes every connection automatically."),
    ]),
    ("api-overview", "API overview", "How the Xevrion API is organised and who can use it.", [
        ("Base address", "The Xevrion API is served from https://api.xevrion.co.uk. The portal is built on the same API."),
        ("Public endpoints", "A small number of endpoints are public: service health, written enquiries from the website and the website assistant. They are rate-limited and accept only what they need."),
        ("Customer endpoints", "Everything about your organisation requires a signed-in session and the right role in that organisation. Changes carry idempotency keys, so a retried request never applies twice."),
        ("Direct API access", "Personal API keys for direct integration are not generally available yet. If you need programmatic access, tell us what you want to build."),
    ]),
]


def docs(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("Documentation", None)]
    body = f'''{B.page_hero(crumbs, "Documentation", "How to set up and run Xevrion.", "Short, accurate reference pages for the people setting Xevrion up.", ctas=False)}
<section class="section section--tight"><div class="wrap">{index_list([(t, d, f"/docs/{s}") for s, t, d, _ in DOCS], event_prefix="docs:")}</div></section>'''
    site.add(Page("/docs", "Documentation", "Xevrion Ops documentation: getting started, workspaces and roles, connecting integrations and an overview of the API.", body, crumbs=crumbs, priority=0.6))
    for slug, title, desc, parts in DOCS:
        c = [("Home", "/"), ("Documentation", "/docs"), (title, None)]
        nav = "".join(f'<a href="/docs/{s}"{" aria-current=page" if s == slug else ""}>{esc(t)}</a>' for s, t, _, _ in DOCS)
        secs = "".join(f"<h2>{esc(h)}</h2><p>{esc(p)}</p>" for h, p in parts)
        body = f'''{B.page_hero(c, "Documentation", title, desc, ctas=False)}
<section class="section section--tight"><div class="wrap doc-layout"><nav class="doc-nav" aria-label="Documentation">{nav}</nav><article class="prose">{secs}</article></div></section>'''
        site.add(Page(f"/docs/{slug}", f"{title} · Documentation", desc + " Xevrion Ops documentation.", body, crumbs=c, priority=0.5, og_type="article"))


def resources(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", None)]
    items = [("Guides", "Plain-English guides to getting value quickly", "/guides"), ("Documentation", "Setting up and running Xevrion", "/docs"),
             ("Product updates", "What changed and when", "/updates"), ("FAQ", "Straight answers to common questions", "/faq"),
             ("Help centre", "Where to go for help", "/help"), ("System status", "Live platform health", "/status"),
             ("Security", "How your data and actions are protected", "/security"), ("AI and human control", "How Xevrion uses AI", "/ai")]
    body = f'''{B.page_hero(crumbs, "Resources", "Everything you need to understand, buy and run Xevrion.", "Guides, documentation, updates and answers, all written to be read by people rather than search engines.", ctas=False)}
<section class="section section--tight"><div class="wrap">{index_list(items, event_prefix="resources:")}</div></section>'''
    site.add(Page("/resources", "Resources", "Xevrion Ops resources: guides, documentation, product updates, FAQ, help centre, system status, security and AI transparency.",
                  body, crumbs=crumbs, priority=0.6, nav_current="/resources"))


def build(site: Site) -> None:
    resources(site)
    guides(site)
    updates(site)
    faq_page(site)
    help_page(site)
    status(site)
    docs(site)
