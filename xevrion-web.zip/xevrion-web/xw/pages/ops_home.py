"""Xevrion Ops homepage: what Xevrion is, the four systems, how it works from start to finish, the value it proves
and what it costs. Each section answers one question; everything deeper is one click away."""
from __future__ import annotations

from .. import blocks as B
from .. import data as D
from ..components import arrow_link, claim, cta_final, primary_ctas, section_head, walkthrough
from ..html import esc, icon
from ..shell import Page, Site

# the general questions (shown on the FAQ page, not here)
FAQ = [
    ("What is Xevrion Ops?",
     "A business operating platform. It connects the tools you already use, finds opportunities and risks across revenue, customers and operations, helps your team act on them with approval, and measures the value of every result in pounds."),
    ("Does Xevrion replace my CRM, support desk or accounting software?",
     "No. They stay your systems of record. Xevrion connects through your own accounts, reads what it needs and writes back only where you have given permission."),
    ("Will the AI take actions on its own?",
     "Only as far as you allow. Anything consequential needs a named person to approve it, and every action is logged with who approved it and when."),
    ("How do you measure the value Xevrion creates?",
     "Every verified result is recorded in the Value Ledger with its outcome, value in pounds, method, evidence and confidence. Low-confidence value is shown but never counted."),
    ("How much does it cost?",
     "Start is £2,500 a month with £2,000 one-time setup, Growth is £5,000 a month with £3,500 setup, and Scale is £10,000 a month with £7,000 setup. Prices exclude VAT."),
    ("Who can see my data?",
     "Only your organisation. Every request is checked against membership and role, and credentials for your connected tools are sealed in a separate secret store."),
    ("Can I cancel?",
     "Yes. Cancelling removes access, stops queued work and revokes connections straight away. You can export your data first, and an owner can then complete deletion."),
]

# the whole platform, start to finish (the same arrows as each service page)
HOW = (("Your existing tools", "CRM, inbox, support desk and accounts"), [
    {"who": "x", "title": "Connects your tools", "what": "Reads only what you allow, through your own accounts.", "out": "One picture of your business"},
    {"who": "x", "title": "Finds what matters", "what": "Spots the opportunities, risks and slow processes spread across them.", "out": "A short, ranked list"},
    {"who": "x", "title": "Recommends the next step", "what": "Explains each recommendation and what it is likely to be worth.", "out": "A clear proposal"},
    {"who": "you", "role": "You approve", "title": "Does the work with you", "what": "Carries out the approved step in your own tools, and logs it.", "out": "Work done, on the record"},
    {"who": "x", "title": "Measures the result", "what": "Checks what really happened and records its value in pounds.", "out": "A line in the Value Ledger"},
], ("Results you can check", "Every pound traced to what caused it"))


def _hero() -> str:
    cards = (
        '<div class="float-card core__card core__card--opp glass glass--elevated glass--edge" data-card-phases="2,3">'
        '<span class="label">Revenue opportunity</span><span class="float-card__value num">£18,400</span>'
        '<span class="float-card__sub">High-intent prospect, ranked 1 of 6</span></div>'
        '<div class="float-card core__card core__card--act glass glass--elevated glass--edge" data-card-phases="4">'
        '<span class="label">Operational saving</span><span class="float-card__value num">£4,820<small class="quiet" style="font-size:14px">/mo</small></span>'
        '<span class="float-card__sub">Approval process automated</span></div>'
        '<div class="float-card core__card core__card--val glass glass--elevated glass--edge" data-card-phases="5,6">'
        '<span class="label">Revenue protected</span><span class="float-card__value num" style="color:#fff">£7,300</span>'
        '<span class="float-card__sub">Renewal kept · verified</span></div>')
    phases = "".join(f"<li data-phase>{esc(p)}</li>" for p in ("Connect", "Understand", "Identify", "Decide", "Act", "Verify", "Value"))
    return f'''<section class="hero" aria-labelledby="hero-title">
  <div class="wrap hero__grid">
    <div class="hero__copy">
      <p class="eyebrow">Xevrion Ops · AI business operations platform</p>
      <h1 class="display-xl" id="hero-title">Your business,<br>continuously improving.</h1>
      <p class="lead">Xevrion connects your tools, finds what is worth acting on, helps your team do it with approval, and measures every result in pounds.</p>
      {primary_ctas(where="hero")}
      <p class="hero__note"><span>{icon("pricing", 16)} Published prices</span><span>{icon("lock", 16)} Your tools, your permissions</span><span>{icon("approval", 16)} People approve what matters</span></p>
    </div>
    <div class="hero__visual">
      <figure class="core" data-viz="core" aria-labelledby="core-cap">
        <div class="core__stage">{cards}</div>
        <ol class="core__phases" aria-label="The stages shown in the animation">{phases}</ol>
        <figcaption id="core-cap">{claim("illustrative")}<span>Business data becoming one measured result. The figures are an example.</span></figcaption>
      </figure>
    </div>
  </div>
</section>'''


def _systems() -> str:
    links = "".join(f'<a href="{s["href"]}" data-reveal data-event="orient:{s["key"]}"><span class="ic">{icon(s["icon"], 20)}</span>'
                    f'<h3>{esc(s["name"])}</h3><p>{esc(s["one"])}</p><span class="go">Explore {icon("arrow", 16)}</span></a>'
                    for s in D.SYSTEMS)
    return f'''<section class="section section--tight" aria-labelledby="orient-title">
  <div class="wrap">
    {section_head("The platform", "Four systems. One picture of your business.", "Each system solves one problem. They share the same data, so what one learns helps the others.", id_="orient-title")}
    <nav class="orient" aria-label="The four Xevrion systems">{links}</nav>
  </div>
</section>'''


def _how() -> str:
    start, steps, finish = HOW
    return f'''<section class="section" aria-labelledby="how-title" id="how">
  <div class="wrap">
    {section_head("How it works", "From your tools to a measured result.", id_="how-title")}
    {walkthrough(steps, start, finish, label="How Xevrion works, from start to finish")}
    <div class="section-foot">{arrow_link("The full walkthrough", "/how-it-works", "home:how-it-works")}</div>
  </div>
</section>'''


def _value() -> str:
    return f'''<section class="section" aria-labelledby="ledger-title">
  <div class="wrap">
    {section_head("The Value Ledger", "Every result in pounds, with its evidence.", "Each line links an action to its outcome, shows how the value was worked out and how sure we are. Low-confidence value is shown, never counted.", id_="ledger-title")}
    <div data-reveal>{B.ledger(open_first=False)}</div>
    <div class="section-foot"><span class="cluster">{claim("illustrative")}<span class="quiet small">One fictional month.</span></span>{arrow_link("How the Value Ledger works", "/product/value-ledger", "home:ledger")}</div>
  </div>
</section>'''


def _pricing() -> str:
    return f'''<section class="section" aria-labelledby="price-title">
  <div class="wrap">
    {section_head("Pricing", "Published prices. No surprises.", "Pick the systems, people and tools you need. You are told before any limit is reached.", id_="price-title")}
    <div data-reveal>{B.price_row()}</div>
    <div class="section-foot"><span class="quiet small">GBP, excluding VAT. Setup is paid once.</span>{arrow_link("Compare plans", "/pricing", "home:pricing")}</div>
  </div>
</section>'''


def build(site: Site) -> None:
    body = "".join([_hero(), _systems(), _how(), _value(), _pricing(),
                    cta_final("Start with one system. Measure everything.", "Create your workspace and connect your first tools, or take the guided tour first. No sign-up, no sales call.", where="home")])
    site.add(Page("/", "Xevrion Ops · Your business, continuously improving",
                  "Xevrion Ops connects your business data, finds opportunities, helps your team act with approval and measures the value in pounds. From £2,500 a month.",
                  body, priority=1.0, schema=[{
                      "@context": "https://schema.org", "@type": "SoftwareApplication", "name": "Xevrion Ops", "applicationCategory": "BusinessApplication",
                      "operatingSystem": "Web", "url": site.origin + "/", "publisher": {"@type": "Organization", "name": "Xevrion"},
                      "offers": [{"@type": "Offer", "name": p["name"], "price": str(p["monthly"]), "priceCurrency": "GBP",
                                  "description": f'£{p["setup"]:,} one-time setup, then £{p["monthly"]:,} per month'} for p in D.PLANS if p["monthly"]]}]))
