"""Deeper pages: Learning and memory, the capability index, architecture, the use-case library and
the glossary. Every mechanism described here is implemented in the platform (see catalog.py)."""
from __future__ import annotations

from .. import blocks as B
from .. import charts
from .. import data as D
from .. import webs
from ..catalog import ARCHITECTURE, CAPABILITIES, GLOSSARY, USE_CASE, USE_CASES, capability_code
from ..components import (answer_block, arrow_link, caps, claim, cta_final, explain, faq, faq_schema, flow, index_list, ledger_list,
                          section_head, table, walkthrough)
from ..html import esc, icon
from ..shell import Page, Site

SYS = {s["key"]: s for s in D.SYSTEMS}


def _sec(inner: str, *, id_: str = "", tight: bool = False) -> str:
    return f'<section class="section{" section--tight" if tight else ""}"{f" id={id_}" if id_ else ""}><div class="wrap">{inner}</div></section>'


# ------------------------------------------------------------------------------------------------ learning and memory
def learning(site: Site) -> None:
    crumbs = [("Home", "/"), ("Platform", "/platform"), ("Learning and memory", None)]
    visual = B.viz_stage("memory", "Events become connected memories; forecasts are scored against what happened, and trust follows the track record.", height=540,
                         panel='<div class="viz__readout" data-readout><span class="label" data-o="phase">Remembering</span>'
                               '<span class="big num" data-o="big">0 memories</span><span class="sub" data-o="sub">Events, decisions and lessons, joined to the customers and processes they concern.</span></div>'
                               '<ul class="viz-legend" aria-label="Kinds of memory">' + "".join(f'<li><i style="background:{c}"></i>{n}</li>' for n, c in (
                                   ("Customer", "#f8f8fb"), ("Deal", "#c6b5ff"), ("Ticket", "#f2c46b"), ("Invoice", "#b7b8c2"), ("Decision", "#a477ff"), ("Lesson", "#4fd69c"))) + '</ul>')
    steps = [{"who": "x", "title": "Remembers what happened", "what": "Events, decisions and lessons are kept on one audited timeline, for your organisation only."},
             {"who": "x", "title": "Scores every forecast", "what": "When the real numbers arrive, each forecast is compared with them and the error measured."},
             {"who": "x", "title": "Scores every recommendation", "what": "Once acted on, its real benefit and cost are compared with what was expected."},
             {"who": "x", "title": "Adjusts, within fixed limits", "what": "How far each forecast is trusted follows its track record. Every change is recorded with its reason."}]
    errors, trust = [31, 26, 19, 13, 9], [0.69, 0.74, 0.81, 0.87, 0.91]
    keep = [["Business memory", "Events, decisions and lessons", "For as long as you are a customer", "Deleted when an owner completes deletion"],
            ["Learning records", "How forecasts and recommendations performed", "For as long as you are a customer", "Deleted with your organisation's data"],
            ["Approved knowledge", "Procedures and answers your team approved", "Until it expires or is replaced", "Expired items are flagged, never silently used"],
            ["Financial records", "Invoices and payments", "As accounting rules require", "Archived, then removed when the rules allow"],
            ["Audit trail", "Who did what, and when", "Kept as evidence", "A minimal record of deletion remains"]]
    qa = [("Does Xevrion learn from other companies' data?", "No. Learning happens inside your organisation only. Nothing is shared between customers, and your data is not used to train AI models."),
          ("Can learning make things worse?", "Adjustments are bounded: forecast trust stays between 0.25 and 1, and recommendation confidence is scaled between 0.5 and 1.2. Every change is recorded with its reason."),
          ("What happens to memory when we leave?", "It is deleted with the rest of your organisation's data when an owner completes deletion. Only a minimal record that the deletion happened is kept.")]
    body = f'''{B.page_hero(crumbs, "Learning and memory", "Xevrion remembers what happened, and gets better because of it.",
        "Xevrion keeps an ordered memory of your business, scores every forecast and recommendation against what really happened, and adjusts how far to trust itself.", visual=visual, where="learning")}
{_sec(section_head("How it learns", "Four steps, repeated every cycle.") + walkthrough(steps, label="How learning works"), id_="how")}
{_sec(f'''<div class="duo"><div>{section_head("In numbers", "Error falls; trust follows.", "In this example a revenue forecast starts 31% out. Each cycle it is scored and recalibrated, and the trust placed in it rises as the error comes down.")}</div>
  <figure class="panel glass glass--ambient" data-reveal style="margin:0"><div class="viz-head"><span class="label">Forecast error and trust, by cycle</span>{claim("illustrative")}</div>{charts.learning_curve(errors, trust)}</figure></div>''', id_="numbers")}
{_sec(f'<div class="duo duo--top">{section_head("What it keeps", "What Xevrion remembers, and for how long.")}<div data-reveal>{table(["Memory", "What it holds", "Kept", "When it goes"], keep)}</div></div>', id_="retention")}
{_sec(f'<div class="duo duo--top">{section_head("Questions", "About learning and memory.")}<div>{faq(qa, open_first=True)}</div></div>', id_="faq")}
{cta_final("A platform that gets better with your business.", "Start with one system; learning begins with the first measured result.", where="learning")}'''
    site.add(Page("/product/learning-and-memory", "Learning and memory", "How Xevrion remembers your business and learns from results: forecasts and recommendations scored against reality, with bounded, recorded adjustments.",
                  body, env="decisions", crumbs=crumbs, schema=[faq_schema(qa)], priority=0.85, group="Product"))


# ------------------------------------------------------------------------------------------------ capability index
def capabilities(site: Site) -> None:
    crumbs = [("Home", "/"), ("Platform", "/platform"), ("Capability index", None)]
    total = sum(len(items) for groups in CAPABILITIES.values() for _, items in groups)
    rows = []
    for key, groups in CAPABILITIES.items():
        s = SYS[key]
        for gi, (g, items) in enumerate(groups, 1):
            for ii, (n, d) in enumerate(items, 1):
                rows.append(f'<div role="listitem"><div class="capi__row" data-item="{esc(n + " " + d + " " + g + " " + s["name"])}" data-category="{esc(s["name"])}">'
                            f'<span class="capi__code">{capability_code(key, gi, ii)}</span>'
                            f'<span class="capi__name"><strong>{esc(n)}</strong><span class="label">{esc(g)}</span></span><span class="capi__desc">{esc(d)}</span>'
                            f'<a class="capi__sys" href="{s["href"]}#capabilities">{icon(s["icon"], 14)}{esc(s["name"])}</a></div></div>')
    pills = '<button type="button" data-cat="all" aria-pressed="true">All</button>' + "".join(
        f'<button type="button" data-cat="{esc(s["name"])}" aria-pressed="false">{esc(s["name"])}</button>' for s in D.SYSTEMS)
    counts = "".join(f'<div><span class="v num">{sum(len(i) for _, i in CAPABILITIES[s["key"]])}</span><span class="l">{esc(s["name"])}</span></div>' for s in D.SYSTEMS)
    body = f'''{B.page_hero(crumbs, "Capability index", f"Everything Xevrion can do: {total} capabilities.",
        "Every capability across the four systems, in plain English. Each one maps to a working part of the platform. Search it, filter it, or jump to the system that provides it.", ctas=False)}
{_sec(f'<div class="proof-strip" data-reveal>{counts}</div>', tight=True)}
{_sec(f"""<div data-viz="search">
  <div class="lib__controls" data-controls hidden>
    <label class="lib__search"><span class="sr-only">Search capabilities</span>{icon("search", 18)}<input class="input" type="search" data-search placeholder="Search, for example “invoices”, “renewal” or “forecast”" autocomplete="off"></label>
    <div class="pill-nav" role="group" aria-label="Filter by system">{pills}</div>
    <p class="quiet small" aria-live="polite"><span data-count-out>{total} of {total}</span> capabilities</p>
  </div>
  <div class="capi" role="list">{"".join(rows)}</div>
  <p class="note" data-empty hidden>Nothing matches that. Try another word, or <a class="link" href="/contact">ask us whether Xevrion can do it</a>.</p>
</div>""")}
{cta_final("See these capabilities working together.", "Take the guided tour, or start with the system you need most.", where="capabilities")}'''
    site.add(Page("/platform/capabilities", "Capability index", f"All {total} Xevrion Ops capabilities across Revenue, Customer Operations, Business Operations and Decision Intelligence, searchable and in plain English.",
                  body, crumbs=crumbs, priority=0.8, group="Product"))


# ------------------------------------------------------------------------------------------------ architecture
def architecture(site: Site) -> None:
    crumbs = [("Home", "/"), ("Platform", "/platform"), ("Architecture", None)]
    visual = B.viz_stage("architecture", "A request travelling through Xevrion: Cloudflare's edge, the encrypted tunnel, the gateway's checks, one system and its database.", height=540, kind="capability")
    layers = "".join(f'''<section class="arch__layer" data-reveal><div class="arch__head"><span class="label">{esc(where)}</span><h3>{esc(name)}</h3></div>
      <ul class="arch__parts">{"".join(f"<li><strong>{esc(p)}</strong><span>{esc(d)}</span></li>" for p, d in parts)}</ul></section>''' for name, where, parts in ARCHITECTURE)
    facts = [("Services", "13", "4 product systems, 8 shared services and the gateway"), ("Databases", "1 per service", "No service reads another's tables"),
             ("Open ports", "0", "Reachable only through the Cloudflare Tunnel")]
    strip = "".join(f'<div><span class="v num">{v}</span><span class="l"><strong style="font-weight:500;color:var(--text-1)">{esc(k)}</strong> · {esc(d)}</span></div>' for k, v, d in facts)
    principles = [("Bounded services", "Each system owns its own data and database. Services talk through the gateway with their own credentials, never sharing tables.", "Isolation"),
                  ("Deny by default", "Security checks that cannot complete refuse rather than allow.", "Safety"),
                  ("Idempotent writes", "Every change in another system carries a key, so retries never apply twice; unclear outcomes are reconciled.", "Safety"),
                  ("Per-customer circuit breakers", "If one customer's tool fails, only that customer's calls to it pause; nobody else is affected.", "Reliability"),
                  ("Error budgets", "Each service tracks its reliability targets and alerts when the budget is burning too fast.", "Reliability"),
                  ("Checksummed migrations", "Database changes are reviewed, recorded and verified before every release.", "Change")]
    body = f'''{B.page_hero(crumbs, "Architecture", "How Xevrion is built.", "Where each part runs, how every request is checked, and the rules that keep your data safe and the service reliable.", visual=visual, where="architecture")}
{_sec(f'<div class="proof-strip" data-reveal>{strip}</div><p class="note">{claim("fact")} From the production deployment.</p>', tight=True)}
{_sec(section_head("Layers", "From the edge to the database.") + f'<div class="arch">{layers}</div>')}
{_sec(f'<div class="duo duo--top">{section_head("Engineering rules", "Six rules every service follows.")}{ledger_list(principles)}</div>')}
{cta_final("Built to be trusted with real work.", "Read the security details, or start with one system.", where="architecture")}'''
    site.add(Page("/platform/architecture", "Architecture", "How Xevrion Ops is built: Cloudflare edge and tunnel, a checked gateway, bounded services with their own databases, and the engineering rules behind them.",
                  body, env="security", crumbs=crumbs, priority=0.7, group="Platform"))


# ------------------------------------------------------------------------------------------------ use cases
def use_cases(site: Site) -> None:
    crumbs = [("Home", "/"), ("Solutions", "/solutions"), ("Use-case library", None)]
    items = []
    for slug, name, sys_key, problem, steps, outcome in USE_CASES:
        s = SYS[sys_key]
        ol = "".join(f"<li>{esc(x)}</li>" for x in steps)
        items.append(f'<div role="listitem"><article class="uc glass glass--ambient" id="{slug}" data-item="{esc(name + " " + problem + " " + " ".join(steps) + " " + s["name"])}" data-category="{esc(s["name"])}">'
                     f'<div class="uc__head"><a class="uc__sys" href="{s["href"]}">{icon(s["icon"], 14)}{esc(s["name"])}</a><h2 class="h4">{esc(name)}</h2><p class="muted">{esc(problem)}</p></div>'
                     f'<ol class="uc__steps">{ol}</ol><p class="uc__out"><span class="label">Outcome</span>{esc(outcome)}</p></article></div>')
    pills = '<button type="button" data-cat="all" aria-pressed="true">All</button>' + "".join(
        f'<button type="button" data-cat="{esc(s["name"])}" aria-pressed="false">{esc(s["name"])}</button>' for s in D.SYSTEMS)
    body = f'''{B.page_hero(crumbs, "Use-case library", f"{len(USE_CASES)} workflows, step by step.",
        "Concrete jobs Xevrion takes on: the problem, the steps and what changes. Filter by system or search for your situation.", where="usecases")}
{_sec(f"""<div data-viz="search">
  <div class="lib__controls" data-controls hidden>
    <label class="lib__search"><span class="sr-only">Search use cases</span>{icon("search", 18)}<input class="input" type="search" data-search placeholder="Search, for example “complaints” or “invoices”" autocomplete="off"></label>
    <div class="pill-nav" role="group" aria-label="Filter by system">{pills}</div>
    <p class="quiet small" aria-live="polite"><span data-count-out>{len(USE_CASES)} of {len(USE_CASES)}</span> use cases</p>
  </div>
  <div class="ucs" role="list">{"".join(items)}</div>
  <p class="note" data-empty hidden>No use case matches that yet. <a class="link" href="/contact">Tell us what you need</a>.</p>
</div>""", tight=True)}
{cta_final("Start with the use case that costs you most.", "One system, one measurable goal, measured in your Value Ledger.", where="usecases")}'''
    site.add(Page("/use-cases", "Use-case library", "Fourteen Xevrion Ops workflows, from quote follow-up and renewal risk to invoice matching and scenario planning, each explained step by step.",
                  body, crumbs=crumbs, priority=0.75, group="Solutions", nav_current="/use-cases"))


# ------------------------------------------------------------------------------------------------ glossary
def glossary(site: Site) -> None:
    crumbs = [("Home", "/"), ("Resources", "/resources"), ("Glossary", None)]
    letters = sorted({t[0][0].upper() for t in GLOSSARY})
    jump = "".join(f'<a href="#g-{l.lower()}">{l}</a>' for l in letters)
    groups = []
    for l in letters:
        terms = "".join(f'<div class="gl__term" id="term-{esc(t.lower().replace(" ", "-"))}"><dt>{esc(t)}</dt><dd>{esc(d)}</dd></div>' for t, d in GLOSSARY if t[0].upper() == l)
        groups.append(f'<section class="gl__group" id="g-{l.lower()}" aria-label="{l}"><span class="gl__letter">{l}</span><dl>{terms}</dl></section>')
    body = f'''{B.page_hero(crumbs, "Glossary", "Every term, explained simply.", "The words used across Xevrion, from approval to workflow run, in plain English. Nothing here needs a technical background.", ctas=False)}
{_sec(f'<nav class="gl__jump" aria-label="Jump to letter">{jump}</nav><div class="gl">{"".join(groups)}</div>', tight=True)}'''
    site.add(Page("/glossary", "Glossary", "Plain-English definitions of the terms used across Xevrion Ops: approvals, attribution, calibration, expected value, idempotency, Value Ledger and more.",
                  body, crumbs=crumbs, priority=0.6, group="Resources",
                  schema=[{"@context": "https://schema.org", "@type": "DefinedTermSet", "name": "Xevrion glossary",
                           "hasDefinedTerm": [{"@type": "DefinedTerm", "name": t, "description": d} for t, d in GLOSSARY]}]))


def build(site: Site) -> None:
    learning(site)
    capabilities(site)
    architecture(site)
    use_cases(site)
    glossary(site)
