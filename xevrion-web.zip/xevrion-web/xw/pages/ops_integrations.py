"""Integrations: a searchable library and one detail page per connector. Every fact comes from the connector catalog:
what Xevrion reads, what it may write, the permissions requested, how you sign in, how it syncs and what that means
for security. No logo wall."""
from __future__ import annotations

from .. import blocks as B
from .. import charts
from .. import data as D
from ..components import arrow_link, claim, cta_final, section_head, table, walkthrough
from ..html import esc, icon
from ..shell import Page, Site

SYS = {s["key"]: s for s in D.SYSTEMS}


def _access(c: dict) -> str:
    return "Reads and writes" if c["reads"] and c["writes"] else "Writes only" if c["writes"] else "Read-only"


def index(site: Site) -> None:
    crumbs = [("Home", "/"), ("Integrations", None)]
    hero = B.page_hero(crumbs, "Integrations", "Connect Xevrion to the tools your business already runs on.",
                       "Thirteen tools, each connected with your own account. You approve exactly what Xevrion may read and change.",
                       where="integrations", visual=f'<figure class="panel glass glass--ambient" style="margin:0">{charts.hub(D.CONNECTORS)}'
                                                     f'<div class="connect-legend"><span><i></i>Read-only</span><span><i class="w"></i>Writes only</span><span><i class="rw"></i>Reads and writes, with permission</span></div></figure>')
    cats = ["all"] + D.CONNECTOR_CATEGORIES
    pills = "".join(f'<button type="button" data-cat="{esc(c)}" aria-pressed="{str(c == "all").lower()}">{"All" if c == "all" else esc(c)}</button>' for c in cats)
    rows = []
    for c in D.CONNECTORS:
        systems = ", ".join(SYS[k]["name"] for k in c["systems"])
        hay = " ".join([c["name"], c["category"], *c["reads"], *c["writes"], systems])
        rows.append(f'<a class="lib__row" href="/integrations/{c["key"]}" data-item="{esc(hay)}" data-category="{esc(c["category"])}">'
                    f'<span class="lib__name"><strong>{esc(c["name"])}</strong><span class="label">{esc(c["category"])}</span></span>'
                    f'<span class="lib__what">{esc("; ".join(c["reads"] + c["writes"]))}</span>'
                    f'<span class="lib__access"><span class="state {"state--active" if c["writes"] else ""}">{_access(c)}</span></span>'
                    f'<span class="lib__sys">{esc(systems)}</span>{icon("arrow", 18)}</a>')
    steps = [{"who": "you", "role": "You", "title": "Choose the tool", "what": "Open Integrations in your portal and pick it. Your plan sets how many you can connect."},
             {"who": "you", "role": "You", "title": "Sign in with your own account", "what": "On the tool's own page. Xevrion never sees your password."},
             {"who": "you", "role": "You approve", "title": "Approve read and write separately", "what": "Read-only is always an option. Sending email is its own permission."},
             {"who": "x", "title": "Xevrion checks it works", "what": "A health check runs first, and the credential is sealed in a separate secret store."}]
    body = f'''{hero}
<section class="section section--tight"><div class="wrap">
  <div data-viz="search">
    <div class="lib__controls" data-controls hidden>
      <label class="lib__search"><span class="sr-only">Search integrations</span>{icon("search", 18)}<input class="input" type="search" data-search placeholder="Search, for example “invoices” or “tickets”" autocomplete="off"></label>
      <div class="pill-nav" role="group" aria-label="Filter by category">{pills}</div>
      <p class="quiet small" aria-live="polite"><span data-count-out>13 of 13</span> integrations</p>
    </div>
    <div class="lib" role="list">{"".join(f'<div role="listitem">{r}</div>' for r in rows)}</div>
    <p class="note" data-empty hidden>No integration matches that. Try a different word, or <a class="link" href="/contact">tell us which tool you need</a>.</p>
  </div>
</div></section>
<section class="section"><div class="wrap">
  {section_head("How connecting works", "Four steps, all in your portal.")}
  {walkthrough(steps, label="How to connect a tool")}
</div></section>
{cta_final("Connect your first three tools on the Start plan.", "Create your workspace and connect with your own accounts, or take the guided tour first.", where="integrations")}'''
    site.add(Page("/integrations", "Integrations", "Connect Xevrion Ops to Gmail, Microsoft 365, HubSpot, Salesforce, Slack, Zendesk, Intercom, Segment, Xero, QuickBooks, Notion, any mailbox and your website.",
                  body, crumbs=crumbs, priority=0.9, nav_current="/integrations"))


def detail(site: Site, c: dict) -> None:
    crumbs = [("Home", "/"), ("Integrations", "/integrations"), (c["name"], None)]
    access = _access(c)
    reads = "".join(f"<li>{esc(r)}</li>" for r in c["reads"]) or "<li>Nothing. This connection only sends data.</li>"
    writes = "".join(f"<li>{esc(w)}</li>" for w in c["writes"]) or "<li>Nothing. This connection is read-only.</li>"
    systems = "".join(f'<a class="chip" href="{SYS[k]["href"]}">{icon(SYS[k]["icon"], 16)}{esc(SYS[k]["name"])}</a>' for k in c["systems"])
    facts = [["Access", access], ["How you connect", c["auth"]], ["Permissions requested", c["scopes"]], ["How data moves", c["sync"]],
             ["You also provide", c["options"] or "Nothing extra"], ["Where the credential is kept", "Sealed in Xevrion's secret store; the application database holds only a reference"]]
    claim_fact = claim("capability", "From the connector catalogue")
    others = [x for x in D.CONNECTORS if x["category"] == c["category"] and x["key"] != c["key"]]
    related = "".join(f'<a class="chip" href="/integrations/{x["key"]}">{esc(x["name"])}</a>' for x in others) or ""
    lead = (f"Connect {c['name']} with your own account. Xevrion "
            + ("reads " + c["reads"][0][0].lower() + c["reads"][0][1:] if c["reads"] else "only sends data to it")
            + (" and, only if you allow it, can " + c["writes"][0][0].lower() + c["writes"][0][1:] if c["writes"] and c["reads"] else "")
            + ".")
    flow = f'<figure class="panel glass glass--ambient" style="margin:0"><div class="viz-head" style="display:flex;justify-content:space-between;gap:12px;margin-bottom:var(--s-4)"><span class="label">What flows, and which way</span>{claim_fact}</div>{charts.connector_flow(c)}</figure>'
    body = f'''{B.page_hero(crumbs, c["category"] + " integration", c["name"] + " and Xevrion", lead, where="int:" + c["key"], visual=flow)}
<section class="section"><div class="wrap two-col">
  <div data-reveal><p class="label" style="margin-bottom:12px">What Xevrion reads</p><ul class="prose">{reads}</ul></div>
  <div data-reveal><p class="label" style="margin-bottom:12px">What Xevrion may write, with your permission</p><ul class="prose">{writes}</ul></div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  <div>{section_head("The details", "How it connects, and where your data goes.")}
    <p class="label" style="margin-bottom:12px">Used by</p><div class="chip-list">{systems}</div>
    <ul class="prose" style="margin-top:var(--s-6)"><li>You sign in on {esc(c["name"])}'s own page; Xevrion never sees your password.</li><li>Every change is logged, and a retry can never create a duplicate.</li><li>Disconnect at any time from your portal.</li></ul></div>
  <div data-reveal>{table(["Detail", c["name"]], facts, caption="From Xevrion's connector catalogue.")}{f'<p class="note">{esc(c["notes"])}</p>' if c["notes"] else ""}
    <div class="section-foot" style="margin-top:var(--s-5)">{f'<span class="chip-list">{related}</span>' if related else "<span></span>"}{arrow_link("All integrations", "/integrations", "int:back")}</div></div>
</div></section>
{cta_final(f"Connect {c['name']} in a few minutes.", "Create your workspace, then connect with your own account from the Integrations page.", where="int:" + c["key"])}'''
    site.add(Page(f"/integrations/{c['key']}", f"{c['name']} integration",
                  f"Connect {c['name']} to Xevrion Ops: {access.lower()}, {c['auth'].split(' (')[0].lower()}. What Xevrion reads and writes, permissions and security.",
                  body, crumbs=crumbs, priority=0.6, nav_current="/integrations"))


def build(site: Site) -> None:
    index(site)
    for c in D.CONNECTORS:
        detail(site, c)
