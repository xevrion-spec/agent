"""The guided tour: four tracks x six steps (about 90 seconds each), each step a narrated product screen.
Without JavaScript every step of every track is readable in order; with it, one step plays at a time."""
from __future__ import annotations

from ..components import claim
from ..html import esc, icon

SHELL_NAV = ["revenue", "customers", "operations", "decisions", "value", "approval"]


def app(section: str, active: str, content: str) -> str:
    rail = "".join(f'<span class="app__ic{" is-on" if n == active else ""}">{icon(n, 16)}</span>' for n in SHELL_NAV)
    return (f'<div class="app" aria-hidden="true"><div class="app__top"><span class="app__brand">XEVRION <span class="quiet">Ops</span></span>'
            f'<span class="app__crumb">{esc(section)}</span><span class="app__user">NL</span></div>'
            f'<div class="app__body"><div class="app__rail">{rail}</div><div class="app__main">{content}</div></div></div>')


def rows(head: list[str], data: list[list[str]], hi: int | None = None) -> str:
    th = "".join(f"<span>{esc(h)}</span>" for h in head)
    tr = "".join(f'<div class="app__tr{" is-hi" if i == hi else ""}">' + "".join(f"<span>{c}</span>" for c in r) + "</div>" for i, r in enumerate(data))
    return f'<div class="app__table" style="--cols:{len(head)}"><div class="app__th">{th}</div>{tr}</div>'


def card(title: str, body: str, tone: str = "") -> str:
    return f'<div class="app__card{" app__card--" + tone if tone else ""}"><span class="label">{esc(title)}</span>{body}</div>'


def kv(pairs: list[tuple[str, str]]) -> str:
    return '<dl class="app__kv">' + "".join(f"<dt>{esc(k)}</dt><dd>{v}</dd>" for k, v in pairs) + "</dl>"


def chip(t: str, tone: str = "") -> str:
    return f'<span class="app__chip{" app__chip--" + tone if tone else ""}">{esc(t)}</span>'


def head(title: str, sub: str = "", actions: str = "") -> str:
    return f'<div class="app__head"><div><strong>{esc(title)}</strong>{f"<span class=quiet>{esc(sub)}</span>" if sub else ""}</div><div class="app__actions">{actions}</div></div>'


def btn(t: str, primary: bool = False) -> str:
    return f'<span class="app__btn{" app__btn--p" if primary else ""}">{esc(t)}</span>'


TRACKS = [
    ("revenue", "Revenue", "revenue", [
        ("Xevrion learns who you sell to", "It studies the deals you have already won and writes down your ideal customer in plain English. You approve it before anything else happens.",
         head("Ideal customer profile", "Drafted from 23 won deals", btn("Edit") + btn("Approve profile", True)) +
         kv([("Sectors", "Transport and storage · Construction"), ("Company size", "20–250 staff"), ("Region", "England and Wales"),
             ("What makes them buy", "New sites, expansion, published tenders"), ("Typical first-year value", "£12,000–£31,000")])),
        ("It finds companies that fit", "Companies matching the profile are gathered from sources you allow, including enquiries through your website and inbox. Each one records where it came from.",
         head("Discovered companies", "120 found · 47 fit your profile") +
         rows(["Company", "Sector", "Source", "Fit"], [["Harbour Freight Ltd", "Transport", "Research", chip("Fits", "ok")], ["Aldgate Build Partners", "Construction", "Tender feed", chip("Fits", "ok")],
                                                      ["Kingsmere Haulage", "Transport", "Research", chip("Too small")], ["Northgate Logistics", "Transport", "Website enquiry", chip("Fits", "ok")],
                                                      ["Stonebridge Data", "Info & comms", "CRM", chip("Existing customer")]])),
        ("It looks for real buying signals", "Fit is not enough. Xevrion looks for signs a company needs you now, and shows you exactly what it found.",
         head("Meaningful signals", "14 of 47 companies") +
         rows(["Company", "Signal", "Strength"], [["Harbour Freight Ltd", "Opening a second depot; hiring 4 drivers", chip("Strong", "v")],
                                                  ["Aldgate Build Partners", "Published a tender for site reporting", chip("Strong", "v")],
                                                  ["Northgate Logistics", "Asked for a quote through your website", chip("Strong", "v")],
                                                  ["Clearline Networks", "Hiring an operations manager", chip("Medium")]])),
        ("It ranks them by expected value", "Likely value multiplied by the chance of converting. Your team starts at the top, and every score shows its reasoning.",
         head("This week's shortlist", "Top 6 by expected value") +
         rows(["Company", "Likely value", "Chance", "Expected"], [["Harbour Freight Ltd", "£24,000", "62%", "<strong>£14,900</strong>"], ["Aldgate Build Partners", "£31,000", "41%", "<strong>£12,700</strong>"],
                                                                  ["Northgate Logistics", "£18,400", "55%", "<strong>£10,100</strong>"], ["Clearline Networks", "£16,000", "48%", "<strong>£7,700</strong>"]], hi=2)),
        ("It drafts a relevant first message", "The draft refers to the signal it found, in your tone. It waits for approval: nothing is sent until a person says so.",
         head("Draft · Northgate Logistics", "Waiting for approval · Sales lead", btn("Edit") + btn("Approve and send", True)) +
         '<div class="app__mail"><p><span class="quiet">To</span> operations@northgate-logistics.example</p><p><span class="quiet">Subject</span> Scheduling across two depots</p>'
         '<p>Hi Sam, thank you for asking for a quote for route planning across your two depots. Before we price it, could you confirm roughly how many vehicles and daily drops you run? We will send a written quote within a day.</p></div>'),
        ("The deal is won and the value recorded", "When the deal closes, Xevrion traces it back to the signal and message that started it and records the value, with its evidence and confidence.",
         head("Value Ledger", "September") + card("Revenue generated", '<p class="app__big num">£18,400</p>' + kv([("Evidence", "Salesforce opportunity · Closed Won"), ("Attribution", "Xevrion ranked and drafted; your team ran the calls"), ("Confidence", chip("High", "ok"))]), "value")),
    ]),
    ("customers", "Customer Operations", "customers", [
        ("Every customer in one view", "Emails, tickets, invoices and usage are joined into one record per customer, each with a health score you can explain.",
         head("Customers", "38 accounts") + rows(["Customer", "Health", "Renewal", "Owner"], [["Northwind Logistics", "82", "45 days", "A. Patel"], ["Brightwell Civils", "77", "4 months", "J. Evans"],
                                                                                              ["Tamar Data Services", "88", "7 months", "A. Patel"], ["Harbour Freight Ltd", "71", "2 months", "R. Shah"]])),
        ("Signals start to change", "Over three days, Northwind's tickets rise and replies slow down. Separately each looks minor; together they matter.",
         head("Northwind Logistics", "Signals, last 7 days") + rows(["Signal", "Was", "Now"], [["Support tickets", "3 / month", "<strong>9 / month</strong>"], ["Average reply time", "4 hours", "<strong>2 days</strong>"],
                                                                                              ["Product usage", "Stable", "−12%"], ["Invoices", "Paid on time", "Paid on time"]])),
        ("A risk is flagged, with its reasons", "Health falls from 82 to 61. The account manager sees the score and exactly why it moved, 41 days before renewal.",
         head("Risk · Northwind Logistics", "Raised to A. Patel") + card("Customer health", '<p class="app__big num" style="color:var(--risk)">61 <span class="quiet" style="font-size:14px">was 82</span></p>'
                                                                       + kv([("Driver 1", "Tickets tripled"), ("Driver 2", "Replies slowed to 2 days"), ("Renewal", "In 41 days")]), "risk")),
        ("Options compared, one recommended", "Three possible actions, each with its expected effect. Xevrion recommends one and says how confident it is.",
         head("Recommended action", "Medium confidence") + rows(["Option", "Cost", "Expected effect"], [["Offer a renewal discount", "£1,100", "Keeps price, not the relationship"], ["Do nothing", "£0", "High risk of losing £7,300"],
                                                                                                        ["Fix the recurring issue and book a success call", "Team time", "<strong>Most likely to renew</strong>"]], hi=2)),
        ("Approved, then carried out", "The account manager approves. Xevrion does the work in your own tools and logs every step.",
         head("Activity", "Approved by A. Patel, 10:40") + rows(["Time", "Action", "Where"], [["10:41", "Email drafted and sent after approval", "Outlook"], ["10:41", "Engineering ticket opened", "Zendesk"],
                                                                                         ["10:42", "Plan shared with the team", "Slack"]])),
        ("Renewal kept, value recorded", "Two weeks later tickets are back to normal and the customer renews. The value is recorded at medium confidence, because the account manager also helped.",
         head("Value Ledger", "September") + card("Revenue protected", '<p class="app__big num">£7,300</p>' + kv([("Evidence", "Renewal invoice in Xero"), ("Attribution", "Shared with the account manager"), ("Confidence", chip("Medium"))]), "value")),
    ]),
    ("operations", "Business Operations", "operations", [
        ("The real process, rebuilt from your tools", "Xevrion follows real purchase requests through email, the CRM and finance, and draws the process as it actually happens.",
         head("Purchase approval process", "Rebuilt from 212 requests") + '<div class="app__flow">' + "".join(f'<span class="app__node{" is-risk" if n == "Finance review" else ""}">{esc(n)}</span>' for n in ["Request", "Review", "CRM entry", "Finance review", "Approval", "Processing", "Update"]) + "</div>"),
        ("Every step measured", "Time spent, time waiting, errors and cost, for each step, from your own records.",
         head("Step measurements", "Last 90 days") + rows(["Step", "Hours / month", "Wait", "Errors"], [["Review", "9", "1.5 days", "1.4%"], ["CRM entry", "11", "0.8 days", "2.3%"], ["Finance review", "<strong>19</strong>", "<strong>3.6 days</strong>", "1.9%"], ["Approval", "5", "2.1 days", "0.3%"]], hi=2)),
        ("The bottleneck, with its cost", "One step causes most of the delay. Finance review costs about £2,130 a month and holds work for 3.6 days.",
         head("Bottleneck", "Finance review") + card("Cost of this step", '<p class="app__big num" style="color:var(--risk)">£2,130<span class="quiet" style="font-size:14px"> /month</span></p>' + kv([("Share of process cost", "31%"), ("Average wait", "3.6 days"), ("Main cause", "Manual matching against purchase orders")]), "risk")),
        ("A better workflow, proposed", "Matching and data entry become automatic. Approval for spend over your limit stays with a person, always.",
         head("Proposed workflow", "Awaiting your approval", btn("Approve design", True)) + rows(["Step", "Before", "After"], [["CRM entry", "Manual", chip("Automated", "v")], ["Finance review", "Manual matching", chip("Automated matching", "v")],
                                                                                                                             ["Approval over £5,000", "Director", "Director (unchanged)"], ["Update", "Manual", chip("Automated", "v")]])),
        ("Running, with approvals where they matter", "The new workflow runs in your tools. Exceptions go to the right person; retries never create duplicates.",
         head("Today", "Live") + rows(["Measure", "Value"], [["Requests processed", "38"], ["Exceptions routed to Finance", "2"], ["Waiting for director approval", "1"], ["Duplicates created", "0"]])),
        ("The saving, proved", "Measured against the 90-day baseline: 61 hours down to 18 a month, errors from 8.2% to 2.1%.",
         head("Value Ledger", "September") + card("Costs reduced", '<p class="app__big num">£4,820<span class="quiet" style="font-size:14px"> /month</span></p>' + kv([("Evidence", "Workflow run records"), ("Method", "Hours × your hourly cost vs baseline"), ("Confidence", chip("High", "ok"))]), "value")),
    ]),
    ("decisions", "Decision Intelligence", "decisions", [
        ("One set of numbers", "Accounting, CRM and operations joined up and checked, so everyone sees the same KPIs.",
         head("KPIs", "Quarter to date") + '<div class="app__tiles">' + "".join(card(k, f'<p class="app__big num">{v}</p><span class="quiet">{s}</span>') for k, v, s in [("Revenue", "£318K", "of £382K expected"), ("Pipeline", "£1.1M", "open"), ("Conversion", "18%", "last 90 days"), ("Gross margin", "31%", "−2.4 pts")]) + "</div>"),
        ("Why a number moved", "Margin fell 2.4 points. Xevrion shows the drivers, with evidence, instead of leaving you to guess.",
         head("Diagnosis", "Gross margin −2.4 pts") + rows(["Driver", "Effect", "Evidence"], [["Discounts on repeat orders", "−1.6 pts", "14 invoices"], ["Fuel costs", "−0.8 pts", "Supplier bills"]])),
        ("A forecast with a range", "Next quarter is expected at £382K, most likely between £356K and £404K. The range is the honest part.",
         head("Forecast", "Next quarter") + card("Expected revenue", '<p class="app__big num">£382K</p>' + kv([("Likely range", "£356K – £404K"), ("Confidence", chip("Medium")), ("Main driver", "Pipeline converts at 18%")]))),
        ("Scenarios, side by side", "What happens if you change something? Each option has an expected value, a range and a confidence level.",
         head("Scenarios", "Next quarter") + rows(["Scenario", "Expected", "Range"], [["Current path", "£382K", "£356K–£404K"], ["Faster follow-up", "<strong>£397K</strong>", "£368K–£421K"],
                                                                                   ["Second product line", "£411K", "£352K–£458K"], ["Lose the largest customer", "£351K", "£339K–£366K"]], hi=1)),
        ("The decision, written down", "What was chosen, by whom and why, so the reasoning survives and can be reviewed.",
         head("Decision record", "Recorded by the managing director") + kv([("Decision", "Invest in faster follow-up"), ("Why", "Best expected value with a medium-confidence range"), ("Review", "In 90 days"), ("Alternatives", "Second product line (too uncertain today)")])),
        ("Accuracy, checked", "Each forecast is scored against what actually happened, so you learn how far to trust it.",
         head("Forecast accuracy", "Last 4 quarters") + rows(["Quarter", "Forecast range", "Actual", "Within range"], [["Q1", "£298K–£341K", "£322K", chip("Yes", "ok")], ["Q2", "£311K–£352K", "£349K", chip("Yes", "ok")],
                                                                                                                   ["Q3", "£320K–£366K", "£371K", chip("No")], ["Q4", "£334K–£379K", "£351K", chip("Yes", "ok")]])),
    ]),
]


def render() -> str:
    tabs, panels = [], []
    for ti, (key, name, ic, steps) in enumerate(TRACKS):
        tabs.append(f'<button type="button" role="tab" id="tt-{key}" aria-controls="tp-{key}" aria-selected="{str(ti == 0).lower()}" tabindex="{0 if ti == 0 else -1}" data-track="{key}">{icon(ic, 16)}{esc(name)}</button>')
        lis = []
        following = TRACKS[(ti + 1) % len(TRACKS)][1]
        for si, (title, narr, screen) in enumerate(steps):
            last = si == len(steps) - 1
            # the player stops on this card; "Next" (shown only once the player runs) moves on to the next system
            end = (f'<p class="tour__end"><a class="btn btn--primary btn--small" href="/get-started" data-event="cta_start:tour-{key}">Start with {esc(name)}</a>'
                   f'<a class="arrow-link" href="/product/{"revenue" if key == "revenue" else "customer-operations" if key == "customers" else "business-operations" if key == "operations" else "decision-intelligence"}">Read about {esc(name)}{icon("arrow", 16)}</a>'
                   f'<button class="btn btn--secondary btn--small" type="button" data-next-track hidden>Next: {esc(following)}{icon("arrow", 16)}</button></p>') if last else ""
            lis.append(f'<li class="tour__step" data-step="{si}"><div class="tour__narr"><span class="label">Step {si + 1} of {len(steps)}</span><h3>{esc(title)}</h3><p>{esc(narr)}</p>{end}</div>'
                       f'<div class="tour__screen">{app(name, ic, screen)}</div></li>')
        panels.append(f'<section class="tour__track" role="tabpanel" id="tp-{key}" aria-labelledby="tt-{key}"><h2 class="sr-only">{esc(name)} tour</h2><ol class="tour__steps">{"".join(lis)}</ol></section>')
    controls = (f'<div class="tour__bar" data-bar hidden><button class="play" type="button" data-prev aria-label="Previous step">{icon("arrow", 16, cls="flip")}<span>Back</span></button>'
                f'<button class="play" type="button" data-next aria-label="Next step"><span>Next</span>{icon("arrow", 16)}</button>'
                f'<div class="tour__dots" data-dots role="group" aria-label="Jump to a step"></div>'
                f'<button class="play play--quiet" type="button" data-toggle aria-label="Pause the tour"><span>Pause</span></button>'
                f'<span class="quiet small" data-where aria-live="polite"></span></div>')
    return (f'<div class="tour" data-viz="tour"><div class="tour__top"><div class="pill-nav" role="tablist" aria-label="Choose a system to tour">{"".join(tabs)}</div>'
            f'{claim("illustrative")}</div>{"".join(panels)}{controls}</div>')
