"""portal.ops.xevrion.co.uk: the sign-in hub. It points each person to the right application and explains access."""
from __future__ import annotations

from .. import blocks as B
from ..components import answer_block, explain, faq, faq_schema, ledger_list, section_head, table
from ..html import icon
from ..shell import APP, OPS, Page, Site

API = APP.rsplit("/", 1)[0]


def home(site: Site) -> None:
    body = f'''<section class="page-hero"><div class="wrap">
  <div class="hero__copy" style="max-width:760px"><p class="eyebrow">Xevrion Ops · Portal</p><h1 class="display" style="margin:var(--s-5) 0">Sign in to Xevrion Ops.</h1>
  <p class="lead">Choose where you are going. Customers sign in to the Xevrion app; Xevrion staff use the operator console.</p></div>
  <div class="start__plans" style="margin-top:var(--s-7)">
    <a class="start__plan glass glass--intel" href="{APP}" data-event="portal:app"><span class="label">Customers</span><span class="portal__t">Xevrion app</span><span class="quiet small">Your organisation's systems, integrations, approvals, billing and Value Ledger.</span><span class="go">Sign in {icon("arrow-up-right", 16)}</span></a>
    <a class="start__plan glass glass--ambient" href="{B.app_link()}" data-event="portal:new"><span class="label">New customers</span><span class="portal__t">Create an account</span><span class="quiet small">Work email, a password of at least 12 characters and a verification code.</span><span class="go">Get started {icon("arrow-up-right", 16)}</span></a>
    <a class="start__plan glass glass--ambient" href="{API}/console" data-event="portal:console"><span class="label">Xevrion staff</span><span class="portal__t">Operator console</span><span class="quiet small">Restricted to Xevrion operators. Access is checked on every request.</span><span class="go">Open console {icon("arrow-up-right", 16)}</span></a>
  </div>
  <p class="note">Signing in happens on api.xevrion.co.uk, Xevrion's own platform. We will never ask for your password by email.</p>
  <p style="margin-top:var(--s-4)"><a class="arrow-link" href="{OPS}/customer-portal" data-event="portal:preview">See what the customer portal looks like, before you sign in {icon("arrow", 16)}</a></p>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Having trouble?", "Common sign-in problems.")}
  <div>{faq(HELP_FAQ[:3], open_first=True)}<p style="margin-top:var(--s-5)"><a class="arrow-link" href="/help">All sign-in help {icon("arrow", 16)}</a></p></div>
</div></section>'''
    site.add(Page("/", "Xevrion Portal · Sign in", "Sign in to Xevrion Ops: the Xevrion app for customers and the operator console for Xevrion staff.", body, priority=1.0))


HELP_FAQ = [
    ("I did not receive my verification code", "Check your spam folder and that you used your work email. Codes expire, so request a new one from the sign-in page if needed."),
    ("I have forgotten my password", "Use “Forgot password” on the sign-in page. Resetting your password signs you out of every other session, for your security."),
    ("I have lost my two-factor device", "Sign in with one of the recovery codes you saved when you turned on two-factor authentication. Each code works once. If you have none left, ask an owner of your organisation to contact us in writing."),
    ("My invitation link does not work", "Invitations are single-use, expire and only work for the email address they were sent to. Ask an owner or administrator to resend it."),
    ("I cannot see a system or setting", "Your role decides what you can see. Owners and administrators can change roles; some settings are for owners only."),
]


def help_page(site: Site) -> None:
    crumbs = [("Portal", "/"), ("Help", None)]
    body = f'''{B.page_hero(crumbs, "Portal help", "Sign-in help.", "Answers to the most common sign-in and access problems. For anything else, contact your organisation's owner or write to us.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  <div>{faq(HELP_FAQ, open_first=True)}</div>
  <div>{explain("Xevrion will never ask for your password, two-factor code or recovery codes by email, phone or chat.", "Stay safe")}
    <p class="note">Other help: <a class="link" href="{OPS}/help">Help centre</a> · <a class="link" href="{OPS}/status">System status</a> · <a class="link" href="{OPS}/contact">Contact</a></p></div>
</div></section>'''
    site.add(Page("/help", "Sign-in help", "Help signing in to Xevrion Ops: verification codes, forgotten passwords, lost two-factor devices, invitations and roles.",
                  body, crumbs=crumbs, schema=[faq_schema(HELP_FAQ)], priority=0.6))


def access(site: Site) -> None:
    crumbs = [("Portal", "/"), ("Access and roles", None)]
    roles = [["Owner", "Everything, including billing, cancellation, deletion and transferring ownership"], ["Administrator", "Manages members (other than owners), integrations and settings"],
             ["Member", "Uses the systems and approvals they have been given"], ["Xevrion operator", "Xevrion staff only, in the operator console; never in your app"]]
    body = f'''{B.page_hero(crumbs, "Access", "Who can do what.", "Access to Xevrion Ops is organised by organisation and role, checked on every request.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  {answer_block("How is access controlled?", "Every record belongs to one organisation. Each person has a role in that organisation, and the platform checks membership and role on every request. Sessions last 12 hours and can be revoked; two-factor sign-in is available to everyone.")}
  <div data-reveal>{table(["Role", "Can"], roles)}</div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Protecting your account", "Four habits that matter.")}
  {ledger_list([("Turn on two-factor sign-in", "Standard six-digit codes from any authenticator app.", "Account"), ("Keep recovery codes safe", "Shown once. Each works once.", "Account"),
                ("Review your team", "Remove people who have left, and keep owners to a minimum.", "Owners"), ("Check the audit trail", "Every approval and action is recorded.", "Owners")])}
</div></section>'''
    site.add(Page("/access", "Access and roles", "How access to Xevrion Ops works: organisations, roles, sessions, two-factor sign-in and the operator console.", body, crumbs=crumbs, priority=0.6))


def not_found(site: Site) -> None:
    body = f'''<section class="page-hero"><div class="wrap"><div class="hero__copy" style="max-width:760px"><p class="eyebrow">404 · Page not found</p>
  <h1 class="display" style="margin:var(--s-5) 0">This page does not exist.</h1><p class="lead">To sign in, go to the <a class="link" href="/">portal home</a> or straight to the <a class="link" href="{APP}">Xevrion app</a>.</p></div></div></section>'''
    site.add(Page("/404", "Page not found · Portal", "The page you were looking for does not exist on the Xevrion portal.", body, noindex=True, priority=0.0))


def build(site: Site) -> None:
    home(site)
    help_page(site)
    access(site)
    not_found(site)
