"""xevrion.co.uk: the Xevrion group. One master brand over focused ventures (as Virgin sits over Virgin Media and Virgin
Atlantic). Xevrion Ops is live; Xevrion Cyber is planned and presented honestly as planned."""
from __future__ import annotations

from .. import blocks as B
from .. import webs
from ..catalog import VENTURES
from ..components import answer_block, arrow_link, brief_form, button, caps, claim, cta_final, explain, faq, faq_schema, index_list, ledger_list, section_head, table
from ..html import BRAND_MARK, brand_mark, esc, icon
from ..shell import OPS, Page, Site

PRINCIPLES = [("Evidence over claims", "Every figure we publish says what it is: an example, a capability, a verified fact or a verified customer result.", "Honesty"),
              ("People stay in control", "Our software recommends and helps. People approve what matters, and every action is recorded.", "Control"),
              ("In writing", "No sales calls. Prices, limits and security are published, and questions are answered by email, precisely.", "Clarity"),
              ("Measured outcomes", "Each venture measures what it delivers, so customers can judge us on evidence.", "Accountability"),
              ("Our own infrastructure", "Websites on Cloudflare; platforms on our own servers at OVHcloud, reachable only through encrypted tunnels.", "Ownership")]
FOUNDATION = [
    ("Infrastructure", "Cloudflare at the edge; our own servers at OVHcloud behind an encrypted tunnel, with no open ports.", "security"),
    ("Identity and security", "Salted password hashes, expiring sessions, two-factor sign-in, roles and strict separation between customers.", "lock"),
    ("AI governance", "An open model run on Cloudflare Workers AI, used only inside rules, with approvals for anything consequential.", "ai"),
    ("Reliability", "Error budgets, safe retries, per-customer circuit breakers, backups and rollback before every upgrade.", "status"),
    ("Measurement", "Every venture records what it delivers, with evidence and confidence, rather than claiming it.", "value"),
    ("Design and brand", "One design system, one mark and one voice, so every venture is recognisably Xevrion.", "spark"),
]
NEWS = [
    ("2026-09-25", "25 September 2026", "A new mark and the Xevrion Atlas", "The new Xevrion mark, a ring with a blade cutting out through it, across every site; and the Atlas, a live map of every page on the group's websites and every link between them.", "/atlas"),
    ("2026-09-24", "24 September 2026", "Xevrion becomes a group of ventures", "xevrion.co.uk now presents Xevrion as a family of focused ventures on one shared foundation, with a new mark. Xevrion Ops is the first; Xevrion Cyber is planned.", "/ventures"),
    ("2026-09-24", "24 September 2026", "New Xevrion Ops website", "A rebuilt product site with interactive examples, a guided tour, a capability index and published prices.", OPS + "/"),
    ("2026-09-23", "23 September 2026", "Xevrion Ops 1.7.0", "Eight new connectors, bring-your-own-app connections, automatic payment matching and reliability measures for every service.", OPS + "/updates"),
]


def _venture_card(v: dict, *, big: bool = False) -> str:
    live = v["status"] == "Live"
    facts = "".join(f'<div><span class="v num">{esc(a)}</span><span class="l">{esc(b)}</span></div>' for a, b in v["facts"])
    areas = "".join(f'<span class="chip">{esc(a)}</span>' for a in v["areas"])
    href = f"/ventures/{v['key']}"
    return (f'<article class="venture glass {"glass--intel" if live else "glass--ambient"}{" venture--big" if big else ""}" data-reveal>'
            f'<div class="venture__top"><span class="venture__lock">{brand_mark()}<span>XEVRION</span><span class="venture__name">{esc(v["short"].upper())}</span></span>'
            f'<span class="state {"state--ok" if live else ""}">{esc(v["status"])}</span></div>'
            f'<p class="venture__one">{esc(v["one"])}</p><div class="chip-list">{areas}</div><div class="venture__facts">{facts}</div>'
            f'<div class="cluster" style="--gap:var(--s-5);margin-top:var(--s-5)">{arrow_link("About " + v["name"], href, "venture:" + v["key"])}'
            f'{arrow_link("Visit " + v["name"], v["url"], "venture_visit:" + v["key"]) if v["url"] else ""}</div></article>')


def home(site: Site) -> None:
    ventures = "".join(_venture_card(v) for v in VENTURES)
    foundation = "".join(f'<div class="fnd__item" data-reveal><span class="ic">{icon(ic, 18)}</span><div><h3>{esc(t)}</h3><p>{esc(d)}</p></div></div>' for t, d, ic in FOUNDATION)
    news = index_list([(t, d, h) for _, _, t, d, h in NEWS[:3]], event_prefix="news:")
    body = f'''<section class="hero" aria-labelledby="hero-title"><div class="wrap hero__grid">
  <div class="hero__copy"><p class="eyebrow">Xevrion · A UK group of ventures</p>
    <h1 class="display-xl" id="hero-title">Focused ventures. One foundation.</h1>
    <p class="lead">Xevrion builds companies that each do one thing exceptionally well, on one shared foundation. Xevrion Ops is live. Xevrion Cyber is next.</p>
    <div class="hero__cta">{button("Explore our ventures", "/ventures", "primary", event="cta_group:hero")}{button("Visit Xevrion Ops", OPS + "/", "secondary", event="cta_ops:hero", icon_name="arrow-up-right")}</div></div>
  <div class="hero__visual"><figure class="constellation" data-viz="constellation" aria-labelledby="const-cap" style="margin:0">
    <div class="constellation__stage"></div>
    <figcaption id="const-cap" class="stage__caption"><span>The Xevrion group: ventures orbit one shared foundation. Solid means live; dashed means planned.</span></figcaption></figure></div>
</div>
</div></section>
<section class="section" id="ventures"><div class="wrap">
  {section_head("The ventures", "Each venture does one job exceptionally well.", "Each has its own focus and customers, and all share the same standards and foundation.")}
  <div class="ventures">{ventures}</div>
  <div class="section-foot">{arrow_link("All ventures and how we choose them", "/ventures", "group:ventures")}</div>
</div></section>
<section class="section" id="foundation"><div class="wrap duo duo--top">
  <div>{section_head("The foundation", "What every venture inherits on day one.", "Infrastructure, security, AI governance, reliability and measurement, already proven in production.")}
  {arrow_link("How the foundation works", "/foundation", "group:foundation")}</div>
  <div class="fnd">{foundation}</div>
</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("News", "The latest from the group.")}
  <div>{news}<div class="section-foot" style="margin-top:var(--s-5)">{arrow_link("All news", "/news", "group:news")}</div></div>
</div></section>
<section class="cta-final" aria-labelledby="cta-group"><div class="wrap">
  <h2 id="cta-group" data-reveal>Start with the venture that fits.</h2><p class="lead" data-reveal>Xevrion Ops is available today with published prices. Xevrion Cyber is being designed now; you can register interest in writing.</p>
  <div class="hero__cta">{button("Visit Xevrion Ops", OPS + "/", "primary", event="cta_ops:group")}{button("Register interest in Cyber", "/ventures/cyber#interest", "secondary", event="cta_cyber:group")}</div>
</div></section>'''
    site.add(Page("/", "Xevrion · Focused ventures, one foundation", "Xevrion is a UK group of focused ventures on one shared foundation. Xevrion Ops, the business operating platform, is live; Xevrion Cyber is planned.",
                  body, priority=1.0, group="Group", schema=[{"@context": "https://schema.org", "@type": "Organization", "name": "Xevrion", "url": site.origin + "/",
                                                            "subOrganization": [{"@type": "Organization", "name": v["name"], **({"url": v["url"]} if v["url"] else {})} for v in VENTURES]}]))


def ventures(site: Site) -> None:
    crumbs = [("Home", "/"), ("Ventures", None)]
    rules = [("A real, measurable problem", "We start where a problem is common, costly and measurable, using published data rather than hunches.", "1"),
             ("A job we can do exceptionally", "Each venture does one job deeply, not many jobs thinly.", "2"),
             ("The foundation fits", "It must run on the shared foundation: our infrastructure, security, AI governance and measurement.", "3"),
             ("Evidence before claims", "Nothing is marketed as working until it works, and results are published only when they meet our standard.", "4")]
    body = f'''{B.page_hero(crumbs, "Ventures", "The Xevrion family.", "Xevrion is the master brand. Each venture carries the name and the standards, and does one job for its own customers.", ctas=False)}
<section class="section section--tight"><div class="wrap"><div class="ventures">{"".join(_venture_card(v, big=True) for v in VENTURES)}</div></div></section>
<section class="section"><div class="wrap duo duo--top">{section_head("How we choose ventures", "Four tests every new venture must pass.")}{ledger_list(rules)}</div></section>
'''
    site.add(Page("/ventures", "Ventures", "The Xevrion family of ventures: Xevrion Ops (live) and Xevrion Cyber (planned), and the four tests every new venture must pass.",
                  body, crumbs=crumbs, priority=0.9, group="Group"))


def venture_ops(site: Site) -> None:
    crumbs = [("Home", "/"), ("Ventures", "/ventures"), ("Xevrion Ops", None)]
    systems = [("Revenue", "Finds and ranks the customers most worth your time, and helps you reach them first.", "/product/revenue"),
               ("Customer Operations", "Keeps a live picture of every customer and spots risk early.", "/product/customer-operations"),
               ("Business Operations", "Finds where time and money leak, and automates what should be automatic.", "/product/business-operations"),
               ("Decision Intelligence", "Forecasts and scenarios with honest ranges, and a record of every decision.", "/product/decision-intelligence")]
    body = f'''{B.page_hero(crumbs, "Venture · Live", "Xevrion Ops: the business operating platform.", "It connects a company's existing tools, finds valuable opportunities, helps the team act on them with approval and records the value of every result in pounds.", ctas=False,
        visual=_venture_card(VENTURES[0], big=True))}
<section class="section section--tight"><div class="wrap">{index_list([(t, d, OPS + h) for t, d, h in systems], event_prefix="venture_ops:")}</div></section>
<section class="section"><div class="wrap duo duo--top">{section_head("At a glance", "Published, measurable, in your control.")}
  {table(["", "Xevrion Ops"], [["Plans", "Start £2,500, Growth £5,000, Scale £10,000 a month, and Custom"], ["Connects to", "13 tools, each through your own account"],
                                 ["Capabilities", "Over 100, listed in the capability index"], ["Buying", "Self-serve, in writing, no sales calls"]])}</div></section>
<section class="section"><div class="wrap" style="text-align:center">{button("Visit ops.xevrion.co.uk", OPS + "/", "primary", event="venture_ops:visit", icon_name="arrow-up-right")}</div></section>'''
    site.add(Page("/ventures/ops", "Xevrion Ops", "Xevrion Ops, the live Xevrion venture: a business operating platform for revenue, customer operations, business operations and decision intelligence.",
                  body, crumbs=crumbs, priority=0.85, group="Group"))


def venture_cyber(site: Site) -> None:
    crumbs = [("Home", "/"), ("Ventures", "/ventures"), ("Xevrion Cyber", None)]
    direction = [("Security posture you can read", "Plain-English evidence of where a business stands, not a wall of alerts.", "Direction"),
                 ("Identity and access done properly", "The accounts, permissions and sign-in controls that stop most incidents before they start.", "Direction"),
                 ("Ready for the bad day", "Clear, rehearsed plans for what to do when something goes wrong.", "Direction"),
                 ("Risk reduction you can measure", "Progress recorded with evidence, the way Xevrion Ops records value.", "Direction")]
    qa = [("Can I buy Xevrion Cyber today?", "No. It is planned and being designed. We will not sell it until it works and we can show evidence. Register interest below and we will write to you when there is something real to see."),
          ("Will it work with Xevrion Ops?", "It will be built on the same foundation: the same infrastructure, security model, AI governance and measurement. How the two work together will be published when it is ready."),
          ("What will it cost?", "Prices will be published before launch, as they are for Xevrion Ops.")]
    body = f'''{B.page_hero(crumbs, "Venture · Planned", "Xevrion Cyber.", "A planned Xevrion venture: security for growing businesses, built on the same principles as Xevrion Ops. Plain-English evidence, people in control, and results you can measure.", ctas=False,
        visual=_venture_card(VENTURES[1], big=True))}
<section class="section"><div class="wrap duo duo--top"><div>{section_head("Direction", "What Xevrion Cyber is being designed to do.")}<p class="note">{claim("illustrative", "Direction, not a product yet")} Nothing here is a feature you can buy today.</p></div>{ledger_list(direction)}</div></section>
<section class="section"><div class="wrap duo duo--top">{section_head("Questions", "About Xevrion Cyber.")}<div>{faq(qa, open_first=True)}</div></div></section>
<section class="section" id="interest"><div class="wrap duo duo--top">
  <div>{section_head("Register interest", "Tell us what worries you most.", "Write a few lines about your business and the security problem you would most like solved. It shapes what we build first. We reply in writing.")}
  {explain("Choose “Not sure yet” as the system and mention Xevrion Cyber in your message.", "How to register")}</div>
  <div class="panel glass glass--elevated glass--edge">{brief_form(source="cyber-interest", service="Not sure yet")}</div>
</div></section>'''
    site.add(Page("/ventures/cyber", "Xevrion Cyber", "Xevrion Cyber is a planned Xevrion venture: security for growing UK businesses, with plain-English evidence and measurable risk reduction. Register interest.",
                  body, crumbs=crumbs, schema=[faq_schema(qa)], priority=0.8, group="Group"))


def foundation(site: Site) -> None:
    crumbs = [("Home", "/"), ("Foundation", None)]
    layers = "".join(f'<li class="stack__layer" style="--d:{i}" data-reveal><span class="stack__lvl label">Layer {len(FOUNDATION) - i}</span><span class="stack__ic">{icon(ic, 18)}</span><span class="stack__body"><strong>{esc(t)}</strong><span class="muted" style="display:block;font-size:14.5px;margin-top:4px">{esc(d)}</span></span></li>'
                     for i, (t, d, ic) in enumerate(reversed(FOUNDATION)))
    body = f'''{B.page_hero(crumbs, "Foundation", "What every Xevrion venture is built on.", "Six layers, proven in production by Xevrion Ops, that every new venture inherits from its first day: infrastructure, identity and security, AI governance, reliability, measurement and brand.", ctas=False,
        visual=f'<ol class="stack" aria-label="The Xevrion foundation">{layers}</ol>')}
<section class="section section--tight"><div class="wrap duo duo--top">{section_head("Why a shared foundation", "Better ventures, sooner, with fewer risks.")}
  {caps([("Speed", "Start on proven ground", "A new venture begins with working infrastructure and security instead of rebuilding them."), ("Safety", "The same standards everywhere", "Every venture passes the same security, reliability and honesty tests."), ("Trust", "One name customers can rely on", "Xevrion on the label means the same principles behind the product.")])}</div></section>
'''
    site.add(Page("/foundation", "The Xevrion foundation", "The shared foundation every Xevrion venture is built on: infrastructure, identity and security, AI governance, reliability, measurement and brand.",
                  body, crumbs=crumbs, priority=0.8, group="Group"))


def news(site: Site) -> None:
    crumbs = [("Home", "/"), ("News", None)]
    items = "".join(f'<li data-reveal><time datetime="{d}">{esc(label)}</time><div><h2>{esc(t)}</h2><p class="muted">{esc(x)}</p><p style="margin-top:10px">{arrow_link("Read more", h)}</p></div></li>' for d, label, t, x, h in NEWS)
    body = f'''{B.page_hero(crumbs, "News", "News from the Xevrion group.", "Launches, releases and changes across the ventures, newest first.", ctas=False)}
<section class="section section--tight"><div class="wrap"><ol class="updates">{items}</ol></div></section>'''
    site.add(Page("/news", "News", "News from the Xevrion group: the group of ventures, the new Xevrion Ops website and the Xevrion Ops 1.7.0 release.", body, crumbs=crumbs, priority=0.6, group="Group"))


def trust(site: Site) -> None:
    crumbs = [("Home", "/"), ("Trust centre", None)]
    items = [("Security", "Tenant isolation, sign-in, two-factor, roles, sealed credentials, approvals and audit", OPS + "/security"),
             ("Architecture", "How the platform is built, with no open ports", OPS + "/platform/architecture"),
             ("AI and human control", "Which model, where it runs, what it may do alone", OPS + "/ai"),
             ("Privacy notice", "What personal data we hold, why and for how long", OPS + "/legal/privacy"),
             ("Subprocessors", "Every provider that processes data for us", OPS + "/legal/subprocessors"),
             ("Responsible disclosure", "How to report a vulnerability", OPS + "/legal/responsible-disclosure"),
             ("System status", "Live health of the platform", OPS + "/status")]
    body = f'''{B.page_hero(crumbs, "Trust centre", "Trust, in one place.", "Security, privacy and AI governance across the Xevrion group. Each venture follows the same model; the details live with the venture that runs them.", ctas=False)}
<section class="section section--tight"><div class="wrap">{index_list(items, event_prefix="trust:")}</div></section>'''
    site.add(Page("/trust", "Trust centre", "Security, privacy, AI governance and system status across the Xevrion group, in one place.", body, crumbs=crumbs, priority=0.6, group="Group"))


def about(site: Site) -> None:
    crumbs = [("Home", "/"), ("About", None)]
    body = f'''{B.page_hero(crumbs, "About Xevrion", "A group that would rather be judged on results.", "Xevrion is a UK group that builds focused ventures on one shared foundation. Our first, Xevrion Ops, is live; our next, Xevrion Cyber, is planned.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  {answer_block("What is Xevrion?", "A UK group of focused ventures. Each venture does one job for its own customers, and all share the same infrastructure, security model, AI governance, measurement and brand.")}
  {explain("Most software is sold on features and judged on hope. We publish prices, label every number and measure what we deliver, so customers can decide for themselves whether we are worth it.", "Why Xevrion exists")}
</div></section>
<section class="section" id="principles"><div class="wrap duo duo--top">{section_head("Principles", "How every venture works.")}{ledger_list(PRINCIPLES)}</div></section>
<section class="section"><div class="wrap duo duo--top">{section_head("What we will not do", "Some things are off the table.")}
  <ul class="prose"><li>Publish borrowed logos or invented case studies.</li><li>Present an example as a customer result.</li><li>Sell a venture before it works.</li><li>Let software take consequential actions without the approval rules you set.</li><li>Put bank details on a website.</li></ul></div></section>'''
    site.add(Page("/about", "About Xevrion", "About Xevrion, the UK group behind Xevrion Ops and the planned Xevrion Cyber, and the principles every venture works by.", body, crumbs=crumbs, priority=0.7, group="Group"))


def approach(site: Site) -> None:
    crumbs = [("Home", "/"), ("Approach", None)]
    items = [("Published prices and limits", "Every Xevrion Ops plan, fee and limit is public.", OPS + "/pricing"),
             ("A tour instead of a pitch", "Watch each system work, step by step, with no sign-up.", OPS + "/demo"),
             ("Every capability listed", "The full capability index, searchable.", OPS + "/platform/capabilities"),
             ("Security you can read", "Sign-in, sessions, secrets, approvals and deletion, explained precisely.", OPS + "/security"),
             ("AI you can inspect", "Which model, where it runs and what it may do on its own.", OPS + "/ai"),
             ("Value you can audit", "Every result in pounds, with evidence and confidence.", OPS + "/product/value-ledger")]
    body = f'''{B.page_hero(crumbs, "Approach", "Transparent by design.", "Everything a customer needs to decide is published: what a venture does, what it costs, how it keeps data safe, how it uses AI and how its value is measured.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">{section_head("Check it yourself", "Six things you can verify before you buy.")}{index_list(items, event_prefix="approach:")}</div></section>
<section class="section"><div class="wrap duo duo--top">{section_head("How we build", "Engineering choices that follow from the principles.")}
  {ledger_list([("Idempotent by default", "Every change made in another system carries a key so a retry can never apply twice.", "Safety"), ("Deny when unsure", "Security checks that cannot complete refuse rather than allow.", "Safety"),
                ("Measured reliability", "Every service tracks its own error budget and alerts before customers notice.", "Reliability"), ("Deletion that really deletes", "Erasing an organisation removes its data from every service.", "Privacy")])}</div></section>'''
    site.add(Page("/approach", "Our approach", "How Xevrion builds ventures transparently: published prices, a no-sign-up tour, a public capability index, readable security, inspectable AI and auditable value.",
                  body, crumbs=crumbs, priority=0.7, group="Group"))


def contact(site: Site) -> None:
    crumbs = [("Home", "/"), ("Contact", None)]
    body = f'''{B.page_hero(crumbs, "Contact", "Write to Xevrion.", "We do not do sales calls or meetings. Send a written enquiry about any venture and you will get a precise written reply, with a reference number for your records.", ctas=False)}
<section class="section section--tight"><div class="wrap duo duo--top">
  <div class="panel glass glass--elevated glass--edge">{brief_form(source="parent-contact")}</div>
  <div>{explain("Xevrion Ops customers raise support requests from their portal, where they are prioritised by urgency. Security reports go to outreach@ops.xevrion.co.uk with “Security” in the subject.", "Already a customer?")}
  <p class="note">Email: <a class="link" href="mailto:outreach@ops.xevrion.co.uk">outreach@ops.xevrion.co.uk</a></p></div>
</div></section>'''
    site.add(Page("/contact", "Contact Xevrion", "Contact the Xevrion group in writing about any venture. Send an enquiry and get a written reply with a reference number. No sales calls.",
                  body, crumbs=crumbs, priority=0.6, group="Group"))


ATLAS_STATS = "<!--ATLAS-STATS-->"
ATLAS_INDEX = "<!--ATLAS-INDEX-->"
ATLAS_MAP = "<!--ATLAS-MAP-->"


def atlas(site: Site) -> None:
    """Every page across the three Xevrion sites and every link between them, drawn from the built pages themselves.
    build.py fills the placeholders once all sites exist: the statistics, the map (the shared relationship-web visual)
    and the full index."""
    crumbs = [("Home", "/"), ("Atlas", None)]
    body = f'''{B.page_hero(crumbs, "Atlas", "Every page across Xevrion, mapped.", "The group site, Xevrion Ops and the Portal are one connected system. This map is generated from the pages themselves at every release: points are pages, lines are the links between them.", ctas=False)}
<section class="section section--tight"><div class="wrap">{ATLAS_STATS}</div></section>
<section class="section section--tight" id="map"><div class="wrap">{ATLAS_MAP}</div></section>
<section class="section" id="index"><div class="wrap">{section_head("Index", "Every page, by site and section.", "The same map as a list: every published page, with where it lives.")}{ATLAS_INDEX}</div></section>'''
    site.add(Page("/atlas", "Atlas", "A live map of every page across the Xevrion group site, Xevrion Ops and the Portal, and every link between them, generated at each release.",
                  body, env="decisions", crumbs=crumbs, priority=0.6, group="Group", toc=[("map", "Map"), ("index", "Index")]))


def not_found(site: Site) -> None:
    body = f'''<section class="page-hero"><div class="wrap duo duo--top"><div class="hero__copy"><p class="eyebrow">404 · Page not found</p>
  <h1 class="display" style="margin:var(--s-5) 0">This page has moved or no longer exists.</h1><p class="lead">These are the places most people are looking for.</p></div>
  {index_list([("Home", "The Xevrion group", "/"), ("Ventures", "Xevrion Ops and Xevrion Cyber", "/ventures"), ("Xevrion Ops", "The business operating platform", OPS + "/"), ("Contact", "Write to us", "/contact")])}
</div></section>'''
    site.add(Page("/404", "Page not found · Xevrion", "The page you were looking for does not exist on xevrion.co.uk.", body, noindex=True, priority=0.0))


def build(site: Site) -> None:
    home(site)
    ventures(site)
    venture_ops(site)
    venture_cyber(site)
    foundation(site)
    news(site)
    trust(site)
    about(site)
    approach(site)
    contact(site)
    atlas(site)
    not_found(site)
