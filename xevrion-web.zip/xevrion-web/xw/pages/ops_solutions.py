"""Solutions: one page per outcome. The outcome and its example (hero), what changes (before and after), how it runs
in five steps, and what it is worth. They link to the product pages rather than repeat them."""
from __future__ import annotations

from .. import blocks as B
from .. import data as D
from ..components import arrow_link, claim, cta_final, index_list, metric, section_head, table, walkthrough
from ..shell import Page, Site

SOL = [
    {"slug": "revenue-growth", "name": "Revenue growth", "env": "revenue",
     "h1": "Grow revenue without growing the sales team.",
     "lead": "Xevrion points your team at the prospects most likely to buy, reaches them while the signal is fresh and shows which efforts actually produced revenue.",
     "meta": "Revenue growth with Xevrion: your team works the prospects with the highest expected value, follows up faster and learns what produces revenue.",
     "change": [["Who gets attention", "Whoever shouted last", "The prospects with the highest expected value"], ["Time to first reply", "Days", "Within the hour, drafted for approval"],
                ["Why a deal closed", "A guess", "Traced to the signal and message that started it"], ["Forecast", "One number", "A range with its drivers"]],
     "systems": ["revenue", "decision-intelligence", "customer-operations"],
     "steps": [("x", "Define who you sell to", "Learned from the customers you already win."), ("x", "Find companies that fit", "From sources you approve, plus your inbound enquiries."),
               ("x", "Rank by expected value", "Each prospect scored, with the reason shown."), ("you", "Reach out", "A relevant first message, sent once you approve it."),
               ("x", "Trace what worked", "Revenue linked back to the signal and message behind it.")],
     "value": [("£18,400", "first-year value from one prioritised prospect", "value"), ("120 → 6", "companies narrowed to the week's shortlist", ""), ("+£15K", "expected quarterly revenue from faster follow-up", "")]},
    {"slug": "operational-efficiency", "name": "Operational efficiency", "env": "operations",
     "h1": "Do the same work in a third of the time.",
     "lead": "Xevrion measures where your team's time goes, fixes the worst step first and proves the saving in pounds.",
     "meta": "Operational efficiency with Xevrion: measure each process step by step, automate the routine with approvals kept, and record the saving against your baseline.",
     "change": [["Hours per month on one process", "61", "18"], ["Error rate", "8.2%", "2.1%"], ["End-to-end time", "9.2 days", "2.5 days"], ["Monthly cost", "£6,840", "£2,020"]],
     "systems": ["business-operations", "decision-intelligence", "customer-operations"],
     "steps": [("x", "Map the real process", "Rebuilt from the work moving through your tools."), ("x", "Measure every step", "Time, waiting, errors and cost."),
               ("x", "Find the bottleneck", "The one step that costs the most."), ("you", "Automate it", "Routine steps run by themselves; approvals stay with people."),
               ("x", "Prove the saving", "Measured against your own baseline.")],
     "value": [("£4,820", "saved each month on one approval process", "value"), ("43 hrs", "of invoice matching removed each month", ""), ("−74%", "fewer errors needing rework", "")]},
    {"slug": "customer-retention", "name": "Customer retention", "env": "customers",
     "h1": "Keep the customers you have worked hard to win.",
     "lead": "Xevrion joins the warning signs spread across tickets, emails and invoices, raises risk weeks before renewal and helps the account owner act in time.",
     "meta": "Customer retention with Xevrion: an explained health score for every customer, risk flagged weeks before renewal, and every intervention approved and measured.",
     "change": [["When risk is spotted", "At renewal", "Weeks before, with its drivers"], ["Customer view", "Five tools", "One record per customer"], ["Intervention", "Ad hoc", "Recommended, approved, tracked"], ["Proof", "None", "Revenue protected, in the Value Ledger"]],
     "systems": ["customer-operations", "revenue", "decision-intelligence"],
     "steps": [("x", "Join the signals", "Tickets, emails, usage and invoices, per customer."), ("x", "Flag the risk", "A health score with its drivers, weeks before renewal."),
               ("x", "Recommend an action", "The step most likely to work, with its expected effect."), ("you", "Act on it", "Approved work, done in your own tools."),
               ("x", "Measure the outcome", "Revenue kept, recorded in the Value Ledger.")],
     "value": [("£7,300", "renewal protected after an early warning", "value"), ("82 → 61 → 84", "health: the fall, the flag and the recovery", ""), ("2 weeks", "earlier warning next time", "")]},
    {"slug": "decision-quality", "name": "Better decisions", "env": "decisions",
     "h1": "Make the big decisions earlier, with the full picture.",
     "lead": "Xevrion keeps your numbers joined up, compares options with honest ranges and writes down what was decided and why.",
     "meta": "Better decisions with Xevrion: trusted KPIs, forecasts and scenarios with honest ranges, and a record of every decision scored against what happened.",
     "change": [["KPIs", "Three versions", "One definition, calculated the same way"], ["Forecast", "A single number", "A range with confidence"], ["Options", "Argued in meetings", "Compared side by side"], ["Decision record", "In someone's head", "Written down and scored later"]],
     "systems": ["decision-intelligence", "revenue", "business-operations"],
     "steps": [("x", "Join and check the data", "Accounting, CRM and operations, quality-checked."), ("x", "Track the KPIs", "One definition per measure."),
               ("x", "Forecast with ranges", "Where things are heading, and how sure we are."), ("you", "Compare and decide", "Options side by side; you record the choice."),
               ("x", "Score it later", "Each forecast checked against what happened.")],
     "value": [("4", "scenarios compared for next quarter", ""), ("£351K–£411K", "the honest spread of expected outcomes", "value"), ("Brier", "score tracking forecast accuracy", "")]},
]
SYS = {s["key"]: s for s in D.SYSTEMS}


def _solution(site: Site, s: dict) -> None:
    from .. import charts
    crumbs = [("Home", "/"), ("Solutions", "/solutions"), (s["name"], None)]
    chart = {"revenue-growth": lambda: charts.funnel_dots(D.FUNNEL),
             "operational-efficiency": lambda: charts.before_after([("Hours per month", 61, 18, "hrs"), ("Error rate", 8.2, 2.1, "pct"), ("Monthly cost", 6840, 2020, "gbp")]),
             "customer-retention": lambda: charts.health_gauge(82, 61, [("Support tickets this month", "3 → 9", "risk"), ("Average reply time", "4 hrs → 2 days", "risk"), ("Renewal due", "45 days", "watch"), ("Invoices paid on time", "Yes", "ok")]),
             "decision-quality": lambda: charts.scenario_ranges(D.SCENARIOS)}[s["slug"]]()
    visual = f'<figure class="panel glass glass--ambient" style="margin:0"><div class="viz-head" style="display:flex;justify-content:space-between;gap:12px;margin-bottom:var(--s-4)"><span class="label">The example in numbers</span>{claim("illustrative")}</div>{chart}</figure>'
    hero = B.page_hero(crumbs, s["name"], s["h1"], s["lead"], where=f"sol:{s['slug']}", visual=visual)
    steps = [{"who": w, "role": "You approve" if w == "you" else None, "title": t, "what": d} for w, t, d in s["steps"]]
    lead, *helpers = [SYS[k] for k in s["systems"]]
    systems = (f'Led by <a class="link" href="{lead["href"]}">{lead["name"]}</a>, with help from '
               + " and ".join(f'<a class="link" href="{h["href"]}">{h["name"]}</a>' for h in helpers) + ".")
    values = "".join(metric(v, l, kind=k) for v, l, k in s["value"])
    body = f'''{hero}
<section class="section"><div class="wrap duo duo--top">
  {section_head("What changes", "Before and after.")}
  <div data-reveal>{table(["", "Before", "With Xevrion"], s["change"], caption="Numbers are an illustrative example.")}</div>
</div></section>
<section class="section"><div class="wrap">
  {section_head("How it runs", "Five steps, from start to finish.")}
  {walkthrough(steps, label=f"How {s['name'].lower()} runs")}
  <p class="note" style="margin-top:var(--s-5)">{systems}</p>
</div></section>
<section class="section"><div class="wrap">
  {section_head("What it is worth", "Measured the same way every time.")}
  <div class="metric-rail" data-reveal>{values}</div>
  <div class="section-foot"><span class="cluster">{claim("illustrative")}<span class="quiet small">Your own results are measured against your own baseline.</span></span>{arrow_link("How value is measured", "/product/value-ledger", "sol:ledger")}</div>
</div></section>
{cta_final(s["h1"], "Start with the system that leads this outcome, or take the guided tour first.", where="sol:" + s["slug"])}'''
    site.add(Page(f"/solutions/{s['slug']}", s["name"], s["meta"], body, env=s["env"], crumbs=crumbs, priority=0.8))


def index(site: Site) -> None:
    crumbs = [("Home", "/"), ("Solutions", None)]
    hero = B.page_hero(crumbs, "Solutions", "Start with the outcome you need.",
                       "Four outcomes Xevrion is built to deliver, each measured in pounds.", where="solutions")
    guide = [["You have more leads than time, or not enough of the right ones", "Revenue growth", "Revenue"],
             ["Your team spends hours copying, chasing and checking", "Operational efficiency", "Business Operations"],
             ["Customers leave without much warning", "Customer retention", "Customer Operations"],
             ["Big decisions rely on numbers nobody fully trusts", "Better decisions", "Decision Intelligence"]]
    body = f'''{hero}
<section class="section section--tight"><div class="wrap">{index_list([(s["name"], s["h1"], f"/solutions/{s['slug']}") for s in SOL], event_prefix="solutions:")}</div></section>
<section class="section"><div class="wrap duo duo--top">
  {section_head("Where to begin", "Not sure which comes first?", "Pick the sentence that sounds most like your business. That is usually the right first system.")}
  <div data-reveal>{table(["If this sounds like you", "Outcome", "Start with"], guide)}</div>
</div></section>
{cta_final("Pick one outcome. Measure it properly.", "Start on one system and add more once the Value Ledger shows it is paying for itself.", where="solutions")}'''
    site.add(Page("/solutions", "Solutions", "Four outcomes Xevrion Ops delivers: revenue growth, operational efficiency, customer retention and better decisions, each measured in pounds.",
                  body, crumbs=crumbs, priority=0.8, nav_current="/solutions"))


def build(site: Site) -> None:
    index(site)
    for s in SOL:
        _solution(site, s)
