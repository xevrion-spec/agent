"""The sites. xevrion.co.uk is the Xevrion group (a family of ventures, in the way Virgin sits over Virgin Media and
Virgin Atlantic). Xevrion Ops (ops.xevrion.co.uk) is the first venture; the Portal is the sign-in hub."""
from __future__ import annotations

from .shell import APP, OPS, PARENT, PORTAL, Site

OPS_NAV = [
    {"label": "Product", "items": [
        ("Platform overview", "Four systems on one picture of your business", "/platform", "ledger"),
        ("How it works", "From connected tools to measured value", "/how-it-works", "flow"),
        ("Revenue", "Win the customers most worth your time", "/product/revenue", "revenue"),
        ("Customer Operations", "Answer on time and keep your customers", "/product/customer-operations", "customers"),
        ("Business Operations", "Fix the process that costs you most", "/product/business-operations", "operations"),
        ("Decision Intelligence", "Decide with ranges, not guesses", "/product/decision-intelligence", "decisions"),
        ("Value Ledger", "Every result in pounds, with evidence", "/product/value-ledger", "value"),
        ("Customer portal", "The workspace your team uses, live", "/customer-portal", "status"),
    ], "foot": [("See Xevrion in action", "/demo")]},
    {"label": "Solutions", "items": [
        ("Revenue growth", "More qualified pipeline, faster follow-up", "/solutions/revenue-growth", "revenue"),
        ("Operational efficiency", "Lower cost and fewer errors", "/solutions/operational-efficiency", "operations"),
        ("Customer retention", "Spot churn risk before renewal", "/solutions/customer-retention", "customers"),
        ("Better decisions", "Plan with ranges, not guesses", "/solutions/decision-quality", "decisions"),
    ], "foot": [("Use-case library", "/use-cases")]},
    {"label": "Integrations", "href": "/integrations"},
    {"label": "Pricing", "href": "/pricing"},
    {"label": "Resources", "items": [
        ("Guides", "Getting value, step by step", "/guides", "guide"),
        ("Documentation", "Set-up, workspaces and the API", "/docs", "docs"),
        ("Security", "How your data and actions are protected", "/security", "security"),
        ("System status", "Live health of the platform", "/status", "status"),
    ], "foot": [("FAQ", "/faq"), ("Help centre", "/help")]},
]

OPS_FOOTER = [
    ("Product", [("Platform", "/platform"), ("How it works", "/how-it-works"), ("Revenue", "/product/revenue"),
                 ("Customer Operations", "/product/customer-operations"), ("Business Operations", "/product/business-operations"),
                 ("Decision Intelligence", "/product/decision-intelligence"), ("Value Ledger", "/product/value-ledger")]),
    ("Solutions", [("Revenue growth", "/solutions/revenue-growth"), ("Operational efficiency", "/solutions/operational-efficiency"),
                   ("Customer retention", "/solutions/customer-retention"), ("Better decisions", "/solutions/decision-quality"),
                   ("Use cases", "/use-cases"), ("Integrations", "/integrations")]),
    ("Company", [("About", "/about"), ("Pricing", "/pricing"), ("Security", "/security"), ("Contact", "/contact"), ("Xevrion group", PARENT + "/")]),
    ("Help", [("Guides", "/guides"), ("Documentation", "/docs"), ("FAQ", "/faq"), ("System status", "/status"), ("Legal", "/legal")]),
]

PARENT_NAV = [
    {"label": "Ventures", "items": [
        ("Xevrion Ops", "Live · the business operating platform", "/ventures/ops", "operations"),
        ("Xevrion Cyber", "Planned · security for growing businesses", "/ventures/cyber", "security"),
        ("All ventures", "The Xevrion family and how it grows", "/ventures", "ledger"),
        ("The foundation", "What every Xevrion venture shares", "/foundation", "flow"),
    ], "foot": [("Visit Xevrion Ops", OPS + "/")]},
    {"label": "Approach", "href": "/approach"},
    {"label": "About", "href": "/about"},
    {"label": "News", "href": "/news"},
    {"label": "Atlas", "href": "/atlas"},
    {"label": "Contact", "href": "/contact"},
]
PARENT_FOOTER = [
    ("Xevrion", [("Home", "/"), ("About", "/about"), ("Approach", "/approach"), ("News", "/news"), ("Atlas", "/atlas"), ("Contact", "/contact")]),
    ("Ventures", [("All ventures", "/ventures"), ("Xevrion Ops", "/ventures/ops"), ("Xevrion Cyber", "/ventures/cyber"), ("The foundation", "/foundation")]),
    ("Xevrion Ops", [("Product", OPS + "/"), ("How it works", OPS + "/how-it-works"), ("Pricing", OPS + "/pricing"), ("Get started", OPS + "/get-started")]),
    ("Trust", [("Trust centre", "/trust"), ("Security", OPS + "/security"), ("AI and control", OPS + "/ai"), ("System status", OPS + "/status")]),
    ("Legal", [("Privacy", OPS + "/legal/privacy"), ("Terms", OPS + "/legal/terms"), ("Cookies", OPS + "/legal/cookies"),
               ("Accessibility", OPS + "/accessibility")]),
]

PORTAL_NAV = [
    {"label": "Sign in", "href": "/"},
    {"label": "Access", "href": "/access"},
    {"label": "Help", "href": "/help"},
    {"label": "Xevrion Ops", "href": OPS + "/"},
]
PORTAL_FOOTER = [
    ("Portal", [("Sign in", "/"), ("Access and roles", "/access"), ("Help", "/help")]),
    ("Xevrion Ops", [("Product", OPS + "/"), ("Pricing", OPS + "/pricing"), ("Documentation", OPS + "/docs")]),
    ("Support", [("Help centre", OPS + "/help"), ("System status", OPS + "/status"), ("Contact", OPS + "/contact")]),
    ("Legal", [("Privacy", OPS + "/legal/privacy"), ("Terms", OPS + "/legal/terms")]),
]


def make_sites() -> dict[str, Site]:
    return {
        "ops": Site("ops", OPS, "Xevrion Ops", "Ops", OPS_NAV, OPS_FOOTER,
                    "Xevrion Ops connects your business data, finds valuable opportunities, helps your team act on them and measures the value created. A Xevrion venture."),
        "parent": Site("parent", PARENT, "Xevrion", None, PARENT_NAV, PARENT_FOOTER,
                       "Xevrion is a UK group building focused ventures on one shared foundation. Xevrion Ops is live; Xevrion Cyber is planned.",
                       cta=("Explore ventures", "/ventures")),
        "portal": Site("portal", PORTAL, "Xevrion Portal", "Portal", PORTAL_NAV, PORTAL_FOOTER,
                       "Sign in to Xevrion Ops: the customer portal for your team, and the operator console for Xevrion staff."),
    }


APP_URL = APP
