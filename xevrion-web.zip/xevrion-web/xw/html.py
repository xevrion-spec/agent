"""Escaping, attribute rendering and the Xevrion icon set. Every icon is a 20px line drawing with a 1.5 stroke, so
iconography stays consistent across the site; icons are decorative (aria-hidden) unless a label is given."""
from __future__ import annotations

import html as _html
from typing import Any


def esc(value: Any) -> str:
    return _html.escape(str(value), quote=True)


def attrs(values: dict[str, Any] | None) -> str:
    if not values:
        return ""
    out = []
    for key, value in values.items():
        if value is None or value is False:
            continue
        name = key.rstrip("_").replace("_", "-")
        out.append(f" {name}" if value is True else f' {name}="{esc(value)}"')
    return "".join(out)


_PATHS = {
    "revenue": '<path d="M3 16.5 8 11l3.5 3L17 7.5"/><path d="M13 7.5h4v4"/><circle cx="8" cy="11" r="1.3" fill="currentColor" stroke="none"/>',
    "customers": '<circle cx="10" cy="10" r="2.2"/><ellipse cx="10" cy="10" rx="7.2" ry="3.4"/><ellipse cx="10" cy="10" rx="7.2" ry="3.4" transform="rotate(60 10 10)"/>',
    "operations": '<rect x="2.5" y="4" width="4.5" height="4.5" rx="1"/><rect x="13" y="4" width="4.5" height="4.5" rx="1"/><rect x="7.75" y="12" width="4.5" height="4.5" rx="1"/><path d="M7 6.25h6M4.75 8.5v3.75h3M15.25 8.5v3.75h-3"/>',
    "decisions": '<circle cx="4" cy="10" r="1.6"/><path d="M5.6 10H9m0 0 4-5.2M9 10l4 0m-4 0 4 5.2"/><circle cx="14.8" cy="4.8" r="1.6"/><circle cx="14.8" cy="10" r="1.6"/><circle cx="14.8" cy="15.2" r="1.6"/>',
    "ledger": '<path d="M4 5h12M4 9h12M4 13h7"/><path d="m12.5 15 2 2 3.5-4"/>',
    "flow": '<circle cx="3.5" cy="10" r="1.5"/><circle cx="10" cy="10" r="1.5"/><circle cx="16.5" cy="10" r="1.5"/><path d="M5 10h3.5m3 0H15"/><path d="M10 4v4.5M10 11.5V16"/>',
    "integrations": '<circle cx="10" cy="10" r="2.5"/><circle cx="3.5" cy="4.5" r="1.5"/><circle cx="16.5" cy="4.5" r="1.5"/><circle cx="3.5" cy="15.5" r="1.5"/><circle cx="16.5" cy="15.5" r="1.5"/><path d="m4.7 5.6 3.4 2.8m7.2-2.8-3.4 2.8m-7.2 6.2 3.4-2.8m7.2 2.8-3.4-2.8"/>',
    "security": '<path d="M10 2.5 16 5v4.6c0 3.6-2.5 6.6-6 7.9-3.5-1.3-6-4.3-6-7.9V5z"/><path d="m7.3 10 1.9 1.9 3.6-3.8"/>',
    "ai": '<rect x="3" y="3" width="14" height="4" rx="1"/><rect x="3" y="8" width="14" height="4" rx="1"/><rect x="3" y="13" width="14" height="4" rx="1"/><circle cx="6" cy="5" r=".8" fill="currentColor"/><circle cx="6" cy="10" r=".8" fill="currentColor"/><circle cx="6" cy="15" r=".8" fill="currentColor"/>',
    "pricing": '<path d="M3.5 10.5 10.5 3.5H16.5V9.5L9.5 16.5z"/><circle cx="13.2" cy="6.8" r="1.2"/>',
    "docs": '<path d="M5 2.5h7l3.5 3.5v11.5H5z"/><path d="M12 2.5V6h3.5M7.5 10h5M7.5 13h5"/>',
    "guide": '<path d="M3 4.5c2.5-1 4.8-1 7 .5 2.2-1.5 4.5-1.5 7-.5v11c-2.5-1-4.8-1-7 .5-2.2-1.5-4.5-1.5-7-.5z"/><path d="M10 5v11"/>',
    "updates": '<circle cx="10" cy="10" r="7"/><path d="M10 6v4l2.8 2"/>',
    "status": '<path d="M2.5 10h3l2-5 3 10 2-5h5"/>',
    "help": '<circle cx="10" cy="10" r="7"/><path d="M8 8a2 2 0 1 1 2.6 1.9c-.4.2-.6.5-.6 1v.6"/><circle cx="10" cy="14" r=".6" fill="currentColor"/>',
    "company": '<path d="M3 17V7l7-4 7 4v10"/><path d="M8 17v-4h4v4"/>',
    "mail": '<rect x="2.5" y="4.5" width="15" height="11" rx="1.5"/><path d="m3 5.5 7 5.5 7-5.5"/>',
    "value": '<path d="M10 2.5v15"/><path d="M13.5 5.5H8.3a2.3 2.3 0 0 0 0 4.6h3.4a2.3 2.3 0 0 1 0 4.6H6"/>',
    "learn": '<path d="M16 10a6 6 0 1 1-1.8-4.3"/><path d="M16 3.5v3.3h-3.3"/>',
    "arrow": '<path d="M4 10h11m-4.5-4.5L15 10l-4.5 4.5"/>',
    "arrow-up-right": '<path d="M6 14 14 6m-6 0h6v6"/>',
    "chevron": '<path d="m5.5 8 4.5 4.5L14.5 8"/>',
    "check": '<path d="m4.5 10.5 3.5 3.5 7.5-8"/>',
    "menu": '<path d="M3 6.5h14M3 13.5h14"/>',
    "close": '<path d="m5 5 10 10M15 5 5 15"/>',
    "search": '<circle cx="9" cy="9" r="5.5"/><path d="m13.2 13.2 3.8 3.8"/>',
    "spark": '<path d="M10 2.5v4M10 13.5v4M2.5 10h4M13.5 10h4"/><circle cx="10" cy="10" r="2"/>',
    "lock": '<rect x="4" y="9" width="12" height="8.5" rx="1.5"/><path d="M6.5 9V6.5a3.5 3.5 0 0 1 7 0V9"/>',
    "key": '<circle cx="6.5" cy="13.5" r="3.5"/><path d="m9 11 7.5-7.5M13.5 6.5l2 2"/>',
    "user": '<circle cx="10" cy="7" r="3.2"/><path d="M3.8 17c.8-3.2 3.3-5 6.2-5s5.4 1.8 6.2 5"/>',
    "audit": '<path d="M4 3.5h12v13H4z"/><path d="M7 7.5h6M7 10.5h6M7 13.5h3.5"/>',
    "backup": '<ellipse cx="10" cy="5" rx="6" ry="2.5"/><path d="M4 5v10c0 1.4 2.7 2.5 6 2.5s6-1.1 6-2.5V5M4 10c0 1.4 2.7 2.5 6 2.5s6-1.1 6-2.5"/>',
    "approval": '<circle cx="10" cy="10" r="7"/><path d="m7 10 2.2 2.2L13.5 8"/>',
    "tenant": '<rect x="2.5" y="2.5" width="6.5" height="6.5" rx="1"/><rect x="11" y="2.5" width="6.5" height="6.5" rx="1"/><rect x="2.5" y="11" width="6.5" height="6.5" rx="1"/><rect x="11" y="11" width="6.5" height="6.5" rx="1"/>',
    "clock": '<circle cx="10" cy="10" r="7"/><path d="M10 6v4l2.5 1.5"/>',
    "external": '<path d="M11.5 3.5h5v5M16 4l-7 7"/><path d="M14 11.5V16H4V6h4.5"/>',
    "play": '<circle cx="10" cy="10" r="7.2"/><path d="m8.4 7 4.6 3-4.6 3z" fill="currentColor"/>',
}


def icon(name: str, size: int = 20, label: str | None = None, cls: str = "") -> str:
    a11y = f' role="img" aria-label="{esc(label)}"' if label else ' aria-hidden="true" focusable="false"'
    c = f' class="{esc(cls)}"' if cls else ""
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" '
            f'stroke-linecap="round" stroke-linejoin="round"{c}{a11y}>{_PATHS[name]}</svg>')


# The Xevrion mark, "Slice": a heavy ring and one blade. The blade starts as a point inside the ring and widens as it
# cuts out through the upper right: the whole business (the ring) and the intelligence that starts at its centre and
# acts beyond it (the blade). Flat and monochrome, it takes the text colour. Geometry on a 32-unit grid: ring radii 13
# and 8.8 about (16, 16); the blade runs at 45 degrees from 3.6 units behind the centre to 15.6 in front, 5.2 wide at
# its end; the ring is cut 1.4 clear of each blade edge, so the gap is even on both sides.
MARK_PATHS = (
    "M27.37 9.71A13 13 0 1 1 22.29 4.63L19.71 8.02A8.8 8.8 0 1 0 23.98 12.29Z",   # the ring
    "M13.45 18.55L28.87 6.81L25.19 3.13Z",                                        # the blade
)


def _paths(fill: str) -> str:
    # one path element per shape: overlapping shapes in a single path can cancel out under the non-zero fill rule
    return "".join(f'<path d="{d}" fill="{fill}"/>' for d in MARK_PATHS)


# The chrome finish: polished metal, lit from above. A bright sky reflection, a sharp dark horizon just below the
# middle, then a bright ground reflection, with a diagonal sheen across it all. The gradients use the mark's own
# 32-unit grid (userSpaceOnUse), so the metal is identical at every size. Keep in step with CHROME in
# src/js/viz-constellation.js and the portal kit (platform-gateway/portal-ui/kit.js).
CHROME_STOPS = ((0, "#ffffff"), (.24, "#e9ecf2"), (.45, "#9ba1af"), (.5, "#4f5463"), (.53, "#cfd4de"), (.72, "#ffffff"), (1, "#a9afbc"))


def _chrome_defs(p: str) -> str:
    stops = "".join(f'<stop offset="{o}" stop-color="{c}"/>' for o, c in CHROME_STOPS)
    return (f'<linearGradient id="{p}-chrome" gradientUnits="userSpaceOnUse" x1="16" y1="3" x2="16" y2="29">{stops}</linearGradient>'
            f'<linearGradient id="{p}-sheen" gradientUnits="userSpaceOnUse" x1="5" y1="5" x2="27" y2="27">'
            '<stop offset=".38" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".6"/>'
            '<stop offset=".62" stop-color="#fff" stop-opacity="0"/></linearGradient>')


def _chrome(p: str) -> str:
    """The mark in chrome: the metal, then the sheen over it."""
    return _paths(f"url(#{p}-chrome)") + _paths(f"url(#{p}-sheen)")


# Every page carries the chrome definitions once, in a zero-size sprite (not display:none, which stops some browsers
# painting gradients defined inside it), and each mark on the page refers to them.
MARK_SPRITE = f'<svg class="sprite" aria-hidden="true" focusable="false"><defs>{_chrome_defs("xv")}</defs></svg>'
BRAND_MARK = f'<svg class="brand__mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false">{_chrome("xv")}</svg>'


def brand_mark(n: int | str = "") -> str:
    """The mark (kept as a function so call sites stay stable if the mark ever needs per-instance ids again)."""
    return BRAND_MARK


def mark_standalone(prefix: str = "m", attrs_: str = "", color: str = "") -> str:
    """A self-contained mark for files and images: chrome by default (for dark backgrounds), or flat in `color`."""
    if color:
        return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"{attrs_}>{_paths(color)}</svg>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"{attrs_}><defs>{_chrome_defs(prefix)}</defs>{_chrome(prefix)}</svg>'


def mark_flat(color: str = "#0b0c11") -> str:
    """The mark in charcoal, for light backgrounds and print."""
    return mark_standalone(color=color)


def favicon_svg() -> str:
    """Favicon: the chrome mark on a black tile, readable on light and dark browser tabs."""
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs>' + _chrome_defs("f") + '</defs>'
            '<rect width="32" height="32" rx="7" fill="#000"/>'
            f'<g transform="translate(3.2 3.2) scale(.8)">{_chrome("f")}</g></svg>')


