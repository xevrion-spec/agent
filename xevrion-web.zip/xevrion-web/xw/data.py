"""Single source of truth for every fact and number the sites publish.

Facts come from the platform itself (plans.py, connector_catalog.py, docs/*.md). Illustrative examples are fixed here so
the homepage, product pages, Value Ledger and demo tour always tell the same story with the same numbers.
"""
from __future__ import annotations

# ------------------------------------------------------------------------------------------------ plans (verified)
# Prices: the published price list. Entitlements: platform-gateway/src/platform_gateway/plans.py.
PLANS = [
    {"key": "start", "name": "Start", "monthly": 2500, "setup": 2000, "modules": 1, "team": 3, "integrations": 3,
     "workflows": 500, "ai_calls": 300, "scenarios": False, "priority": False,
     "fit": "One system, one team, one measurable goal. The fastest way to prove value on a single problem.",
     "support": "Support requests from your portal, prioritised by urgency"},
    {"key": "growth", "name": "Growth", "monthly": 5000, "setup": 3500, "modules": 2, "team": 15, "integrations": 12,
     "workflows": 5000, "ai_calls": 1000, "scenarios": False, "priority": False, "featured": True,
     "fit": "Two systems working together, for example Revenue and Customer Operations, across a growing team.",
     "support": "Support requests from your portal, prioritised by urgency"},
    {"key": "scale", "name": "Scale", "monthly": 10000, "setup": 7000, "modules": 4, "team": 50, "integrations": 50,
     "workflows": 50000, "ai_calls": 3000, "scenarios": True, "priority": True,
     "fit": "All four systems, scenario planning and priority onboarding for a business running several teams.",
     "support": "Priority onboarding and prioritised support"},
    {"key": "custom", "name": "Custom", "monthly": None, "setup": None, "modules": 4, "team": 250, "integrations": 250,
     "workflows": 500000, "ai_calls": 10000, "scenarios": True, "priority": True,
     "fit": "Larger organisations, unusual volumes or specific contract, security or data-residency terms.",
     "support": "Support terms agreed in your contract"},
]
PLAN = {p["key"]: p for p in PLANS}


def money(v: float | int | None, *, per: str = "") -> str:
    if v is None:
        return "Tailored"
    return f"£{v:,.0f}{per}"


# ------------------------------------------------------------------------------------------------ systems (products)
SYSTEMS = [
    {"key": "revenue", "name": "Revenue", "href": "/product/revenue", "icon": "revenue",
     "one": "Finds the customers most worth your time, explains why, and helps your team reach them first.",
     "outcome": "More of the right pipeline, less time on the wrong prospects."},
    {"key": "customer-operations", "name": "Customer Operations", "href": "/product/customer-operations", "icon": "customers",
     "one": "Keeps a live picture of every customer, spots risk early and recommends the next best action.",
     "outcome": "Fewer surprises at renewal, faster answers, more expansion."},
    {"key": "business-operations", "name": "Business Operations", "href": "/product/business-operations", "icon": "operations",
     "one": "Maps how work really moves, finds where time and money leak, and automates the steps that should be automatic.",
     "outcome": "Lower cost per process, fewer errors, faster cycle times."},
    {"key": "decision-intelligence", "name": "Decision Intelligence", "href": "/product/decision-intelligence", "icon": "decisions",
     "one": "Turns your numbers into forecasts, scenarios and recommendations, with honest ranges instead of false certainty.",
     "outcome": "Better decisions made earlier, with the reasoning written down."},
]

# The operating loop: the same eight stages on every page that explains it.
LOOP = [
    {"name": "Connect", "title": "Connect the tools you already use",
     "what": "You sign in to your own tools (email, CRM, support desk, accounting) and approve exactly what Xevrion may read and, separately, what it may change.",
     "inputs": "Your accounts in Gmail, Microsoft 365, HubSpot, Salesforce, Zendesk, Xero and others",
     "system": "Stores each credential in a sealed secret store, never in the application database, and checks the connection works",
     "output": "A verified, permission-scoped connection for each tool",
     "control": "You choose read or write per tool and can disconnect at any time"},
    {"name": "Understand", "title": "Build one picture of the business",
     "what": "Records from different tools are matched to the same customer, deal, invoice or process, so information stops living in separate places.",
     "inputs": "Contacts, conversations, tickets, invoices, deals and workflow events",
     "system": "Resolves duplicates, links related records and checks data quality before anything relies on it",
     "output": "A connected, quality-checked model of customers, work and money",
     "control": "Data-quality issues are shown to you, not hidden"},
    {"name": "Identify", "title": "Find what is worth acting on",
     "what": "Xevrion looks for the moments that matter: a prospect showing real intent, a customer going quiet, a process step where work piles up.",
     "inputs": "The connected model plus your goals and priorities",
     "system": "Scores opportunities and risks by expected value and explains the evidence behind each one",
     "output": "A short, ranked list of opportunities and risks, each with its reason",
     "control": "You set the goals and thresholds that decide what gets surfaced"},
    {"name": "Decide", "title": "Recommend what should happen next",
     "what": "For each opportunity Xevrion sets out the possible actions, what each is likely to achieve and how confident it is.",
     "inputs": "The ranked opportunity, history of similar situations, your policies",
     "system": "Compares options with honest ranges and never presents a forecast as a certainty",
     "output": "A recommended action with alternatives, expected value and confidence",
     "control": "A person approves anything consequential. Policies define what needs approval"},
    {"name": "Act", "title": "Help carry out the work",
     "what": "Approved actions are carried out in your own tools: a drafted email, a created task, an updated record, a routed ticket.",
     "inputs": "The approved decision and the permissions you granted",
     "system": "Executes each step once, with an idempotency key so a retry can never send or charge twice",
     "output": "The work done, in the system where your team already works",
     "control": "Every action runs within the permissions and policies you set, and is logged"},
    {"name": "Verify", "title": "Check what actually happened",
     "what": "Xevrion watches for the result: did the prospect reply, did the customer renew, did the process get faster?",
     "inputs": "Outcomes read back from your connected tools",
     "system": "Matches outcomes to the actions that preceded them and flags anything that failed or is uncertain",
     "output": "A verified outcome, or an honest 'not yet' or 'did not work'",
     "control": "Failed or ambiguous actions are raised for a person to review"},
    {"name": "Value", "title": "Measure the value in pounds",
     "what": "Verified outcomes are converted into money (revenue generated, revenue protected, cost removed) and recorded in the Value Ledger.",
     "inputs": "Verified outcomes, your prices and your cost baselines",
     "system": "Calculates each line with its source, method and a confidence level; low-confidence value is shown but not counted",
     "output": "A line-by-line ledger of value created, compared with what Xevrion costs",
     "control": "Every line can be inspected, questioned and excluded"},
    {"name": "Learn", "title": "Get better every cycle",
     "what": "What worked and what did not is fed back, so scoring, recommendations and forecasts improve with your own results.",
     "inputs": "Outcomes, forecast accuracy and your feedback",
     "system": "Recalibrates scoring and forecasts against what actually happened, and tracks its own accuracy",
     "output": "Sharper priorities and more reliable forecasts next time",
     "control": "Changes to policies and automations stay with you"},
]

# ------------------------------------------------------------------------------------------------ connectors (verified)
# From connector_catalog.py and docs/CONNECTORS.md. auth: how the customer connects.
CONNECTORS = [
    {"key": "gmail", "name": "Gmail", "category": "Email", "auth": "Google sign-in (OAuth 2.0 with PKCE)",
     "reads": ["Email messages (read-only scope)"], "writes": ["Send email you have approved"],
     "scopes": "gmail.readonly · gmail.send (only if you allow sending)", "systems": ["revenue", "customer-operations"],
     "sync": "Reads new messages on a schedule; sends only approved drafts", "options": None,
     "notes": "Sending is a separate permission. Without it, Xevrion can read and draft but never send."},
    {"key": "microsoft-365", "name": "Microsoft 365", "category": "Email", "auth": "Microsoft sign-in (OAuth 2.0 with PKCE)",
     "reads": ["Outlook mail (Mail.Read)"], "writes": ["Send approved email (Mail.Send)"],
     "scopes": "Mail.Read · Mail.Send (only if you allow sending) · User.Read", "systems": ["revenue", "customer-operations"],
     "sync": "Reads new messages on a schedule; sends only approved drafts", "options": "Your Microsoft directory (tenant)",
     "notes": "Works with your organisation's own Microsoft directory, so your IT policies still apply."},
    {"key": "other-email", "name": "Other email (IMAP/SMTP)", "category": "Email", "auth": "Mailbox credentials for IMAP and SMTP",
     "reads": ["Messages in the mailbox you connect, such as a shared inbox"], "writes": ["Send approved email through your SMTP server"],
     "scopes": "The single mailbox you connect", "systems": ["revenue", "customer-operations"],
     "sync": "Reads the mailbox on a schedule", "options": "Mail server host and port",
     "notes": "For providers other than Google and Microsoft, and for shared inboxes."},
    {"key": "hubspot", "name": "HubSpot", "category": "CRM", "auth": "HubSpot sign-in (OAuth 2.0)",
     "reads": ["Contacts (crm.objects.contacts.read)"], "writes": [],
     "scopes": "oauth · crm.objects.contacts.read", "systems": ["revenue", "customer-operations", "decision-intelligence"],
     "sync": "Reads contacts on a schedule", "options": None,
     "notes": "Read-only today: Xevrion uses your HubSpot contacts to understand customers and never changes them."},
    {"key": "salesforce", "name": "Salesforce", "category": "CRM", "auth": "Salesforce Connected App (OAuth 2.0 with PKCE)",
     "reads": ["Leads, contacts, accounts, opportunities, tasks and cases", "Bounded single SELECT queries"],
     "writes": ["Create, update or upsert leads, contacts, accounts, opportunities, tasks and cases"],
     "scopes": "api · refresh_token", "systems": ["revenue", "customer-operations", "decision-intelligence"],
     "sync": "Reads on demand and on a schedule; writes carry an idempotency key", "options": None,
     "notes": "The API host must be a Salesforce domain; Xevrion rejects anything else."},
    {"key": "slack", "name": "Slack", "category": "Messaging", "auth": "Slack app install (OAuth 2.0)",
     "reads": ["Channel list", "Look up a teammate by email"], "writes": ["Post a message to a channel the bot is invited to"],
     "scopes": "channels:read · groups:read · users:read · users:read.email · chat:write", "systems": ["customer-operations", "business-operations"],
     "sync": "Posts on events, such as an approval request or a risk alert", "options": None,
     "notes": "The Xevrion bot can only post in channels you invite it to."},
    {"key": "zendesk", "name": "Zendesk", "category": "Support", "auth": "Zendesk OAuth (with PKCE)",
     "reads": ["Tickets", "Users"], "writes": ["Create tickets", "Add comments"],
     "scopes": "tickets:read · users:read · tickets:write", "systems": ["customer-operations"],
     "sync": "Reads tickets on a schedule; writes are idempotent", "options": "Your Zendesk subdomain",
     "notes": "Ticket creation passes an Idempotency-Key to Zendesk, so a retry never creates a duplicate."},
    {"key": "intercom", "name": "Intercom", "category": "Support", "auth": "Intercom OAuth",
     "reads": ["Contacts", "Conversations"], "writes": ["Create contacts", "Reply to conversations"],
     "scopes": "Set in the Intercom app", "systems": ["customer-operations"],
     "sync": "Reads conversations on a schedule", "options": "Data region (US, EU or Australia)",
     "notes": "UK and EU workspaces are usually hosted in Intercom's EU region; Xevrion connects to the right one."},
    {"key": "segment", "name": "Segment", "category": "Analytics", "auth": "Your Segment source write key",
     "reads": [], "writes": ["Track, identify, group and page events"],
     "scopes": "Write key for one source", "systems": ["decision-intelligence"],
     "sync": "Sends events as they happen, each with a message ID", "options": "Region",
     "notes": "Write-only: Xevrion sends outcome events to Segment so your analytics stack sees them too."},
    {"key": "xero", "name": "Xero", "category": "Accounting", "auth": "Xero sign-in (OAuth 2.0 with PKCE)",
     "reads": ["Organisation", "Invoices", "Contacts"], "writes": ["Create invoices (as DRAFT unless you choose otherwise)", "Create contacts"],
     "scopes": "accounting.transactions(.read) · accounting.contacts(.read) · accounting.settings.read", "systems": ["business-operations", "decision-intelligence"],
     "sync": "Reads on a schedule; writes are idempotent", "options": "The organisation you choose on Xero's consent screen",
     "notes": "Invoices are created as drafts by default, so nothing is issued until a person approves it in Xero."},
    {"key": "quickbooks", "name": "QuickBooks Online", "category": "Accounting", "auth": "Intuit sign-in (OAuth 2.0)",
     "reads": ["Company information", "Invoices", "Bounded single SELECT queries"], "writes": ["Create invoices", "Create customers"],
     "scopes": "com.intuit.quickbooks.accounting", "systems": ["business-operations", "decision-intelligence"],
     "sync": "Reads on a schedule; writes carry Intuit's requestid for idempotency", "options": "Company, sandbox or production",
     "notes": "Every create uses Intuit's own duplicate protection as well as Xevrion's."},
    {"key": "notion", "name": "Notion", "category": "Knowledge", "auth": "Notion public integration (OAuth 2.0)",
     "reads": ["Only the pages and databases you share"], "writes": ["Create pages", "Append content"],
     "scopes": "Chosen by you in Notion's page picker", "systems": ["business-operations", "decision-intelligence"],
     "sync": "Reads shared pages on demand", "options": "Pages and databases to share",
     "notes": "Xevrion sees nothing in Notion that you have not explicitly shared with it."},
    {"key": "website", "name": "Website", "category": "Website", "auth": "Website channel set up in the portal",
     "reads": ["Enquiries and messages from your website"], "writes": ["Written replies you have approved"],
     "scopes": "Your website channel only", "systems": ["revenue", "customer-operations"],
     "sync": "Enquiries arrive as they are submitted", "options": None,
     "notes": "Website enquiries join the same picture as email, so no lead is handled twice or missed."},
]
CONNECTOR = {c["key"]: c for c in CONNECTORS}
CONNECTOR_CATEGORIES = ["Email", "CRM", "Support", "Messaging", "Accounting", "Knowledge", "Analytics", "Website"]

# ------------------------------------------------------------------------------------------------ illustrative examples
# One fictional month for one fictional GROWTH customer. Every example on the site draws from these figures.
EXAMPLE = {
    "opportunity": 18400,          # revenue opportunity identified and then won (Revenue)
    "protected": 7300,             # renewal kept (Customer Operations)
    "saving_process": 4820,        # purchase-approval process, per month (Business Operations)
    "invoice_hours": 43,           # hours removed by automated invoice matching
    "invoice_saving": 3820,        # its monthly saving
    "excluded": 2100,              # low-confidence value shown, not counted
}
LEDGER = [
    {"action": "Prioritised a high-intent prospect and drafted the follow-up", "short": ("Prospect prioritised", "Contract signed"), "system": "Revenue", "category": "Revenue generated",
     "outcome": "Annual contract signed after 3 conversations", "value": 18400, "confidence": "High",
     "method": "First-year contract value from the signed order in your CRM", "source": "Salesforce opportunity (Closed Won)",
     "attribution": "Xevrion surfaced and ranked the prospect; your team ran the conversations"},
    {"action": "Flagged a customer whose health fell from 82 to 61 and recommended a success call", "short": ("Risk flagged early", "Renewal kept"), "system": "Customer Operations",
     "category": "Revenue protected", "outcome": "Renewal signed on time", "value": 7300, "confidence": "Medium",
     "method": "Annual renewal value; counted at medium confidence because the account manager was already in contact",
     "source": "Renewal invoice in Xero", "attribution": "Shared: Xevrion's alert plus the account manager's call"},
    {"action": "Automated invoice matching against purchase orders", "short": ("Matching automated", "43 hours removed"), "system": "Business Operations", "category": "Costs reduced",
     "outcome": "43 hours of manual matching removed this month", "value": 3820, "confidence": "High",
     "method": "43 hours × fully loaded hourly cost, measured against the 90-day baseline", "source": "Workflow run records",
     "attribution": "Direct: the work is now done by the automation"},
    {"action": "Suggested a price change on low-margin repeat orders", "short": ("Price change suggested", "Margin up, 14 orders"), "system": "Decision Intelligence", "category": "Revenue generated",
     "outcome": "Margin improved on 14 orders", "value": 2100, "confidence": "Low",
     "method": "Difference against prior margin; other price changes happened in the same period", "source": "QuickBooks invoices",
     "attribution": "Unclear: several changes overlapped, so this is shown but not counted"},
]
LEDGER_COUNTED = sum(x["value"] for x in LEDGER if x["confidence"] != "Low")          # 29,520
LEDGER_COST = PLAN["growth"]["monthly"]                                               # 5,000
LEDGER_ROI = LEDGER_COUNTED / LEDGER_COST                                              # 5.9x

FUNNEL = [("Discovered", 120, "Companies matching your market definition"), ("Fit your ideal customer", 47, "Right size, sector and need"),
          ("Meaningful signals", 14, "Hiring, funding, tender or intent activity"), ("High expected value", 6, "Likely value × likelihood to convert"),
          ("Conversations", 3, "Replied and booked a call"), ("Customer", 1, "Signed: £18,400 first-year value")]

PROCESS_BEFORE = {"hours": 61, "error": 8.2, "cost": 6840}
PROCESS_AFTER = {"hours": 18, "error": 2.1, "cost": 2020}
PROCESS_STEPS = [  # Request → Review → CRM → Finance → Approval → Processing → Update (hours per month, wait in days)
    {"name": "Request", "owner": "Requester", "hours": 4, "wait": 0.2, "error": 1.1},
    {"name": "Review", "owner": "Team lead", "hours": 9, "wait": 1.5, "error": 1.4},
    {"name": "CRM entry", "owner": "Sales ops", "hours": 11, "wait": 0.8, "error": 2.3},
    {"name": "Finance review", "owner": "Finance", "hours": 19, "wait": 3.6, "error": 1.9, "bottleneck": True},
    {"name": "Approval", "owner": "Director", "hours": 5, "wait": 2.1, "error": 0.3},
    {"name": "Processing", "owner": "Operations", "hours": 9, "wait": 0.6, "error": 0.9},
    {"name": "Update", "owner": "Sales ops", "hours": 4, "wait": 0.4, "error": 0.3},
]

SCENARIOS = [  # quarterly revenue scenarios: expected, low, high, confidence, driver
    {"name": "Current path", "expected": 382000, "low": 356000, "high": 404000, "confidence": "Medium", "driver": "Pipeline converts at today's 18% rate"},
    {"name": "Faster follow-up", "expected": 397000, "low": 368000, "high": 421000, "confidence": "Medium", "driver": "Respond to high-intent leads within 1 hour instead of 2 days"},
    {"name": "Add a second product line", "expected": 411000, "low": 352000, "high": 458000, "confidence": "Low", "driver": "New line sells to 12% of existing customers"},
    {"name": "Lose the largest customer", "expected": 351000, "low": 339000, "high": 366000, "confidence": "High", "driver": "Largest account (8% of revenue) does not renew"},
]

# ------------------------------------------------------------------------------------------------ security facts (verified)
SECURITY = [
    ("Tenant isolation", "tenant", "Every record belongs to one organisation. Every request carries its organisation and is checked against membership and role before anything is read or changed. Checks that cannot be completed deny rather than allow."),
    ("Sign-in", "key", "Passwords are stored only as salted PBKDF2-SHA256 hashes. Sessions are opaque tokens that expire after 12 hours, are stored only as a digest and can be revoked. Resetting a password signs out every session."),
    ("Two-factor authentication", "lock", "Standard six-digit authenticator codes (RFC 6238 TOTP). Recovery codes are shown once, stored only as digests and used once. Turning MFA on or off signs out your other sessions."),
    ("Roles and permissions", "user", "Owners and administrators manage the team; roles are checked on every organisation route. Invitations are single-use, expire and only work for the invited email address."),
    ("Human approval", "approval", "Consequential actions are policy-controlled and approval-aware. AI output is treated as evidence, never as authority to act without limits."),
    ("Audit trail", "audit", "Actions, approvals, support requests and deletions are recorded with who, what and when. A minimal record of deletion is kept even after your data is removed."),
    ("Secrets and connections", "key", "Connection credentials are sealed in a separate secret store. The application database holds only an opaque reference, never your provider tokens."),
    ("Safe retries", "flow", "Every change made in another system carries an idempotency key. If an outcome is unknown, Xevrion reconciles it rather than trying again elsewhere, so nothing is sent or created twice."),
    ("Backups and recovery", "backup", "Every upgrade starts with a full database backup and a tagged rollback image, so a bad release can be reversed. Durable job leases, retries, dead-letter queues and reconciliation let interrupted work resume safely instead of repeating."),
    ("No open doors", "lock", "The platform has no ports open to the internet. It is reachable only through an encrypted Cloudflare Tunnel, and the websites carry strict security headers, including a content security policy."),
    ("Cancellation and deletion", "close", "Cancelling removes entitlements, stops queued work and revokes connections straight away. You can export, and an owner can then complete deletion with a recorded reason."),
]

COMPANY = {"name": "Xevrion", "product": "Xevrion Ops", "email": "outreach@ops.xevrion.co.uk", "country": "United Kingdom"}

# ------------------------------------------------------------------------------------------------ published statistics
# From docs/SECTOR_TARGETS.md, with the original sources. These describe sectors, never a named business, and are
# context for the problem, not evidence that Xevrion solves it.
LSBS = ("Longitudinal Small Business Survey 2024 (SME employers), Department for Business and Trade",
        "https://www.gov.uk/government/statistics/small-business-survey-2024-businesses-with-employees/longitudinal-small-business-survey-2024-sme-employers-businesses-with-1-to-249-employees")
ORR = ("Office of Rail and Road, complaints handling performance 2024-25",
       "https://www.orr.gov.uk/complaints-handling-and-delay-compensation-operator-performance-and-continuous-improvement-actions")
OFCOM_PARCEL = ("Ofcom, parcel firms customer satisfaction 2025",
                "https://www.ofcom.org.uk/post/deliveries-and-charges/best-and-worst-parcel-firms-for-customer-satisfaction-revealed-2025")
OFCOM_BB = ("Ofcom, telecoms complaint handling 2024",
            "https://www.ofcom.org.uk/phones-and-broadband/service-quality/telecoms-companies-up-their-game-on-complaint-handling-but-more-to-do-to-keep-customers-satisfied")
STATS = {
    "revenue": [("51%", "of transport and storage SME employers name competition as an obstacle to their business", LSBS),
                ("48%", "in information and communications say the same", LSBS),
                ("46%", "in construction say the same", LSBS)],
    "customers": [("31%", "of rail passengers who complained were satisfied with how it was handled (2024-25)", ORR),
                  ("46%", "satisfaction with parcel delivery complaint handling (2025)", OFCOM_PARCEL),
                  ("58%", "satisfaction with broadband complaint handling (2024)", OFCOM_BB)],
    "operations": [("84%", "of SME employers in the primary sector name regulation as an obstacle", LSBS),
                   ("66%", "in finance and real estate say the same", LSBS),
                   ("66%", "in transport and storage say the same", LSBS)],
    "decisions": [("58%", "of construction SME employers use technology or web software to sell or manage the business", LSBS),
                  ("62%", "in the primary sector", LSBS),
                  ("63%", "in manufacturing", LSBS)],
}
