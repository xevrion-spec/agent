# Xevrion websites

This project builds **xevrion.co.uk**, **ops.xevrion.co.uk** and **portal.ops.xevrion.co.uk** as static sites.
- The Cloudflare Worker `xevrion-websites` serves all three.
- Forms, the assistant and usage measurement call the Xevrion platform on OVH (`api.xevrion.co.uk`).
- There are no third-party scripts, font CDNs or trackers.
- Only the production hosts (`*.xevrion.co.uk`) call the API. Local and workers.dev previews measure nothing and show
  "Preview: not sent" on forms and the assistant.
- Sign-up links open the app's Create account tab with the plan: `https://api.xevrion.co.uk/app?plan=<start|growth|scale>#signup`
  (`blocks.app_link`). Sign-in links stay bare (`/app`).

## Everyday use

```
python build.py --strict                                                          # build dist/ and run every check
node tools/test_worker.mjs                                                        # Worker checks (redirects, HTTPS, hosts) on the built worker-dist/
node tools/test_core_analytics.mjs                                                # measurement checks for src/js/core.js
python tools/serve.py                                                             # preview: parent :8801, ops :8802, portal :8803
powershell -ExecutionPolicy Bypass -File scripts\deploy-websites.ps1 -Target preview       # workers.dev preview (noindex)
powershell -ExecutionPolicy Bypass -File scripts\deploy-websites.ps1 -Target production    # the live sites
python tools/render_images.py                                                     # re-render social cards and icons (uses local Edge)
```

**How the live sites were deployed (24 September 2026):** with Wrangler, using `wrangler.toml` in this folder.
- Wrangler is signed in to the Cloudflare account through Cloudflare's OAuth consent, limited to Workers
  permissions.
- Commands: `python build.py --strict`, then `wrangler deploy --env preview` or `wrangler deploy`.
- Custom domains are managed in the Cloudflare dashboard; deploys leave them untouched.

**Alternative:** `scripts\deploy-websites.ps1` deploys with an API token, saved once with `scripts\set-cloudflare-token.ps1`.

**To roll back:** run `wrangler rollback`, or open Cloudflare → Workers → `xevrion-websites` → Deployments. The
version live before the rebuild was `498b8ae4`.

## Where things live

| Path | What it is |
|---|---|
| `xw/data.py` | **Every fact and number on the sites.** Plans, limits, connectors, security facts, statistics with sources, and the one illustrative example used everywhere. Change a price here and every page follows. |
| `xw/pages/*.py` | Page content: `ops_home`, `ops_core` (platform, how it works), `ops_product`, `ops_solutions`, `ops_integrations`, `ops_commercial` (pricing, get started, tour, customers, security, AI), `ops_resources`, `ops_company` (about, contact, legal), `parent`, `portal`, `tour` |
| `xw/components.py`, `xw/blocks.py` | Reusable pieces: claim labels, the CTA pair, flows, tables, FAQ with schema, the enquiry form, the Value Ledger, the autonomy ladder, the security facts |
| `xw/charts.py` | Build-time SVG charts: funnel, health, before/after, scenarios, the connection map, causal value chains |
| `xw/shell.py`, `xw/sites.py` | Page shell (SEO, OpenGraph, structured data), navigation and footers for the three sites |
| `src/css/` | The design system (`xevrion.css`: tokens, glass materials, components) and page compositions (`pages.css`) |
| `src/js/core.js` | The runtime for every page: navigation, reveal, flows, the enquiry form, cookieless measurement and lazy visuals |
| `src/js/viz-*.js` | The interactive visuals, each loaded only when it scrolls near: `core` (homepage), `journey`, `pipeline`, `opportunity`, `orbit`, `process`, `scenario`, `tour`, `roi`, `search`, `ask` |
| `worker/worker.js` | The Worker: host to site, clean URLs, redirects (from `xw/redirects.py`), security headers and caching |

## Rules the build enforces (`build.py --strict`)

- Every internal and cross-site link resolves to a page or a redirect.
- Each page has exactly one h1, heading levels are not skipped, ids are unique and ARIA references point to real elements.
- Titles are unique and meta descriptions are 50–175 characters.
- There is no placeholder text.
- The sites never publish anything that looks like a bank sort code or account number.
- There is no demo-booking or call-booking language. Xevrion sells self-serve and in writing.
- Every analytics event name (each `data-event` and each literal `track()` name in `src/js`) passes the API's rule
  (`[a-z0-9_]` before the first `:`); a name that fails it would be dropped by the API without an error.

## Claim labels

Every number says what it is:
- **Illustrative example:** a fictional example that explains the product.
- **Product capability:** what the product does.
- **Verified company fact:** published prices, and what is implemented.
- **Published statistic:** third-party data with its source.
- **Customer result:** reserved until a result meets the ten-part evidence standard on `/customers`.
