# Builds the three Xevrion websites and deploys them to Cloudflare.
#   powershell -ExecutionPolicy Bypass -File scripts\deploy-websites.ps1 -Target preview
#   powershell -ExecutionPolicy Bypass -File scripts\deploy-websites.ps1 -Target production
# The Cloudflare token saved by scripts\set-cloudflare-token.ps1 is decrypted for this process only and never printed.
param([ValidateSet("preview", "production")][string]$Target = "preview", [string]$Python = "")
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$tokenFile = Join-Path $env:USERPROFILE ".xevrion\cloudflare-token.xml"
if (-not (Test-Path $tokenFile)) { throw "No Cloudflare token saved yet. Run scripts\set-cloudflare-token.ps1 first." }
if (-not $Python) {
    $venv = Join-Path $env:LOCALAPPDATA "Temp\claude\C--Users\3d10b7ba-2092-44f9-826f-1ca36e2379d7\scratchpad\venvs\xev\Scripts\python.exe"
    $Python = if (Test-Path $venv) { $venv } else { "python" }
}
Push-Location $root
try {
    & $Python build.py --strict
    if ($LASTEXITCODE -ne 0) { throw "Build checks failed; nothing was deployed." }
    $credential = Import-Clixml $tokenFile
    $env:CLOUDFLARE_API_TOKEN = $credential.GetNetworkCredential().Password
    & $Python tools\deploy.py "--$Target"
    if ($LASTEXITCODE -ne 0) { throw "Deploy failed." }
} finally {
    Remove-Item Env:\CLOUDFLARE_API_TOKEN -ErrorAction SilentlyContinue
    Pop-Location
}
