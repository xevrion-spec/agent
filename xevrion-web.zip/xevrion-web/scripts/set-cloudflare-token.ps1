# Stores a Cloudflare API token for deploying the Xevrion websites, encrypted with Windows DPAPI.
# Only your Windows user on this PC can decrypt it; the token is never printed or written in plain text.
#
# Create the token first: dash.cloudflare.com -> My Profile -> API Tokens -> Create Token ->
#   "Edit Cloudflare Workers" template -> Account Resources: your account; Zone Resources: xevrion.co.uk -> Create.
# Then run:  powershell -ExecutionPolicy Bypass -File scripts\set-cloudflare-token.ps1
$ErrorActionPreference = "Stop"
$folder = Join-Path $env:USERPROFILE ".xevrion"
New-Item -ItemType Directory -Force $folder | Out-Null
$secure = Read-Host "Paste the Cloudflare API token (input is hidden)" -AsSecureString
if ($secure.Length -lt 20) { throw "That does not look like a Cloudflare API token." }
$credential = New-Object System.Management.Automation.PSCredential("cloudflare", $secure)
$credential | Export-Clixml -Path (Join-Path $folder "cloudflare-token.xml")
Write-Host "Saved (encrypted for your Windows user only). Checking it with Cloudflare..."
$token = $credential.GetNetworkCredential().Password
try {
    $check = Invoke-RestMethod -Uri "https://api.cloudflare.com/client/v4/user/tokens/verify" -Headers @{ Authorization = "Bearer $token" }
    Write-Host ("Cloudflare says the token is: " + $check.result.status)
} finally {
    $token = $null
}
