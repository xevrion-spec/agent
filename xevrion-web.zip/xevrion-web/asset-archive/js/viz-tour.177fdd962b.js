// Guided tour player. Each step stays on screen long enough to read (about 250 ms a word, at least 5 seconds), then the
// next one shows. At a system's last step the tour stops on its end card ("Start with …" and "Next: …"), so the call to
// action does not slide away; Next, Play or the next system's tab carry on. Back, Next and the step dots move freely at
// any time. Autoplay stops while the tour is off screen or the tab is hidden, can be paused (WCAG 2.2.2), and never
// starts when reduced motion is requested.
const MIN_MS = 5000, MS_PER_WORD = 250;

export function mount(host, { reduced, track }) {
  const tabs = [...host.querySelectorAll("[role=tab]")];
  const panels = [...host.querySelectorAll("[role=tabpanel]")];
  const bar = host.querySelector("[data-bar]");
  const where = bar.querySelector("[data-where]");
  const dots = bar.querySelector("[data-dots]");
  const toggle = bar.querySelector("[data-toggle]");
  let t = 0, s = 0, playing = !reduced, visible = false, timer = 0;
  const seen = new Set(), chosen = new Set(), ended = new Set();   // tracks completed, chosen by the visitor, autoplayed to the end
  host.classList.add("is-live");
  bar.hidden = false;
  host.querySelectorAll("[data-next-track]").forEach((b) => { b.hidden = false; });

  const steps = () => [...panels[t].querySelectorAll(".tour__step")];
  const last = () => s === steps().length - 1;
  const stepMs = () => {
    const words = (steps()[s]?.querySelector(".tour__narr")?.textContent || "").trim().split(/\s+/).length;
    return Math.max(MIN_MS, words * MS_PER_WORD);
  };
  const schedule = () => {
    clearTimeout(timer);
    if (playing && visible && document.visibilityState === "visible" && !last()) timer = setTimeout(advance, stepMs());
  };
  const render = () => {
    panels.forEach((p, i) => { p.hidden = i !== t; });
    tabs.forEach((b, i) => { b.setAttribute("aria-selected", String(i === t)); b.tabIndex = i === t ? 0 : -1; });
    const list = steps();
    list.forEach((li, i) => li.toggleAttribute("data-on", i === s));
    dots.innerHTML = list.map((_, i) => `<button type="button" class="tour__dot" aria-label="Step ${i + 1}"${i === s ? ' aria-current="step"' : ""} data-dot="${i}"></button>`).join("");
    where.textContent = `${tabs[t].textContent.trim()} · step ${s + 1} of ${list.length}`;
    if (last()) playing = false;                                     // the tour rests on each end card
    toggle.querySelector("span").textContent = playing ? "Pause" : "Play";
    toggle.setAttribute("aria-label", playing ? "Pause the tour" : "Play the tour");
    schedule();
  };
  const go = (track_, step, user) => {
    t = (track_ + tabs.length) % tabs.length;
    const n = steps().length;
    s = Math.max(0, Math.min(n - 1, step));
    const key = tabs[t].dataset.track;
    if (user) { chosen.add(t); track?.(`tour_step:${key}:${s + 1}`); }
    // a completion counts only for a system the visitor chose or moved through; an unattended autoplay is counted apart
    if (s === n - 1 && chosen.has(t) && !seen.has(t)) { seen.add(t); track?.(`tour_complete:${key}`, true); }
    else if (s === n - 1 && !chosen.has(t) && !ended.has(t)) { ended.add(t); track?.(`tour_autoplay_end:${key}`, true); }
    render();
  };
  function advance() {
    if (!last()) go(t, s + 1);
  }
  const back = () => (s > 0 ? go(t, s - 1, true) : go(t - 1, 99, true));
  const next = () => (!last() ? go(t, s + 1, true) : go(t + 1, 0, true));

  tabs.forEach((b, i) => {
    b.addEventListener("click", () => go(i, 0, true));
    b.addEventListener("keydown", (e) => {
      const n = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (n === undefined) return;
      e.preventDefault(); go(n, 0, true); tabs[t].focus();
    });
  });
  bar.querySelector("[data-prev]").addEventListener("click", back);
  bar.querySelector("[data-next]").addEventListener("click", next);
  dots.addEventListener("click", (e) => { const d = e.target.closest("[data-dot]"); if (d) go(t, +d.dataset.dot, true); });
  host.addEventListener("click", (e) => {
    if (!e.target.closest("[data-next-track]")) return;
    playing = !reduced;
    go(t + 1, 0, true);
    tabs[t].focus();
  });
  toggle.addEventListener("click", () => {
    playing = !playing;
    track?.(`tour_${playing ? "play" : "pause"}`);
    if (playing && last()) go(t + 1, 0, true); else render();       // Play on an end card moves on to the next system
  });
  host.addEventListener("keydown", (e) => {
    if (e.target.closest("[role=tab]") || e.target.closest("input,textarea,select")) return;
    if (e.key === "ArrowRight") { e.preventDefault(); next(); }
    if (e.key === "ArrowLeft") { e.preventDefault(); back(); }
  });
  document.addEventListener("visibilitychange", schedule);
  go(0, 0);
  return { visible(v) { visible = v; schedule(); } };
}
