// Business Operations: Process Transformation. A purchase-approval process of seven steps. Work items flow through;
// box width = hours of work per month, gap = average waiting time, red marks = errors sent back for rework.
// "Before" shows the Finance review bottleneck with a queue; "After" shows the redesigned, partly automated process.
import { C, clamp, glow, lerp, lifecycle, loop, mulberry, rgba, roundRect, stageCanvas } from "./viz-kit.88725e7ff9.js";

const STEPS = [
  // name, owner, before: hours, wait days, error %; after: hours, wait, error, automated
  ["Request", "Requester", 4, 0.2, 1.1, 2, 0.1, 0.4, false],
  ["Review", "Team lead", 9, 1.5, 1.4, 3, 0.6, 0.4, false],
  ["CRM entry", "Sales ops", 11, 0.8, 2.3, 0.5, 0.05, 0.1, true],
  ["Finance review", "Finance", 19, 3.6, 1.9, 4, 0.4, 0.5, true],
  ["Approval", "Director", 5, 2.1, 0.3, 4, 1.0, 0.3, false],
  ["Processing", "Operations", 9, 0.6, 0.9, 3, 0.3, 0.3, false],
  ["Update", "Sales ops", 4, 0.4, 0.3, 1.5, 0.05, 0.1, true],
];
const MODES = {
  before: { label: "Before automation", cost: "£6,840/mo", detail: "61 hours a month · 8.2% error rate · 9.2 days end to end" },
  after: { label: "After automation", cost: "£2,020/mo", detail: "18 hours a month · 2.1% error rate · 2.5 days end to end · saving £4,820/mo" },
};

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const rand = mulberry(9);
  const q = (s) => host.querySelector(s);
  const out = { mode: q('[data-o="mode"]'), cost: q('[data-o="cost"]'), detail: q('[data-o="detail"]') };
  const buttons = [...host.querySelectorAll("[data-mode]")];
  let mode = "before", mix = 0; // mix eases 0 (before) -> 1 (after)
  const items = [];
  let spawn = 0;

  const setMode = (m, user) => {
    mode = m;
    buttons.forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.mode === m)));
    const M = MODES[m];
    out.mode.textContent = M.label; out.cost.textContent = M.cost; out.detail.textContent = M.detail;
    q("[data-readout]").dataset.tone = m === "after" ? "ok" : "risk";
    if (user) track?.(`viz_interact:process:${m}`);
    if (reduced) { mix = m === "after" ? 1 : 0; frame(0, 0); }
  };
  buttons.forEach((b) => b.addEventListener("click", () => setMode(b.dataset.mode, true)));

  const layout = () => {
    const { w, h } = state;
    const vertical = w < 620;
    const vals = STEPS.map((s) => ({ hours: lerp(s[2], s[5], mix), wait: lerp(s[3], s[6], mix), err: lerp(s[4], s[7], mix), auto: s[8] }));
    if (vertical) {
      const top = h * 0.3, bottom = h * 0.9, total = vals.reduce((a, v) => a + v.hours * 0.6 + v.wait * 3 + 6, 0);
      const k = (bottom - top) / total;
      let y = top;
      return vals.map((v, i) => { const bh = Math.max(14, (v.hours * 0.6 + 6) * k); const box = { x: w * 0.36, y, w: w * 0.5, h: bh, v, i, vertical }; y += bh + v.wait * 3 * k; return box; });
    }
    const left = w * 0.04, right = w * 0.96, total = vals.reduce((a, v) => a + v.hours + v.wait * 3 + 2, 0);
    const k = (right - left) / total;
    let x = left;
    return vals.map((v, i) => { const bw = Math.max(10, (v.hours + 2) * k); const box = { x, y: h * 0.5, w: bw, h: 44, v, i, vertical }; x += bw + v.wait * 3 * k; return box; });
  };

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    mix = reduced ? (mode === "after" ? 1 : 0) : lerp(mix, mode === "after" ? 1 : 0, clamp(dt * 3));
    const boxes = layout();
    ctx.clearRect(0, 0, w, h);
    // the path through the process
    const vertical = boxes[0].vertical;
    ctx.strokeStyle = rgba(C.text1, 0.1); ctx.lineWidth = 1; ctx.setLineDash([3, 5]); ctx.beginPath();
    if (vertical) { ctx.moveTo(boxes[0].x + boxes[0].w / 2, boxes[0].y); ctx.lineTo(boxes[0].x + boxes[0].w / 2, boxes.at(-1).y + boxes.at(-1).h); }
    else { ctx.moveTo(boxes[0].x, boxes[0].y + 22); ctx.lineTo(boxes.at(-1).x + boxes.at(-1).w, boxes[0].y + 22); }
    ctx.stroke(); ctx.setLineDash([]);
    boxes.forEach((b) => {
      const s = STEPS[b.i];
      const bottleneck = b.i === 3 && mix < 0.5;
      const automated = b.v.auto && mix > 0.5;
      if (bottleneck) glow(ctx, b.x + b.w / 2, b.y + b.h / 2, 80, C.risk, 0.5);
      roundRect(ctx, b.x, b.y, b.w, b.h, 8);
      ctx.fillStyle = automated ? rgba(C.violet, 0.28) : bottleneck ? rgba(C.risk, 0.14) : rgba(C.text1, 0.05);
      ctx.fill();
      ctx.strokeStyle = automated ? C.violetBright : bottleneck ? C.risk : rgba(C.text1, 0.22); ctx.lineWidth = 1.2; ctx.stroke();
      ctx.textBaseline = "middle"; ctx.fillStyle = C.text1;
      if (vertical) {
        ctx.textAlign = "right"; ctx.font = "500 12.5px Geist, sans-serif"; ctx.fillText(s[0], b.x - 12, b.y + b.h / 2 - 7);
        ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillStyle = automated ? C.violetPale : bottleneck ? "#ff8f9a" : C.text3;
        ctx.fillText(automated ? "AUTOMATED" : bottleneck ? "BOTTLENECK" : `${b.v.hours.toFixed(0)} HRS`, b.x - 12, b.y + b.h / 2 + 8);
      } else {
        ctx.textAlign = "left"; ctx.font = "500 12.5px Geist, sans-serif";
        const above = b.i % 2 === 0;
        const ty = above ? b.y - 34 : b.y + b.h + 20;
        ctx.fillText(s[0], b.x, ty);
        ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillStyle = automated ? C.violetPale : bottleneck ? "#ff8f9a" : C.text3;
        ctx.fillText(automated ? "AUTOMATED" : bottleneck ? "BOTTLENECK" : `${b.v.hours.toFixed(0)} HRS · ${s[1].toUpperCase()}`, b.x, ty + 15);
        // waiting time between steps
        if (b.v.wait > 0.3 && b.i < boxes.length - 1) {
          ctx.fillStyle = rgba(C.text3, 0.9); ctx.textAlign = "center";
          ctx.fillText(`${b.v.wait.toFixed(1)}d wait`, b.x + b.w + (boxes[b.i + 1].x - b.x - b.w) / 2, b.y + b.h / 2 + (above ? 30 : -30));
        }
      }
    });
    // work items: spawn, move (slow inside long steps), queue, sometimes fail and go back
    if (!reduced) {
      spawn += dt;
      if (spawn > 0.55 && items.length < 60) { spawn = 0; items.push({ step: 0, t: 0, err: false, errT: 0 }); }
      for (const it of items) {
        const b = boxes[it.step];
        const dur = 0.5 + (b.v.hours / 19) * 2.4 + b.v.wait * 0.35;
        it.t += dt / dur;
        if (it.t >= 1) {
          if (!it.err && rand() < b.v.err / 12) { it.err = true; it.errT = 1; it.t = 0; } // rework: repeat the step
          else { it.step++; it.t = 0; it.err = false; }
        }
        it.errT = Math.max(0, it.errT - dt);
      }
      for (let i = items.length - 1; i >= 0; i--) if (items[i].step >= boxes.length) items.splice(i, 1);
    }
    const perStep = new Map();
    for (const it of items) {
      const b = boxes[it.step];
      const n = perStep.get(it.step) || 0; perStep.set(it.step, n + 1);
      let x, y;
      if (b.vertical) { x = b.x + b.w + 14 + (n % 6) * 9; y = b.y + b.h / 2 + Math.floor(n / 6) * 9 - 4; }
      else { x = b.x + clamp(it.t, 0, 1) * b.w; y = b.y + b.h / 2 + (n % 5 - 2) * 7; }
      ctx.fillStyle = it.errT > 0 ? C.risk : rgba(C.text1, 0.85);
      ctx.beginPath(); ctx.arc(x, y, 2.6, 0, Math.PI * 2); ctx.fill();
    }
  }

  setMode("before");
  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
