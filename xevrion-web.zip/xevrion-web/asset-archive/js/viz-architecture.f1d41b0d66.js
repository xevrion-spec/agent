// Architecture: requests travel left to right through the real layers. Cloudflare's edge, the encrypted tunnel, the
// gateway's four checks (sign-in, organisation, role, plan limits), one system, its database. Some requests fail a check
// and are refused at the gateway (deny by default), shown in red; the rest complete and return.
import { C, clamp, glow, lerp, lifecycle, loop, mulberry, rgba, roundRect, stageCanvas } from "./viz-kit.88725e7ff9.js";

const COLS = [
  { key: "user", label: "YOUR BROWSER", items: ["You"] },
  { key: "edge", label: "CLOUDFLARE", items: ["Websites", "Tunnel", "AI bridge"] },
  { key: "gate", label: "GATEWAY · CHECKS", items: ["Signed in?", "Your organisation?", "Allowed by role?", "Within plan?"] },
  { key: "sys", label: "SYSTEMS", items: ["Revenue", "Customer Ops", "Business Ops", "Decisions"] },
  { key: "data", label: "DATA", items: ["Own database", "Audit trail"] },
];

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const rand = mulberry(5);
  const packets = [];
  let spawn = 0, served = 0, refused = 0;

  const layout = () => {
    const { w, h } = state;
    const vertical = w < 620;
    return COLS.map((col, i) => {
      const n = col.items.length;
      return col.items.map((it, j) => {
        if (vertical) return { x: w * (0.14 + (j + 0.5) / Math.max(n, 1) * 0.72), y: h * (0.1 + i * 0.2), label: it, col: i };
        return { x: w * (0.1 + i * 0.2), y: h * (0.5 + (j - (n - 1) / 2) * 0.15), label: it, col: i };
      });
    });
  };

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    const L = layout();
    const vertical = w < 620;
    ctx.clearRect(0, 0, w, h);
    // column captions
    ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = C.text3;
    if (!vertical) COLS.forEach((c, i) => ctx.fillText(c.label, w * (0.1 + i * 0.2), h * 0.1));
    // links between columns
    for (let i = 0; i < L.length - 1; i++) L[i].forEach((a) => L[i + 1].forEach((b) => {
      ctx.strokeStyle = rgba(C.text1, 0.04); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    }));
    // nodes
    L.flat().forEach((n) => {
      const gate = COLS[n.col].key === "gate";
      const bw = Math.min(130, w * (vertical ? 0.2 : 0.17)), bh = 28;
      roundRect(ctx, n.x - bw / 2, n.y - bh / 2, bw, bh, 8);
      ctx.fillStyle = gate ? rgba(C.violet, 0.14) : rgba(C.text1, 0.04); ctx.fill();
      ctx.strokeStyle = gate ? rgba(C.violetPale, 0.45) : rgba(C.text1, 0.18); ctx.stroke();
      ctx.fillStyle = C.text1; ctx.font = `500 ${vertical ? 10 : 11.5}px Geist, sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(n.label, n.x, n.y + 1);
    });
    ctx.textBaseline = "alphabetic";
    // packets
    if (!reduced) {
      spawn += dt;
      if (spawn > 0.5 && packets.length < 16) {
        spawn = 0;
        const bad = rand() < 0.22;
        packets.push({ route: [0, 1, 2, 2, 2, 2, 3, 4].map((c, k) => c === 2 ? [2, k - 2] : c === 1 ? [1, 1] : [c, Math.floor(rand() * L[c].length)]),
                       t: 0, fail: bad ? 2 + Math.floor(rand() * 4) : -1, done: false });
      }
      packets.forEach((p) => {
        p.t += dt * 2.2;
        const seg = Math.floor(p.t), f = p.t - seg;
        if (p.fail >= 0 && seg >= p.fail) { p.done = true; p.refused = time; refused++; return; }
        if (seg >= p.route.length - 1) { p.done = true; served++; return; }
        const [ca, ia] = p.route[seg], [cb, ib] = p.route[seg + 1];
        const a = L[ca][ia], b = L[cb][ib];
        const x = lerp(a.x, b.x, f), y = lerp(a.y, b.y, f);
        glow(ctx, x, y, 12, C.violet, 0.8);
        ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(x, y, 2.6, 0, Math.PI * 2); ctx.fill();
      });
      for (let i = packets.length - 1; i >= 0; i--) {
        const p = packets[i];
        if (p.done) {
          if (p.refused && time - p.refused < 0.8) { // show the refusal at the check that failed
            const [c, k] = p.route[p.fail]; const n = L[c][k];
            ctx.strokeStyle = rgba(C.risk, 1 - (time - p.refused) / 0.8); ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(n.x + Math.min(130, w * 0.17) / 2 + 10, n.y, 6, 0, Math.PI * 2); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(n.x + Math.min(130, w * 0.17) / 2 + 6, n.y - 4); ctx.lineTo(n.x + Math.min(130, w * 0.17) / 2 + 14, n.y + 4); ctx.stroke();
          } else packets.splice(i, 1);
        }
      }
    }
    ctx.font = "500 10px 'Geist Mono', monospace"; ctx.textAlign = "left"; ctx.fillStyle = C.text3;
    ctx.fillText(`COMPLETED ${served}   REFUSED AT A CHECK ${refused}`, 16, h - 14);
  }

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  host.addEventListener("pointerenter", () => track?.("viz_interact:architecture", true), { once: true });
  return lifecycle(run, { reduced });
}
