// AI and human control: three real kinds of task travel the nine-step path. Code handles what code can; the model is
// used only where language or judgement is needed; policy decides whether a person must approve; everything is audited.
// Interactive: choose a task and you become the approver; hover any step to read what happens there.
import { C, clamp, ease, glow, lerp, lifecycle, loop, rgba, roundRect, stageCanvas, tooltip } from "./viz-kit.88725e7ff9.js";

const STEPS = ["Task", "Risk", "Code or model", "Output", "Policy", "Approval", "Execution", "Audit", "Outcome"];
const INFO = {
  "Task": "A piece of work arrives: an email, a record that changed or a scheduled job.",
  "Risk": "The task is classified by what it could affect: money, customers or data.",
  "Code or model": "Deterministic code handles what code can. The model is used only where language or judgement is needed.",
  "Output": "The result is checked against a strict format before anything uses it.",
  "Policy": "Your rules decide whether this kind of task may run on its own.",
  "Approval": "When policy requires it, a named person approves or rejects the action.",
  "Execution": "The approved action runs once, with an idempotency key, so a retry can never repeat it.",
  "Audit": "Who, what, when and why is written to the audit trail.",
  "Outcome": "The result is measured and, where it creates value, recorded in the Value Ledger.",
};
const TASKS = [
  { name: "Match a payment to an invoice", via: "Code", approval: false, note: "Deterministic code; allowed by policy; no approval needed." },
  { name: "Draft a reply to a customer", via: "Model", approval: true, note: "Language task, so the model drafts it; a person approves before it is sent." },
  { name: "Offer a renewal discount", via: "Model", approval: true, note: "Money is involved, so approval is always required." },
];
const APPROVAL = STEPS.indexOf("Approval");

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const tip = tooltip(host);
  const out = { task: host.querySelector('[data-o="task"]'), note: host.querySelector('[data-o="note"]') };
  const bar = document.createElement("div");
  bar.className = "viz-choices"; bar.setAttribute("role", "group"); bar.setAttribute("aria-label", "Choose a task to send down the path");
  bar.innerHTML = `<span class="label">Send a task</span>` + TASKS.map((x, i) => `<button type="button" data-i="${i}" aria-pressed="${i === 0}">${x.name}</button>`).join("");
  host.append(bar);
  let ti = 0, t = 0, waiting = 0, manual = false, approved = false, hover = -1, now = 0, used = false;

  const setTask = (i, byUser) => {
    ti = i; t = 0; waiting = 0; approved = false; manual = byUser;
    out.task.textContent = TASKS[i].name;
    out.note.textContent = byUser && TASKS[i].approval ? TASKS[i].note + " You are the approver: click Approval when it arrives." : TASKS[i].note;
    bar.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(+b.dataset.i === i)));
  };
  const pos = (i) => {
    const { w, h } = state;
    if (w < 620) return { x: w * 0.3, y: h * (0.08 + i * 0.105) };
    const row = i < 5 ? 0 : 1, col = row === 0 ? i : 8 - i;       // a U-shaped path: left to right, then back
    return { x: w * (0.1 + col * 0.2), y: h * (row === 0 ? 0.5 : 0.84) };
  };
  const boxW = () => Math.min(118, state.w * 0.17);

  function frame(time = 0, dt = 0.016) {
    now = time;
    const { w, h } = state, task = TASKS[ti];
    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = rgba(C.text1, 0.12); ctx.lineWidth = 1.2; ctx.beginPath();
    STEPS.forEach((_, i) => { const p = pos(i); i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.stroke();
    const k = reduced && !manual ? STEPS.length - 1 : t;
    const atApproval = task.approval && Math.floor(t) === APPROVAL && !approved;
    STEPS.forEach((s, i) => {
      const p = pos(i), done = i < k, here = Math.floor(k) === i, hov = i === hover;
      const special = (s === "Approval" && task.approval) || s === "Code or model";
      const skip = s === "Approval" && !task.approval;
      const bw = boxW(), bh = 30;
      roundRect(ctx, p.x - bw / 2, p.y - bh / 2, bw, bh, 4);
      ctx.fillStyle = here ? rgba(C.violet, 0.3) : hov ? rgba(C.text1, 0.1) : done ? rgba(C.text1, 0.07) : rgba(C.text1, 0.03); ctx.fill();
      ctx.strokeStyle = skip ? rgba(C.text1, 0.12) : here || hov ? C.violetBright : special ? rgba(C.violetPale, 0.5) : rgba(C.text1, 0.2);
      if (skip) ctx.setLineDash([3, 4]);
      ctx.lineWidth = hov ? 1.6 : 1; ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1;
      if (s === "Approval" && atApproval && manual) {                 // the visitor's turn: a pulsing approve target
        const pulse = 0.5 + 0.5 * Math.sin(time * 5);
        ctx.strokeStyle = rgba(C.violetBright, 0.35 + pulse * 0.5); ctx.lineWidth = 2;
        roundRect(ctx, p.x - bw / 2 - 5, p.y - bh / 2 - 5, bw + 10, bh + 10, 6); ctx.stroke(); ctx.lineWidth = 1;
      }
      ctx.fillStyle = skip ? C.text3 : C.text1; ctx.font = "500 11.5px Geist, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      const label = s === "Code or model" ? (done || here ? task.via : s) : s === "Approval" && skip ? "Not needed" : s;
      ctx.fillText(label, p.x, p.y + 1);
      ctx.font = "500 9px 'Geist Mono', monospace"; ctx.fillStyle = C.text3; ctx.fillText(String(i + 1).padStart(2, "0"), p.x, p.y - bh / 2 - 8);
    });
    ctx.textBaseline = "alphabetic";
    if (reduced && !manual) return;
    // the task token
    if (atApproval) {
      waiting += dt;
      const p = pos(APPROVAL);
      ctx.font = "500 10px 'Geist Mono', monospace"; ctx.fillStyle = C.violetPale; ctx.textAlign = "center";
      if (manual) {
        ctx.fillText(waiting < 12 ? "WAITING FOR YOU · CLICK TO APPROVE" : "APPROVED ✓", p.x, p.y + 32);
        if (waiting >= 12) approved = true;                       // nobody clicked: approve so the example completes
      } else {
        ctx.fillText(waiting < 0.9 ? "WAITING FOR A PERSON" : "APPROVED ✓", p.x, p.y + 32);
        if (waiting >= 1.4) approved = true;
      }
    } else {
      t += dt * 1.6;
    }
    if (t >= STEPS.length - 1 + 0.9) {
      if (manual) { manual = false; setTask(ti, false); }
      else setTask((ti + 1) % TASKS.length, false);
    }
    const i = Math.floor(clamp(t, 0, STEPS.length - 1)), f = ease(t - i);
    const a = pos(i), b = pos(Math.min(i + 1, STEPS.length - 1));
    const x = lerp(a.x, b.x, i >= STEPS.length - 1 ? 0 : f), y = lerp(a.y, b.y, i >= STEPS.length - 1 ? 0 : f);
    glow(ctx, x, y, 18, C.violet, 1); ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(x, y, 3.2, 0, Math.PI * 2); ctx.fill();
  }

  const stepAt = (e) => {
    const r = host.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, bw = boxW();
    return STEPS.findIndex((_, i) => { const p = pos(i); return Math.abs(x - p.x) < bw / 2 + 4 && Math.abs(y - p.y) < 20; });
  };
  const use = (what) => { if (!used) { used = true; track?.(`viz_interact:aipath:${what}`, true); } };
  host.addEventListener("pointermove", (e) => {
    if (e.target.closest(".viz-choices")) { hover = -1; tip.hide(); return; }
    const i = stepAt(e);
    hover = i;
    host.style.cursor = i === APPROVAL && TASKS[ti].approval && Math.floor(t) === APPROVAL && !approved ? "pointer" : "";
    const r = host.getBoundingClientRect();
    if (i >= 0) {
      const s = STEPS[i], task = TASKS[ti];
      const extra = s === "Code or model" ? `For “${task.name}”: ${task.via.toLowerCase()}.` : s === "Approval" ? (task.approval ? "This task needs a person's approval." : "This task is allowed by policy without approval.") : "";
      tip.show(`<span class="label">${String(i + 1).padStart(2, "0")} · ${s}</span><p style="margin-top:6px">${INFO[s]}</p>${extra ? `<p class="quiet" style="margin-top:6px">${extra}</p>` : ""}`, e.clientX - r.left, e.clientY - r.top);
      use("hover");
    } else tip.hide();
    if (reduced && !manual) frame(now, 0);
  });
  host.addEventListener("pointerleave", () => { hover = -1; tip.hide(); if (reduced && !manual) frame(now, 0); });
  host.addEventListener("click", (e) => {
    if (e.target.closest(".viz-choices")) return;
    if (stepAt(e) === APPROVAL && TASKS[ti].approval && Math.floor(t) === APPROVAL && !approved) { approved = true; use("approve"); }
  });
  bar.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-i]");
    if (!b) return;
    setTask(+b.dataset.i, true); use("choose");
    if (reduced) { run.start(); setTimeout(() => { if (!manual) { run.stop(); frame(now, 0); } }, 30000); }
  });

  setTask(0, false);
  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
