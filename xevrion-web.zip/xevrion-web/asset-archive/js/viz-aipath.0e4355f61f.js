// AI and human control: three real kinds of task travel the nine-step path. Code handles what code can; the model is
// used only where language or judgement is needed; policy decides whether a person must approve; everything is audited.
import { C, clamp, ease, glow, lerp, lifecycle, loop, rgba, roundRect, stageCanvas } from "./viz-kit.88725e7ff9.js";

const STEPS = ["Task", "Risk", "Code or model", "Output", "Policy", "Approval", "Execution", "Audit", "Outcome"];
const TASKS = [
  { name: "Match a payment to an invoice", via: "Code", approval: false, note: "Deterministic code; allowed by policy; no approval needed." },
  { name: "Draft a reply to a customer", via: "Model", approval: true, note: "Language task, so the model drafts it; a person approves before it is sent." },
  { name: "Offer a renewal discount", via: "Model", approval: true, note: "Money is involved, so approval is always required." },
];

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const out = { task: host.querySelector('[data-o="task"]'), note: host.querySelector('[data-o="note"]') };
  let ti = 0, t = 0, waiting = 0;

  const pos = (i) => {
    const { w, h } = state;
    const vertical = w < 620;
    if (vertical) return { x: w * 0.3, y: h * (0.08 + i * 0.105) };
    const row = i < 5 ? 0 : 1;
    const col = row === 0 ? i : 8 - i;                  // a U-shaped path: left to right, then back
    return { x: w * (0.1 + col * 0.2), y: h * (row === 0 ? 0.5 : 0.84) };  // top of the stage is left for the caption card
  };

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    const task = TASKS[ti];
    ctx.clearRect(0, 0, w, h);
    // path
    ctx.strokeStyle = rgba(C.text1, 0.12); ctx.lineWidth = 1.2; ctx.beginPath();
    STEPS.forEach((_, i) => { const p = pos(i); i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }); ctx.stroke();
    const k = reduced ? STEPS.length - 1 : t;
    STEPS.forEach((s, i) => {
      const p = pos(i), done = i < k, here = Math.floor(k) === i;
      const special = (s === "Approval" && task.approval) || (s === "Code or model");
      const skip = s === "Approval" && !task.approval;
      const bw = Math.min(118, w * 0.17), bh = 30;
      roundRect(ctx, p.x - bw / 2, p.y - bh / 2, bw, bh, 9);
      ctx.fillStyle = here ? rgba(C.violet, 0.3) : done ? rgba(C.text1, 0.07) : rgba(C.text1, 0.03); ctx.fill();
      ctx.strokeStyle = skip ? rgba(C.text1, 0.12) : here ? C.violetBright : special ? rgba(C.violetPale, 0.5) : rgba(C.text1, 0.2);
      if (skip) ctx.setLineDash([3, 4]);
      ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = skip ? C.text3 : C.text1; ctx.font = "500 11.5px Geist, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      const label = s === "Code or model" ? (done || here ? task.via : s) : s === "Approval" && skip ? "Not needed" : s;
      ctx.fillText(label, p.x, p.y + 1);
      ctx.font = "500 9px 'Geist Mono', monospace"; ctx.fillStyle = C.text3; ctx.fillText(String(i + 1).padStart(2, "0"), p.x, p.y - bh / 2 - 8);
    });
    ctx.textBaseline = "alphabetic";
    // the task token
    if (!reduced) {
      const approvalStep = STEPS.indexOf("Approval");
      if (task.approval && Math.floor(t) === approvalStep && waiting < 1.4) {
        waiting += dt;
        const p = pos(approvalStep);
        ctx.font = "500 10px 'Geist Mono', monospace"; ctx.fillStyle = C.violetPale; ctx.textAlign = "center";
        ctx.fillText(waiting < 0.9 ? "WAITING FOR A PERSON" : "APPROVED ✓", p.x, p.y + 32);
      } else {
        t += dt * 1.6;
        if (Math.floor(t) !== approvalStep) waiting = task.approval ? waiting : 0;
      }
      if (t >= STEPS.length - 1 + 0.9) { t = 0; waiting = 0; ti = (ti + 1) % TASKS.length; out.task.textContent = TASKS[ti].name; out.note.textContent = TASKS[ti].note; }
      const i = Math.floor(clamp(t, 0, STEPS.length - 1)), f = ease(t - i);
      const a = pos(i), b = pos(Math.min(i + 1, STEPS.length - 1));
      const x = lerp(a.x, b.x, i >= STEPS.length - 1 ? 0 : f), y = lerp(a.y, b.y, i >= STEPS.length - 1 ? 0 : f);
      glow(ctx, x, y, 18, C.violet, 1); ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(x, y, 3.2, 0, Math.PI * 2); ctx.fill();
    }
  }

  out.task.textContent = TASKS[0].name; out.note.textContent = TASKS[0].note;
  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  host.addEventListener("pointerenter", () => track?.("viz_interact:aipath", true), { once: true });
  return lifecycle(run, { reduced });
}
