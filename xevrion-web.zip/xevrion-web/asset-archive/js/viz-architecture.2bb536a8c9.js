// Architecture: requests travel left to right through the real layers. Cloudflare's edge, the encrypted tunnel, the
// gateway's four checks (sign-in, organisation, role, plan limits), one system, its database. Some requests fail a check
// and are refused at the gateway (deny by default), shown in red; the rest complete and return.
// Interactive: hover any part to read what it does; click a check to send a request that fails it; click anything
// else to send one that passes.
import { C, clamp, glow, lerp, lifecycle, loop, mulberry, rgba, roundRect, stageCanvas, tooltip } from "./viz-kit.88725e7ff9.js";

const COLS = [
  { key: "user", label: "YOUR BROWSER", items: ["You"] },
  { key: "edge", label: "CLOUDFLARE", items: ["Websites", "Tunnel", "AI bridge"] },
  { key: "gate", label: "GATEWAY · CHECKS", items: ["Signed in?", "Your organisation?", "Allowed by role?", "Within plan?"] },
  { key: "sys", label: "SYSTEMS", items: ["Revenue", "Customer Ops", "Business Ops", "Decisions"] },
  { key: "data", label: "DATA", items: ["Own database", "Audit trail"] },
];
const INFO = {
  "You": "Your browser. Everything it sends is encrypted in transit.",
  "Websites": "The public websites, served from Cloudflare's edge.",
  "Tunnel": "An encrypted tunnel from Cloudflare to our servers: the platform has no open ports on the internet.",
  "AI bridge": "A Cloudflare Worker that runs the open model on Workers AI, used only inside the platform's rules.",
  "Signed in?": "A valid, unexpired session is required, with two-factor where it is set.",
  "Your organisation?": "The request must belong to your organisation; customers are strictly separated.",
  "Allowed by role?": "Your role must permit the action you are asking for.",
  "Within plan?": "The request must fall within your plan's limits.",
  "Revenue": "The system that finds and wins the customers most worth your time.",
  "Customer Ops": "The system that keeps customers healthy and renewing.",
  "Business Ops": "The system that runs and improves operational processes.",
  "Decisions": "The system that measures, forecasts and recommends.",
  "Own database": "Each system keeps its own database.",
  "Audit trail": "Every action is recorded: who, what, when and why.",
};
const REFUSAL = ["no valid session", "not your organisation", "your role does not allow it", "outside your plan's limits"];

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const tip = tooltip(host);
  const rand = mulberry(5);
  const packets = [];
  let spawn = 0, served = 0, refused = 0, hover = null, notice = null, now = 0, used = false;

  const layout = () => {
    const { w, h } = state;
    const vertical = w < 620;
    return COLS.map((col, i) => {
      const n = col.items.length;
      return col.items.map((it, j) => {
        if (vertical) return { x: w * (0.14 + (j + 0.5) / Math.max(n, 1) * 0.72), y: h * (0.1 + i * 0.2), label: it, col: i };
        return { x: w * (0.1 + i * 0.2), y: h * (0.5 + (j - (n - 1) / 2) * 0.15), label: it, col: i };
      });
    });
  };

  const newPacket = (L, fail, manual) => ({
    route: [0, 1, 2, 2, 2, 2, 3, 4].map((c, k) => c === 2 ? [2, k - 2] : c === 1 ? [1, 1] : [c, Math.floor(rand() * L[c].length)]),
    t: 0, fail, done: false, manual,
  });

  function frame(time = 0, dt = 0.016) {
    now = time;
    const { w, h } = state;
    const L = layout();
    const vertical = w < 620;
    ctx.clearRect(0, 0, w, h);
    // column captions
    ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = C.text3;
    if (!vertical) COLS.forEach((c, i) => ctx.fillText(c.label, w * (0.1 + i * 0.2), h * 0.1));
    // links between columns
    for (let i = 0; i < L.length - 1; i++) L[i].forEach((a) => L[i + 1].forEach((b) => {
      ctx.strokeStyle = rgba(C.text1, 0.04); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    }));
    // nodes
    L.flat().forEach((n) => {
      const gate = COLS[n.col].key === "gate", on = hover && hover.label === n.label;
      const bw = Math.min(130, w * (vertical ? 0.2 : 0.17)), bh = 28;
      roundRect(ctx, n.x - bw / 2, n.y - bh / 2, bw, bh, 4);
      ctx.fillStyle = on ? rgba(C.violet, 0.3) : gate ? rgba(C.violet, 0.14) : rgba(C.text1, 0.04); ctx.fill();
      ctx.strokeStyle = on ? C.violetBright : gate ? rgba(C.violetPale, 0.45) : rgba(C.text1, 0.18); ctx.lineWidth = on ? 1.6 : 1; ctx.stroke(); ctx.lineWidth = 1;
      ctx.fillStyle = C.text1; ctx.font = `500 ${vertical ? 10 : 11.5}px Geist, sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(n.label, n.x, n.y + 1);
    });
    ctx.textBaseline = "alphabetic";
    // packets
    if (!reduced || packets.length) {
      spawn += dt;
      if (!reduced && spawn > 0.6 && packets.length < 14) {
        spawn = 0;
        packets.push(newPacket(L, rand() < 0.22 ? 2 + Math.floor(rand() * 4) : -1, false));
      }
      packets.forEach((p) => {
        if (p.done) return;
        p.t += dt * (p.manual ? 1.5 : 2.2);
        const seg = Math.floor(p.t), f = p.t - seg;
        if (p.fail >= 0 && seg >= p.fail) {
          p.done = true; p.refused = time; refused++;
          if (p.manual) notice = { text: `Refused at the gateway: ${REFUSAL[p.fail - 2]}`, risk: true, at: time };
          return;
        }
        if (seg >= p.route.length - 1) {
          p.done = true; served++;
          if (p.manual) notice = { text: "Completed: every check passed, the system answered and the action was recorded", risk: false, at: time };
          return;
        }
        const [ca, ia] = p.route[seg], [cb, ib] = p.route[seg + 1];
        const a = L[ca][ia], b = L[cb][ib];
        const x = lerp(a.x, b.x, f), y = lerp(a.y, b.y, f);
        glow(ctx, x, y, p.manual ? 22 : 12, C.violet, p.manual ? 1 : 0.8);
        ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(x, y, p.manual ? 3.6 : 2.6, 0, Math.PI * 2); ctx.fill();
      });
      for (let i = packets.length - 1; i >= 0; i--) {
        const p = packets[i];
        if (p.done) {
          if (p.refused && time - p.refused < 0.8) { // show the refusal at the check that failed
            const [c, k] = p.route[p.fail]; const n = L[c][k];
            ctx.strokeStyle = rgba(C.risk, 1 - (time - p.refused) / 0.8); ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(n.x + Math.min(130, w * 0.17) / 2 + 10, n.y, 6, 0, Math.PI * 2); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(n.x + Math.min(130, w * 0.17) / 2 + 6, n.y - 4); ctx.lineTo(n.x + Math.min(130, w * 0.17) / 2 + 14, n.y + 4); ctx.stroke();
          } else packets.splice(i, 1);
        }
      }
    }
    if (notice && time - notice.at < 2.6) {
      ctx.font = "500 12.5px Geist, sans-serif"; ctx.textAlign = "left";
      ctx.fillStyle = rgba(notice.risk ? "#ff8f9a" : C.ok, 1 - (time - notice.at) / 2.6);
      ctx.fillText(notice.text, 16, h - 34);
    }
    ctx.font = "500 10px 'Geist Mono', monospace"; ctx.textAlign = "left"; ctx.fillStyle = C.text3;
    ctx.fillText(`COMPLETED ${served}   REFUSED AT A CHECK ${refused}`, 16, h - 14);
  }

  const nodeAt = (e) => {
    const r = host.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    const bw = Math.min(130, state.w * (state.w < 620 ? 0.2 : 0.17));
    return layout().flat().find((n) => Math.abs(x - n.x) < bw / 2 && Math.abs(y - n.y) < 16) || null;
  };
  host.addEventListener("pointermove", (e) => {
    const n = nodeAt(e);
    hover = n;
    host.style.cursor = n ? "pointer" : "";
    const r = host.getBoundingClientRect();
    if (n) {
      const gate = COLS[n.col].key === "gate";
      tip.show(`<span class="label">${COLS[n.col].label}</span><p style="margin-top:6px"><strong>${n.label}</strong></p><p style="margin-top:4px">${INFO[n.label]}</p>` +
        `<p class="quiet" style="margin-top:6px">${gate ? "Click to send a request that fails this check." : "Click to send a request that passes every check."}</p>`, e.clientX - r.left, e.clientY - r.top);
    } else tip.hide();
    if (reduced) frame(now, 0);
  });
  host.addEventListener("pointerleave", () => { hover = null; tip.hide(); if (reduced) frame(now, 0); });
  host.addEventListener("click", (e) => {
    const n = nodeAt(e);
    if (!n) return;
    const L = layout(), gate = COLS[n.col].key === "gate";
    packets.push(newPacket(L, gate ? 2 + COLS[2].items.indexOf(n.label) : -1, true));
    if (!used) { used = true; track?.("viz_interact:architecture", true); }
    if (reduced) { run.start(); setTimeout(() => { if (packets.every((p) => p.done)) { run.stop(); frame(now, 0); } }, 6000); }
  });

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
