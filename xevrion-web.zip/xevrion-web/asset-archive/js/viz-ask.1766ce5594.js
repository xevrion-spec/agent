// "Ask a question": the public assistant on the Xevrion backend (POST /v1/public/guide). It answers only from
// Xevrion's published information, cannot see any account, and says so when it is not confident.
const API = "https://api.xevrion.co.uk";
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function mount(host, { track }) {
  const form = host.querySelector("form");
  const q = form.elements.question, consent = form.elements.ai_consent;
  const outEl = host.querySelector("[data-answer]"), submit = form.querySelector("button[type=submit]");
  form.hidden = false;
  host.querySelector("[data-ask-nojs]")?.remove();
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const question = q.value.trim();
    if (question.length < 3) { q.focus(); q.setAttribute("aria-invalid", "true"); return; }
    if (!consent.checked) { consent.focus(); host.querySelector("[data-consent-error]").hidden = false; return; }
    host.querySelector("[data-consent-error]").hidden = true;
    q.removeAttribute("aria-invalid");
    submit.disabled = true;
    const label = submit.textContent;
    submit.innerHTML = '<span class="spinner" aria-hidden="true"></span> Thinking';
    outEl.hidden = false;
    outEl.className = "ask__answer";
    outEl.textContent = "";
    try {
      const res = await fetch(`${API}/v1/public/guide`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question, ai_consent: true }), credentials: "omit" });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw Object.assign(new Error("unavailable"), { status: res.status });
      outEl.innerHTML = `<span class="label">${body.fallback ? "No reliable answer" : "Automated answer"} · from published information only</span><p>${esc(body.answer || "")}</p>`;
      track?.(`ask:${body.fallback ? "fallback" : "answered"}`);
    } catch (err) {
      outEl.className = "ask__answer ask__answer--error";
      outEl.innerHTML = `<p>${err.status === 429 ? "Lots of questions right now. Please try again in a few minutes." : "The assistant is not available just now."} You can also <a class="link" href="/contact">send a written question</a>.</p>`;
      track?.(`ask:error:${err.status || "network"}`);
    } finally {
      submit.disabled = false;
      submit.textContent = label;
    }
  });
  return { visible() {} };
}
