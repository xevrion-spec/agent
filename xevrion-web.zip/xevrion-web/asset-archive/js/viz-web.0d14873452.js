// Relationship web: the Atlas visual for any catalogue data (xw/webs.py). Points sit on one ring, grouped; lines are
// real relationships, bundled through the centre. A focus group can be emphasised (a product page shows how its system
// connects to the rest). Hover a point to trace its links; click to open it; search and group switches dim the rest.
import { C, glow, lerp, lifecycle, loop, rgba, stageCanvas } from "./viz-kit.88725e7ff9.js";

const TONE = { violet: C.violetBright, white: C.text1, pale: C.violetPale };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function mount(host, { reduced, track }) {
  const data = JSON.parse(host.querySelector("[data-web-data]").textContent);
  const root = host.closest("[data-web]") || host;
  const tools = root.querySelector("[data-web-tools]");
  const input = root.querySelector("[data-web-q]");
  const chips = [...root.querySelectorAll("[data-web-g]")];
  const readout = host.querySelector("[data-web-readout]");
  const { ctx, state } = stageCanvas(host);
  const N = data.nodes.length, focus = data.focus ?? -1;
  const out = data.nodes.map(() => []);
  data.edges.forEach(([a, b], k) => { out[a].push([b, k]); out[b].push([a, k]); });
  let pos = [], hover = -1, pinned = -1, query = "", group = -1, used = false, pulses = [], lastType = "mouse";
  if (tools) tools.hidden = false;

  const use = (what) => { if (!used) { used = true; track?.(`viz_interact:web:${root.dataset.web}:${what}`, true); } };
  const matches = (n) => (group < 0 || n.g === group) && (!query || (n.t + " " + (n.s || "") + " " + (n.d || "")).toLowerCase().includes(query));
  const groupCol = (g) => (focus >= 0 ? (g === focus ? C.violetPale : C.text2) : [C.text1, C.violetPale, C.text2, C.violetBright, "#9fb4ff", "#d6c8ff", C.text3, "#b9f0ff", "#ffffff"][g % 9]);

  function layout() {
    const { w, h } = state;
    const groups = data.groups.length, gap = N > 40 ? 3 : 1.4;       // small webs keep their groups close together
    const slots = N + groups * gap;
    const step = (Math.PI * 2) / slots;
    state.labelsOn = w > 820;
    const top = state.labelsOn ? 0 : 124;
    state.cx = w / 2; state.cy = top + (h - top) / 2;
    // room outside the ring for the longest name (names are cut at 26 characters)
    const longest = Math.min(26, Math.max(...data.nodes.map((n) => n.t.length)));
    const room = state.labelsOn ? Math.min(170, 40 + longest * (N > 60 ? 5.2 : 6)) : 0;
    const R = Math.max(60, state.labelsOn ? Math.min(w * 0.3, h / 2 - room - 16) : Math.min(w * 0.42, (h - top) / 2 - 34));
    state.R = R; state.ring = R + (state.labelsOn ? room - 12 : 14); state.step = step;
    let a = -Math.PI / 2 + step * gap / 2, prev = -1;
    pos = data.nodes.map((n) => {
      if (prev >= 0 && n.g !== prev) a += step * gap;
      prev = n.g;
      const p = { a, x: state.cx + Math.cos(a) * R, y: state.cy + Math.sin(a) * R };
      a += step;
      return p;
    });
  }

  function label(i, strong) {
    const n = data.nodes[i], p = pos[i], left = Math.cos(p.a) < 0;
    const text = n.t.length > 26 ? n.t.slice(0, 25) + "…" : n.t;
    ctx.save(); ctx.translate(state.cx + Math.cos(p.a) * (state.R + 12), state.cy + Math.sin(p.a) * (state.R + 12));
    ctx.rotate(left ? p.a + Math.PI : p.a);
    ctx.textAlign = left ? "right" : "left"; ctx.textBaseline = "middle";
    ctx.font = `${strong ? 600 : 500} ${strong ? 12 : N > 60 ? 9.5 : 11}px Geist, sans-serif`;
    ctx.fillStyle = strong ? C.text1 : rgba(C.text2, 0.82);
    ctx.fillText(text, 0, 0);
    ctx.restore();
  }

  const curve = (a, b) => {
    const pa = pos[a], pb = pos[b];
    return { pa, pb, c: { x: lerp(state.cx, (pa.x + pb.x) / 2, 0.2), y: lerp(state.cy, (pa.y + pb.y) / 2, 0.2) } };
  };

  function frame(time = 0, dt = 0.016) {
    const { w, h, cx, cy } = state;
    ctx.clearRect(0, 0, w, h);
    const sel = pinned >= 0 ? pinned : hover;
    const near = sel >= 0 ? new Set([sel, ...out[sel].map(([j]) => j)]) : null;
    const lit = data.nodes.map((n, i) => (near ? near.has(i) : matches(n) && (focus < 0 || n.g === focus || out[i].some(([j]) => data.nodes[j].g === focus))));
    // group arcs with their names
    let start = 0;
    data.nodes.forEach((n, i) => {
      if (i < N - 1 && data.nodes[i + 1].g === n.g) return;
      const a0 = pos[start].a - state.step * 0.5, a1 = pos[i].a + state.step * 0.5, on = (group < 0 || group === n.g) && (focus < 0 || focus === n.g);
      ctx.strokeStyle = rgba(groupCol(n.g), on ? 0.6 : 0.16); ctx.lineWidth = focus === n.g ? 3 : 2;
      ctx.beginPath(); ctx.arc(cx, cy, state.ring, a0, a1); ctx.stroke();
      const am = (a0 + a1) / 2, lx = cx + Math.cos(am) * (state.ring + 12), ly = cy + Math.sin(am) * (state.ring + 12);
      ctx.font = "500 10.5px 'Geist Mono', monospace"; ctx.textAlign = Math.cos(am) > 0.2 ? "left" : Math.cos(am) < -0.2 ? "right" : "center";
      ctx.fillStyle = rgba(groupCol(n.g), on ? 0.95 : 0.4);
      ctx.fillText(`${data.groups[n.g].label.toUpperCase()} · ${i - start + 1}`, lx, ly + 4);
      start = i + 1;
    });
    // relationships, bundled through the centre
    data.edges.forEach(([a, b, k]) => {
      const { pa, pb, c } = curve(a, b);
      const tone = TONE[data.kinds[k]?.tone] || C.text1;
      let alpha, width = 1;
      if (near) {
        const mine = a === sel || b === sel;
        alpha = mine ? 0.9 : 0.02; width = mine ? 1.6 : 1;
      } else {
        const both = lit[a] && lit[b];
        const f = focus < 0 || data.nodes[a].g === focus || data.nodes[b].g === focus;
        alpha = both && f ? (tone === C.text1 ? 0.14 : 0.3) : 0.025;
      }
      ctx.strokeStyle = rgba(tone, alpha); ctx.lineWidth = width;
      ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.quadraticCurveTo(c.x, c.y, pb.x, pb.y); ctx.stroke();
    });
    // signals travelling along the lit relationships
    if (!reduced) {
      if (pulses.length < 16 && Math.random() < 0.09) {
        const pool = data.edges.filter(([a, b]) => (near ? a === sel || b === sel : lit[a] && lit[b]));
        if (pool.length) { const e = pool[Math.floor(Math.random() * pool.length)]; pulses.push({ a: e[0], b: e[1], t: 0, rev: Math.random() < 0.5 }); }
      }
      pulses = pulses.filter((p) => (p.t += dt * 0.6) < 1);
      pulses.forEach((p) => {
        const { pa, pb, c } = curve(p.rev ? p.b : p.a, p.rev ? p.a : p.b), t = p.t, u = 1 - t;
        const x = u * u * pa.x + 2 * u * t * c.x + t * t * pb.x, y = u * u * pa.y + 2 * u * t * c.y + t * t * pb.y;
        glow(ctx, x, y, 10, C.violet, Math.sin(t * Math.PI));
        ctx.fillStyle = rgba(C.text1, Math.sin(t * Math.PI)); ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
      });
    }
    // the points
    data.nodes.forEach((n, i) => {
      const p = pos[i], me = i === sel, hub = n.hub;
      const r = me ? 5.5 : hub ? 5 : 2.2 + Math.min(2.8, out[i].length * 0.22);
      if (me || hub) glow(ctx, p.x, p.y, me ? 28 : 18, C.violet, me ? 1 : 0.6);
      ctx.fillStyle = rgba(groupCol(n.g), lit[i] ? 0.95 : 0.16);
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
      if (state.labelsOn && (me || (lit[i] && (focus < 0 || n.g === focus || near)))) label(i, me);
    });
    if (!near) {
      ctx.textAlign = "center"; ctx.fillStyle = C.text3; ctx.font = "500 10px 'Geist Mono', monospace";
      ctx.fillText(data.centre, cx, cy + 4);
    }
  }

  function describe(i) {
    if (i < 0) {
      const f = focus >= 0 ? `<strong>${esc(data.groups[focus].label)}</strong><span>${data.nodes.filter((n) => n.g === focus).length} ${data.unit === "capability" ? "capabilities" : "points"} and their links to the rest of the platform.</span>`
        : `<strong>${N} points · ${data.edges.length} links</strong><span>${data.kinds.map((k) => esc(k.label)).join(" · ")}</span>`;
      readout.innerHTML = `<span class="label label--violet">Map</span>${f}<span class="quiet">Point at anything to trace it; click to open it.</span>`;
      return;
    }
    const n = data.nodes[i], links = out[i];
    const why = [...new Set(links.map(([, k]) => data.edges[k][3]).filter(Boolean).join(", ").split(", "))].slice(0, 5).join(", ");
    readout.innerHTML = `<span class="label label--violet">${esc(data.groups[n.g].label)}${n.s && n.s !== data.groups[n.g].label ? " · " + esc(n.s) : ""}${n.c ? " · " + esc(n.c) : ""}</span>` +
      `<strong>${esc(n.t)}</strong>${n.d ? `<span>${esc(n.d)}</span>` : ""}` +
      `<span class="atlas__deg">${esc(data.link).replace("{n}", `<b>${links.length}</b>`)}${why ? ` · via ${esc(why)}` : ""}</span>`;
  }

  function hit(e) {
    const r = host.getBoundingClientRect(), x = e.clientX - r.left - state.cx, y = e.clientY - r.top - state.cy;
    const d = Math.hypot(x, y);
    if (d < state.R - 36 || d > state.ring + 6) return -1;
    const a = Math.atan2(y, x);
    let best = -1, bd = state.step * 0.8;
    pos.forEach((p, i) => {
      const diff = Math.abs(Math.atan2(Math.sin(a - p.a), Math.cos(a - p.a)));
      if (diff < bd && (group < 0 || data.nodes[i].g === group)) { bd = diff; best = i; }
    });
    return best;
  }

  host.addEventListener("pointerdown", (e) => { lastType = e.pointerType; });
  host.addEventListener("pointermove", (e) => {
    if (e.pointerType !== "mouse" || pinned >= 0) return;
    const i = hit(e);
    if (i !== hover) { hover = i; describe(i); host.style.cursor = i >= 0 ? "pointer" : ""; if (i >= 0) use("hover"); if (reduced) frame(); }
  });
  host.addEventListener("pointerleave", (e) => { if (e.pointerType !== "mouse") return; hover = -1; if (pinned < 0) describe(-1); if (reduced) frame(); });
  host.addEventListener("click", (e) => {
    const i = hit(e);
    if (i < 0) { if (pinned >= 0) { pinned = -1; describe(-1); if (reduced) frame(); } return; }
    if (lastType !== "mouse" && pinned !== i) { pinned = i; describe(i); use("tap"); if (reduced) frame(); return; }
    const n = data.nodes[i];
    if (n.u) { track?.(`web_open:${root.dataset.web}:${n.u}`); location.href = n.u; }
  });
  input?.addEventListener("input", () => { query = input.value.trim().toLowerCase(); use("search"); if (reduced) frame(); });
  chips.forEach((c) => c.addEventListener("click", () => {
    group = +c.dataset.webG; chips.forEach((x) => x.setAttribute("aria-pressed", String(x === c))); use("group"); if (reduced) frame();
  }));

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  state.onResize = () => { layout(); if (reduced) frame(); };
  layout(); describe(-1); frame();
  return lifecycle(run, { reduced });
}
