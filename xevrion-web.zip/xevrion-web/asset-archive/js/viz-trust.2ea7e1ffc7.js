// Security: five concentric layers of protection. Requests arrive from outside and must pass every ring to reach your
// data at the centre. Most pass; some are stopped at the ring whose check they fail (shown in red, with the reason).
import { C, clamp, glow, lerp, lifecycle, loop, mulberry, rgba, stageCanvas } from "./viz-kit.88725e7ff9.js";

const RINGS = [
  ["Lifecycle", "Deleted data stays deleted"],
  ["Actions", "Consequential actions need approval"],
  ["Connections", "Only the permissions you granted"],
  ["Access", "Wrong organisation or role: refused"],
  ["Identity", "No valid session or two-factor code: refused"],
];

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const rand = mulberry(3);
  const reqs = [];
  let spawn = 0, notice = null;

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    const cx = w / 2, cy = h / 2, R = Math.min(w, h) * 0.44;
    ctx.clearRect(0, 0, w, h);
    RINGS.forEach(([name], i) => {                                  // i = 0 innermost
      const r = R * (0.3 + i * 0.16);
      ctx.strokeStyle = rgba(C.text1, 0.1 + i * 0.03); ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      // rotating check marks on each ring
      const a = (reduced ? 0 : time * (0.08 + i * 0.03)) * (i % 2 ? 1 : -1);
      for (let k = 0; k < 3; k++) {
        const ang = a + (k * Math.PI * 2) / 3;
        ctx.fillStyle = rgba(C.text1, 0.55); ctx.fillRect(cx + Math.cos(ang) * r - 2, cy + Math.sin(ang) * r - 2, 4, 4);
      }
      ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = C.text3;
      ctx.fillText(name.toUpperCase(), cx, cy - r - 5);
    });
    glow(ctx, cx, cy, R * 0.3, C.text1, 0.35);
    ctx.fillStyle = C.text1; ctx.font = "500 11px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillText("YOUR DATA", cx, cy + 4);
    if (!reduced) {
      spawn += dt;
      if (spawn > 0.45 && reqs.length < 18) {
        spawn = 0;
        const stop = rand() < 0.28 ? 4 - Math.floor(rand() * 3) : -1;   // stopped at identity, access or connections
        reqs.push({ a: rand() * Math.PI * 2, t: 0, stop });
      }
      reqs.forEach((q) => {
        q.t += dt * 0.32;
        const r = lerp(R * 1.08, R * 0.28, clamp(q.t));
        const ringR = q.stop >= 0 ? R * (0.3 + q.stop * 0.16) : -1;
        if (q.stop >= 0 && r <= ringR + 2) { q.dead = time; notice = { text: RINGS[q.stop][1], at: time }; return; }
        const x = cx + Math.cos(q.a) * r, y = cy + Math.sin(q.a) * r;
        ctx.fillStyle = q.stop >= 0 ? rgba(C.text1, 0.8) : C.violetPale; ctx.beginPath(); ctx.arc(x, y, 2.4, 0, Math.PI * 2); ctx.fill();
        if (q.t >= 1) q.dead = time;
      });
      for (let i = reqs.length - 1; i >= 0; i--) {
        const q = reqs[i];
        if (q.dead) {
          if (q.stop >= 0 && time - q.dead < 0.7) {
            const r = R * (0.3 + q.stop * 0.16), x = cx + Math.cos(q.a) * r, y = cy + Math.sin(q.a) * r;
            ctx.strokeStyle = rgba(C.risk, 1 - (time - q.dead) / 0.7); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, 7, 0, Math.PI * 2); ctx.stroke();
          } else reqs.splice(i, 1);
        }
      }
      if (notice && time - notice.at < 1.6) {
        ctx.font = "500 12px Geist, sans-serif"; ctx.textAlign = "center"; ctx.fillStyle = rgba("#ff8f9a", 1 - (time - notice.at) / 1.6);
        ctx.fillText(`Refused: ${notice.text.toLowerCase()}`, cx, h - 16);
      }
    }
  }

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  host.addEventListener("pointerenter", () => track?.("viz_interact:trust", true), { once: true });
  return lifecycle(run, { reduced });
}
