// End-to-end example told as a scroll story. Each step carries the state of the business at that moment
// (data-state JSON); as a step reaches the reading line, the sticky panel shows that state. Without this module the
// panel shows the final state and every step is fully readable.
export function mount(host, { reduced, track }) {
  const panel = host.querySelector("[data-story-panel]");
  const steps = [...host.querySelectorAll("[data-state]")];
  if (!panel || !steps.length) return { visible() {} };
  const field = (k) => panel.querySelector(`[data-f="${k}"]`);
  const meter = panel.querySelector(".story__meter i");
  let current = -1, seen = 0;

  function show(i) {
    if (i === current) return;
    current = i;
    const s = JSON.parse(steps[i].dataset.state);
    steps.forEach((el, j) => el.toggleAttribute("data-on", j <= i));
    for (const [k, v] of Object.entries(s)) {
      const el = field(k);
      if (el && el.textContent !== String(v)) el.textContent = v;
    }
    panel.dataset.health = s.tone || "neutral";
    if (meter && s.health) meter.style.setProperty("--w", `${s.health}%`);
    if (i > seen) { seen = i; if (i === steps.length - 1) track?.("story_complete:home", true); }
  }

  host.classList.add("is-live");
  const io = new IntersectionObserver((entries) => {
    // the step closest to the reading line (40% down the viewport) wins
    const visible = entries.filter((e) => e.isIntersecting).map((e) => steps.indexOf(e.target));
    if (visible.length) show(Math.max(...visible));
  }, { rootMargin: "-40% 0px -55% 0px" });
  steps.forEach((el) => io.observe(el));
  show(0);
  if (reduced) panel.querySelector(".story__meter i")?.style.setProperty("transition", "none");
  return { visible() {} };
}
