// Relationship web: the Atlas visual for any catalogue data (xw/webs.py). Points sit on one ring, grouped; lines are
// real relationships, bundled through the centre. A focus group can be emphasised (a product page shows how its system
// connects to the rest). Hover a point to trace its links; click to open it; search and group switches dim the rest.
//
// Two canvases: the structure (rings, links, points, names) is painted only when something changes, at up to 3x pixel
// density so it stays sharp on 4K screens; the travelling signals animate on a light canvas underneath it. Names are
// only drawn around the ring when there is room for every one of them without touching; otherwise they appear on
// hover in the panel beside the map.
//
// On a narrow stage (a phone) the group names beside the ring would shrink it to a fraction of the space, so the web
// goes compact: the ring fills the stage, and the group names move to the group chips above the map, each chip
// carrying a dot in its arc's colour.
import { C, glow, lerp, lifecycle, loop, rgba, roundRect, stageCanvas, rel } from "./viz-kit.0fe0c83bce.js";

const TONE = { violet: C.violetBright, white: C.text1, pale: C.violetPale };
const GROUP_FONT = "500 10.5px 'Geist Mono', monospace";
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function mount(host, { reduced, track }) {
  const data = JSON.parse(host.querySelector("[data-web-data]").textContent);
  const root = host.closest("[data-web]") || host;
  const tools = root.querySelector("[data-web-tools]");
  const input = root.querySelector("[data-web-q]");
  const chips = [...root.querySelectorAll("[data-web-g]")];
  const readout = host.querySelector("[data-web-readout]");
  const { ctx, state } = stageCanvas(host, { maxDpr: 3 });
  const fx = stageCanvas(host, { maxDpr: 2 });      // prepended, so it sits underneath the structure
  const N = data.nodes.length, focus = data.focus ?? -1;
  const MAXC = N > 60 ? 24 : 28;                     // names are cut to this many characters around the ring
  const cut = (t) => (t.length > MAXC ? t.slice(0, MAXC - 1) + "…" : t);
  const out = data.nodes.map(() => []);
  data.edges.forEach(([a, b], k) => { out[a].push([b, k]); out[b].push([a, k]); });
  let pos = [], spans = [], hover = -1, pinned = -1, query = "", group = -1, used = false, pulses = [], lastType = "mouse";
  let sel = -1, near = null, lit = [], pool = [];
  if (tools) tools.hidden = false;

  const use = (what) => { if (!used) { used = true; track?.(`viz_interact:web:${root.dataset.web}:${what}`, true); } };
  const matches = (n) => (group < 0 || n.g === group) && (!query || (n.t + " " + (n.s || "") + " " + (n.d || "")).toLowerCase().includes(query));
  const groupCol = (g) => (focus >= 0 ? (g === focus ? C.violetPale : C.text2) : [C.text1, C.violetPale, C.text2, C.violetBright, "#9fb4ff", "#d6c8ff", C.text3, "#b9f0ff", "#ffffff"][g % 9]);

  function layout() {
    const { w, h } = state;
    const G = data.groups.length, gap = N > 40 ? 3 : 1.4;      // small webs keep their groups close together
    const step = (Math.PI * 2) / (N + G * gap);
    let a = -Math.PI / 2 + (step * gap) / 2, prev = -1;
    const ang = data.nodes.map((n) => { if (prev >= 0 && n.g !== prev) a += step * gap; prev = n.g; const v = a; a += step; return v; });
    ctx.font = GROUP_FONT;
    spans = [];
    let start = 0;
    data.nodes.forEach((n, i) => {
      if (i < N - 1 && data.nodes[i + 1].g === n.g) return;
      const a0 = ang[start] - step * 0.5, a1 = ang[i] + step * 0.5;
      const text = `${data.groups[n.g].label.toUpperCase()} · ${i - start + 1}`;
      spans.push({ g: n.g, a0, a1, am: (a0 + a1) / 2, text, wd: ctx.measureText(text).width });
      start = i + 1;
    });
    const cx = w / 2, cy = h / 2, full = Math.min(cx, cy) - 10;
    // the largest outer ring whose group names stay wholly inside the canvas
    let ring = Math.min(cx, cy) - 8;
    for (const s of spans) {
      const c = Math.cos(s.am), si = Math.sin(s.am);
      if (c > 0.2) ring = Math.min(ring, (w - 8 - s.wd - cx) / c - 12);
      else if (c < -0.2) ring = Math.min(ring, (cx - 8 - s.wd) / -c - 12);
      else if (Math.abs(c) > 0.01) ring = Math.min(ring, (cx - 8 - s.wd / 2) / Math.abs(c) - 12);
      if (si > 0.01) ring = Math.min(ring, (h - cy - 16) / si - 12);
      else if (si < -0.01) ring = Math.min(ring, (cy - 14) / -si - 12);
    }
    // compact when the names would cost the ring more than a third of its size (and there are chips to carry them)
    state.compact = chips.length > 1 && ring < full * 0.7;
    if (state.compact) ring = full;
    // names go around the ring only if neighbours cannot touch (the gap between two names where they start, next to
    // the ring, must be at least the text height) and the ring stays a useful size; smaller type is tried once
    state.labelsOn = false;
    let R = ring - 14;
    for (const fs of N > 60 ? [10, 9] : [11.5, 10.5]) {
      ctx.font = `500 ${fs}px Geist, sans-serif`;
      const lw = Math.max(...data.nodes.map((n) => ctx.measureText(cut(n.t)).width));
      const r = ring - lw - 26;
      if (r >= Math.min(150, Math.min(w, h) * 0.2) && step * (r + 12) >= fs * 0.96) { state.labelsOn = true; state.fs = fs; R = r; break; }
    }
    R = Math.max(40, R);
    state.cx = cx; state.cy = cy; state.R = R; state.step = step;
    state.ring = state.labelsOn ? ring : R + 14;
    pos = ang.map((v) => ({ a: v, x: cx + Math.cos(v) * R, y: cy + Math.sin(v) * R }));
  }

  const curve = (a, b) => {
    const pa = pos[a], pb = pos[b];
    return { pa, pb, c: { x: lerp(state.cx, (pa.x + pb.x) / 2, 0.2), y: lerp(state.cy, (pa.y + pb.y) / 2, 0.2) } };
  };

  function label(i, strong) {
    const p = pos[i], left = Math.cos(p.a) < 0;
    ctx.save(); ctx.translate(state.cx + Math.cos(p.a) * (state.R + 12), state.cy + Math.sin(p.a) * (state.R + 12));
    ctx.rotate(left ? p.a + Math.PI : p.a);
    ctx.textAlign = left ? "right" : "left"; ctx.textBaseline = "middle";
    ctx.font = `${strong ? 600 : 500} ${state.fs}px Geist, sans-serif`;
    ctx.fillStyle = strong ? C.text1 : rgba(C.text2, 0.85);
    ctx.fillText(cut(data.nodes[i].t), 0, 0);
    ctx.restore();
  }

  // what is selected, lit and animating: recomputed on every change, then the structure is repainted once
  function refresh() {
    sel = pinned >= 0 ? pinned : hover;
    near = sel >= 0 ? new Set([sel, ...out[sel].map(([j]) => j)]) : null;
    lit = data.nodes.map((n, i) => (near ? near.has(i) : matches(n) && (focus < 0 || n.g === focus || out[i].some(([j]) => data.nodes[j].g === focus))));
    pool = data.edges.filter(([a, b]) => (near ? a === sel || b === sel : lit[a] && lit[b]));
    pulses = [];
    paint();
  }

  function paint() {
    const { w, h, cx, cy } = state;
    ctx.clearRect(0, 0, w, h);
    // group arcs with their names
    for (const s of spans) {
      const on = (group < 0 || group === s.g) && (focus < 0 || focus === s.g), c = Math.cos(s.am);
      ctx.strokeStyle = rgba(groupCol(s.g), on ? (state.compact ? 0.85 : 0.6) : 0.16); ctx.lineWidth = (focus === s.g ? 3 : 2) + (state.compact ? 1 : 0);
      ctx.beginPath(); ctx.arc(cx, cy, state.ring, s.a0, s.a1); ctx.stroke();
      if (state.compact) continue;   // the chips above the map carry the names
      ctx.font = GROUP_FONT; ctx.textBaseline = "alphabetic"; ctx.textAlign = c > 0.2 ? "left" : c < -0.2 ? "right" : "center";
      ctx.fillStyle = rgba(groupCol(s.g), on ? 0.95 : 0.4);
      ctx.fillText(s.text, cx + c * (state.ring + 12), cy + Math.sin(s.am) * (state.ring + 12) + 4);
    }
    // relationships, bundled through the centre: faint ones first so the lit ones sit on top
    const draw = (bright) => data.edges.forEach(([a, b, k]) => {
      const tone = TONE[data.kinds[k]?.tone] || C.text1;
      let alpha, width = 1;
      if (near) {
        const mine = a === sel || b === sel;
        if (mine !== bright) return;
        alpha = mine ? 0.9 : 0.02; width = mine ? 1.6 : 1;
      } else {
        const on = lit[a] && lit[b] && (focus < 0 || data.nodes[a].g === focus || data.nodes[b].g === focus);
        if (on !== bright) return;
        alpha = on ? (data.kinds[k]?.alpha ?? (tone === C.text1 ? 0.14 : 0.3)) : 0.025;
      }
      const { pa, pb, c } = curve(a, b);
      ctx.strokeStyle = rgba(tone, alpha); ctx.lineWidth = width;
      ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.quadraticCurveTo(c.x, c.y, pb.x, pb.y); ctx.stroke();
    });
    draw(false); draw(true);
    // the points, then their names
    data.nodes.forEach((n, i) => {
      const p = pos[i], me = i === sel, hub = n.hub;
      const r = me ? 5.5 : hub ? 5 : 2.2 + Math.min(2.8, out[i].length * 0.22);
      if (me || hub) glow(ctx, p.x, p.y, me ? 28 : 18, C.violet, me ? 1 : 0.6);
      ctx.fillStyle = rgba(groupCol(n.g), lit[i] ? 0.95 : 0.16);
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
    });
    if (state.labelsOn) data.nodes.forEach((n, i) => { if (i === sel || (lit[i] && (focus < 0 || n.g === focus || near))) label(i, i === sel); });
    if (!near) {
      // the centre caption sits on its own backing, so the links bundled through the centre never run through it
      ctx.font = "500 10px 'Geist Mono', monospace"; const tw = ctx.measureText(data.centre).width;
      ctx.fillStyle = "rgba(8,9,13,0.82)"; roundRect(ctx, cx - tw / 2 - 9, cy - 9, tw + 18, 19, 9.5); ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.10)"; ctx.lineWidth = 1; ctx.stroke();
      ctx.textAlign = "center"; ctx.textBaseline = "alphabetic"; ctx.fillStyle = C.text2; ctx.fillText(data.centre, cx, cy + 4);
    }
  }

  // signals travelling along the lit relationships, on their own canvas
  function frame(time = 0, dt = 0.016) {
    const g = fx.ctx;
    g.clearRect(0, 0, fx.state.w, fx.state.h);
    if (reduced || !pool.length) return;
    if (pulses.length < 10 && Math.random() < 0.07) { const e = pool[Math.floor(Math.random() * pool.length)]; pulses.push({ a: e[0], b: e[1], t: 0, rev: Math.random() < 0.5 }); }
    pulses = pulses.filter((p) => (p.t += dt * 0.6) < 1);
    for (const p of pulses) {
      const { pa, pb, c } = curve(p.rev ? p.b : p.a, p.rev ? p.a : p.b), t = p.t, u = 1 - t, s = Math.sin(t * Math.PI);
      const x = u * u * pa.x + 2 * u * t * c.x + t * t * pb.x, y = u * u * pa.y + 2 * u * t * c.y + t * t * pb.y;
      glow(g, x, y, 10, C.violet, s);
      g.fillStyle = rgba(C.text1, s); g.beginPath(); g.arc(x, y, 1.6, 0, Math.PI * 2); g.fill();
    }
  }

  function describe(i) {
    if (i < 0) {
      const f = focus >= 0 ? `<strong>${esc(data.groups[focus].label)}</strong><span>${data.nodes.filter((n) => n.g === focus).length} ${data.unit === "capability" ? "capabilities" : "points"} and their links to the rest of the platform.</span>`
        : `<strong>${esc(data.centre.toLowerCase())}${/LINKS/.test(data.centre) ? "" : ` · ${data.edges.length} links`}</strong><span>${data.kinds.map((k) => esc(k.label)).join(" · ")}</span>`;
      readout.innerHTML = `<span class="label label--violet">Map</span>${f}<span class="quiet">Point at anything to trace it; click to open it.</span>`;
      return;
    }
    const n = data.nodes[i], links = out[i];
    const why = [...new Set(links.map(([, k]) => data.edges[k][3]).filter(Boolean).join(", ").split(", "))].slice(0, 5).join(", ");
    readout.innerHTML = `<span class="label label--violet">${esc(data.groups[n.g].label)}${n.s && n.s !== data.groups[n.g].label ? " · " + esc(n.s) : ""}${n.c ? " · " + esc(n.c) : ""}</span>` +
      `<strong>${esc(n.t)}</strong>${n.d ? `<span>${esc(n.d)}</span>` : ""}` +
      `<span class="atlas__deg">${esc(data.link).replace("{n}", `<b>${links.length}</b>`)}${why ? ` · via ${esc(why)}` : ""}</span>`;
  }

  function hit(e) {
    const r = rel(host, e), x = r.x - state.cx, y = r.y - state.cy;
    const d = Math.hypot(x, y);
    if (d < state.R - 36 || d > state.ring + 6) return -1;
    const a = Math.atan2(y, x);
    let best = -1, bd = state.step * 0.8;
    pos.forEach((p, i) => {
      const diff = Math.abs(Math.atan2(Math.sin(a - p.a), Math.cos(a - p.a)));
      if (diff < bd && (group < 0 || data.nodes[i].g === group)) { bd = diff; best = i; }
    });
    return best;
  }

  host.addEventListener("pointerdown", (e) => { lastType = e.pointerType; });
  host.addEventListener("pointermove", (e) => {
    if (e.pointerType !== "mouse" || pinned >= 0) return;
    const i = hit(e);
    if (i !== hover) { hover = i; describe(i); host.style.cursor = i >= 0 ? "pointer" : ""; if (i >= 0) use("hover"); refresh(); }
  });
  host.addEventListener("pointerleave", (e) => { if (e.pointerType !== "mouse" || hover < 0) return; hover = -1; if (pinned < 0) describe(-1); refresh(); });
  host.addEventListener("click", (e) => {
    const i = hit(e);
    if (i < 0) { if (pinned >= 0) { pinned = -1; describe(-1); refresh(); } return; }
    if (lastType !== "mouse" && pinned !== i) { pinned = i; describe(i); use("tap"); refresh(); return; }
    const n = data.nodes[i];
    if (n.u) { track?.(`web_open:${root.dataset.web}:${n.u}`); location.href = n.u; }
  });
  input?.addEventListener("input", () => { query = input.value.trim().toLowerCase(); use("search"); refresh(); });
  chips.forEach((c) => c.addEventListener("click", () => {
    group = +c.dataset.webG; chips.forEach((x) => x.setAttribute("aria-pressed", String(x === c))); use("group"); refresh();
  }));

  // each group chip carries its arc's colour, so the map can be read from the chips when its names are not drawn
  chips.forEach((c) => { const g = +c.dataset.webG; if (g >= 0) c.style.setProperty("--dot", groupCol(g)); });

  const run = loop(frame);
  run.renderStatic = () => paint();
  state.onResize = () => { layout(); refresh(); };
  layout(); describe(-1); refresh();
  // names are measured and drawn in the site's fonts: once they have loaded, measure and paint again
  document.fonts?.ready.then(() => { layout(); refresh(); });
  return lifecycle(run, { reduced });
}
