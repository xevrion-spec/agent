/* Copied from the gateway (platform-gateway/portal-ui) by tools/sync_portal.py. Edit the gateway copy, not this one. */
(function () {
  "use strict";
/* Xevrion portal kit: the machinery shared by the customer portal (portal.js, /app) and the owner console
   (console.js, /console): formatting, icons and the mark, render helpers, SVG charts, the constellation engine and
   the drawer, dialog and toast overlays. scripts/build_portal_ui.py wraps kit.js and one app in a single strict IIFE,
   so the app's own declarations (S, go) are in scope here; nothing in this file runs until the app calls it.
   The kit never touches browser storage. */
  // ================================================================ basics
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
  const fmtN = (v, d = 0) => num(v).toLocaleString("en-GB", { maximumFractionDigits: d, minimumFractionDigits: d });
  const compact = (v) => { const n = num(v); if (Math.abs(n) >= 1e9) return "No limit"; if (Math.abs(n) >= 1e6) return fmtN(n / 1e6, 1).replace(/\.0$/, "") + "M"; if (Math.abs(n) >= 1e4) return fmtN(n / 1e3, 1).replace(/\.0$/, "") + "K"; return fmtN(n); };
  const money = (v, cur = "GBP") => { const n = num(v); try { return n.toLocaleString("en-GB", { style: "currency", currency: cur || "GBP", maximumFractionDigits: Math.abs(n) >= 1000 ? 0 : 2 }); } catch (e) { return (cur || "") + " " + fmtN(n, 2); } };
  const pct = (v, d = 0) => (v === null || v === undefined || v === "" ? "—" : fmtN(num(v) * 100, d) + "%");
  const words = (s) => String(s ?? "").replace(/[_.]+/g, " ").replace(/\s+/g, " ").trim();
  const cap = (s) => { const w = words(s); return w ? w.charAt(0).toUpperCase() + w.slice(1) : "—"; };
  const initials = (s) => String(s || "?").replace(/[^A-Za-z0-9 ]/g, " ").trim().split(/\s+/).slice(0, 2).map((x) => x[0]).join("").toUpperCase() || "?";
  const uid = () => (window.crypto && crypto.randomUUID ? crypto.randomUUID() : "k" + Date.now().toString(36) + Math.random().toString(36).slice(2));
  const $ = (id) => document.getElementById(id);
  const dateOf = (iso) => { if (!iso) return null; const d = new Date(iso); return isNaN(d) ? null : d; };
  const when = (iso) => { const d = dateOf(iso); return d ? d.toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : (iso ? String(iso) : "—"); };
  const dayLabel = (iso) => { const d = dateOf(iso); return d ? d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "—"; };
  const ago = (iso) => {
    const d = dateOf(iso); if (!d) return "—";
    const s = (Date.now() - d.getTime()) / 1000, a = Math.abs(s), f = s >= 0 ? " ago" : " from now";
    if (a < 60) return "just now"; if (a < 3600) return Math.round(a / 60) + " min" + f; if (a < 86400) return Math.round(a / 3600) + " h" + f;
    if (a < 86400 * 30) return Math.round(a / 86400) + " d" + f; return dayLabel(iso);
  };
  const settle = (p) => Promise.resolve(p).then((v) => ({ ok: true, v }), (e) => ({ ok: false, e }));
  const reduced = () => window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ================================================================ icons and the mark
  const ICONS = {
    core: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8.5" stroke-dasharray="2.5 3"/>',
    map: '<circle cx="5" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="12" cy="18.5" r="2"/><path d="M7 6h10M6.1 7.8l4.9 9M17.9 7.8l-4.9 9"/>',
    revenue: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    customers: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18.5 14.8c1.6.8 2.6 2.5 3 5.2"/>',
    operations: '<rect x="3" y="4" width="7" height="7" rx="1.5"/><rect x="14" y="4" width="7" height="7" rx="1.5"/><rect x="8.5" y="14" width="7" height="7" rx="1.5"/><path d="M6.5 11v1.5h11V11M12 12.5V14"/>',
    decisions: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    value: '<path d="M4 20h16"/><rect x="5" y="11" width="3" height="6" rx=".5"/><rect x="10.5" y="7" width="3" height="10" rx=".5"/><rect x="16" y="4" width="3" height="13" rx=".5"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.3"/>',
    gauge: '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/>',
    setup: '<path d="M10 6h10M10 12h10M10 18h10"/><path d="M3.5 6l1.5 1.5L7.5 4.5M3.5 12l1.5 1.5 2.5-3M3.5 18l1.5 1.5 2.5-3"/>',
    plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0z"/><path d="M12 17v4"/>',
    team: '<circle cx="8" cy="9" r="3"/><circle cx="16.5" cy="9.5" r="2.5"/><path d="M2.5 19c.7-3 2.9-4.6 5.5-4.6s4.8 1.6 5.5 4.6M14 14.6c2.8-.4 5.1 1 5.8 4.4"/>',
    card: '<rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="M3 10h18M7 15h4"/>',
    bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    chat: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9.5h8M8 12.5h5"/>',
    shield: '<path d="M12 3l8 3v6c0 4.5-3.3 8-8 9-4.7-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10h14V9M10 13h4"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.5-4.5L4 8M4 13a8 8 0 0 0 14.5 4.5L20 16"/><path d="M4 4v4h4M20 20v-4h-4"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    approve: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
    alert: '<path d="M12 3.5l9 16h-18z"/><path d="M12 10v4.5M12 17.5v.3"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5H5V6h5"/>',
    logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    play: '<path d="M8 5l11 7-11 7z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5l8.5 7 8.5-7"/>',
    flow: '<circle cx="5" cy="12" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="19" cy="18" r="2"/><path d="M7 12h4c2 0 2-6 6-6M11 12c2 0 2 6 6 6"/>',
    spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 20c1-4 4-6 8-6s7 2 8 6"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>',
  };
  const icon = (n, s = 18) => '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || ICONS.core) + "</svg>";
  // The mark in chrome (polished metal lit from above, with a diagonal sheen), as on the websites (xevrion-web/xw/html.py
  // CHROME_STOPS). The gradients use the mark's 32-unit grid, so the metal is the same at every size.
  const MARK = '<svg viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="xpm-chrome" gradientUnits="userSpaceOnUse" x1="16" y1="3" x2="16" y2="29"><stop offset="0" stop-color="#ffffff"/><stop offset="0.24" stop-color="#e9ecf2"/><stop offset="0.45" stop-color="#9ba1af"/><stop offset="0.5" stop-color="#4f5463"/><stop offset="0.53" stop-color="#cfd4de"/><stop offset="0.72" stop-color="#ffffff"/><stop offset="1" stop-color="#a9afbc"/></linearGradient><linearGradient id="xpm-sheen" gradientUnits="userSpaceOnUse" x1="5" y1="5" x2="27" y2="27"><stop offset=".38" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".6"/><stop offset=".62" stop-color="#fff" stop-opacity="0"/></linearGradient></defs><path fill="url(#xpm-chrome)" d="M27.37 9.71A13 13 0 1 1 22.29 4.63L19.71 8.02A8.8 8.8 0 1 0 23.98 12.29Z"/><path fill="url(#xpm-chrome)" d="M13.45 18.55L28.87 6.81L25.19 3.13Z"/><path fill="url(#xpm-sheen)" d="M27.37 9.71A13 13 0 1 1 22.29 4.63L19.71 8.02A8.8 8.8 0 1 0 23.98 12.29Z"/><path fill="url(#xpm-sheen)" d="M13.45 18.55L28.87 6.81L25.19 3.13Z"/></svg>';
  const CHROME = [[0, "#ffffff"], [0.24, "#e9ecf2"], [0.45, "#9ba1af"], [0.5, "#4f5463"], [0.53, "#cfd4de"], [0.72, "#ffffff"], [1, "#a9afbc"]];
  const MARK_PATHS = ["M27.37 9.71A13 13 0 1 1 22.29 4.63L19.71 8.02A8.8 8.8 0 1 0 23.98 12.29Z", "M13.45 18.55L28.87 6.81L25.19 3.13Z"];

  // ================================================================ small render helpers
  const chip = (text, tone = "", dot = true) => '<span class="xp-chip"' + (tone ? ' data-tone="' + tone + '"' : "") + ">" + (dot ? "<i></i>" : "") + esc(text) + "</span>";
  // Every status the gateway and its engines emit has a tone (tests/integration/test_portal_live_ui.py checks the
  // gateway's literals): ok = done or healthy, info = moving, warn = waiting on someone, risk = needs attention,
  // "" = neutral (ended or not applicable).
  const STATUS_TONE = { completed: "ok", active: "ok", healthy: "ok", connected: "ok", verified: "ok", paid: "ok", approved: "ok", resolved: "ok", confirmed: "ok", ready: "ok", trial: "info",
    pending: "warn", open: "warn", in_progress: "violet", triaged: "info", awaiting_authorization: "warn", pending_verification: "warn", past_due: "risk", failed: "risk", rejected: "risk", error: "risk",
    reconciliation_required: "risk", needs_attention: "risk", revoked: "", disconnected: "", cancelled: "", closed: "", void: "", escalated: "risk", observed: "info", estimated: "", pending_setup: "warn", not_subscribed: "warn", scheduled: "info",
    // done, delivered or answered
    accepted: "ok", delivered: "ok", sent: "ok", confirmed_sent: "ok", executed: "ok", answered_by_owner: "ok", answered_from_knowledge: "ok", qualified: "ok", ok: "ok", interested: "ok", customer: "ok", won: "ok",
    token_revocation_confirmed: "ok", researched: "ok", found: "ok", registered: "ok", available: "ok", reply_queued: "ok", matched: "ok", processed: "ok",
    // moving
    authorised: "info", new: "info", reviewing: "info", received: "info", invited: "info", queued: "info", sending: "info", running: "info", researching: "info", started: "info", advanced: "info", routed: "info",
    executing: "info", understanding: "info", assigned: "info", planned: "info", syncing: "info", exchanging: "info", warming: "info", trialing: "info", draft_workspace: "info", claimed: "info", leased: "info", frozen: "info", pilot: "info", restarting: "info", recommended: "violet", unread: "violet",
    // waiting on someone
    awaiting_payment: "warn", pending_payment: "warn", link_required: "warn", awaiting_details: "warn", awaiting_inputs: "warn", missing_inputs: "warn", awaiting_approval: "warn", needs_approval: "warn", needs_information: "warn",
    needs_review: "warn", review_required: "warn", delivery_review: "warn", human_review: "warn", needs_setup: "warn", configuration: "warn", not_configured: "warn", not_connected: "warn", waiting: "warn", waiting_for_service_rules: "warn",
    shared_verification_pending: "warn", retention_pending: "warn", retry_wait: "warn", retrying: "warn", retryable: "warn", paused: "warn", deferred: "warn", degraded: "warn", soft_bounce: "warn", rolled_back: "warn",
    manual_provider_action_required: "warn", replay_required: "warn", crawl_delay_exceeds_limit: "warn", website_unavailable: "warn", none_verified: "warn", retry: "warn", review: "warn", waiting_for_search: "warn",
    // needs attention
    unconfirmed: "risk", disconnect_pending: "risk", attention_required: "risk", reconnect_required: "risk", suspended: "risk", provider_rejected: "risk", revocation_unconfirmed: "risk", outcome_unknown: "risk",
    dead_letter: "risk", conflict: "risk", hard_bounce: "risk", complaint: "risk", unhealthy: "risk", missed: "risk", down: "risk", uncertain: "risk", exception: "risk",
    // ended or not applicable
    deleted: "", removed: "", suppressed_privacy: "", off: "", disabled: "", stopped: "", retired: "", waived: "", skipped: "", not_sent: "", not_started: "", not_required: "", expired: "", unknown: "", draft: "", disqualified: "", lost: "" };
  const status = (s) => chip(cap(s), STATUS_TONE[String(s)] ?? "");
  const card = (title, body, { sub = "", tag = "", cls = "", actions = "", id = "" } = {}) =>
    '<section class="xp-card ' + cls + '"' + (id ? ' id="' + id + '"' : "") + '><div class="xp-card-h"><div><h3>' + esc(title) + "</h3>" + (sub ? "<p>" + esc(sub) + "</p>" : "") + "</div>" +
    (actions ? '<div class="xp-card-f" style="margin:0">' + actions + "</div>" : tag ? '<span class="xp-tag">' + esc(tag) + "</span>" : "") + "</div>" + body + "</section>";
  const btn = (label, act, { tone = "", ic = "", data = {}, sm = false, disabled = false, go = "" } = {}) =>
    '<button type="button" class="xp-btn' + (tone ? " xp-btn--" + tone : "") + (sm ? " xp-btn--sm" : "") + '"' + (go ? ' data-go="' + esc(go) + '"' : act ? ' data-act="' + esc(act) + '"' : "") +
    Object.entries(data).map(([k, v]) => " data-" + k + '="' + esc(v) + '"').join("") + (disabled ? " disabled" : "") + ">" + (ic ? icon(ic, 16) : "") + esc(label) + "</button>";
  const empty = (title, text = "") => '<div class="xp-empty"><svg viewBox="0 0 64 64" fill="none"><circle cx="32" cy="32" r="22" stroke="rgba(255,255,255,.16)" stroke-dasharray="3 5"/><circle cx="32" cy="32" r="12" stroke="rgba(164,119,255,.55)"/><circle cx="32" cy="32" r="3" fill="#c6b5ff"/></svg><b>' + esc(title) + "</b>" + (text ? "<span>" + esc(text) + "</span>" : "") + "</div>";
  const kpi = (label, value, sub = "", { ic = "", tone = "", spark = "", meter = null, meterTone = "" } = {}) =>
    '<div class="xp-card xp-kpi"' + (tone ? ' data-tone="' + tone + '"' : "") + '><div class="xp-k-l">' + (ic ? icon(ic, 14) : "") + esc(label) + '</div><div class="xp-k-v">' + value + "</div>" +
    (sub ? '<div class="xp-k-s">' + sub + "</div>" : "") + (meter !== null ? '<div class="xp-meter"' + (meterTone ? ' data-tone="' + meterTone + '"' : "") + '><i style="width:' + Math.max(0, Math.min(100, meter * 100)).toFixed(1) + '%"></i></div>' : "") + (spark ? '<div class="xp-spark">' + spark + "</div>" : "") + "</div>";
  const field = ({ name, label, type = "text", value = "", hint = "", options = null, placeholder = "", required = false, rows = 0, readonly = false, attrs = "" }) => {
    const common = ' name="' + esc(name) + '"' + (placeholder ? ' placeholder="' + esc(placeholder) + '"' : "") + (required ? " required" : "") + (readonly ? " readonly" : "") + attrs;
    let control;
    if (type === "textarea") control = "<textarea" + common + (rows ? ' rows="' + rows + '"' : "") + ">" + esc(value) + "</textarea>";
    else if (type === "select") control = "<select" + common + ">" + (options || []).map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return '<option value="' + esc(v) + '"' + (String(v) === String(value) ? " selected" : "") + ">" + esc(l) + "</option>"; }).join("") + "</select>";
    else if (type === "checkbox") return '<label class="xp-check"><input type="checkbox"' + common + (value ? " checked" : "") + "><span>" + esc(label) + (hint ? " <small>" + esc(hint) + "</small>" : "") + "</span></label>";
    else control = '<input type="' + esc(type) + '"' + common + ' value="' + esc(value) + '"' + (type === "number" ? ' step="any" inputmode="decimal"' : "") + ">";
    return '<label class="xp-field"><span>' + esc(label) + (hint ? "<small>" + esc(hint) + "</small>" : "") + "</span>" + control + "</label>";
  };
  const collect = (root) => {
    const out = {};
    root.querySelectorAll("[name]").forEach((el) => { if (el.type === "checkbox") { if (el.value && el.value !== "on" && el.dataset.multi) { (out[el.name] = out[el.name] || []); if (el.checked) out[el.name].push(el.value); } else out[el.name] = el.checked; } else if (el.type === "radio") { if (el.checked) out[el.name] = el.value; } else out[el.name] = el.value; });
    return out;
  };
  const table = (rows, cols, { act = "", key = "id", emptyText = "Nothing has been recorded here yet." } = {}) => {
    if (!rows || !rows.length) return empty(emptyText);
    return '<div class="xp-table-wrap"><table class="xp-table"><thead><tr>' + cols.map((c) => "<th" + (c.num ? ' class="xp-num"' : "") + ">" + esc(c.label) + "</th>").join("") + "</tr></thead><tbody>" +
      rows.map((r) => "<tr" + (act ? ' data-row data-act="' + esc(act) + '" data-id="' + esc(r[key]) + '"' : "") + ">" + cols.map((c) => "<td" + (c.num ? ' class="xp-num"' : "") + ">" + (c.render ? c.render(r) : esc(r[c.key] ?? "—")) + "</td>").join("") + "</tr>").join("") + "</tbody></table></div>";
  };
  const bars = (items, { max = null, fmt = (v) => fmtN(v) } = {}) => {
    if (!items.length) return empty("Nothing measured yet");
    const top = max ?? Math.max(1e-9, ...items.map((x) => num(x.value)));
    return items.map((x) => '<div class="xp-bar-row"><span title="' + esc(x.label) + '">' + esc(x.label) + '</span><span class="xp-bar"><i' + (x.tone ? ' data-tone="' + x.tone + '"' : "") + ' style="width:' + Math.max(1.5, Math.min(100, (num(x.value) / top) * 100)).toFixed(1) + '%"></i></span><b>' + (x.text ?? fmt(x.value)) + "</b></div>").join("");
  };
  const statsRow = (items) => '<div class="xp-stats">' + items.map(([l, v]) => '<div class="xp-stat"><span>' + esc(l) + "</span><b>" + v + "</b></div>").join("") + "</div>";
  const hero = ({ eyebrow, title, lead = "", meta = "", actions = "", viz = "", solo = false }) =>
    '<section class="xp-hero' + (solo ? " xp-hero--solo" : "") + '"><div><p class="xp-eyebrow">' + esc(eyebrow) + "</p><h1>" + esc(title) + "</h1>" + (lead ? '<p class="xp-lead">' + lead + "</p>" : "") +
    (meta ? '<div class="xp-hero-meta">' + meta + "</div>" : "") + (actions ? '<div class="xp-hero-actions">' + actions + "</div>" : "") + "</div>" + (viz ? '<div class="xp-hero-viz"><div class="xp-viz" id="' + viz + '"></div></div>' : "") + "</section>";
  const sectionTitle = (t, s = "") => '<div class="xp-section-title"><h2>' + esc(t) + "</h2>" + (s ? "<span>" + esc(s) + "</span>" : "") + "</div>";
  const restricted = (what) => empty(what + " is not available to your role", "Ask an owner or administrator if you need it.");

  // ================================================================ SVG charts
  const TONE = { violet: "#a477ff", pale: "#c6b5ff", ok: "#4fd69c", warn: "#f2c46b", risk: "#ff5c6c", info: "#8fb3ff", white: "#f8f8fb", muted: "rgba(255,255,255,.28)" };
  const tone = (t) => TONE[t] || t || TONE.violet;
  let gid = 0;
  function spark(values, { w = 240, h = 44, t = "violet" } = {}) {
    if (!values || values.length < 2) return "";
    const max = Math.max(1, ...values), step = w / (values.length - 1), id = "xpg" + ++gid;
    const pts = values.map((v, i) => [i * step, h - 4 - (v / max) * (h - 10)]);
    const line = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join("");
    return '<svg class="xp-chart" viewBox="0 0 ' + w + " " + h + '" preserveAspectRatio="none" style="height:100%"><defs><linearGradient id="' + id + '" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="' + tone(t) + '" stop-opacity=".35"/><stop offset="1" stop-color="' + tone(t) + '" stop-opacity="0"/></linearGradient></defs><path d="' + line + "L" + w + " " + h + "L0 " + h + 'Z" fill="url(#' + id + ')"/><path d="' + line + '" fill="none" stroke="' + tone(t) + '" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>';
  }
  function columns(labels, series, { h = 190, stacked = true, w = 640 } = {}) {
    const W = w, H = h, L = 34, B = 26, T = 10, n = labels.length;
    const totals = labels.map((_, i) => stacked ? series.reduce((a, s) => a + num(s.values[i]), 0) : Math.max(0, ...series.map((s) => num(s.values[i]))));
    const max = Math.max(1, ...totals), step = (W - L - 6) / n, bw = Math.max(3, step * (stacked ? 0.62 : 0.8 / Math.max(1, series.length)));
    const Y = (v) => H - B - (v / max) * (H - B - T);
    let out = "";
    [0, 0.5, 1].forEach((f) => { const v = max * f, y = Y(v); out += '<line class="xp-ax" x1="' + L + '" x2="' + W + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '"/><text x="' + (L - 8) + '" y="' + (y + 3.5).toFixed(1) + '" text-anchor="end">' + compact(Math.round(v)) + "</text>"; });
    labels.forEach((lab, i) => {
      const x0 = L + 3 + i * step + (step - (stacked ? bw : bw * series.length)) / 2; let base = 0;
      series.forEach((s, k) => {
        const v = num(s.values[i]); if (!v) { if (!stacked) return; return; }
        const x = stacked ? x0 : x0 + k * bw, y1 = stacked ? Y(base + v) : Y(v), y0 = stacked ? Y(base) : Y(0);
        out += '<rect x="' + x.toFixed(1) + '" y="' + y1.toFixed(1) + '" width="' + (bw - (stacked ? 0 : 1)).toFixed(1) + '" height="' + Math.max(1, y0 - y1).toFixed(1) + '" rx="2" fill="' + tone(s.color) + '" opacity=".9"><title>' + esc(s.name + " · " + lab + ": " + fmtN(v)) + "</title></rect>";
        if (stacked) base += v;
      });
      if (n <= 8 || i % Math.ceil(n / 7) === 0) out += '<text x="' + (L + 3 + i * step + step / 2).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(lab) + "</text>";
    });
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + H + '" role="img">' + out + "</svg>";
  }
  function donut(parts, { size = 170, thick = 16, centre = "", sub = "" } = {}) {
    const total = parts.reduce((a, p) => a + num(p.value), 0), r = size / 2 - thick / 2 - 2, c = size / 2, C = 2 * Math.PI * r;
    let off = 0, arcs = "";
    if (!total) arcs = '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="' + thick + '"/>';
    parts.forEach((p) => { const v = num(p.value); if (!v) return; const len = (v / total) * C;
      arcs += '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="' + tone(p.color) + '" stroke-width="' + thick + '" stroke-dasharray="' + Math.max(0, len - 2).toFixed(2) + " " + C.toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 ' + c + " " + c + ')"><title>' + esc(p.label + ": " + fmtN(v)) + "</title></circle>"; off += len; });
    const svg = '<svg class="xp-chart" viewBox="0 0 ' + size + " " + size + '" style="width:' + size + 'px;max-width:100%">' + arcs + '<text x="' + c + '" y="' + (c + (sub ? 2 : 7)) + '" text-anchor="middle" style="font:500 24px var(--font);fill:#f8f8fb;letter-spacing:-.03em">' + esc(centre) + "</text>" + (sub ? '<text x="' + c + '" y="' + (c + 20) + '" text-anchor="middle">' + esc(sub) + "</text>" : "") + "</svg>";
    const legend = '<div class="xp-legend">' + parts.map((p) => '<span><i style="background:' + tone(p.color) + '"></i>' + esc(p.label) + " <b>" + fmtN(p.value) + "</b></span>").join("") + "</div>";
    return '<div style="display:grid;justify-items:center;gap:6px">' + svg + legend + "</div>";
  }
  function ring(frac, { size = 132, thick = 10, label = "", sub = "", t = "violet" } = {}) {
    const f = Math.max(0, Math.min(1, num(frac))), r = size / 2 - thick / 2 - 2, c = size / 2, C = 2 * Math.PI * r;
    return '<svg class="xp-chart" viewBox="0 0 ' + size + " " + size + '" style="width:' + size + 'px;max-width:100%"><circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="' + thick + '"/>' +
      '<circle cx="' + c + '" cy="' + c + '" r="' + r + '" fill="none" stroke="' + tone(t) + '" stroke-width="' + thick + '" stroke-linecap="round" stroke-dasharray="' + (f * C).toFixed(2) + " " + C.toFixed(2) + '" transform="rotate(-90 ' + c + " " + c + ')"/>' +
      '<text x="' + c + '" y="' + (c + (sub ? 3 : 8)) + '" text-anchor="middle" style="font:500 ' + Math.round(size / 5.2) + 'px var(--font);fill:#f8f8fb;letter-spacing:-.03em">' + esc(label) + "</text>" + (sub ? '<text x="' + c + '" y="' + (c + 20) + '" text-anchor="middle">' + esc(sub) + "</text>" : "") + "</svg>";
  }
  function segRing(flags, { size = 170, labels = [], unit = "STEPS DONE" } = {}) {
    const n = flags.length, c = size / 2, r = size / 2 - 14, gap = 0.06; let out = "";
    flags.forEach((on, i) => { const a0 = -Math.PI / 2 + (i / n) * 2 * Math.PI + gap / 2, a1 = -Math.PI / 2 + ((i + 1) / n) * 2 * Math.PI - gap / 2;
      const p = (a) => (c + r * Math.cos(a)).toFixed(2) + " " + (c + r * Math.sin(a)).toFixed(2);
      out += '<path d="M' + p(a0) + " A" + r + " " + r + " 0 0 1 " + p(a1) + '" fill="none" stroke-width="11" stroke-linecap="round" stroke="' + (on ? TONE.ok : "rgba(255,255,255,.1)") + '"><title>' + esc((labels[i] || "Step " + (i + 1)) + (on ? ": done" : ": to do")) + "</title></path>"; });
    const done = flags.filter(Boolean).length;
    return '<svg class="xp-chart" viewBox="0 0 ' + size + " " + size + '" style="width:' + size + 'px;max-width:100%">' + out + '<text x="' + c + '" y="' + (c + 4) + '" text-anchor="middle" style="font:500 30px var(--font);fill:#f8f8fb;letter-spacing:-.04em">' + done + "/" + n + '</text><text x="' + c + '" y="' + (c + 24) + '" text-anchor="middle">' + esc(unit) + "</text></svg>";
  }
  function gauge(score, { label = "HEALTH" } = {}) {
    const W = 260, H = 150, c = W / 2, cy = 130, r = 104, s = Math.max(0, Math.min(100, num(score)));
    const pt = (v, rr) => { const a = Math.PI + (v / 100) * Math.PI; return [c + rr * Math.cos(a), cy + rr * Math.sin(a)]; };
    const arc = (a, b, col, w) => { const [x0, y0] = pt(a, r), [x1, y1] = pt(b, r); return '<path d="M' + x0.toFixed(1) + " " + y0.toFixed(1) + " A" + r + " " + r + " 0 0 1 " + x1.toFixed(1) + " " + y1.toFixed(1) + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round"/>'; };
    let ticks = ""; for (let v = 0; v <= 100; v += 10) { const [a, b] = pt(v, r + 12), [x, y] = pt(v, r + 18); ticks += '<line x1="' + a.toFixed(1) + '" y1="' + b.toFixed(1) + '" x2="' + x.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="rgba(255,255,255,.2)"/>'; }
    const [nx, ny] = pt(s, r - 26), col = s < 45 ? TONE.risk : s < 70 ? TONE.warn : TONE.ok;
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + H + '" style="max-width:320px;margin:0 auto">' + arc(0, 100, "rgba(255,255,255,.08)", 12) + arc(0, 45, "rgba(255,92,108,.35)", 3) + arc(45, 70, "rgba(242,196,107,.35)", 3) + arc(70, 100, "rgba(79,214,156,.35)", 3) + (s > 0 ? arc(0, s, col, 12) : "") + ticks +
      '<line x1="' + c + '" y1="' + cy + '" x2="' + nx.toFixed(1) + '" y2="' + ny.toFixed(1) + '" stroke="#f8f8fb" stroke-width="2" stroke-linecap="round"/><circle cx="' + c + '" cy="' + cy + '" r="5" fill="#f8f8fb"/>' +
      '<text x="' + c + '" y="' + (cy - 30) + '" text-anchor="middle" style="font:500 34px var(--font);fill:#f8f8fb;letter-spacing:-.04em">' + Math.round(s) + '</text><text x="' + c + '" y="' + (cy - 10) + '" text-anchor="middle">' + esc(label) + "</text></svg>";
  }
  function funnel(stages) {
    const max = Math.max(1, ...stages.map((s) => num(s.value))), W = 640, rowH = 34; let out = "";
    stages.forEach((s, i) => { const w = Math.max(6, (num(s.value) / max) * (W - 250)), y = i * rowH;
      out += '<text x="0" y="' + (y + 21) + '" style="fill:#b7b8c2;font:500 12px var(--font)">' + esc(s.label) + '</text><rect x="210" y="' + (y + 7) + '" width="' + w.toFixed(1) + '" height="20" rx="4" fill="' + (num(s.value) ? tone(i < stages.length - 1 ? "violet" : "ok") : "rgba(255,255,255,.08)") + '" opacity="' + (0.95 - i * 0.06).toFixed(2) + '"/><text x="' + (218 + w).toFixed(1) + '" y="' + (y + 21) + '" style="fill:#f8f8fb">' + fmtN(s.value) + "</text>"; });
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + stages.length * rowH + '">' + out + "</svg>";
  }
  function pairs(items) { // expected vs actual per decision
    if (!items.length) return empty("No paired outcomes yet", "Pairs appear when a recorded decision has an observed or verified outcome.");
    const max = Math.max(1, ...items.flatMap((x) => [Math.abs(num(x.expected)), Math.abs(num(x.actual))])), W = 640, rowH = 40; let out = "";
    items.slice(0, 10).forEach((x, i) => { const y = i * rowH, we = (Math.abs(num(x.expected)) / max) * (W - 260), wa = (Math.abs(num(x.actual)) / max) * (W - 260);
      out += '<text x="0" y="' + (y + 16) + '" style="fill:#b7b8c2;font:500 12px var(--font)">' + esc(cap(x.service || "decision")) + '</text><text x="0" y="' + (y + 31) + '">' + esc(String(x.decision_id || "").slice(0, 14)) + "</text>" +
        '<rect x="180" y="' + (y + 6) + '" width="' + we.toFixed(1) + '" height="10" rx="3" fill="rgba(255,255,255,.35)"/><rect x="180" y="' + (y + 20) + '" width="' + wa.toFixed(1) + '" height="10" rx="3" fill="#a477ff"/>' +
        '<text x="' + (190 + Math.max(we, wa)).toFixed(1) + '" y="' + (y + 24) + '" style="fill:#f8f8fb">' + esc("error " + fmtN(x.error, 0)) + "</text>"; });
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + Math.min(10, items.length) * rowH + '">' + out + '</svg><div class="xp-legend"><span><i style="background:rgba(255,255,255,.35)"></i>Expected</span><span><i style="background:#a477ff"></i>Actual</span></div>';
  }
  function heat(rows, cols, get) {
    const vals = rows.flatMap((r) => cols.map((c) => num(get(r, c)))), max = Math.max(1, ...vals);
    return '<div class="xp-table-wrap"><table class="xp-table"><thead><tr><th></th>' + cols.map((c) => "<th>" + esc(cap(c)) + "</th>").join("") + "</tr></thead><tbody>" + rows.map((r) => "<tr><td>" + esc(cap(r)) + "</td>" + cols.map((c) => { const v = num(get(r, c));
      return '<td><span style="display:inline-block;min-width:64px;padding:4px 8px;border-radius:6px;font:500 12px var(--mono);background:rgba(128,86,255,' + (0.06 + (v / max) * 0.5).toFixed(2) + ');color:' + (v ? "#fff" : "var(--t3)") + '">' + compact(v) + "</span></td>"; }).join("") + "</tr>").join("") + "</tbody></table></div>";
  }
  function jsonTree(v, depth = 0) {
    if (v === null || v === undefined) return '<span class="z">null</span>';
    if (typeof v === "string") return '<span class="s">"' + esc(v.length > 600 ? v.slice(0, 600) + "…" : v) + '"</span>';
    if (typeof v === "number") return '<span class="n">' + esc(v) + "</span>";
    if (typeof v === "boolean") return '<span class="b">' + v + "</span>";
    const arr = Array.isArray(v), keys = arr ? v.map((_, i) => i) : Object.keys(v);
    if (!keys.length) return '<span class="z">' + (arr ? "[]" : "{}") + "</span>";
    return "<details" + (depth < 2 ? " open" : "") + "><summary>" + (arr ? "[" + keys.length + " items]" : "{" + keys.length + " fields}") + "</summary>" + keys.map((k) => "<div>" + (arr ? "" : '<span class="k">' + esc(k) + "</span>: ") + jsonTree(v[k], depth + 1) + "</div>").join("") + "</details>";
  }
  const evidence = (v) => '<div class="xp-json">' + jsonTree(v) + "</div>";

  // time series: completed operations per day for the last `days` days (today included), split by module. Days and
  // rows are both keyed by the viewer's local calendar date, so British Summer Time never shifts a day.
  const dayKey = (d) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  function daily(rows, days = 14, split = "module", keys = null) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const labels = [], index = {};
    for (let i = days - 1; i >= 0; i--) { const d = new Date(today); d.setDate(d.getDate() - i); index[dayKey(d)] = labels.length; labels.push(d.toLocaleDateString("en-GB", { day: "numeric", month: "short" })); }
    const groups = keys || [...new Set(rows.map((r) => r[split] || "other"))];
    const series = groups.map((g) => ({ key: g, values: labels.map(() => 0) }));
    rows.forEach((r) => { const d = dateOf(r.completed_at || r.at || r.created_at); if (!d) return; const i = index[dayKey(d)]; if (i === undefined) return;
      const s = series.find((x) => x.key === (r[split] || "other")); if (s) s.values[i]++; });
    return { labels, series };
  }

  // ================================================================ canvas: the constellation engine
  // A centre, rings of nodes, links between them and signals travelling along the links. Labels are placed outward
  // from each node and skipped when they would touch another label, the centre or the canvas edge.
  function constellation(host, spec) {
    if (!host) return () => {};
    const canvas = document.createElement("canvas"); canvas.setAttribute("aria-hidden", "true"); host.appendChild(canvas);
    const tip = document.createElement("div"); tip.className = "xp-viz-tip"; host.appendChild(tip);
    const ctx = canvas.getContext("2d");
    let w = 0, h = 0, floor = 0, dpr = 1, nodes = [], centre = null, raf = 0, running = false, hover = null, t0 = performance.now(), pulses = [], placed = [];
    const rings = spec.rings || [], links = spec.links || [];
    const col = (t) => ({ violet: "#a477ff", ok: "#4fd69c", warn: "#f2c46b", risk: "#ff5c6c", info: "#8fb3ff", white: "#f8f8fb", muted: "#8e909d", pale: "#c6b5ff" }[t] || t || "#a477ff");
    const rgba = (hex, a) => { if (hex[0] !== "#") return hex; const n = parseInt(hex.slice(1), 16); return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")"; };
    function layout() {
      const box = host.getBoundingClientRect(); w = Math.max(10, host.clientWidth); h = Math.max(10, host.clientHeight);
      const zoom = box.width / w || 1; dpr = Math.min(2.5, (window.devicePixelRatio || 1) * zoom);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      // floorEl: content overlaid on the lower part of the canvas (a headline); the map keeps to the space above it
      floor = spec.floorEl && spec.floorEl.offsetTop > 120 ? Math.min(h, spec.floorEl.offsetTop - 16) : h;
      const cx = w * (spec.cx ?? 0.5), cy = floor * (spec.cy ?? 0.5), labels = spec.labels !== false && w > 360;
      const rx = Math.max(40, Math.min(w * 0.5, w - cx) - (labels ? spec.labelRoom ?? 96 : 18)), ry = Math.max(30, Math.min(cy, floor - cy) - (labels ? 30 : 14));
      centre = { x: cx, y: cy, ...(spec.centre || {}) };
      nodes = [];
      rings.forEach((ring, k) => {
        const f = rings.length === 1 ? 0.78 : 0.52 + 0.48 * (k / (rings.length - 1)), base = (spec.rotate || -Math.PI / 2) + k * 0.37;
        ring.forEach((n, i) => { const a = base + (i / ring.length) * Math.PI * 2; nodes.push({ ...n, ring: k, a, x: cx + Math.cos(a) * rx * f, y: cy + Math.sin(a) * ry * f, r: 3.5 + Math.max(0, Math.min(1, num(n.weight))) * 6.5 }); });
      });
      placeLabels(labels);
    }
    function placeLabels(on) {
      placed = []; const cBox = centre.label ? { x0: centre.x - 60, x1: centre.x + 60, y0: centre.y - 34, y1: centre.y + 30 } : null; if (cBox) placed.push(cBox);
      ctx.font = "500 11.5px Geist, sans-serif";
      nodes.forEach((n) => {
        n.lab = null; if (!on || !n.label || n.quiet) return;  // quiet nodes are named in their tooltip only
        const c = Math.cos(n.a), s = Math.sin(n.a), side = Math.abs(c) < 0.25 ? 0 : c > 0 ? 1 : -1;
        const t1 = String(n.label), t2 = n.sub ? String(n.sub) : "", wd = Math.max(ctx.measureText(t1).width, t2 ? ctx.measureText(t2).width * 0.92 : 0), hh = t2 ? 28 : 15, gap = n.r + 8;
        // try the outward side first, then above, below and the opposite side; skip the label if none is clear
        const right = [n.x + gap, n.y - (t2 ? 13 : 7)], left = [n.x - gap - wd, n.y - (t2 ? 13 : 7)], above = [n.x - wd / 2, n.y - gap - hh], below = [n.x - wd / 2, n.y + gap];
        const tries = side === 1 ? [right, above, below, left] : side === -1 ? [left, above, below, right] : s < 0 ? [above, right, left, below] : [below, right, left, above];
        for (const [x, y] of tries) {
          const box = { x0: x - 3, x1: x + wd + 3, y0: y - 2, y1: y + hh };
          if (box.x0 < 2 || box.x1 > w - 2 || box.y0 < 2 || box.y1 > floor - 2) continue;
          if (placed.some((q) => box.x0 < q.x1 && q.x0 < box.x1 && box.y0 < q.y1 && q.y0 < box.y1)) continue;
          if (nodes.some((m) => m !== n && !m.quiet && m.x + m.r + 3 > box.x0 && m.x - m.r - 3 < box.x1 && m.y + m.r + 3 > box.y0 && m.y - m.r - 3 < box.y1)) continue;  // never over another node
          placed.push(box); n.lab = { x, y, t1, t2, w: wd }; break;
        }
      });
    }
    const target = (id) => (id === "c" ? centre : nodes.find((n) => n.id === id));
    const ctrl = (a, b) => ({ x: (a.x + b.x) / 2 + (centre.x - (a.x + b.x) / 2) * 0.25, y: (a.y + b.y) / 2 + (centre.y - (a.y + b.y) / 2) * 0.25 });
    function frame(now) {
      const t = (now - t0) / 1000; ctx.clearRect(0, 0, w, h);
      // orbits
      const rxs = [...new Set(nodes.map((n) => n.ring))];
      rxs.forEach((k) => { const ns = nodes.filter((n) => n.ring === k); if (!ns.length) return; const rx = Math.max(...ns.map((n) => Math.abs(n.x - centre.x))) || 1, ry = Math.max(...ns.map((n) => Math.abs(n.y - centre.y))) || 1;
        ctx.strokeStyle = "rgba(255,255,255," + (k ? 0.05 : 0.08) + ")"; ctx.lineWidth = 1; ctx.setLineDash(k ? [2, 6] : []); ctx.beginPath(); ctx.ellipse(centre.x, centre.y, rx, ry, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]); });
      // links
      links.forEach(([a, b, wgt, c]) => { const A = target(a), B = target(b); if (!A || !B) return; const k = ctrl(A, B), lit = hover && (hover === A || hover === B);
        ctx.strokeStyle = rgba(col(c || "violet"), lit ? 0.75 : 0.1 + Math.min(0.35, num(wgt) * 0.35)); ctx.lineWidth = lit ? 1.6 : 1;
        ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.quadraticCurveTo(k.x, k.y, B.x, B.y); ctx.stroke(); });
      // signals
      if (!reduced()) {
        if (pulses.length < (spec.maxPulses || 14) && links.length && Math.random() < 0.12) { const L = links[Math.floor(Math.random() * links.length)]; if (Math.random() < 0.25 + num(L[2]) * 0.75) pulses.push({ L, t: 0, v: 0.35 + Math.random() * 0.35 }); }
        pulses = pulses.filter((p) => (p.t += 0.016 * p.v) < 1);
        pulses.forEach((p) => { const A = target(p.L[0]), B = target(p.L[1]); if (!A || !B) return; const k = ctrl(A, B), u = 1 - p.t, x = u * u * A.x + 2 * u * p.t * k.x + p.t * p.t * B.x, y = u * u * A.y + 2 * u * p.t * k.y + p.t * p.t * B.y, s = Math.sin(p.t * Math.PI);
          const g = ctx.createRadialGradient(x, y, 0, x, y, 9); g.addColorStop(0, rgba(col(p.L[3] || "violet"), 0.6 * s)); g.addColorStop(1, rgba(col(p.L[3] || "violet"), 0)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 9, 0, 6.3); ctx.fill();
          ctx.fillStyle = "rgba(255,255,255," + s + ")"; ctx.beginPath(); ctx.arc(x, y, 1.5, 0, 6.3); ctx.fill(); });
      }
      // centre
      const breathe = reduced() ? 1 : 0.9 + Math.sin(t * 1.4) * 0.1, R = Math.min(w, h) * (spec.coreSize || 0.16);
      let g = ctx.createRadialGradient(centre.x, centre.y, 0, centre.x, centre.y, R * 1.6 * breathe); g.addColorStop(0, "rgba(128,86,255,.42)"); g.addColorStop(0.45, "rgba(128,86,255,.12)"); g.addColorStop(1, "rgba(128,86,255,0)");
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(centre.x, centre.y, R * 1.6, 0, 6.3); ctx.fill();
      if (spec.mark) { const s = R * 0.9 / 16; ctx.save(); ctx.translate(centre.x - 16 * s, centre.y - 16 * s); ctx.scale(s, s);
        const metal = ctx.createLinearGradient(16, 3, 16, 29); CHROME.forEach(([o, c]) => metal.addColorStop(o, c)); ctx.fillStyle = metal; MARK_PATHS.forEach((d) => ctx.fill(new Path2D(d)));
        const sheen = ctx.createLinearGradient(5, 5, 27, 27); sheen.addColorStop(0.38, "rgba(255,255,255,0)"); sheen.addColorStop(0.5, "rgba(255,255,255,0.6)"); sheen.addColorStop(0.62, "rgba(255,255,255,0)");
        ctx.fillStyle = sheen; MARK_PATHS.forEach((d) => ctx.fill(new Path2D(d))); ctx.restore(); }
      else {
        ctx.strokeStyle = "rgba(198,181,255,.5)"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(centre.x, centre.y, R * 0.62, 0, 6.3); ctx.stroke();
        ctx.fillStyle = "rgba(8,9,13,.85)"; ctx.beginPath(); ctx.arc(centre.x, centre.y, R * 0.6, 0, 6.3); ctx.fill();
        if (centre.value !== undefined) { ctx.fillStyle = "#f8f8fb"; ctx.textAlign = "center"; ctx.textBaseline = "alphabetic"; ctx.font = "500 " + Math.max(15, R * 0.44).toFixed(0) + "px Geist, sans-serif"; ctx.fillText(String(centre.value), centre.x, centre.y + R * 0.1); }
        if (centre.label) { ctx.fillStyle = "#8e909d"; ctx.textAlign = "center"; ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillText(String(centre.label).toUpperCase(), centre.x, centre.y + R * 0.1 + 16); }
      }
      // nodes and labels
      nodes.forEach((n) => { const c = col(n.tone), me = hover === n;
        if (n.tone !== "muted") { g = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r * 3.2); g.addColorStop(0, rgba(c, me ? 0.5 : 0.28)); g.addColorStop(1, rgba(c, 0)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(n.x, n.y, n.r * 3.2, 0, 6.3); ctx.fill(); }
        ctx.fillStyle = n.tone === "muted" ? "rgba(255,255,255,.25)" : c; ctx.beginPath(); ctx.arc(n.x, n.y, me ? n.r + 1.5 : n.r, 0, 6.3); ctx.fill();
        if (n.ring_outline) { ctx.strokeStyle = rgba(c, 0.6); ctx.beginPath(); ctx.arc(n.x, n.y, n.r + 4, 0, 6.3); ctx.stroke(); }
      });
      // labels last, each on a soft backing, so no link, signal or glow ever runs through the text
      nodes.forEach((n) => { if (!n.lab) return; const me = hover === n, L = n.lab, bh = L.t2 ? 30 : 17;
        ctx.fillStyle = "rgba(8,9,13,.66)"; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(L.x - 4, L.y - 2, L.w + 8, bh, 4); else ctx.rect(L.x - 4, L.y - 2, L.w + 8, bh); ctx.fill();
        ctx.textAlign = "left"; ctx.textBaseline = "top"; ctx.font = "500 11.5px Geist, sans-serif"; ctx.fillStyle = me ? "#fff" : "rgba(248,248,251,.9)"; ctx.fillText(L.t1, L.x, L.y);
        if (L.t2) { ctx.font = "500 10px 'Geist Mono', monospace"; ctx.fillStyle = "rgba(142,144,157,.95)"; ctx.fillText(L.t2, L.x, L.y + 15); } });
      if (running) raf = requestAnimationFrame(frame);
    }
    const start = () => { if (running || reduced()) { if (!running) frame(performance.now()); return; } running = true; raf = requestAnimationFrame(frame); };
    const stopRun = () => { running = false; cancelAnimationFrame(raf); };
    const ro = new ResizeObserver(() => { layout(); if (!running) frame(performance.now()); }); ro.observe(host);
    const io = new IntersectionObserver((es) => es.forEach((e) => (e.isIntersecting && !document.hidden ? start() : stopRun()))); io.observe(host);
    const vis = () => (document.hidden ? stopRun() : start()); document.addEventListener("visibilitychange", vis);
    const pick = (e) => { const r = host.getBoundingClientRect(), k = host.clientWidth / r.width || 1, x = (e.clientX - r.left) * k, y = (e.clientY - r.top) * k; let best = null, bd = 20; nodes.forEach((n) => { const d = Math.hypot(n.x - x, n.y - y); if (d < bd) { bd = d; best = n; } }); return { best, x, y }; };
    host.addEventListener("pointermove", (e) => { const { best, x, y } = pick(e); hover = best; host.style.cursor = best && (best.go || spec.onPick) ? "pointer" : "";
      if (best) { tip.innerHTML = "<b>" + esc(best.label) + "</b>" + (best.sub ? esc(best.sub) : "") + (best.detail ? "<br>" + esc(best.detail) : "") + (best.go ? '<br><span style="color:var(--v200)">Click to open</span>' : ""); tip.dataset.show = "";
        const tw = tip.offsetWidth || 200; tip.style.left = Math.min(Math.max(8, x + 16), host.clientWidth - tw - 8) + "px"; tip.style.top = Math.max(8, y - 20) + "px"; } else delete tip.dataset.show;
      if (!running) frame(performance.now()); });
    host.addEventListener("pointerleave", () => { hover = null; delete tip.dataset.show; if (!running) frame(performance.now()); });
    host.addEventListener("click", (e) => { const { best } = pick(e); if (!best) return; if (spec.onPick) spec.onPick(best); else if (best.go) go(best.go); });
    layout(); frame(performance.now());
    const stop = () => { stopRun(); ro.disconnect(); io.disconnect(); document.removeEventListener("visibilitychange", vis); };
    S.stops.push(stop); return stop;
  }
  const stopViz = () => { S.stops.forEach((f) => { try { f(); } catch (e) { /* already stopped */ } }); S.stops = []; };

  // ================================================================ tailored charts (SVG): each one answers one question
  const TODAY = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
  const localKey = (d) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  // "When did the work happen?" A calendar of the last `weeks` weeks, one square per day, darker for busier days.
  function heatCalendar(entries, { weeks = 13, unit = "actions" } = {}) {
    const counts = {}; entries.forEach((e) => { const d = dateOf(e.date || e.at || e.completed_at || e.day); if (d) { const k = localKey(d); counts[k] = (counts[k] || 0) + num(e.value ?? 1); } });
    const end = TODAY(), start = new Date(end); start.setDate(end.getDate() - (weeks * 7 - 1) - ((end.getDay() + 6) % 7 === 6 ? 0 : 0));
    start.setDate(start.getDate() - ((start.getDay() + 6) % 7));                       // back to a Monday
    const vals = Object.values(counts), max = Math.max(1, ...vals), C = 14, G = 3, L = 30, T = 18;
    let out = "", d = new Date(start), col = 0, lastMonth = -1, total = 0, active = 0;
    while (d <= end) {
      const row = (d.getDay() + 6) % 7, k = localKey(d), v = counts[k] || 0, x = L + col * (C + G), y = T + row * (C + G);
      if (row === 0 && d.getMonth() !== lastMonth) { lastMonth = d.getMonth(); out += '<text x="' + x + '" y="11">' + d.toLocaleDateString("en-GB", { month: "short" }) + "</text>"; }
      const a = v ? 0.22 + 0.78 * Math.sqrt(v / max) : 0;
      out += '<rect x="' + x + '" y="' + y + '" width="' + C + '" height="' + C + '" rx="3" fill="' + (v ? "rgba(164,119,255," + a.toFixed(2) + ")" : "rgba(255,255,255,.05)") + '"' + (k === localKey(end) ? ' stroke="#c6b5ff" stroke-width="1.2"' : "") + "><title>" + esc(d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" }) + ": " + fmtN(v) + " " + unit) + "</title></rect>";
      total += v; if (v) active++;
      if (row === 6) col++; d.setDate(d.getDate() + 1);
    }
    ["Mon", "Wed", "Fri"].forEach((l, i) => { out += '<text x="0" y="' + (T + (i * 2) * (C + G) + 11) + '">' + l + "</text>"; });
    const W = L + (col + 1) * (C + G);
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + (T + 7 * (C + G)) + '" style="max-width:' + W * 1.6 + 'px">' + out + "</svg>" +
      '<div class="xp-legend"><span><b>' + fmtN(total) + "</b> " + esc(unit) + " in " + weeks + " weeks</span><span><b>" + fmtN(active) + "</b> active days</span><span>Less <i style=\"background:rgba(255,255,255,.05)\"></i><i style=\"background:rgba(164,119,255,.35)\"></i><i style=\"background:rgba(164,119,255,.7)\"></i><i style=\"background:#a477ff\"></i> More</span></div>";
  }
  // "How much of the promised value became real?" Estimated, then observed, then verified, each as a share of the first.
  function valueFlow(parts, { cur = "GBP" } = {}) {
    const P = parts.filter((p) => p), base = Math.max(1e-9, ...P.map((p) => num(p.value))), W = 640, row = 46; let out = "";
    P.forEach((p, i) => { const w = Math.max(4, (num(p.value) / base) * (W - 230)), y = i * row + 6;
      out += '<text x="0" y="' + (y + 20) + '" style="fill:#b7b8c2;font:500 12.5px var(--font)">' + esc(p.label) + "</text>" +
        '<rect x="150" y="' + y + '" width="' + (W - 230) + '" height="24" rx="6" fill="rgba(255,255,255,.04)"/>' +
        '<rect x="150" y="' + y + '" width="' + w.toFixed(1) + '" height="24" rx="6" fill="' + tone(p.color || "violet") + '" opacity=".9"><title>' + esc(p.label + ": " + money(p.value, cur)) + "</title></rect>" +
        '<text x="' + (158 + w).toFixed(1) + '" y="' + (y + 17) + '" style="fill:#f8f8fb;font:500 12.5px var(--font)">' + esc(money(p.value, cur)) + "</text>" +
        (i ? '<text x="' + (W - 4) + '" y="' + (y + 17) + '" text-anchor="end" style="fill:' + tone(p.color || "violet") + '">' + esc(pct(num(p.value) / base)) + " of " + esc(P[0].label.toLowerCase()) + "</text>" : "");
      if (i) out += '<path d="M150 ' + (y - 16) + " v10" + '" stroke="rgba(255,255,255,.18)"/>'; });
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + (P.length * row + 6) + '">' + out + "</svg>";
  }
  // "What moved, and which way?" One bar per measure from zero: right is up, left is down, sized by percent change.
  function changeBars(items, { row = 34, fs = 12.5 } = {}) {
    const I = items.filter((x) => x.change !== null && x.change !== undefined && isFinite(x.change));
    if (!I.length) return empty("No change measured yet", "A measure needs two dated values to show a change.");
    const W = 640, mid = 380, span = W - mid - 70, mx = Math.max(1, ...I.map((x) => Math.abs(x.change))); let out = '<line class="xp-ax" x1="' + mid + '" x2="' + mid + '" y1="0" y2="' + I.length * row + '"/>';
    I.forEach((x, i) => { const w = (Math.abs(x.change) / mx) * Math.min(span, mid - 190), y = i * row + 6 + (row - 34) / 2, up = x.change >= 0, c = up ? "#4fd69c" : "#f2c46b";
      out += '<text x="0" y="' + (y + 16) + '" style="fill:#e3e4ea;font:500 ' + fs + 'px var(--font)">' + esc(String(x.label).slice(0, 26)) + "</text>" +
        '<rect x="' + (up ? mid : mid - w).toFixed(1) + '" y="' + (y + 3) + '" width="' + Math.max(2, w).toFixed(1) + '" height="16" rx="4" fill="' + c + '" opacity=".85"><title>' + esc(x.label + ": " + (x.detail || "")) + "</title></rect>" +
        '<text x="' + (up ? mid + w + 8 : mid - w - 8).toFixed(1) + '" y="' + (y + 16) + '" text-anchor="' + (up ? "start" : "end") + '" style="fill:' + c + ";font:600 " + (fs - 1) + 'px var(--mono)">' + (up ? "+" : "") + fmtN(x.change, 1) + "%</text>"; });
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + (I.length * row + 8) + '">' + out + "</svg>";
  }
  // "How fast is each route, for most people and for the slowest?" p50 to p99 on a log scale, with the Apdex target.
  function latencyStrips(rows, { target = 500 } = {}) {
    const R = rows.filter((r) => r.p50 !== null && r.p50 !== undefined);
    if (!R.length) return empty("No latency measured yet");
    const W = 640, L = 250, row = 30, lo = Math.log10(1), hi = Math.log10(10000), X = (ms) => L + ((Math.log10(Math.max(1, Math.min(10000, ms))) - lo) / (hi - lo)) * (W - L - 12);
    let out = [1, 10, 100, 1000, 10000].map((t) => '<line class="xp-ax" x1="' + X(t).toFixed(1) + '" x2="' + X(t).toFixed(1) + '" y1="14" y2="' + (R.length * row + 14) + '"/><text x="' + X(t).toFixed(1) + '" y="10" text-anchor="middle">' + (t >= 1000 ? t / 1000 + " s" : t + " ms") + "</text>").join("");
    out += '<line x1="' + X(target).toFixed(1) + '" x2="' + X(target).toFixed(1) + '" y1="14" y2="' + (R.length * row + 14) + '" stroke="#f2c46b" stroke-dasharray="3 3" opacity=".7"/>';
    R.forEach((r, i) => { const y = 14 + i * row + row / 2, c = num(r.p95) > target ? "#f2c46b" : num(r.err) > 0 ? "#ff5c6c" : "#a477ff";
      out += '<text x="0" y="' + (y + 4) + '" style="fill:#b7b8c2;font:500 11.5px var(--mono)">' + esc(String(r.label).slice(0, 34)) + "</text>" +
        '<line x1="' + X(r.p50).toFixed(1) + '" x2="' + X(r.p99 ?? r.p95).toFixed(1) + '" y1="' + y + '" y2="' + y + '" stroke="' + c + '" stroke-width="3" stroke-linecap="round" opacity=".45"/>' +
        '<rect x="' + (X(r.p95) - 1.5).toFixed(1) + '" y="' + (y - 7) + '" width="3" height="14" rx="1.5" fill="' + c + '"/>' +
        '<circle cx="' + X(r.p50).toFixed(1) + '" cy="' + y + '" r="4.5" fill="#f8f8fb"><title>' + esc(r.label + " · p50 " + fmtN(r.p50) + " ms · p95 " + fmtN(r.p95) + " ms · p99 " + fmtN(r.p99) + " ms") + "</title></circle>"; });
    return '<svg class="xp-chart" viewBox="0 0 ' + W + " " + (R.length * row + 20) + '">' + out + '</svg><div class="xp-legend"><span><i style="background:#f8f8fb;border-radius:50%"></i>p50 (typical)</span><span><i style="background:#a477ff"></i>p95</span><span><i style="background:rgba(164,119,255,.45)"></i>up to p99 (slowest 1%)</span><span><i style="background:#f2c46b"></i>Apdex target ' + target + " ms</span></div>";
  }

  // ================================================================ canvas: a stage for the tailored animated visuals
  // Fills its host at full resolution, redraws on resize, animates only while visible and on screen (one still frame
  // with reduced motion), and shows a tooltip for whatever hit(x, y) returns. Stopped with the page like the others.
  function stage(host, draw, { hit = null, click = null } = {}) {
    if (!host) return null;
    const canvas = document.createElement("canvas"); canvas.setAttribute("aria-hidden", "true"); host.appendChild(canvas);
    const tip = document.createElement("div"); tip.className = "xp-viz-tip"; host.appendChild(tip);
    const ctx = canvas.getContext("2d"), st = { w: 0, h: 0, t: 0, dt: 0.016, hover: null };
    let raf = 0, running = false, last = performance.now(); const t0 = last;
    const size = () => { const box = host.getBoundingClientRect(); st.w = Math.max(10, host.clientWidth); st.h = Math.max(10, host.clientHeight);
      const dpr = Math.min(2.5, (window.devicePixelRatio || 1) * (box.width / st.w || 1)); canvas.width = Math.round(st.w * dpr); canvas.height = Math.round(st.h * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    const frame = (now) => { st.dt = Math.min(0.05, (now - last) / 1000 || 0.016); last = now; st.t = (now - t0) / 1000; ctx.clearRect(0, 0, st.w, st.h); draw(ctx, st); if (running) raf = requestAnimationFrame(frame); };
    const start = () => { if (running) return; if (reduced()) { frame(performance.now()); return; } running = true; last = performance.now(); raf = requestAnimationFrame(frame); };
    const stopRun = () => { running = false; cancelAnimationFrame(raf); };
    const ro = new ResizeObserver(() => { size(); if (!running) frame(performance.now()); }); ro.observe(host);
    const io = new IntersectionObserver((es) => es.forEach((e) => (e.isIntersecting && !document.hidden ? start() : stopRun()))); io.observe(host);
    const vis = () => (document.hidden ? stopRun() : start()); document.addEventListener("visibilitychange", vis);
    const pos = (e) => { const r = host.getBoundingClientRect(), k = host.clientWidth / r.width || 1; return [(e.clientX - r.left) * k, (e.clientY - r.top) * k]; };
    if (hit) {
      host.addEventListener("pointermove", (e) => { const [x, y] = pos(e), h = hit(x, y, st); st.hover = h; host.style.cursor = h && click ? "pointer" : "";
        if (h) { tip.innerHTML = h.html; tip.dataset.show = ""; const tw = tip.offsetWidth || 200; tip.style.left = Math.min(Math.max(8, x + 16), st.w - tw - 8) + "px"; tip.style.top = Math.max(8, y - 24) + "px"; } else delete tip.dataset.show;
        if (!running) frame(performance.now()); });
      host.addEventListener("pointerleave", () => { st.hover = null; delete tip.dataset.show; if (!running) frame(performance.now()); });
      if (click) host.addEventListener("click", (e) => { const [x, y] = pos(e), h = hit(x, y, st); if (h) click(h); });
    }
    size(); frame(performance.now());
    S.stops.push(() => { stopRun(); ro.disconnect(); io.disconnect(); document.removeEventListener("visibilitychange", vis); });
    return st;
  }
  // a text label on a soft backing (so lines and particles never run through words); returns its box
  function pill(ctx, text, x, y, { align = "center", font = "500 11.5px Geist, sans-serif", fg = "rgba(248,248,251,.94)", bg = "rgba(8,9,13,.74)" } = {}) {
    ctx.font = font; const w = ctx.measureText(text).width + 12, h = 19, x0 = align === "center" ? x - w / 2 : align === "right" ? x - w : x;
    ctx.fillStyle = bg; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x0, y - h / 2, w, h, 6); else ctx.rect(x0, y - h / 2, w, h); ctx.fill();
    ctx.fillStyle = fg; ctx.textAlign = "left"; ctx.textBaseline = "middle"; ctx.fillText(text, x0 + 6, y + 0.5); return { x0, x1: x0 + w };
  }
  const rgbaOf = (hex, a) => { const n = parseInt(String(hex).slice(1), 16); return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")"; };

  // The flow river: a pipeline drawn the way it behaves. Each stage is a column sized by its count; a ribbon carries
  // what continues to the next stage, labelled with its conversion rate, and a fainter ribbon peels away for what
  // dropped out. Particles travel the ribbons in proportion to the volume, so where work piles up or leaks shows at a glance.
  function flowRiver(host, { stages = [], color = "violet", unit = "", onPick = null, rates = true } = {}) {  // rates:false for lifecycles that are not funnels
    const SG = stages.map((s) => ({ ...s, value: Math.max(0, num(s.value)) })), n = SG.length; if (!host || !n) return;
    const c = tone(color), max = Math.max(1, ...SG.map((s) => s.value)), first = Math.max(1, SG[0].value);
    let parts = [];
    const geo = (st) => { const top = 54, bot = 50, H = Math.max(30, st.h - top - bot), padX = 30;
      return SG.map((s, i) => { const x = n === 1 ? st.w / 2 : padX + i * ((st.w - padX * 2) / (n - 1)), hh = s.value ? Math.max(5, Math.sqrt(s.value / max) * H) : 2; return { ...s, i, x, hh, y0: top + (H - hh) / 2, cy: top + H / 2 }; }); };
    const bez = (x0, y0, x1, y1, t) => { const u = 1 - t, mx = (x0 + x1) / 2; return [u * u * u * x0 + 3 * u * u * t * mx + 3 * u * t * t * mx + t * t * t * x1, u * u * u * y0 + 3 * u * u * t * y0 + 3 * u * t * t * y1 + t * t * t * y1]; };
    const band = (ctx, x0, a0, a1, x1, b0, b1, fill) => { const mx = (x0 + x1) / 2; ctx.beginPath(); ctx.moveTo(x0, a0); ctx.bezierCurveTo(mx, a0, mx, b0, x1, b0); ctx.lineTo(x1, b1); ctx.bezierCurveTo(mx, b1, mx, a1, x0, a1); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); };
    const st = stage(host, (ctx, st) => {
      const g = geo(st), narrow = n > 1 && (st.w - 60) / (n - 1) < 118;
      for (let i = 0; i < n - 1; i++) { const a = g[i], b = g[i + 1], keep = Math.min(a.hh, b.hh), x0 = a.x + 5, x1 = b.x - 5;
        const grad = ctx.createLinearGradient(x0, 0, x1, 0); grad.addColorStop(0, rgbaOf(c, 0.34)); grad.addColorStop(1, rgbaOf(c, 0.22));
        band(ctx, x0, a.y0, a.y0 + keep, x1, b.y0, b.y0 + b.hh, grad);
        if (rates && a.hh - keep > 1.5) { const dg = ctx.createLinearGradient(0, a.y0 + keep, 0, st.h); dg.addColorStop(0, "rgba(255,255,255,.10)"); dg.addColorStop(1, "rgba(255,255,255,0)");
          band(ctx, x0, a.y0 + keep, a.y0 + a.hh, (x0 + x1) / 2, st.h - 8, st.h - 6, dg); } }
      if (!reduced()) {                                                      // particles: more where more flows
        for (let i = 0; i < n - 1; i++) if (g[i].value && Math.random() < 0.05 + 0.25 * (g[i].value / max)) parts.push({ i, t: 0, off: Math.random(), drop: rates && Math.random() > (g[i + 1].value / Math.max(1, g[i].value)), v: 0.25 + Math.random() * 0.25 });
        parts = parts.filter((p) => (p.t += st.dt * p.v) < 1).slice(-260);
        parts.forEach((p) => { const a = g[p.i], b = g[p.i + 1], keep = Math.min(a.hh, b.hh); let x, y;
          if (p.drop && a.hh - keep > 1.5) { [x, y] = bez(a.x + 5, a.y0 + keep + p.off * (a.hh - keep), (a.x + b.x) / 2, st.h - 8, p.t); ctx.fillStyle = "rgba(255,255,255," + (0.5 * (1 - p.t)).toFixed(2) + ")"; }
          else { [x, y] = bez(a.x + 5, a.y0 + p.off * keep, b.x - 5, b.y0 + p.off * b.hh, p.t); ctx.fillStyle = rgbaOf(c, 0.9 * Math.sin(p.t * Math.PI)); }
          ctx.beginPath(); ctx.arc(x, y, 1.7, 0, 6.3); ctx.fill(); }); }
      g.forEach((s, i) => { const me = st.hover && st.hover.i === i;                          // the stage columns
        const cg = ctx.createLinearGradient(0, s.y0, 0, s.y0 + s.hh); cg.addColorStop(0, "#f8f8fb"); cg.addColorStop(1, c);
        ctx.shadowColor = rgbaOf(c, me ? 0.9 : 0.5); ctx.shadowBlur = me ? 22 : 12; ctx.fillStyle = s.value ? cg : "rgba(255,255,255,.18)";
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(s.x - 5, s.y0, 10, s.hh, 5); else ctx.rect(s.x - 5, s.y0, 10, s.hh); ctx.fill(); ctx.shadowBlur = 0;
        const al = i === 0 ? "left" : i === n - 1 ? "right" : "center", ax = i === 0 ? s.x - 6 : i === n - 1 ? s.x + 6 : s.x;
        const label = narrow && String(s.label).length > 14 ? String(s.label).split(" ")[0] : String(s.label);
        pill(ctx, label, ax, narrow && i % 2 ? 36 : 16, { align: al });
        pill(ctx, s.text ?? fmtN(s.value) + (unit ? " " + unit : ""), ax, st.h - (narrow && i % 2 ? 36 : 16), { align: al, font: "600 12.5px Geist, sans-serif" }); });
      if (rates) for (let i = 0; i < n - 1; i++) { const a = g[i], b = g[i + 1]; if (!a.value) continue;             // conversion between stages
        pill(ctx, pct(b.value / a.value), (a.x + b.x) / 2, (a.y0 + Math.min(a.hh, b.hh) / 2 + b.y0 + b.hh / 2) / 2, { font: "500 10.5px 'Geist Mono', monospace", fg: "#c6b5ff" }); }
    }, { hit: (x, y, st) => { const g = geo(st); let best = null, bd = 1e9; g.forEach((s) => { const d = Math.abs(s.x - x); if (d < bd) { bd = d; best = s; } });
        if (!best || bd > Math.max(40, st.w / n / 2)) return null; const prev = best.i ? g[best.i - 1] : null;
        return { i: best.i, stage: best, html: "<b>" + esc(best.label) + "</b>" + esc(best.text ?? fmtN(best.value) + (unit ? " " + unit : "")) + (rates && prev && prev.value ? "<br>" + esc(pct(best.value / prev.value, 1) + " of " + String(prev.label).toLowerCase()) : "") + (rates && best.i && first ? "<br>" + esc(pct(best.value / first, 1) + " of " + String(SG[0].label).toLowerCase()) : "") + (best.detail ? "<br>" + esc(best.detail) : "") }; },
      click: onPick ? (h) => onPick(h.stage) : null });
    return st;
  }

  // The response clock: every request placed on a dial by how long it has waited, against the response target. The
  // arc is green within target, amber approaching it and red once overdue; answered requests sit on the inner ring.
  function slaDial(host, { items = [], targetHours = 24, centre = {}, onPick = null } = {}) {
    if (!host) return;
    // the first half of the dial is the response target; the second half compresses everything older (log scale) up to
    // 30 days, so fresh and stale requests both have a readable place
    const I = items.map((x) => ({ ...x, age: Math.max(0, num(x.age)) })), T = Math.max(1, targetHours), maxH = Math.max(T * 2, Math.min(24 * 30, Math.max(...I.map((x) => x.age), T * 7)));
    const frac = (h) => (h <= T ? 0.5 * h / T : 0.5 + 0.5 * Math.min(1, Math.log1p((h - T) / T) / Math.log1p((maxH - T) / T)));
    const ang = (h) => -Math.PI / 2 + frac(Math.min(h, maxH)) * Math.PI * 2 * 0.985;
    const place = (st) => { const cx = st.w / 2, cy = st.h / 2, R = Math.max(40, Math.min(st.w, st.h) / 2 - 36);
      return { cx, cy, R, dots: I.map((x, k) => { const a = ang(x.age) + ((k % 5) - 2) * 0.012, r = x.done ? R * 0.62 : R - 12 - (k % 3) * 7; return { ...x, x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r }; }) }; };
    stage(host, (ctx, st) => {
      const { cx, cy, R, dots } = place(st), zones = [[0, targetHours * 0.75, "#4fd69c"], [targetHours * 0.75, targetHours, "#f2c46b"], [targetHours, maxH, "#ff5c6c"]];
      ctx.lineWidth = 10; ctx.lineCap = "butt"; ctx.strokeStyle = "rgba(255,255,255,.05)"; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 6.3); ctx.stroke();
      zones.forEach(([a, b, col], z) => { if (b <= a) return; ctx.strokeStyle = rgbaOf(col, z === 2 ? 0.32 : 0.5); ctx.beginPath(); ctx.arc(cx, cy, R, ang(a), ang(b)); ctx.stroke(); });
      ctx.lineWidth = 1; ctx.setLineDash([2, 5]); ctx.strokeStyle = "rgba(255,255,255,.10)"; ctx.beginPath(); ctx.arc(cx, cy, R * 0.62, 0, 6.3); ctx.stroke(); ctx.setLineDash([]);
      for (const h of [0, T / 4, T / 2, T * 0.75, T, T * 2, T * 4, 24 * 7, 24 * 14, 24 * 30].filter((x) => x <= maxH)) { const a = ang(h); ctx.strokeStyle = "rgba(255,255,255,.22)"; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * (R + 7), cy + Math.sin(a) * (R + 7)); ctx.lineTo(cx + Math.cos(a) * (R + 12), cy + Math.sin(a) * (R + 12)); ctx.stroke(); }
      if (!reduced()) { const a = -Math.PI / 2 + (st.t * 0.5) % (Math.PI * 2), sw = ctx.createLinearGradient(cx, cy, cx + Math.cos(a) * R, cy + Math.sin(a) * R); sw.addColorStop(0, "rgba(198,181,255,0)"); sw.addColorStop(1, "rgba(198,181,255,.35)");
        ctx.strokeStyle = sw; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * (R - 4), cy + Math.sin(a) * (R - 4)); ctx.stroke(); }
      dots.forEach((d) => { const col = d.overdue ? "#ff5c6c" : d.done ? "#4fd69c" : d.age > targetHours * 0.75 ? "#f2c46b" : "#8fb3ff", me = st.hover && st.hover.d === d;
        const gl = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, me ? 16 : 11); gl.addColorStop(0, rgbaOf(col, 0.55)); gl.addColorStop(1, rgbaOf(col, 0)); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(d.x, d.y, me ? 16 : 11, 0, 6.3); ctx.fill();
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(d.x, d.y, me ? 5 : 3.6, 0, 6.3); ctx.fill(); });
      ctx.fillStyle = "rgba(8,9,13,.9)"; ctx.beginPath(); ctx.arc(cx, cy, R * 0.34, 0, 6.3); ctx.fill(); ctx.strokeStyle = "rgba(198,181,255,.35)"; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = "#f8f8fb"; ctx.textAlign = "center"; ctx.textBaseline = "alphabetic"; ctx.font = "500 " + Math.max(16, R * 0.2).toFixed(0) + "px Geist, sans-serif"; ctx.fillText(String(centre.value ?? ""), cx, cy + R * 0.04);
      ctx.fillStyle = "#8e909d"; ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillText(String(centre.label || "").toUpperCase(), cx, cy + R * 0.04 + 15);
      pill(ctx, "0 h", cx, cy - R - 24, { font: "500 10px 'Geist Mono', monospace", fg: "#b7b8c2" });
      const oa = ang(maxH); pill(ctx, maxH >= 48 ? Math.round(maxH / 24) + " d+" : Math.round(maxH) + " h", cx + Math.cos(oa) * (R + 26) - 26, cy + Math.sin(oa) * (R + 22), { font: "500 10px 'Geist Mono', monospace", fg: "#ff8f9a" });
      const ta = ang(targetHours); pill(ctx, "target " + targetHours + " h", cx + Math.cos(ta) * (R + 26), cy + Math.sin(ta) * (R + 22), { font: "500 10px 'Geist Mono', monospace", fg: "#f2c46b" });
    }, { hit: (x, y, st) => { const { dots } = place(st); let best = null, bd = 12; dots.forEach((d) => { const dd = Math.hypot(d.x - x, d.y - y); if (dd < bd) { bd = dd; best = d; } });
        return best ? { d: best, html: "<b>" + esc(best.label) + "</b>" + esc((best.done ? "Answered · " : best.overdue ? "Overdue · " : "Waiting · ") + (best.age < 1 ? Math.round(best.age * 60) + " min" : fmtN(best.age, best.age < 10 ? 1 : 0) + " h") + " since it arrived") + (best.sub ? "<br>" + esc(best.sub) : "") } : null; },
      click: onPick ? (h) => onPick(h.d) : null });
  }

  // ================================================================ overlays: drawer, dialog, toast
  function toast(message, t = "violet", ms = 4200) {
    const box = $("xpToasts"); if (!box) return; const el = document.createElement("div"); el.className = "xp-toast"; el.dataset.tone = t; el.innerHTML = "<i></i><span>" + esc(message) + "</span>"; box.appendChild(el);
    setTimeout(() => el.remove(), ms);
  }
  function overlay(html, cls, onClose) {
    const scrim = document.createElement("div"); scrim.className = "xp-scrim"; const el = document.createElement("div"); el.className = cls; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.innerHTML = html;
    const layer = S.root.querySelector(".xp") || S.root; layer.appendChild(scrim); layer.appendChild(el);
    let closed = false; const close = () => { if (closed) return; closed = true; scrim.remove(); el.remove(); document.removeEventListener("keydown", onKey); if (onClose) onClose(); };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } }; document.addEventListener("keydown", onKey); scrim.addEventListener("click", close);
    return { el, close };
  }
  // A side sheet for forms and details. submit(values, el) may throw; the drawer stays open and shows the error.
  function drawer({ title, sub = "", body, submit = null, submitLabel = "Save", submitTone = "primary", secondary = "" }) {
    const o = overlay('<header><div><h3>' + esc(title) + "</h3>" + (sub ? "<p>" + esc(sub) + "</p>" : "") + '</div><button class="xp-iconbtn" type="button" data-x="close" aria-label="Close">' + icon("close") + '</button></header><div class="xp-drawer-b">' + body + '<p class="xp-err" data-x="err" role="alert"></p></div>' +
      "<footer>" + secondary + '<button type="button" class="xp-btn xp-btn--ghost" data-x="close">' + (submit ? "Cancel" : "Close") + "</button>" + (submit ? '<button type="button" class="xp-btn xp-btn--' + submitTone + '" data-x="submit">' + esc(submitLabel) + "</button>" : "") + "</footer>", "xp-drawer");
    const err = o.el.querySelector('[data-x="err"]');
    o.el.addEventListener("click", async (e) => { const b = e.target.closest("[data-x]"); if (!b) return;
      if (b.dataset.x === "close") o.close();
      if (b.dataset.x === "submit" && submit && !b.dataset.busy) { b.dataset.busy = ""; err.textContent = ""; try { const r = await submit(collect(o.el), o.el); if (r !== false) o.close(); } catch (x) { err.textContent = x.message || String(x); } finally { delete b.dataset.busy; } } });
    setTimeout(() => { const f = o.el.querySelector("input:not([readonly]),select,textarea"); if (f) f.focus(); }, 60);
    return o;
  }
  function ask({ title, text = "", confirm = "Confirm", t = "primary", fields = "" }) {
    return new Promise((resolve) => {
      const o = overlay("<h3>" + esc(title) + "</h3>" + (text ? "<p>" + esc(text) + "</p>" : "") + (fields ? '<div class="xp-form" style="margin-top:16px">' + fields + "</div>" : "") + '<p class="xp-err" data-x="err"></p><div class="xp-card-f"><button type="button" class="xp-btn xp-btn--ghost" data-x="no">Cancel</button><button type="button" class="xp-btn xp-btn--' + t + '" data-x="yes">' + esc(confirm) + "</button></div>", "xp-dialog", () => resolve(null));
      const done = (v) => { resolve(v); o.close(); };
      o.el.addEventListener("click", (e) => { const b = e.target.closest("[data-x]"); if (!b) return; if (b.dataset.x === "no") done(null); if (b.dataset.x === "yes") done(collect(o.el)); });
      setTimeout(() => { const f = o.el.querySelector("input,textarea,select") || o.el.querySelector('[data-x="yes"]'); if (f) f.focus(); }, 40);
    });
  }

/* Xevrion customer portal (/app).
   Environment-agnostic: XevrionPortal.boot(root, {api, demo}) renders the whole portal into `root`. In production the
   api is fetch with the CSRF header (XevrionPortal.fetchApi()); on the website's presentation page it is an
   illustrative in-memory API. Every figure on screen comes from the API; nothing here invents data.
   No inline handlers: one delegated listener reads data-go / data-act; data-click is left to the page's nonce'd
   dispatcher (portal_security.py) for signin() and logout().
   Built together with kit.js (the shared machinery) by scripts/build_portal_ui.py. */
  const P = (window.XevrionPortal = window.XevrionPortal || {});

  // browser storage is used only for the chosen organisation and the notifications you have seen
  const store = { get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } } };
  // ================================================================ services and their actions (form definitions)
  const MODULES = {
    revenue: { id: "revenue", label: "Revenue", verb: "Sell", icon: "revenue", color: "#a477ff" },
    customer_operations: { id: "customer_operations", label: "Customer Operations", verb: "Deliver", icon: "customers", color: "#7fd1ff" },
    business_operations: { id: "business_operations", label: "Business Operations", verb: "Run", icon: "operations", color: "#e9e9ef" },
    business_intelligence: { id: "business_intelligence", label: "Decision Intelligence", verb: "Decide", icon: "decisions", color: "#7b8cff" },
  };
  const MODULE_IDS = Object.keys(MODULES);
  const modLabel = (m) => (MODULES[m] ? MODULES[m].label : cap(m));
  const CONFIGS = {
    revenue: { title: "Revenue programme", intro: "Set the customer profile and approved programme once, then create and run the service from this workspace.", actions: [
      ["create_program", "Create programme", "Define who you sell to, the approved offer and a daily limit.", "Programme name|name|text,Target market or industry|market|text,Customer problem|problem|textarea,Decision-maker role|decision_maker_role|text,Approved offer|offer|textarea,Value proposition|value_proposition|textarea,Proof or evidence|proof|textarea,Target geography|geography|text,Daily send limit|daily_limit|number"],
      ["list_programs", "View programmes", "See every programme recorded for this organisation.", ""],
      ["ingest_prospects", "Add prospects", "Add prospects to a programme, one email address per line.", "Programme ID|program_id|text,Prospect email addresses (one per line)|prospect_emails|textarea"],
      ["status", "Check programme status", "See where a programme is and what it has done.", "Programme ID|program_id|text"],
      ["start", "Start programme", "Begin authorised outreach for a programme.", "Programme ID|program_id|text"],
      ["pause", "Pause programme", "Hold a programme without losing its state.", "Programme ID|program_id|text"],
      ["cycle", "Run authorised cycle", "Run one authorised cycle of research and messages.", "Programme ID|program_id|text"],
      ["stop", "Stop programme", "End a programme; its records are kept.", "Programme ID|program_id|text"]] },
    customer_operations: { title: "Customer operations", intro: "Bring support, account context, risk and growth work into one customer operating record.", actions: [
      ["customer_360", "Build customer view", "Join everything recorded about one customer.", "Customer ID|customer_id|text"],
      ["support_intake", "Record support request", "Record a customer request so it can be resolved and measured.", "Customer ID|customer_id|text,Request|message|textarea"],
      ["resolve", "Resolve customer request", "Resolve a recorded support case.", "Case ID from a recorded support receipt|case_id|text,Account value|account_value|number"],
      ["confirm", "Confirm resolution", "Record the customer's confirmation.", "Case ID|case_id|text,Confirmation note|note|textarea"],
      ["health", "Assess customer health", "Score usage, adoption and support into one health view.", "Customer ID|customer_id|text,Usage score 0 to 1|usage|number,Adoption score 0 to 1|adoption|number,Support score 0 to 1|support|number"],
      ["success", "Assess success plan", "Measure progress against the customer's own target.", "Customer ID|customer_id|text,Usage score 0 to 1|usage|number,Adoption score 0 to 1|adoption|number,Metric name|metric|text,Baseline|baseline_value|number,Current measurement|current_value|number,Target|target|number,Service cost|service_cost|number"],
      ["churn", "Assess churn risk", "See the drivers of risk before renewal.", "Customer ID|customer_id|text,Usage score 0 to 1|usage|number,Adoption score 0 to 1|adoption|number,Support score 0 to 1|support|number,Previous usage 0 to 1|previous_usage|number,Repeated problems|repeated_problems|number,Account value|account_value|number"],
      ["retention", "Prepare retention action", "Prepare an action for an at-risk customer.", "Customer ID|customer_id|text,Recorded health score 0 to 1|health_score|number,Value evidence|value_evidence|textarea"],
      ["expansion", "Identify expansion", "Assess an unmet need as a growth opportunity.", "Customer ID|customer_id|text,Unmet need|unmet_need|text,Candidate service|candidate_service|text,Estimated gross value|estimated_value|number,Estimated cost|estimated_cost|number,Usage growth|usage_growth|number,Account value|account_value|number"],
      ["feedback", "Record feedback", "Keep the customer's words with their record.", "Customer ID|customer_id|text,Feedback|feedback|textarea"]] },
    business_operations: { title: "Business operations", intro: "Map work, identify bottlenecks and turn approved opportunities into observable delivery.", actions: [
      ["discover", "Assess process", "Describe a process and its constraints to map it.", "Process name|process_name|text,Current process and constraints|context|textarea"],
      ["opportunity", "Analyse automation opportunity", "Size the time, cost and risk of automating a process.", "Process name|process_name|text,Tasks per month|frequency_per_month|number,Minutes per task|human_minutes_per_task|number,Labour cost per hour|labor_cost_per_hour|number,Error rate 0 to 1|error_rate|number,Complexity 0 to 1|complexity|number,Data availability 0 to 1|data_availability|number,AI suitability 0 to 1|ai_suitability|number,Deterministic suitability 0 to 1|deterministic_suitability|number,Risk 0 to 1|risk|number,Implementation cost|implementation_cost|number"],
      ["work", "Create work item", "Record a piece of work with its requirements.", "Work title|title|text,Requirements|description|textarea"],
      ["workflow", "Create workflow work item", "Start work from a named workflow.", "Workflow name|workflow_name|text,Workflow context|context|textarea"]] },
    business_intelligence: { title: "Decision intelligence", intro: "Use supplied business facts to diagnose performance and record decisions with their evidence. Scenarios use illustrative fixed assumptions; they are not calibrated forecasts.", actions: [
      ["ingest", "Ingest business metric", "Add a measured value for a metric.", "Metric name|metric|text,Value|value|number,Date|date|date"],
      ["kpi", "Record KPI", "Record a KPI reading.", "KPI name|metric|text,Value|value|number,Date|date|date"],
      ["analyze", "Analyse performance", "Ask a question of the business facts you supplied.", "Question and any context it needs|question|textarea"],
      ["diagnose", "Diagnose a change", "Find the likely drivers of a change in one ingested metric over the last 30 days.", "Metric name exactly as ingested|metric|text"],
      ["forecast", "Create forecast", "Forecast a metric with a stated range.", "Metric|metric|select:revenue/pipeline/cash/demand/costs/churn/ltv=Lifetime value/workload/capacity,Forecast context|context|textarea"],
      ["scenario", "Compare scenario", "Compare a scenario against the baseline.", "Scenario name|name|text,Baseline revenue|baseline_revenue|number,Baseline costs|baseline_costs|number,Price change percent|price_percent|number"],
      ["recommend", "Generate recommendation", "Generate recommendations, with their reasoning, from your organisation's recorded data.", ""],
      ["decision", "Record decision", "Record a decision, its options and evidence.", "Decision question|decision|textarea,Evidence|evidence|textarea,Option A|a_name|text,A expected benefit|a_value|number,A probability 0 to 1|a_probability|number,A cost|a_cost|number,A risk 0 to 1|a_risk|number,Option B|b_name|text,B expected benefit|b_value|number,B probability 0 to 1|b_probability|number,B cost|b_cost|number,B risk 0 to 1|b_risk|number"]] },
  };
  const fieldsOf = (spec) => (spec ? spec.split(",").map((x) => { const [label, key, type] = x.split("|"); return { label, key, type }; }) : []);
  // the plans a website link can name (/app?plan=growth#signup); the plan is kept in memory only, never in storage
  const PLAN_NAMES = { START: "Start", GROWTH: "Growth", SCALE: "Scale" };
  // "?plan=growth", "#signup" -> { plan: "GROWTH", signup: true }. A valid plan alone also means "create an account".
  function signupIntent(search, hash) {
    let q; try { q = new URLSearchParams(search || ""); } catch (e) { return { plan: "", signup: false }; }
    const p = String(q.get("plan") || "").trim().toUpperCase(), plan = Object.prototype.hasOwnProperty.call(PLAN_NAMES, p) ? p : "";
    return { plan, signup: !!plan || /^#(signup|create)$/i.test(String(hash || "")) || q.get("signup") === "1" || q.get("start") === "create" };
  }
  // once the chosen plan has been invoiced, drop it from the address so a later reload does not offer it again
  function clearPlanQuery() {
    if (S.demo) return;
    try { const q = new URLSearchParams(location.search); ["plan", "signup", "start"].forEach((k) => q.delete(k)); const s = q.toString(); history.replaceState(null, "", location.pathname + (s ? "?" + s : "") + location.hash); } catch (e) { /* history unavailable */ }
  }
  const ROLES = {
    OWNER: ["Everything, including ownership and deletion"],
    ADMIN: ["Team", "Configuration", "Connections", "Service activation"],
    OPERATOR: ["Run services", "Read configuration"],
    APPROVER: ["Decide approvals", "Read configuration"],
    ANALYST: ["Analytics", "Value ledger"],
    BILLING: ["Billing", "Usage"],
    READ_ONLY: ["Dashboard", "Value ledger"],
  };
  const PERMS = [["dashboard.read", "See the dashboard"], ["service.operate", "Run service actions"], ["approval.decide", "Decide approvals"], ["configuration.manage", "Manage setup"], ["integration.manage", "Manage connections"], ["team.manage", "Manage team"], ["billing.manage", "Manage billing"], ["analytics.read", "Read analytics"], ["value.read", "Read the value ledger"], ["usage.read", "Read usage"]];
  const ROLE_PERMS = { OWNER: ["*"], ADMIN: ["org.read", "team.manage", "configuration.manage", "integration.manage", "service.manage"], OPERATOR: ["service.operate", "configuration.read"], APPROVER: ["approval.decide", "configuration.read"], ANALYST: ["analytics.read", "value.read"], BILLING: ["billing.manage", "usage.read"], READ_ONLY: ["dashboard.read", "value.read"] };

  // ================================================================ state, api
  const S = { root: null, api: null, demo: false, org: "", orgs: [], role: "", grants: ["*"], page: "home", dash: {}, badges: {}, nav: 0, stops: [], pendingAction: null, pendingBusiness: null, busy: false, updated: null, wantPlan: "", wantSignup: false };
  const may = (p) => S.grants.includes("*") || S.grants.includes(p);
  const api = (path, options = {}) => S.api(path, options);
  const O = (p = "") => "/v1/customer/saas/" + encodeURIComponent(S.org) + p;
  const post = (path, body, headers) => api(path, { method: "POST", body: JSON.stringify(body || {}), headers: headers || {} });

  P.fetchApi = function () {
    return async function (path, options = {}) {
      const csrf = decodeURIComponent((document.cookie.split("; ").find((x) => /^(?:__Host-)?xevrion_csrf=/.test(x)) || "").split("=").slice(1).join("=") || "");
      const response = await fetch(path, { ...options, headers: { "content-type": "application/json", "x-csrf-token": csrf, ...(options.headers || {}) } });
      let body;
      try { body = await response.json(); } catch (e) { throw Error("The service returned an unreadable response. Please retry."); }
      if (!response.ok) {
        const d = body && body.detail;
        const error = Error(typeof d === "string" ? d : (d && d.message) || (Array.isArray(d) ? d.map((x) => x.msg).join("; ") : "") || "The request could not be completed.");
        error.status = response.status; throw error;
      }
      return body;
    };
  };

  // ================================================================ pages
  const PAGES = [
    { id: "home", label: "Command centre", group: "Overview", icon: "core", lead: "Everything happening in your workspace, as it happens." },
    { id: "systems", label: "Systems map", group: "Overview", icon: "map", lead: "Every system in your workspace and how work and evidence move between them." },
    { id: "revenue", label: "Revenue", group: "Services", icon: "revenue", perm: "service.operate", module: "revenue" },
    { id: "customer_operations", label: "Customer Operations", group: "Services", icon: "customers", perm: "service.operate", module: "customer_operations" },
    { id: "business_operations", label: "Business Operations", group: "Services", icon: "operations", any: ["service.operate", "approval.decide", "configuration.manage"], module: "business_operations" },
    { id: "business_intelligence", label: "Decision Intelligence", group: "Services", icon: "decisions", perm: "service.operate", module: "business_intelligence" },
    { id: "value", label: "Results & value", group: "Evidence", icon: "value", perm: "value.read" },
    { id: "optimisation", label: "Optimisation", group: "Evidence", icon: "target", perm: "analytics.read" },
    { id: "usage", label: "Usage & limits", group: "Evidence", icon: "gauge" },
    { id: "setup", label: "Setup", group: "Workspace", icon: "setup", perm: "configuration.manage" },
    { id: "connections", label: "Connections", group: "Workspace", icon: "plug", perm: "integration.manage" },
    { id: "team", label: "Team & access", group: "Workspace", icon: "team", perm: "team.manage" },
    { id: "billing", label: "Billing", group: "Workspace", icon: "card", perm: "billing.manage" },
    { id: "notifications", label: "Notifications", group: "Workspace", icon: "bell" },
    { id: "support", label: "Support", group: "Workspace", icon: "chat" },
    { id: "security", label: "Account security", group: "Account", icon: "shield" },
    { id: "data", label: "Data & closure", group: "Account", icon: "archive", perm: "configuration.manage" },
  ];
  const visible = (p) => (!p.perm || may(p.perm)) && (!p.any || p.any.some(may));
  const pageOf = (id) => PAGES.find((p) => p.id === id && visible(p));

  // ================================================================ command palette
  function palette() {
    const items = [];
    PAGES.filter(visible).forEach((p) => items.push({ label: p.label, hint: p.group, ic: p.icon, run: () => go(p.id) }));
    MODULE_IDS.forEach((m) => { const p = pageOf(m); if (!p || !may("service.operate")) return; CONFIGS[m].actions.forEach((a) => items.push({ label: a[1], hint: MODULES[m].label, ic: MODULES[m].icon, run: async () => { await go(m); launch(m, a[0]); } })); });
    const o = overlay('<input type="search" placeholder="Search pages and actions" aria-label="Search pages and actions"><ul role="listbox"></ul>', "xp-cmd");
    const input = o.el.querySelector("input"), list = o.el.querySelector("ul"); let sel = 0, shown = items;
    const draw = () => { const q = input.value.trim().toLowerCase(); shown = items.filter((x) => !q || (x.label + " " + x.hint).toLowerCase().includes(q)).slice(0, 40); sel = Math.min(sel, Math.max(0, shown.length - 1));
      list.innerHTML = shown.map((x, i) => '<li><button type="button" data-i="' + i + '" aria-selected="' + (i === sel) + '">' + icon(x.ic, 17) + esc(x.label) + "<small>" + esc(x.hint) + "</small></button></li>").join("") || '<li style="padding:16px;color:var(--t3)">No match</li>'; };
    input.addEventListener("input", () => { sel = 0; draw(); });
    input.addEventListener("keydown", (e) => { if (e.key === "ArrowDown") { sel = Math.min(shown.length - 1, sel + 1); draw(); e.preventDefault(); } if (e.key === "ArrowUp") { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); } if (e.key === "Enter" && shown[sel]) { o.close(); shown[sel].run(); } });
    list.addEventListener("click", (e) => { const b = e.target.closest("[data-i]"); if (b) { o.close(); shown[+b.dataset.i].run(); } });
    draw(); setTimeout(() => input.focus(), 30);
  }

  // ================================================================ shell
  function renderShell() {
    stopViz();
    S.root.innerHTML = '<div class="xp" data-nav="closed"><div class="xp-grid-bg"></div>' +
      '<aside class="xp-side" aria-label="Portal navigation"><a class="xp-brand" href="#" data-go="home">' + MARK + "<b>XEVRION</b><span>OPS</span></a>" +
      '<div class="xp-org" id="xpOrg"></div><nav class="xp-nav" id="xpNav"></nav>' +
      '<div class="xp-side-foot"><div class="xp-live" id="xpLive"><i></i><span>Connecting…</span></div><button class="xp-btn xp-btn--ghost xp-btn--sm" type="button" data-click="logout()">' + icon("logout", 16) + "Sign out</button></div></aside>" +
      '<header class="xp-top"><button class="xp-iconbtn xp-menu" type="button" data-act="menu" aria-label="Open navigation">' + icon("menu") + '</button><div class="xp-crumb" id="xpCrumb"></div>' +
      '<button class="xp-search" type="button" data-act="cmd">' + icon("search") + "<span>Search pages and actions</span><kbd>Ctrl K</kbd></button>" +
      '<button class="xp-iconbtn" type="button" data-act="refresh" aria-label="Refresh" id="xpRefresh">' + icon("refresh") + "</button>" +
      '<button class="xp-iconbtn" type="button" data-go="notifications" aria-label="Notifications" id="xpBell">' + icon("bell") + "</button></header>" +
      '<main class="xp-main" id="xpMain" tabindex="-1"></main><div class="xp-toasts" id="xpToasts" aria-live="polite"></div></div>';
    renderOrg(); renderNav();
  }
  function renderOrg() {
    const el = $("xpOrg"); if (!el) return;
    el.innerHTML = "<label for=\"xpOrgPick\">Organisation</label>" + (S.orgs.length > 1 ? '<select id="xpOrgPick" data-act-change="org">' + S.orgs.map((o) => '<option value="' + esc(o.id) + '"' + (o.id === S.org ? " selected" : "") + ">" + esc(o.name) + "</option>").join("") + "</select>"
      : '<div style="padding:10px 12px;border:1px solid var(--line2);border-radius:10px;background:var(--bg2);font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc((S.orgs.find((o) => o.id === S.org) || {}).name || "Your organisation") + "</div>") +
      '<div class="xp-role">' + icon("user", 14) + "<span>Signed in as <b style=\"color:var(--t2);font-weight:500\">" + esc(cap(S.role || "member")) + "</b></span></div>";
  }
  function renderNav() {
    const nav = $("xpNav"); if (!nav) return; let html = "", group = "";
    PAGES.filter(visible).forEach((p) => { if (p.group !== group) { group = p.group; html += "<h6>" + esc(group) + "</h6>"; }
      const b = S.badges[p.id]; html += '<button type="button" data-go="' + p.id + '"' + (p.id === S.page ? ' aria-current="page"' : "") + ">" + icon(p.icon) + "<span>" + esc(p.label) + "</span>" + (b && b.n ? '<span class="xp-badge" data-tone="' + (b.t || "") + '">' + esc(b.n) + "</span>" : "") + "</button>"; });
    nav.innerHTML = html;
  }
  function renderCrumb(p) {
    const el = $("xpCrumb"); if (el) el.innerHTML = "<span>" + esc(p.group) + "</span><i>/</i><b>" + esc(p.label) + "</b>";
  }
  function setLive(text, t = "") { const el = $("xpLive"); if (!el) return; el.dataset.tone = t; el.querySelector("span").textContent = text; }
  const skeleton = () => '<div class="xp-page"><div class="xp-skel" style="height:220px"></div><div class="xp-g xp-g4">' + '<div class="xp-skel" style="height:132px"></div>'.repeat(4) + '</div><div class="xp-g xp-g2"><div class="xp-skel" style="height:280px"></div><div class="xp-skel" style="height:280px"></div></div></div>';

  function updateBadges(extra = {}) {
    const d = S.dash || {};
    S.badges.home = { n: (d.pending_approvals || []).length, t: "violet" };
    Object.assign(S.badges, extra);
    renderNav();
    const bell = $("xpBell"); if (bell) { const dot = bell.querySelector(".xp-dot"); const n = (S.badges.notifications || {}).n; if (n && !dot) bell.insertAdjacentHTML("beforeend", '<span class="xp-dot"></span>'); if (!n && dot) dot.remove(); }
  }

  async function go(id, { keepScroll = false } = {}) {
    const p = pageOf(id) || pageOf("home"); S.page = p.id; renderNav(); renderCrumb(p);
    const x = S.root.querySelector(".xp"); if (x) x.dataset.nav = "closed";
    if (!S.demo) { try { history.replaceState(null, "", "#/" + p.id); } catch (e) { /* history unavailable */ } }
    const main = $("xpMain"), token = ++S.nav; stopViz(); const top = main.scrollTop; if (!keepScroll) main.innerHTML = skeleton();
    try {
      S.dash = await api(O("/dashboard")); if (token !== S.nav) return;
      await (RENDER[p.id] || pageHome)(main, p); if (token !== S.nav) return;
      if (keepScroll) main.scrollTop = top; else main.scrollTop = 0;
      S.updated = new Date(); setLive("Live · updated " + S.updated.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }), "");
      updateBadges();
    } catch (e) {
      if (token !== S.nav) return;
      if (e.status === 401) return renderAuth("signin", "Your session has ended. Sign in again to continue.");
      main.innerHTML = '<div class="xp-page">' + card("We could not load this page", '<p class="xp-err">' + esc(e.message) + '</p><div class="xp-card-f">' + btn("Retry", "retry", { tone: "primary", ic: "refresh" }) + "</div>") + "</div>";
      setLive("Connection problem", "warn");
    }
  }
  const reload = () => go(S.page, { keepScroll: true });

  // ================================================================ services: actions, programmes, cases
  function launch(module, action, preset = {}) {
    const cfg = CONFIGS[module], a = cfg.actions.find((x) => x[0] === action); if (!a) return;
    const ops = S.lastOps || [], fields = fieldsOf(a[3]);
    const programs = ops.filter((r) => r.module === "revenue" && r.action === "create_program" && r.receipt && r.receipt.program && r.receipt.program.id).map((r) => [String(r.receipt.program.id), (r.receipt.program.name || "Programme") + " · " + r.receipt.program.id]);
    const cases = ops.filter((r) => r.module === "customer_operations" && r.action === "support_intake" && r.receipt && r.receipt.id).map((r) => [String(r.receipt.id), (r.receipt.customer_id || "Case") + " · " + r.receipt.id]);
    const body = (fields.length ? '<div class="xp-form">' + fields.map((f) => {
      if (f.key === "program_id" && programs.length) return field({ name: f.key, label: f.label, type: "select", options: programs, value: preset[f.key] || "" });
      if (f.key === "case_id" && cases.length) return field({ name: f.key, label: f.label, type: "select", options: cases, value: preset[f.key] || "" });
      if (/^select:/.test(f.type)) return field({ name: f.key, label: f.label, type: "select", options: f.type.slice(7).split("/").map((o) => { const [k, l] = o.split("="); return [k, l || cap(k)]; }), value: preset[f.key] || "" });
      return field({ name: f.key, label: f.label, type: f.type === "textarea" ? "textarea" : f.type, value: preset[f.key] ?? "", rows: f.type === "textarea" ? 4 : 0 });
    }).join("") + "</div>" : '<p class="xp-note">This action needs no details. It runs against your organisation\'s own records.</p>') +
      '<p class="xp-note"><b>What happens:</b> the request is authorised against your plan and role, runs once (a repeated click cannot run it twice), and its receipt is kept in the activity below.</p>';
    drawer({ title: a[1], sub: MODULES[module].label + " · " + a[2], body, submitLabel: a[1], submit: async (v) => {
      const payload = {};
      fields.forEach((f) => { let value = String(v[f.key] ?? "").trim();
        if (f.type === "number") { if (!value) throw Error("Please supply " + f.label.toLowerCase()); value = Number(value); if (!Number.isFinite(value)) throw Error(f.label + " needs a finite number");
          if (/ 0 to 1$/.test(f.label) && (value < 0 || value > 1)) throw Error(f.label.replace(/ 0 to 1$/, "") + " must be between 0 and 1"); }
        if (f.key === "prospect_emails") { payload.prospects = value.split(/\n|,/).map((x) => x.trim()).filter(Boolean).map((email) => ({ email })); return; }
        payload[f.key] = value; });
      await runAction(module, action, action === "create_program" ? { program: { ...payload } } : payload);
      toast(a[1] + " completed. The receipt is in the activity list.", "ok"); reload();
    } });
  }
  async function runAction(module, action, payload) {
    const body = JSON.stringify({ action, payload }), identity = S.org + module + body;
    if (!S.pendingAction || S.pendingAction.identity !== identity) S.pendingAction = { identity, key: uid() };
    const r = await api(O("/operations/" + module + "/authorize"), { method: "POST", headers: { "Idempotency-Key": S.pendingAction.key }, body });
    S.pendingAction = null; return r;
  }
  async function operationDetail(id) {
    const r = await api(O("/operations/" + encodeURIComponent(id)));
    drawer({ title: cap(r.action), sub: modLabel(r.module) + " · " + when(r.completed_at), body: statsRow([["Status", status(r.status)], ["Completed", esc(when(r.completed_at))], ["Receipt", '<span class="xp-mono">' + esc(String(r.id || "").slice(0, 18)) + "</span>"]]) +
      (r.error ? '<p class="xp-err">' + esc(r.error) + "</p>" : "") + '<h4 style="font-size:13px;color:var(--t2);font-weight:500">Service receipt</h4>' + evidence(r.receipt ?? r) });
  }

  // ================================================================ page: command centre
  async function pageHome(main) {
    const d = S.dash, sub = d.subscription || {}, ops = d.operation_results || [], onboarding = d.onboarding || {};
    S.lastOps = ops;
    const [health, ai, value, integ, support, notes] = await Promise.all([settle(api(O("/health"))), settle(api(O("/ai-usage"))), may("value.read") ? settle(api(O("/value-summary"))) : Promise.resolve({ ok: false }),
      may("integration.manage") ? settle(api(O("/integrations/health"))) : Promise.resolve({ ok: false }), settle(api(O("/support"))), settle(api(O("/notifications")))]);
    const H = health.ok ? health.v : null, A = ai.ok ? ai.v : null, V = value.ok ? value.v : null, I = integ.ok ? integ.v.items || [] : null;
    const openSupport = support.ok ? (support.v.items || []).filter((x) => !["resolved", "confirmed", "closed"].includes(x.status)) : [];
    const notifs = notes.ok ? notes.v.items || [] : [];
    const seen = dateOf(store.get("xevrion.seen")), since = Math.max(Date.now() - 86400000 * 2, seen ? seen.getTime() : 0);
    const recent = notifs.filter((n) => { const t = dateOf(n.at); return t && t.getTime() > since; }).length;
    updateBadges({ support: { n: openSupport.length, t: "violet" }, notifications: { n: recent, t: "" } });
    const done = ops.filter((r) => r.status === "completed"), bad = ops.filter((r) => ["failed", "reconciliation_required"].includes(r.status));
    const series = daily(ops.filter((r) => r.status === "completed"), 14, "module", MODULE_IDS);
    const perDay = series.labels.map((_, i) => series.series.reduce((a, s) => a + s.values[i], 0));
    const modules = sub.modules || [], approvals = d.pending_approvals || [];
    const steps = ["business", "goals", "metrics", "integrations", "permissions", "services", "automation", "approvals"], completed = onboarding.completed_steps || [];
    const connected = I ? I.filter((x) => x.status !== "disconnected") : [];
    const orgName = (d.organization || {}).name || "your organisation";
    const hour = new Date().getHours(), greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
    const lead = [modules.length + " of 4 services in your plan", fmtN(done.length) + " actions completed recently", approvals.length ? approvals.length + " approval" + (approvals.length > 1 ? "s" : "") + " waiting for you" : "no approvals waiting"].join(" · ");
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Command centre · " + orgName, title: greet + ". Here is " + orgName + " right now.", lead: esc(lead) + ".",
      meta: (sub.plan ? chip("Plan " + cap(sub.plan), "violet") : "") + status(sub.status || "not_subscribed") + chip(cap(S.role || "member") + " access", "", false),
      actions: (approvals.length && may("approval.decide") ? btn("Review approvals", "scroll", { tone: "primary", ic: "approve", data: { to: "xpApprovals" } }) : "") + btn("Open the systems map", "", { go: "systems", ic: "map" }) + (completed.length < 8 && may("configuration.manage") ? btn("Finish setup", "", { go: "setup", ic: "setup" }) : ""), viz: "xpCore" }) +
      '<div class="xp-g xp-g4">' +
      kpi("Health score", H ? H.score + "<small>/100</small>" : "—", H ? chip(cap(H.churn_risk) + " risk", H.churn_risk === "low" ? "ok" : H.churn_risk === "medium" ? "warn" : "risk") : "Not available", { ic: "target", tone: "violet", meter: H ? H.score / 100 : null, meterTone: H && H.score >= 70 ? "ok" : H && H.score >= 45 ? "warn" : "risk" }) +
      kpi("Actions completed", fmtN(done.length), "<b>" + fmtN(perDay.reduce((a, b) => a + b, 0)) + "</b> in the last 14 days", { ic: "flow", spark: spark(perDay) }) +
      kpi("Success rate", ops.length ? pct(done.length / ops.length) : "—", bad.length ? "<b>" + bad.length + "</b> failed or need reconciliation" : "No failed actions", { ic: "check", meter: ops.length ? done.length / ops.length : null, meterTone: "ok" }) +
      kpi("Verified value", V ? money(V.verified_value_gbp) : "—", V ? "Observed <b>" + money(V.observed_value_gbp) + "</b> · estimated <b>" + money(V.estimated_value_gbp) + "</b>" : may("value.read") ? "No ledger yet" : "Not in your role", { ic: "value" }) +
      kpi("Approvals waiting", fmtN(approvals.length), approvals.length ? "Oldest requested " + esc(ago(approvals[0].requested_at)) : "Nothing is waiting for a decision", { ic: "approve" }) +
      kpi("Connected tools", I ? fmtN(connected.length) : "—", I ? "<b>" + I.filter((x) => x.health === "healthy").length + "</b> healthy" + (sub.entitlements && sub.entitlements.integrations ? " · allowance " + compact(sub.entitlements.integrations) : "") : "Managed by an administrator", { ic: "plug", meter: I && sub.entitlements && sub.entitlements.integrations && sub.entitlements.integrations < 1e8 ? connected.length / sub.entitlements.integrations : null }) +
      kpi("AI calls today", A ? fmtN(A.used) : "—", A ? (A.allowance >= 1e8 ? "No daily limit" : "of <b>" + compact(A.allowance) + "</b> · resets " + esc(ago(A.resets_at))) : "Not available", { ic: "spark", meter: A && A.allowance && A.allowance < 1e8 ? A.used / A.allowance : null }) +
      kpi("Setup", completed.length + "<small>/8</small>", completed.length === 8 ? "Setup complete" : "Next: " + esc(cap(steps.find((s) => !completed.includes(s)) || "")), { ic: "setup", meter: completed.length / 8, meterTone: completed.length === 8 ? "ok" : "" }) +
      "</div>" +
      '<div class="xp-g xp-g-main">' + card("Activity across your services", '<div id="xpActivity">' + columns(series.labels, series.series.map((s) => ({ name: modLabel(s.key), color: MODULES[s.key].color, values: s.values }))) + "</div>" +
        '<div class="xp-legend">' + MODULE_IDS.map((m) => '<span><i style="background:' + MODULES[m].color + '"></i>' + esc(MODULES[m].label) + " <b>" + fmtN(done.filter((r) => r.module === m).length) + "</b></span>").join("") + "</div>", { sub: "Completed actions per day for the last 14 days, by service.", tag: "14 days" }) +
      card("Service mix", donut(MODULE_IDS.map((m) => ({ label: MODULES[m].label, value: done.filter((r) => r.module === m).length, color: MODULES[m].color })), { centre: fmtN(done.length), sub: "COMPLETED" }), { sub: "Where the completed work happened." }) + "</div>" +
      '<div class="xp-g xp-g2">' + card("Waiting for your decision", approvalsList(approvals), { sub: "Nothing consequential runs without a named approval.", id: "xpApprovals" }) +
      card("Health drivers", H ? healthBars(H) : restricted("Health"), { sub: H ? "An operational indicator, not a calibrated probability." : "" }) + "</div>" +
      card("When the work happened", heatCalendar(done.map((r) => ({ date: r.completed_at })), { weeks: 13, unit: "actions completed" }), { sub: "Every completed action over the last 13 weeks, one square per day. Today is outlined.", tag: "13 weeks" }) +
      card("Latest service activity", table(ops.slice(-8).reverse(), [{ label: "Service", render: (r) => esc(modLabel(r.module)) }, { label: "Action", render: (r) => esc(cap(r.action)) }, { label: "Status", render: (r) => status(r.status) }, { label: "Completed", render: (r) => esc(ago(r.completed_at)) }], { act: "op" }), { sub: "Open any record to see its service receipt and outcome.", actions: MODULE_IDS.filter((m) => pageOf(m)).slice(0, 1).map((m) => btn("All activity", "", { go: m, sm: true, ic: "arrow" })).join("") }) +
      "</div>";
    constellation($("xpCore"), { centre: { value: H ? H.score : "—", label: "Health" }, labelRoom: 110, rings: [MODULE_IDS.map((m) => { const n = done.filter((r) => r.module === m).length; return { id: m, label: MODULES[m].label, sub: modules.includes(m) ? fmtN(n) + " done" : "Not in plan", weight: Math.min(1, n / Math.max(1, done.length) * 2), tone: modules.includes(m) ? "violet" : "muted", go: pageOf(m) ? m : "" }; }),
      [{ id: "value", label: "Value ledger", sub: V ? money(V.verified_value_gbp) + " verified" : "Ledger", tone: "ok", weight: 0.6, go: pageOf("value") ? "value" : "" }, { id: "appr", label: "Approvals", sub: approvals.length + " waiting", tone: approvals.length ? "warn" : "pale", weight: 0.4 }, { id: "conn", label: "Connections", sub: I ? connected.length + " connected" : "Tools", tone: "info", weight: 0.4, go: pageOf("connections") ? "connections" : "" }, { id: "sup", label: "Support", sub: openSupport.length + " open", tone: "pale", weight: 0.3, go: "support" }]],
      links: MODULE_IDS.map((m) => [m, "c", Math.min(1, done.filter((r) => r.module === m).length / Math.max(1, done.length) * 2), "violet"]).concat([["value", "c", 0.6, "ok"], ["appr", "c", 0.4, "warn"], ["conn", "c", 0.5, "info"], ["sup", "c", 0.3, "pale"]]).concat(MODULE_IDS.map((m) => [m, "value", 0.3, "ok"])) });
  }
  function approvalsList(approvals) {
    if (!may("approval.decide")) return restricted("Deciding approvals");
    if (!approvals.length) return empty("Nothing is waiting for you", "Requests appear here the moment a service needs a decision.");
    return '<div class="xp-list">' + approvals.map((a) => '<div class="xp-li"><span class="xp-ico" data-tone="warn">' + icon("approve") + "</span><div><b>" + esc(a.summary || cap(a.action)) + "</b><small>" + esc(modLabel(a.module)) + " · " + esc(cap(a.action)) + " · requested " + esc(ago(a.requested_at)) + (a.expires_at ? " · expires " + esc(ago(a.expires_at)) : "") + "</small></div>" +
      btn("Approve", "decide", { tone: "primary", sm: true, data: { id: a.id, ok: "1" } }) + btn("Decline", "decide", { sm: true, data: { id: a.id, ok: "0" } }) + "</div>").join("") + "</div>";
  }
  function healthBars(H) {
    const d = H.drivers || {};
    const items = [["Subscription active", d.subscription_active ? 1 : 0, d.subscription_active ? "Yes" : "No"], ["Setup progress", num(d.onboarding_progress), pct(d.onboarding_progress)], ["Healthy connections", Math.min(1, num(d.healthy_integrations) / 3), fmtN(d.healthy_integrations)],
      ["Workflow success rate", num(d.workflow_success_rate), pct(d.workflow_success_rate)], ["Verified value records", Math.min(1, num(d.verified_value_items) / 5), fmtN(d.verified_value_items)], ["Measured service usage", Math.min(1, num(d.actual_service_usage) / 100), compact(d.actual_service_usage)], ["Open support requests", num(d.open_support) ? 0.2 : 1, fmtN(d.open_support)]];
    return '<div style="display:grid;gap:14px">' + gauge(H.score) + "<div>" + bars(items.map(([l, v, t]) => ({ label: l, value: v, text: t, tone: v >= 0.7 ? "ok" : v >= 0.4 ? "" : "warn" })), { max: 1 }) + "</div></div>";
  }

  // ================================================================ page: systems map
  async function pageSystems(main) {
    const d = S.dash, sub = d.subscription || {}, ops = d.operation_results || [];
    const [health, integ, value, support, ai, notes] = await Promise.all([settle(api(O("/health"))), may("integration.manage") ? settle(api(O("/integrations/health"))) : Promise.resolve({ ok: false }), may("value.read") ? settle(api(O("/value-summary"))) : Promise.resolve({ ok: false }), settle(api(O("/support"))), settle(api(O("/ai-usage"))), settle(api(O("/notifications")))]);
    const H = health.ok ? health.v : null, I = integ.ok ? integ.v.items || [] : [], V = value.ok ? value.v : null, SUP = support.ok ? support.v.items || [] : [], A = ai.ok ? ai.v : null, N = notes.ok ? notes.v.items || [] : [];
    const modules = sub.modules || [], done = ops.filter((r) => r.status === "completed");
    const last = (rows, k = "completed_at") => rows.map((r) => r[k]).filter(Boolean).sort().slice(-1)[0];
    const systems = MODULE_IDS.map((m) => { const rows = ops.filter((r) => r.module === m); return { id: m, name: MODULES[m].label, kind: "Service", state: modules.includes(m) ? (rows.length ? "active" : "ready") : "not in plan", tone: modules.includes(m) ? "violet" : "muted", measure: fmtN(rows.filter((r) => r.status === "completed").length) + " completed", last: last(rows), go: pageOf(m) ? m : "" }; })
      .concat([{ id: "value", name: "Value ledger", kind: "Evidence", state: V ? (V.verified_items ? "verified" : "recording") : "restricted", tone: "ok", measure: V ? V.items + " records · " + money(V.verified_value_gbp) + " verified" : "—", last: last(d.value_items || [], "verified_at"), go: pageOf("value") ? "value" : "" },
        { id: "approvals", name: "Approvals", kind: "Control", state: (d.pending_approvals || []).length ? "pending" : "clear", tone: (d.pending_approvals || []).length ? "warn" : "ok", measure: (d.pending_approvals || []).length + " waiting", last: last(d.pending_approvals || [], "requested_at"), go: "home" },
        { id: "support", name: "Support", kind: "Service desk", state: SUP.filter((x) => !["resolved", "confirmed", "closed"].includes(x.status)).length ? "open" : "clear", tone: "pale", measure: SUP.length + " conversations", last: last(SUP, "created_at"), go: "support" },
        { id: "billing", name: "Billing", kind: "Account", state: sub.status || "not_subscribed", tone: sub.status === "active" ? "ok" : "warn", measure: sub.plan ? "Plan " + cap(sub.plan) : "No plan", last: sub.paid_through || sub.updated_at, go: pageOf("billing") ? "billing" : "" },
        { id: "ai", name: "AI allowance", kind: "Platform", state: A ? "metered" : "restricted", tone: "info", measure: A ? fmtN(A.used) + (A.allowance >= 1e8 ? " calls today" : " of " + compact(A.allowance) + " today") : "—", last: A ? A.day : "", go: "usage" },
        { id: "notifications", name: "Notifications", kind: "Signals", state: N.length ? "active" : "quiet", tone: "pale", measure: N.length + " recent", last: last(N, "at"), go: "notifications" }]);
    const providers = I.map((x) => ({ id: "p:" + x.key, name: cap(x.key), kind: "Connection", state: x.status === "disconnected" ? "disconnected" : x.health, tone: x.health === "healthy" ? "ok" : x.status === "disconnected" ? "muted" : "warn", measure: x.last_sync_at ? "Synced " + ago(x.last_sync_at) : "Not synced yet", last: x.last_sync_at, go: pageOf("connections") ? "connections" : "" }));
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Systems map · every system in your workspace", title: "How your workspace fits together.", lead: "The four services at the centre, the controls and evidence around them, and the tools you connected on the outer ring. Signals show where work is moving; point at anything for its state and click to open it.", solo: true,
      meta: chip(systems.length + providers.length + " systems", "violet") + chip(done.length + " completed actions", "") + chip(I.length + " connections", "") }) +
      '<section class="xp-card xp-card--hud" style="padding:0;overflow:hidden"><div class="xp-viz" id="xpSystems" style="height:min(620px,70vh);min-height:420px"></div></section>' +
      card("Every system", table(systems.concat(providers), [{ label: "System", render: (r) => "<b style=\"font-weight:500\">" + esc(r.name) + "</b>" }, { label: "Kind", render: (r) => esc(r.kind) }, { label: "State", render: (r) => status(String(r.state).replace(/ /g, "_")) }, { label: "Measure", render: (r) => esc(r.measure) }, { label: "Last activity", render: (r) => esc(r.last ? ago(r.last) : "—") }, { label: "", render: (r) => (r.go ? btn("Open", "", { go: r.go, sm: true }) : "") }], { key: "id" }), { sub: "The same systems as the map, as a list you can scan." }) + "</div>";
    constellation($("xpSystems"), { centre: { value: H ? H.score : "—", label: "Workspace health" }, coreSize: 0.1, labelRoom: 120, maxPulses: 24,
      rings: [systems.slice(0, 4).map((s) => ({ id: s.id, label: s.name, sub: s.measure, tone: s.tone, weight: 0.7, go: s.go, detail: "State: " + s.state })),
        systems.slice(4).map((s) => ({ id: s.id, label: s.name, sub: s.measure, tone: s.tone, weight: 0.45, go: s.go, detail: "State: " + s.state })),
        providers.map((s) => ({ id: s.id, label: s.name, sub: s.state, tone: s.tone, weight: 0.3, go: s.go, detail: s.measure }))].filter((r) => r.length),
      links: systems.slice(0, 4).map((s) => [s.id, "c", 0.8, "violet"]).concat(systems.slice(0, 4).map((s) => [s.id, "value", 0.4, "ok"]), systems.slice(0, 4).map((s) => [s.id, "approvals", 0.25, "warn"]), [["support", "c", 0.3, "pale"], ["billing", "c", 0.3, "info"], ["ai", "c", 0.35, "info"], ["notifications", "c", 0.2, "pale"]],
        providers.map((p, i) => [p.id, systems[i % 4].id, 0.5, "info"])) });
  }

  // ================================================================ page: a service
  async function pageService(main, p) {
    const module = p.module, cfg = CONFIGS[module], meta = MODULES[module], sub = S.dash.subscription || {};
    const res = await settle(api(O("/operations?module=" + module + "&limit=200")));
    const ops = res.ok ? res.v.items || [] : [], allOps = S.dash.operation_results || [];
    S.lastOps = ops.concat(allOps.filter((r) => r.module !== module));
    const inPlan = (sub.modules || []).includes(module), done = ops.filter((r) => r.status === "completed"), bad = ops.filter((r) => ["failed", "reconciliation_required"].includes(r.status));
    const byAction = {}; ops.forEach((r) => (byAction[r.action] = (byAction[r.action] || 0) + 1));
    const series = daily(ops, 30, "status", ["completed", "failed", "reconciliation_required"]);
    const filter = S.filter && S.filter.module === module ? S.filter.status : "";
    const shown = ops.filter((r) => !filter || r.status === filter).slice().reverse();
    let special = "";
    if (module === "revenue") {
      const progs = ops.filter((r) => r.action === "create_program" && r.receipt && r.receipt.program && r.receipt.program.id);
      special = card("Programmes", progs.length ? '<div class="xp-g xp-g3">' + progs.map((r) => { const pr = r.receipt.program, id = String(pr.id), acts = ops.filter((x) => x.receipt && x.receipt.program && String(x.receipt.program.id) === id || (x.receipt && String(x.receipt.program_id || "") === id));
        return '<div class="xp-card" style="padding:16px"><div class="xp-card-h" style="margin-bottom:10px"><div><h3>' + esc(pr.name || "Programme") + '</h3><p class="xp-mono">' + esc(id) + "</p></div>" + (pr.status ? status(pr.status) : "") + "</div>" +
          '<p class="xp-note">' + esc([pr.market, pr.geography].filter(Boolean).join(" · ") || "Created " + ago(r.completed_at)) + '</p><div class="xp-card-f">' + [["status", "Status", "clock"], ["start", "Start", "play"], ["pause", "Pause", "pause"], ["cycle", "Run cycle", "refresh"], ["ingest_prospects", "Add prospects", "plus"], ["stop", "Stop", "stop"]].map(([a, l, ic]) => btn(l, "launch", { sm: true, ic, data: { module, action: a, program: id } })).join("") + "</div>" +
          '<p class="xp-note" style="margin-top:10px">' + fmtN(acts.length) + " recorded actions</p></div>"; }).join("") + "</div>" : empty("No programme yet", "Create a programme to define who you sell to and the approved offer."), { sub: "Each programme with its quick actions. Programme IDs are filled in for you.", actions: btn("Create programme", "launch", { tone: "primary", sm: true, ic: "plus", data: { module, action: "create_program" } }) });
    }
    if (module === "customer_operations") {
      const cases = ops.filter((r) => r.action === "support_intake" && r.receipt && r.receipt.id);
      special = card("Recorded support cases", cases.length ? table(cases.slice().reverse(), [{ label: "Case", render: (r) => '<span class="xp-mono">' + esc(r.receipt.id) + "</span>" }, { label: "Customer", render: (r) => esc(r.receipt.customer_id || "—") }, { label: "Recorded", render: (r) => esc(ago(r.completed_at)) },
        { label: "", render: (r) => btn("Resolve", "launch", { sm: true, data: { module, action: "resolve", case: r.receipt.id } }) + " " + btn("Confirm", "launch", { sm: true, data: { module, action: "confirm", case: r.receipt.id } }) }], { key: "id" }) : empty("No support case recorded yet", "Record a support request to resolve and measure it here."), { sub: "Cases from recorded support requests, ready to resolve or confirm." });
    }
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: meta.label + " · " + meta.verb, title: cfg.title, lead: esc(cfg.intro), meta: (inPlan ? chip("In your plan", "ok") : chip("Not in your plan", "warn")) + chip(fmtN(ops.length) + " actions recorded", "violet") + (bad.length ? chip(bad.length + " need attention", "risk") : ""),
      actions: btn("New action", "launcher", { tone: "primary", ic: "plus", data: { module } }) + (inPlan ? "" : btn("Add to plan", "", { go: pageOf("billing") ? "billing" : "support", ic: "card" })), viz: "xpSvcViz" }) +
      '<div class="xp-g xp-g4">' + kpi("Actions recorded", fmtN(ops.length), "Across " + Object.keys(byAction).length + " action types", { ic: meta.icon, tone: "violet" }) + kpi("Completed", fmtN(done.length), ops.length ? pct(done.length / ops.length) + " success" : "No actions yet", { ic: "check", meter: ops.length ? done.length / ops.length : null, meterTone: "ok" }) +
      kpi("Need attention", fmtN(bad.length), bad.length ? "Failed or awaiting reconciliation" : "Nothing failed", { ic: "alert" }) + kpi("Last activity", done.length ? esc(ago(done[done.length - 1].completed_at)) : "—", done.length ? esc(cap(done[done.length - 1].action)) : "Run your first action", { ic: "clock" }) + "</div>" +
      '<div class="xp-g xp-g-main">' + card("Activity over 30 days", columns(series.labels, [{ name: "Completed", color: "ok", values: series.series[0].values }, { name: "Failed", color: "risk", values: series.series[1].values }, { name: "Needs reconciliation", color: "warn", values: series.series[2].values }]) + '<div class="xp-legend"><span><i style="background:#4fd69c"></i>Completed</span><span><i style="background:#ff5c6c"></i>Failed</span><span><i style="background:#f2c46b"></i>Needs reconciliation</span></div>', { tag: "30 days" }) +
      card("Actions by type", bars(Object.entries(byAction).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: cap(k), value: v }))), { sub: "How often each action has run." }) + "</div>" + special +
      card("Run an action", '<div class="xp-g xp-g3">' + cfg.actions.map((a) => '<button type="button" class="xp-card" data-act="launch" data-module="' + module + '" data-action="' + a[0] + '" style="text-align:left;cursor:pointer;padding:16px;display:grid;gap:8px"><span style="display:flex;align-items:center;gap:10px"><span class="xp-ico">' + icon(meta.icon) + '</span><b style="font-weight:500">' + esc(a[1]) + '</b></span><span class="xp-note">' + esc(a[2]) + "</span></button>").join("") + "</div>", { sub: "Each action opens a short form. Nothing runs until you confirm it." }) +
      card("Activity and outcomes", '<div class="xp-card-f" style="margin:0 0 12px">' + [["", "All"], ["completed", "Completed"], ["failed", "Failed"], ["reconciliation_required", "Needs reconciliation"]].map(([v, l]) => '<button type="button" class="xp-btn xp-btn--sm' + (filter === v ? " xp-btn--violet" : "") + '" data-act="filter" data-module="' + module + '" data-status="' + v + '">' + esc(l) + "</button>").join("") + "</div>" +
        table(shown, [{ label: "Action", render: (r) => esc(cap(r.action)) }, { label: "Status", render: (r) => status(r.status) }, { label: "Completed", render: (r) => esc(when(r.completed_at)) }, { label: "Receipt", render: (r) => '<span class="xp-mono">' + esc(String(r.id || "").slice(0, 14)) + "</span>" }], { act: "op" }), { sub: "Each activity keeps its service receipt and is included in usage and health. Open a row for the full receipt." }) + "</div>";
    serviceViz($("xpSvcViz"), module, ops, done);
  }
  // Each service's hero shows the shape of its own work: Revenue and Decision Intelligence as the lifecycle their actions
  // move through, Customer Operations as a response clock of its support cases. Clicking a stage opens its action.
  const LIFECYCLES = {
    revenue: [["Define", ["create_program"], "Programmes created with an approved offer"], ["Load prospects", ["ingest_prospects"], "Prospect lists added"], ["Launch", ["start"], "Programmes started"], ["Run cycles", ["cycle"], "Authorised research and message cycles"]],
    business_intelligence: [["Measure", ["ingest", "kpi"], "Metrics and KPI readings supplied"], ["Analyse", ["analyze", "diagnose"], "Questions and diagnoses"], ["Project", ["forecast", "scenario"], "Forecasts and scenarios"], ["Decide", ["recommend", "decision"], "Recommendations and recorded decisions"]],
  };
  function serviceViz(host, module, ops, done) {
    const cfg = CONFIGS[module];
    if (module === "customer_operations") {
      const now = Date.now(), cases = ops.filter((r) => r.action === "support_intake" && r.status === "completed" && r.receipt && r.receipt.id);
      const closedBy = (id) => ops.find((r) => ["resolve", "confirm"].includes(r.action) && r.status === "completed" && JSON.stringify(r).includes(String(id)));
      return slaDial(host, { targetHours: 24, centre: { value: fmtN(cases.filter((c) => !closedBy(c.receipt.id)).length), label: "Open cases" },
        items: cases.slice(-60).map((c) => { const fin = closedBy(c.receipt.id), start = dateOf(c.completed_at), age = start ? ((fin ? dateOf(fin.completed_at) || new Date(now) : new Date(now)) - start) / 36e5 : 0;
          return { label: "Case " + String(c.receipt.id).slice(0, 12), sub: c.receipt.customer_id ? "Customer " + c.receipt.customer_id : "", age, done: !!fin, overdue: !fin && age > 24, action: fin ? "confirm" : "resolve" }; }),
        onPick: (d) => launch(module, d.action) });
    }
    const L = LIFECYCLES[module] || [];
    flowRiver(host, { rates: false, stages: L.map(([label, acts, detail]) => ({ label, value: done.filter((r) => acts.includes(r.action)).length, detail, action: acts[0] })),
      onPick: (st) => launch(module, cfg.actions.find((a) => a[0] === st.action) ? st.action : cfg.actions[0][0]) });
  }

  // ================================================================ page: business operations (processes, runs, exceptions)
  async function pageBusiness(main, p) {
    const [pr, wk, ex] = await Promise.all(["processes", "work", "exceptions"].map((k) => settle(api(O("/business-workspace/" + k)))));
    if (!pr.ok && !wk.ok) {
      main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Business Operations · Run", title: "Business operations", lead: esc(CONFIGS.business_operations.intro), solo: true }) + card("Business workspace unavailable", '<p class="xp-note">' + esc((pr.e && pr.e.message) || "Business Operations is not in your plan yet.") + "</p>") + "</div>";
      return;
    }
    const processes = pr.ok ? pr.v.items || [] : [], work = wk.ok ? wk.v.items || [] : [], exceptions = ex.ok ? ex.v.items || [] : [];
    S.biz = { processes, work, exceptions };
    const openEx = exceptions.filter((x) => !["resolved", "waived"].includes(x.status)), waiting = work.filter((w) => w.approval_required && w.approval_status === "pending");
    const lanes = {}; work.forEach((w) => (lanes[w.status || "unknown"] = lanes[w.status || "unknown"] || []).push(w));
    const laneKeys = Object.keys(lanes).sort((a, b) => lanes[b].length - lanes[a].length);
    let opsHtml = "";
    if (may("service.operate")) { const res = await settle(api(O("/operations?module=business_operations&limit=200"))); const ops = res.ok ? res.v.items || [] : []; S.lastOps = ops;
      opsHtml = card("Assessments and work items", '<div class="xp-g xp-g3">' + CONFIGS.business_operations.actions.map((a) => '<button type="button" class="xp-card" data-act="launch" data-module="business_operations" data-action="' + a[0] + '" style="text-align:left;cursor:pointer;padding:16px;display:grid;gap:8px"><b style="font-weight:500">' + esc(a[1]) + '</b><span class="xp-note">' + esc(a[2]) + "</span></button>").join("") + "</div>" +
        '<div style="margin-top:18px">' + table(ops.slice().reverse().slice(0, 30), [{ label: "Action", render: (r) => esc(cap(r.action)) }, { label: "Status", render: (r) => status(r.status) }, { label: "Completed", render: (r) => esc(when(r.completed_at)) }], { act: "op" }) + "</div>", { sub: "Map processes, size automation opportunities and record work. Every run keeps its receipt." }); }
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Business Operations · Run", title: "Business operations", lead: esc(CONFIGS.business_operations.intro), meta: chip(processes.length + " processes", "violet") + chip(work.length + " runs", "") + (openEx.length ? chip(openEx.length + " open exceptions", "risk") : chip("No open exceptions", "ok")),
      actions: (may("configuration.manage") ? btn("New process", "proc-edit", { tone: "primary", ic: "plus", data: { i: "-1" } }) : "") + (waiting.length ? btn(waiting.length + " run" + (waiting.length > 1 ? "s" : "") + " awaiting approval", "scroll", { ic: "approve", data: { to: "xpRuns" } }) : ""), viz: "xpBizViz" }) +
      '<div class="xp-g xp-g4">' + kpi("Processes", fmtN(processes.length), fmtN(processes.filter((x) => x.active !== false).length) + " active", { ic: "flow", tone: "violet" }) + kpi("Workflow runs", fmtN(work.length), laneKeys.length ? laneKeys.slice(0, 2).map((k) => "<b>" + lanes[k].length + "</b> " + esc(words(k))).join(" · ") : "No runs yet", { ic: "operations" }) +
      kpi("Awaiting approval", fmtN(waiting.length), waiting.length ? "Decide them below" : "Nothing waiting", { ic: "approve" }) + kpi("Open exceptions", fmtN(openEx.length), openEx.length ? "Recover them below" : "All clear", { ic: "alert" }) + "</div>" +
      card("Processes", processes.length ? processes.map((pp, i) => '<div class="xp-li" style="align-items:flex-start;flex-wrap:wrap;gap:12px"><div style="min-width:220px"><b>' + esc(pp.name) + "</b><small>" + esc([pp.department, "version " + (pp.version ?? 1), pp.active === false ? "inactive" : "active"].filter(Boolean).join(" · ")) + "</small></div>" +
        (may("configuration.manage") ? btn("Edit", "proc-edit", { sm: true, data: { i } }) : "") + (may("service.operate") ? btn("Start a run", "proc-run", { sm: true, tone: "primary", ic: "play", data: { i } }) : "") +
        '<div style="flex-basis:100%"><div class="xp-flow">' + (pp.steps || []).map((s, k) => (k ? '<span class="xp-flow-a"></span>' : "") + '<div class="xp-flow-n" data-type="' + esc(s.type) + '"><b>' + esc(s.name) + "</b><span>" + esc(s.type) + (s.connector ? " · " + esc(s.connector) : "") + "</span></div>").join("") + "</div></div></div>").join("") : empty("No process designed yet", "Design a process once; every run follows that saved version."), { sub: "Saved versions apply to new runs. Existing runs keep their original process snapshot." }) +
      card("Workflow runs", work.length ? '<div class="xp-board">' + laneKeys.slice(0, 4).map((k) => '<div class="xp-lane"><h4><span>' + esc(words(k)) + "</span><span>" + lanes[k].length + "</span></h4>" + lanes[k].slice(0, 12).map((w) => '<button type="button" class="xp-tile" data-act="run-open" data-id="' + esc(w.id) + '"><b>' + esc(w.id) + "</b>" + esc("v" + (w.process_version ?? "?") + " · step " + (w.current_step ?? "—")) + (w.approval_status === "pending" ? " · " + "approval pending" : "") + "</button>").join("") + "</div>").join("") + "</div>" : empty("No runs yet", "Start a run from a saved process."), { id: "xpRuns", sub: "Runs grouped by state. Open a run to continue it or decide its approval." }) +
      card("Exceptions", table(exceptions, [{ label: "Exception", render: (r) => '<span class="xp-mono">' + esc(r.id) + "</span>" }, { label: "Run", render: (r) => '<span class="xp-mono">' + esc(r.work_item_id || "—") + "</span>" }, { label: "Kind", render: (r) => esc(cap(r.kind)) }, { label: "Status", render: (r) => status(r.status) }], { act: "exc-open", emptyText: "No exceptions recorded." }), { sub: "Recovery never executes provider actions by itself; review the run and continue it explicitly." }) + opsHtml + "</div>";
    // runs as a flow: every run received, how many got going, cleared approval and completed; what leaks is visible
    const st = (w) => String(w.status || "").toLowerCase(), finished = (w) => /complete|closed|done|succeed/.test(st(w)), stuck = (w) => /fail|error|exception|cancel/.test(st(w));
    const started = work.filter((w) => finished(w) || stuck(w) || !/^(new|queued|pending|draft|created|scheduled)$/.test(st(w)));
    const cleared = started.filter((w) => !(w.approval_required && w.approval_status !== "approved") && !stuck(w));
    flowRiver($("xpBizViz"), { stages: [{ label: "Received", value: work.length, detail: processes.length + " processes" }, { label: "Started", value: started.length }, { label: "Cleared approval", value: cleared.length, detail: waiting.length + " awaiting a decision" }, { label: "Completed", value: work.filter(finished).length, detail: openEx.length + " open exceptions" }],
      onPick: () => { const el = $("xpRuns"); if (el) el.scrollIntoView({ behavior: reduced() ? "auto" : "smooth" }); } });
  }
  // process designer
  const STEP_TYPES = ["validate", "approval", "action", "notify", "record", "close", "decision"];
  function processDesigner(index) {
    const proc = index >= 0 ? S.biz.processes[index] : null;
    let steps = JSON.parse(JSON.stringify((proc && proc.steps) || [{ name: "Validate details", type: "validate", required_fields: [] }, { name: "Record completion", type: "record" }, { name: "Close run", type: "close" }]));
    const stepHtml = () => steps.map((s, i) => '<fieldset data-step="' + i + '" class="xp-card" style="padding:14px;display:grid;gap:10px"><legend style="font:500 10.5px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--v200);padding:0 6px">Step ' + (i + 1) + "</legend>" +
      '<div class="xp-form xp-form-2">' + field({ name: "s_name", label: "Name", value: s.name }) + field({ name: "s_type", label: "Type", type: "select", options: STEP_TYPES, value: s.type }) + "</div>" +
      field({ name: "s_required_fields", label: "Required fields", hint: "comma separated", value: (s.required_fields || []).join(", ") }) +
      '<div class="xp-form xp-form-2">' + field({ name: "s_connector", label: "Connector", hint: "action or notify", value: s.connector || "" }) + field({ name: "s_operation", label: "Operation", value: s.operation || "" }) + "</div>" +
      field({ name: "s_approval_reason", label: "Approval reason", value: s.approval_reason || "" }) +
      field({ name: "s_mapping", label: "Payload mapping", hint: "destination = source path, one per line", type: "textarea", rows: 3, value: Object.entries(s.payload_map || {}).map(([k, v]) => k + " = " + v).join("\n") }) +
      '<div data-rules><p class="xp-note"><b>Decision rules</b> apply to decision steps. Values are typed JSON (quote text). Matching rules merge their results in order.</p>' + (s.rules || []).map((r, j) => '<div data-rule="' + j + '" class="xp-form" style="padding:10px;border:1px dashed var(--line2);border-radius:9px;margin-top:8px"><div class="xp-form xp-form-2">' + field({ name: "r_field", label: "Field path", value: r.field }) + field({ name: "r_op", label: "Comparison", type: "select", options: ["eq", "ne", "gt", "gte", "lt", "lte", "in", "contains", "exists"], value: r.op }) + "</div>" + field({ name: "r_value", label: "Compare with (JSON)", type: "textarea", rows: 2, value: JSON.stringify(r.value ?? null) }) + field({ name: "r_then", label: "Result fields (JSON object)", type: "textarea", rows: 3, value: JSON.stringify(r.then || {}, null, 2) }) + btn("Remove rule", "", { sm: true, tone: "ghost", data: { x: "rule-del", i: i + ":" + j } }) + "</div>").join("") +
      '<div class="xp-card-f">' + '<button type="button" class="xp-btn xp-btn--sm" data-x="rule-add" data-i="' + i + '">Add rule</button><button type="button" class="xp-btn xp-btn--sm" data-x="up" data-i="' + i + '">Move up</button><button type="button" class="xp-btn xp-btn--sm xp-btn--danger" data-x="remove" data-i="' + i + '">Remove step</button></div></div></fieldset>').join("");
    const read = (el) => {
      const obj = (text, label) => { const v = JSON.parse(text); if (!v || Array.isArray(v) || typeof v !== "object") throw Error(label + " must be a JSON object"); return v; };
      el.querySelectorAll("[data-step]").forEach((fs) => { const i = +fs.dataset.step, s = steps[i], q = (n) => fs.querySelector('[name="' + n + '"]');
        s.name = q("s_name").value; s.type = q("s_type").value; s.required_fields = q("s_required_fields").value.split(",").map((x) => x.trim()).filter(Boolean);
        ["connector", "operation", "approval_reason"].forEach((k) => { s[k] = q("s_" + k).value; });
        s.payload_map = {}; q("s_mapping").value.split("\n").filter((x) => x.trim()).forEach((line) => { const at = line.indexOf("="); if (at < 1) throw Error("Each mapping needs destination = source path"); s.payload_map[line.slice(0, at).trim()] = line.slice(at + 1).trim(); });
        s.rules = [...fs.querySelectorAll("[data-rule]")].map((row) => { const g = (n) => row.querySelector('[name="' + n + '"]').value; return { field: g("r_field"), op: g("r_op"), value: JSON.parse(g("r_value")), then: obj(g("r_then"), "Rule result") }; }); });
    };
    const body = '<div class="xp-form">' + field({ name: "name", label: "Process name", value: (proc && proc.name) || "" }) + '<div class="xp-form xp-form-2">' + field({ name: "department", label: "Department", value: (proc && proc.department) || "operations" }) + field({ name: "description", label: "Description", value: (proc && proc.description) || "" }) + "</div>" +
      field({ name: "fields", label: "Required fields", hint: "comma separated", value: ((proc && proc.required_fields) || []).join(", ") }) + '</div><div data-steps class="xp-form"></div><div class="xp-card-f"><button type="button" class="xp-btn xp-btn--sm" data-x="add">' + icon("plus", 16) + "Add step</button></div>";
    const o = drawer({ title: proc ? "Edit " + proc.name : "New process", sub: proc ? "Saving creates version " + ((proc.version || 1) + 1) + ". Existing runs keep their snapshot." : "Design the steps once; every run follows the saved version.", body, submitLabel: proc ? "Save new version" : "Create process", submit: async (v, el) => {
      read(el); if (!steps.length) throw Error("Add at least one step");
      const payload = {}; if (proc) ["keywords", "dependencies", "decision_points", "approvals", "exceptions", "baseline_frequency_per_month", "baseline_human_minutes", "baseline_labor_cost_per_hour", "baseline_error_rate", "baseline_cycle_minutes", "sla_minutes", "active"].forEach((k) => { if (k in proc) payload[k] = proc[k]; });
      Object.assign(payload, { name: v.name, department: v.department, description: v.description, required_fields: String(v.fields || "").split(",").map((x) => x.trim()).filter(Boolean), steps });
      if (proc) { payload.process_id = proc.id; payload.expected_version = proc.version; }
      await businessAction(proc ? "update_process" : "create_process", payload); toast(proc ? "New process version saved." : "Process created.", "ok"); reload(); } });
    const holder = o.el.querySelector("[data-steps]"); const redraw = () => { holder.innerHTML = stepHtml(); }; redraw();
    o.el.addEventListener("click", (e) => { const b = e.target.closest("[data-x]"); if (!b || ["close", "submit"].includes(b.dataset.x)) return;
      try { read(o.el); const x = b.dataset.x, i = +b.dataset.i;
        if (x === "add") steps.push({ name: "New step", type: "record" });
        if (x === "up" && i > 0) [steps[i - 1], steps[i]] = [steps[i], steps[i - 1]];
        if (x === "remove") steps.splice(i, 1);
        if (x === "rule-add") (steps[i].rules = steps[i].rules || []).push({ field: "", op: "eq", value: null, then: {} });
        if (x === "rule-del") { const [a, bIdx] = b.dataset.i.split(":").map(Number); steps[a].rules.splice(bIdx, 1); }
        redraw(); } catch (err) { toast(err.message, "risk"); } });
  }
  async function businessAction(action, payload) {
    const identity = S.org + JSON.stringify({ action, payload });
    if (!S.pendingBusiness || S.pendingBusiness.identity !== identity) S.pendingBusiness = { identity, key: uid() };
    const r = await api(O("/operations/business_operations/authorize"), { method: "POST", headers: { "Idempotency-Key": S.pendingBusiness.key }, body: JSON.stringify({ action, payload }) });
    S.pendingBusiness = null; return r;
  }
  function safePathSet(data, path, value) { const parts = path.split("."); if (parts.some((x) => !x || ["__proto__", "prototype", "constructor"].includes(x))) throw Error("Invalid field path"); let t = data; for (const x of parts.slice(0, -1)) { if (x in t && (typeof t[x] !== "object" || t[x] === null || Array.isArray(t[x]))) throw Error("Conflicting field paths"); t = t[x] = t[x] || Object.create(null); } t[parts[parts.length - 1]] = value; }
  function processRun(index) {
    const proc = S.biz.processes[index];
    const body = (proc.required_fields || []).map((k, i) => '<div class="xp-form xp-form-2">' + field({ name: "f" + i, label: k }) + field({ name: "t" + i, label: "Value type", type: "select", options: ["Text", "Number", "Boolean", "JSON"] }) + "</div>").join("") + field({ name: "extra", label: "Additional nested data", hint: "JSON object", type: "textarea", rows: 3, value: "{}" }) +
      '<p class="xp-note"><b>This executes saved version ' + esc(proc.version) + ".</b> Provider actions may have real effects. Dotted field names create nested objects.</p>";
    drawer({ title: "Run " + proc.name, sub: "Version " + proc.version + " · " + (proc.steps || []).length + " steps", body, submitLabel: "Run saved version", submit: async (v) => {
      const ok = await ask({ title: "Execute this saved workflow?", text: "The run follows version " + proc.version + " and may act through your connected tools.", confirm: "Run it" }); if (!ok) return false;
      const extra = JSON.parse(v.extra || "{}"); if (!extra || Array.isArray(extra) || typeof extra !== "object") throw Error("Additional data must be a JSON object");
      (proc.required_fields || []).forEach((k, i) => { const raw = v["f" + i], type = v["t" + i]; let value = raw;
        if (type === "Number") { value = Number(raw); if (!String(raw).trim() || !Number.isFinite(value)) throw Error(k + " needs a finite number"); }
        if (type === "Boolean") { if (!["true", "false"].includes(raw)) throw Error(k + " needs true or false"); value = raw === "true"; }
        if (type === "JSON") value = JSON.parse(raw); safePathSet(extra, k, value); });
      await businessAction("start_workflow", { process_id: proc.id, data: extra }); toast("Run started.", "ok"); reload(); } });
  }
  function runReview(id) {
    const w = S.biz.work.find((x) => String(x.id) === String(id)); if (!w) return;
    const canDecide = may("approval.decide") && w.approval_required && w.approval_status === "pending";
    const o = drawer({ title: "Run " + w.id, sub: "Process version " + (w.process_version ?? "—") + " · step " + (w.current_step ?? "—"), body: statsRow([["Status", status(w.status)], ["Approval", w.approval_required ? status(w.approval_status || "pending") : "Not required"], ["Missing fields", esc((w.missing_fields || []).join(", ") || "None")]]) +
      '<h4 style="font-size:13px;color:var(--t2);font-weight:500">Result and decision</h4>' + evidence({ result: w.result, decision: w.decision }) + (canDecide ? field({ name: "reason", label: "Approval decision reason", type: "textarea", rows: 3 }) : ""),
      secondary: (may("service.operate") ? '<button type="button" class="xp-btn" data-y="continue">' + icon("play", 16) + "Continue execution</button>" : "") + (canDecide ? '<button type="button" class="xp-btn xp-btn--danger" data-y="reject">Reject</button><button type="button" class="xp-btn xp-btn--primary" data-y="approve">Approve</button>' : "") });
    o.el.addEventListener("click", async (e) => { const b = e.target.closest("[data-y]"); if (!b) return; try {
      if (b.dataset.y === "continue") await businessAction("execute_work", { work_id: w.id });
      else { const note = (o.el.querySelector('[name="reason"]') || {}).value || ""; if (note.trim().length < 3) throw Error("Explain the approval decision in at least three characters"); await businessAction("approve_work", { work_id: w.id, approved: b.dataset.y === "approve", note: note.trim() }); }
      o.close(); toast("Run updated.", "ok"); reload(); } catch (err) { toast(err.message, "risk"); } });
  }
  function exceptionReview(id) {
    const x = S.biz.exceptions.find((y) => String(y.id) === String(id)); if (!x) return;
    drawer({ title: "Resolve " + cap(x.kind), sub: x.reason || "Recovery does not execute provider actions.", body: evidence(x.details || {}) + field({ name: "action", label: "Recovery action", type: "select", options: [["supply_data", "Supply missing or corrected data"], ["retry", "Prepare for retry"], ["cancel", "Cancel run"]] }) + field({ name: "data", label: "Replacement top-level fields", hint: "JSON object", type: "textarea", rows: 4, value: "{}" }) +
      '<p class="xp-note">Review the run and explicitly continue it after resolving the underlying cause.</p>', submitLabel: "Apply recovery", submit: async (v) => {
      if (!may("service.operate") || ["resolved", "waived"].includes(x.status)) throw Error("This exception cannot be recovered from your role or state.");
      const data = JSON.parse(v.data || "{}"); if (!data || Array.isArray(data) || typeof data !== "object") throw Error("Recovery data must be a JSON object");
      if (!(await ask({ title: "Apply this recovery action?", confirm: "Apply" }))) return false;
      await businessAction("recover_exception", { exception_id: x.id, action: v.action, data }); if (v.action === "supply_data" && x.work_item_id) await businessAction("understand_work", { work_id: x.work_item_id });
      toast("Recovery applied.", "ok"); reload(); } });
  }

  // ================================================================ page: results & value
  async function pageValue(main) {
    const d = S.dash, items = d.value_items || [];
    const [sum, prod, health] = await Promise.all([settle(api(O("/value-summary"))), may("analytics.read") ? settle(api(O("/product-analytics"))) : Promise.resolve({ ok: false }), settle(api(O("/health")))]);
    const V = sum.ok ? sum.v : { by_currency: {}, items: 0, verified_items: 0 }, PA = prod.ok ? prod.v : null, H = health.ok ? health.v : null;
    const byStatus = {}; items.forEach((x) => (byStatus[x.status || "unknown"] = (byStatus[x.status || "unknown"] || 0) + 1));
    const conf = [0, 0, 0, 0]; items.forEach((x) => { const c = num(x.confidence); conf[c >= 0.75 ? 3 : c >= 0.5 ? 2 : c >= 0.25 ? 1 : 0]++; });
    const cur = Object.entries(V.by_currency || {});
    const ttv = PA && PA.time_to_first_value_seconds !== null && PA.time_to_first_value_seconds !== undefined ? PA.time_to_first_value_seconds : null;
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Results & value · the value ledger", title: money(V.verified_value_gbp) + " verified value.", lead: "Every outcome Xevrion records, with the evidence behind it. Verified means recorded outcome evidence, not proven causation; missing costs are unknown, not zero.",
      meta: chip(V.items + " records", "violet") + chip(V.verified_items + " verified", "ok") + chip("Cost coverage " + pct(V.cost_coverage), ""),
      actions: may("service.operate") ? btn("Record measured value", "value-new", { tone: "primary", ic: "plus" }) + (items.length ? btn("Record action and outcome", "value-outcome", { ic: "check" }) : "") : "", viz: "xpValViz" }) +
      '<div class="xp-g xp-g4">' + kpi("Verified value", money(V.verified_value_gbp), "GBP · evidence recorded", { ic: "value", tone: "violet" }) + kpi("Observed value", money(V.observed_value_gbp), "GBP · awaiting verification", { ic: "target" }) + kpi("Estimated value", money(V.estimated_value_gbp), "GBP · expected before action", { ic: "spark" }) +
      kpi("Time to first value", ttv !== null ? fmtN(ttv / 86400, 1) + "<small>days</small>" : "—", ttv !== null ? "From organisation creation to first verified outcome" : "Appears with the first verified outcome", { ic: "clock" }) + "</div>" +
      '<div class="xp-g xp-g3">' + card("Value by stage", cur.length ? cur.map(([c, t]) => '<p class="xp-note" style="margin:6px 0 4px"><b>' + esc(c) + "</b></p>" + bars([{ label: "Estimated", value: num(t.estimated), text: money(t.estimated, c), tone: "muted" }, { label: "Observed", value: num(t.observed), text: money(t.observed, c) }, { label: "Verified", value: num(t.verified), text: money(t.verified, c), tone: "ok" }, { label: "Recorded costs", value: num(t.verified_costs), text: money(t.verified_costs, c), tone: "risk" }, { label: "Net where costed", value: Math.max(0, num(t.net_verified_with_recorded_costs)), text: t.net_verified_with_recorded_costs === null ? "Unknown" : money(t.net_verified_with_recorded_costs, c), tone: "ok" }])).join("") : empty("No value recorded yet"), { sub: "Currencies are never combined." }) +
      card("Evidence status", donut(Object.entries(byStatus).map(([k, v]) => ({ label: cap(k), value: v, color: k === "verified" ? "ok" : k === "observed" ? "info" : k === "estimated" ? "muted" : "violet" })), { centre: fmtN(items.length), sub: "RECORDS" })) +
      card("Confidence", bars([["75 to 100%", conf[3], "ok"], ["50 to 74%", conf[2], ""], ["25 to 49%", conf[1], "warn"], ["Below 25%", conf[0], "risk"]].map(([l, v, t]) => ({ label: l, value: v, tone: t }))), { sub: "How sure each record is, as recorded with it." }) + "</div>" +
      '<div class="xp-g xp-g2">' + card("Customer health", H ? healthBars(H) : restricted("Health"), { sub: "An operational indicator, not a calibrated probability." }) +
      card("From sign-up to value", PA ? funnel([["Organisation created", "organization.created"], ["Checkout created", "subscription.checkout_created"], ["Setup updated", "onboarding.updated"], ["Tool verified", "integration.verified"], ["Services activated", "services.activated"], ["Actions executed", "operations.executed"]].map(([l, k]) => ({ label: l, value: (PA.events || {})[k] || 0 }))) + '<p class="xp-note" style="margin-top:10px">' + esc(PA.basis || "") + "</p>" : restricted("Product analytics"), { sub: "Lifecycle events recorded for this organisation." }) + "</div>" +
      card("Value ledger", table(items.slice().reverse(), [{ label: "Outcome", render: (r) => esc(r.title) }, { label: "Service", render: (r) => esc(modLabel(r.service)) }, { label: "Evidence", render: (r) => status(r.status) }, { label: "Benefit", num: true, render: (r) => esc(r.actual_value !== undefined && r.actual_value !== null ? money(r.actual_value, r.currency) : r.expected_value !== undefined ? money(r.expected_value, r.currency) + " exp." : "—") },
        { label: "Confidence", render: (r) => '<div class="xp-meter" style="margin:0;width:90px"><i style="width:' + Math.round(num(r.confidence) * 100) + '%"></i></div>' }], { act: "value-open", emptyText: "No outcomes recorded yet." }), { sub: esc(V.basis || "") }) + "</div>";
    // the value river: how much of what was expected has been observed, and how much of that is verified with evidence
    flowRiver($("xpValViz"), { color: "ok", rates: false, stages: [["Estimated", V.estimated_value_gbp, "estimated", "Expected before action"], ["Observed", V.observed_value_gbp, "observed", "Measured, awaiting verification"], ["Verified", V.verified_value_gbp, "verified", "Outcome evidence recorded"]]
      .map(([label, v, k, detail]) => ({ label, value: num(v), text: money(v), detail: fmtN(byStatus[k] || 0) + " records · " + detail })) });
  }
  function valueNew() {
    drawer({ title: "Record measured value", sub: "Start a ledger record before acting, so the outcome can be compared with what was expected.", body: '<div class="xp-form">' + field({ name: "title", label: "Title" }) + '<div class="xp-form xp-form-2">' + field({ name: "service", label: "Service", type: "select", options: MODULE_IDS.map((m) => [m, MODULES[m].label]) }) + field({ name: "currency", label: "Currency", value: "GBP" }) + "</div>" +
      field({ name: "problem", label: "Problem" }) + field({ name: "baseline", label: "Baseline evidence" }) + '<div class="xp-form xp-form-2">' + field({ name: "expected", label: "Expected gross benefit", type: "number" }) + field({ name: "confidence", label: "Confidence", hint: "0 to 1", type: "number" }) + "</div>" +
      field({ name: "method", label: "Attribution method" }) + field({ name: "evidence", label: "Evidence reference" }) + "</div>", submitLabel: "Create value record", submit: async (v) => {
      // checked here so a blank field is never sent as an empty reference or a zero (Number("") is 0)
      const t = (k) => String(v[k] ?? "").trim(), expected = t("expected"), confidence = t("confidence");
      if (t("title").length < 5) throw Error("Give the record a title of at least five characters");
      if (t("problem").length < 10 || t("baseline").length < 10) throw Error("Describe the problem and the baseline evidence in at least ten characters each");
      if (!expected || !Number.isFinite(Number(expected))) throw Error("Expected gross benefit needs a finite number");
      if (!confidence || !(Number(confidence) >= 0 && Number(confidence) <= 1)) throw Error("Confidence needs a number between 0 and 1");
      if (t("method").length < 10) throw Error("Describe the attribution method in at least ten characters");
      if (!t("evidence")) throw Error("Add an evidence reference");
      await post(O("/value-ledger"), { request_id: uid(), title: t("title"), service: v.service, problem: t("problem"), baseline: t("baseline"), expected_value: expected, currency: t("currency").toUpperCase() || "GBP", confidence: Number(confidence), attribution_method: t("method"), evidence_refs: [t("evidence")] }); toast("Value record created.", "ok"); reload(); } });
  }
  function valueOutcome() {
    const items = S.dash.value_items || [];
    // The action is recorded once. If the outcome is then refused, a retry sends only the outcome, against the
    // version the action returned (re-posting the action with the drawer's older version would be a 409).
    let recorded = null;
    drawer({ title: "Record an action and outcome", sub: "Costs and benefits must use the same currency and period. Verification records evidence; it does not prove causation.", body: '<div class="xp-form">' + field({ name: "item", label: "Value record", type: "select", options: items.map((x) => [x.id, x.title + " — " + cap(x.status)]) }) + field({ name: "action", label: "Executed action" }) + field({ name: "receipt", label: "Execution receipt" }) + field({ name: "outcome", label: "Observed outcome" }) +
      field({ name: "evidence", label: "Outcome evidence reference", hint: "optional; the execution receipt is used when blank" }) +
      '<div class="xp-form xp-form-2">' + field({ name: "actual", label: "Actual gross benefit", type: "number" }) + field({ name: "cost", label: "Total recorded cost", hint: "optional", type: "number" }) + "</div>" + field({ name: "verified", label: "I have verified the outcome evidence", type: "checkbox" }) + "</div>", submitLabel: "Record action and outcome", submit: async (v) => {
      const item = items.find((x) => x.id === v.item); if (!item) throw Error("Choose a value record");
      const t = (k) => String(v[k] ?? "").trim(), receipt = t("receipt"), actual = t("actual"), cost = t("cost");
      if (!recorded || recorded.id !== item.id) {
        if (t("action").length < 10) throw Error("Describe the executed action in at least ten characters");
        if (!receipt) throw Error("Add the execution receipt");
      }
      if (t("outcome").length < 10) throw Error("Describe the observed outcome in at least ten characters");
      if (!actual || !Number.isFinite(Number(actual))) throw Error("Actual gross benefit needs a finite number");
      if (cost && !(Number.isFinite(Number(cost)) && Number(cost) >= 0)) throw Error("Total recorded cost needs a number of zero or more");
      if (!recorded || recorded.id !== item.id) {
        const action = await post(O("/value-ledger/" + item.id + "/action"), { version: item.version, action: t("action"), execution_receipts: [receipt], status: "executed" });
        recorded = { id: item.id, version: action.version, receipt };
      }
      await post(O("/value-ledger/" + item.id + "/outcome"), { version: recorded.version, outcome: t("outcome"), actual_value: actual, costs: cost ? { other: cost } : null, evidence_refs: [t("evidence") || receipt || recorded.receipt], attribution_method: item.attribution_method, verified: !!v.verified });
      toast("Outcome recorded.", "ok"); reload(); } });
  }

  // ================================================================ page: optimisation
  async function pageOptimisation(main) {
    const r = await api(O("/optimization")); const L = r.learning_calibration || {}, AQ = r.attribution_quality || {}, CT = r.contribution || {}, CS = r.cross_service || {}, HD = r.health || {};
    const methods = Object.entries(AQ.by_method || {});
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Optimisation · how well Xevrion is learning", title: "Calibration, attribution and adoption.", lead: "How close forecasts came to what happened, how well outcomes are attributed and costed, and which services are actually doing work. Deterministic evidence; " + (r.causal_roi_claim ? "" : "not causal ROI."),
      meta: chip(fmtN(L.pairs || 0) + " paired outcomes", "violet") + chip("Generated " + ago(r.generated_at), "") + chip("No causal ROI claim", "info"), solo: true }) +
      '<div class="xp-g xp-g4">' + kpi("Paired outcomes", fmtN(L.pairs || 0), "Decisions with a recorded outcome", { ic: "target", tone: "violet" }) + kpi("Mean absolute error", L.mean_absolute_error === null || L.mean_absolute_error === undefined ? "—" : fmtN(L.mean_absolute_error, 0), L.bias !== null && L.bias !== undefined ? "Bias " + esc(fmtN(L.bias, 0)) : "Appears with the first pair", { ic: "gauge" }) +
      kpi("Cost coverage", pct(AQ.cost_coverage), fmtN(AQ.costed_verified_items || 0) + " of " + fmtN(AQ.verified_items || 0) + " verified records costed", { ic: "value", meter: AQ.cost_coverage ?? null, meterTone: "ok" }) + kpi("Services doing work", fmtN((CS.modules_with_completed_work || []).length) + "<small>/" + fmtN((CS.entitled_modules || []).length || 4) + "</small>", CS.cross_service ? "Cross-service adoption" : "Single-service so far", { ic: "operations" }) + "</div>" +
      '<div class="xp-g xp-g-main">' + card("Expected against actual", pairs(L.items || []), { sub: "Each pair is a recorded decision and its observed or verified outcome." }) + card("Attribution methods", methods.length ? donut(methods.map(([k, v], i) => ({ label: cap(k), value: v, color: ["violet", "info", "ok", "pale", "warn"][i % 5] })), { centre: fmtN(methods.reduce((a, b) => a + b[1], 0)), sub: "RECORDS" }) + '<p class="xp-note" style="margin-top:10px">Unspecified share: <b>' + pct(AQ.unspecified_share) + "</b>. " + esc(AQ.basis || "") + "</p>" : empty("No attributed outcomes yet")) + "</div>" +
      '<div class="xp-g xp-g2">' + card("Service adoption", heat(MODULE_IDS, ["entitled", "completed"], (m, c) => (c === "entitled" ? ((CS.entitled_modules || []).includes(m) ? 1 : 0) : (CS.completion_counts || {})[m] || 0)) + '<p class="xp-note" style="margin-top:10px">' + esc(CS.basis || "") + "</p>" + ((CS.unused_entitled || []).length ? '<p class="xp-note">Entitled but unused: <b>' + esc((CS.unused_entitled || []).map(modLabel).join(", ")) + "</b></p>" : "")) +
      card("Health drivers", (HD.drivers || []).length ? '<div class="xp-list">' + HD.drivers.map((x) => '<div class="xp-li"><span class="xp-ico" data-tone="' + (String(x.effect).startsWith("+0") ? "warn" : "ok") + '">' + icon(String(x.effect).startsWith("+0") ? "alert" : "check") + "</span><div><b>" + esc(cap(x.driver)) + "</b><small>" + esc(words(x.state)) + '</small></div><span class="xp-badge" data-tone="' + (String(x.effect).startsWith("+0") ? "" : "violet") + '">' + esc(x.effect) + "</span></div>").join("") + "</div>" + (HD.score !== undefined ? '<p class="xp-note" style="margin-top:10px">Score <b>' + esc(HD.score) + "</b>" + (HD.priority_band ? " · band <b>" + esc(words(HD.priority_band)) + "</b>" : "") + "</p>" : "") : empty("No drivers recorded")) + "</div>" +
      card("Contribution evidence", statsRow([["Plan", esc(cap(CT.plan || "—"))], ["Active services", esc(fmtN((CT.active_modules || []).length))], ["Net verified available", CT.net_verified_available ? "Yes" : "Not yet"]]) + '<div style="margin-top:16px">' + bars(Object.entries(CT.usage_totals || {}).map(([k, v]) => ({ label: cap(k), value: v, text: compact(v) }))) + '</div><p class="xp-note" style="margin-top:10px">' + esc(CT.basis || "") + "</p>", { sub: "Usage recorded against verified value. No invented costs." }) + "</div>";
  }

  // ================================================================ page: usage & limits
  async function pageUsage(main) {
    const sub = S.dash.subscription || {}, ent = sub.entitlements || {};
    const [ai, meter, analytics, team, integ] = await Promise.all([settle(api(O("/ai-usage"))), may("usage.read") ? settle(api(O("/usage-metering"))) : Promise.resolve({ ok: false }), may("analytics.read") ? settle(api(O("/analytics"))) : Promise.resolve({ ok: false }), settle(api(O("/team"))), may("integration.manage") ? settle(api(O("/integrations/health"))) : Promise.resolve({ ok: false })]);
    const A = ai.ok ? ai.v : null, M = meter.ok ? meter.v : null, AN = analytics.ok ? analytics.v : null, members = team.ok ? (team.v.members || []).filter((x) => x.status === "active") : null, I = integ.ok ? (integ.v.items || []).filter((x) => x.status !== "disconnected") : null;
    const totals = M ? M.totals || {} : AN ? AN.usage_totals || {} : {};
    const limit = (used, lim, label, unit = "") => { const unlimited = !lim || lim >= 1e8; return '<div style="padding:10px 0;border-bottom:1px solid var(--line)"><div style="display:flex;justify-content:space-between;gap:12px;font-size:13.5px"><span>' + esc(label) + '</span><b style="font-weight:500;font-variant-numeric:tabular-nums">' + (used === null ? "—" : compact(used)) + (unlimited ? " · no limit" : " / " + compact(lim)) + unit + "</b></div>" + (unlimited || used === null ? "" : '<div class="xp-meter"' + (used / lim > 0.9 ? ' data-tone="risk"' : used / lim > 0.7 ? ' data-tone="warn"' : "") + '><i style="width:' + Math.min(100, (used / lim) * 100).toFixed(1) + '%"></i></div>') + "</div>"; };
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Usage & limits · measured, not estimated", title: "What you have used, against what your plan allows.", lead: "The same counters the platform enforces. Totals include only recorded measured quantities; missing evidence is unknown, not zero.", solo: true,
      meta: (sub.plan ? chip("Plan " + cap(sub.plan), "violet") : "") + (M && M.reconciliation_pending ? chip(M.reconciliation_pending + " awaiting reconciliation", "warn") : chip("Nothing awaiting reconciliation", "ok")) }) +
      '<div class="xp-g xp-g3">' + card("AI calls today", A ? '<div style="display:grid;justify-items:center;gap:8px">' + ring(A.allowance >= 1e8 ? 0.02 : A.used / Math.max(1, A.allowance), { size: 170, label: fmtN(A.used), sub: A.allowance >= 1e8 ? "NO DAILY LIMIT" : "OF " + compact(A.allowance) }) + '<p class="xp-note">Resets ' + esc(ago(A.resets_at)) + " · " + esc(A.day) + "</p></div>" : restricted("AI usage"), { sub: "Calls to the AI model today, against your daily allowance." }) +
      card("Plan limits", limit(members ? members.length : null, ent.team, "Team members") + limit(I ? I.length : null, ent.integrations, "Connected tools") + limit(num(totals.workflow_executions), ent.workflows, "Workflow executions") + limit(num(totals.ai_tokens), ent.ai_tokens, "AI tokens") + '<p class="xp-note" style="margin-top:10px">' + (ent.decision_scenarios ? "Decision scenarios included." : "Decision scenarios are included in the Scale plan.") + "</p>", { sub: "Purchased entitlements; values never change retroactively." }) +
      card("Recorded usage", Object.keys(totals).length ? bars(Object.entries(totals).map(([k, v]) => ({ label: cap(k), value: v, text: compact(v) }))) : empty("No usage recorded yet"), { sub: M ? esc(M.basis || "") : AN ? "From analytics totals." : "" }) + "</div>" +
      (M && Object.keys(M.by_service || {}).length ? card("Usage by service", heat(Object.keys(M.by_service), [...new Set(Object.values(M.by_service).flatMap((x) => Object.keys(x)))], (s, m) => (M.by_service[s] || {})[m] || 0), { sub: "Each measured quantity, by the service that used it." }) : "") +
      (AN ? card("Workspace activity", statsRow([["Audit events", fmtN(AN.audit_events)], ["Connections", fmtN(AN.integrations)], ["Active services", fmtN((AN.active_modules || []).length)]])) : "") + "</div>";
  }

  // ================================================================ page: setup
  const SETUP = [["business", "Your business"], ["goals", "Goals"], ["metrics", "Success metric"], ["integrations", "Connections"], ["permissions", "Authority"], ["services", "Services"], ["automation", "Automation"], ["approvals", "Approvals"]];
  async function pageSetup(main) {
    const ob = S.dash.onboarding || {}, data = ob.data || {}, done = ob.completed_steps || [], sub = S.dash.subscription || {};
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Setup · eight steps", title: done.length === 8 ? "Setup is complete." : "Set up your workspace.", lead: "Tell Xevrion about your business once. Services are selected and paid for in Billing; connections are optional and can be added later.", meta: chip(done.length + " of 8 steps done", done.length === 8 ? "ok" : "violet") + status(ob.status || "in_progress"), actions: may("service.manage") || may("configuration.manage") ? btn("Activate paid services", "activate", { tone: done.length === 8 ? "primary" : "", ic: "play", disabled: done.length !== 8 }) : "", solo: true }) +
      '<div class="xp-g xp-g-main">' + card("Steps", '<div class="xp-steps">' + SETUP.map(([k, l], i) => '<div class="xp-step"' + (done.includes(k) ? " data-done" : "") + "><b>" + String(i + 1).padStart(2, "0") + (done.includes(k) ? " · DONE" : "") + "</b><span>" + esc(l) + "</span></div>").join("") + "</div>", { sub: "Every step is saved together when you save setup." }) +
      card("Progress", '<div style="display:grid;justify-items:center">' + segRing(SETUP.map(([k]) => done.includes(k)), { labels: SETUP.map((s) => s[1]) }) + "</div>") + "</div>" +
      card("Complete your business setup", '<div class="xp-form" id="xpSetup"><div class="xp-form xp-form-2">' + field({ name: "legal", label: "Legal business name", value: (data.business || {}).legal_name || "" }) + field({ name: "industry", label: "Industry", value: (data.business || {}).industry || "" }) + "</div>" +
        '<div class="xp-form xp-form-2">' + field({ name: "goal", label: "Primary customer outcome", value: (data.goals || {}).primary_outcome || "" }) + field({ name: "metric", label: "Success metric", value: (data.metrics || {}).primary_metric || "" }) + "</div>" +
        field({ name: "providers", label: "Connections", hint: "gmail, later or skip — optional", value: ((data.integrations || {}).selected || ["later"]).join(",") }) +
        '<div class="xp-form xp-form-2">' + field({ name: "schedule", label: "Automation schedule", value: (data.automation || {}).schedule || "", placeholder: "For example: weekdays 09:00–17:00" }) + field({ name: "policy", label: "Approval policy", value: (data.approvals || {}).policy || "", placeholder: "For example: every outbound message" }) + "</div>" +
        field({ name: "authority", label: "I have authority to connect this business and operate the selected services", type: "checkbox", value: !!(data.permissions || {}).confirmed }) +
        '<p class="xp-note">Services for this organisation: <b>' + esc((sub.modules || []).map(modLabel).join(", ") || "none selected yet — choose them in Billing") + "</b></p></div>" +
        '<div class="xp-card-f">' + btn("Save setup", "setup-save", { tone: "primary", ic: "check" }) + "</div>", { sub: "Select and pay for services in Billing. Connections are optional: Gmail one-click, other email with an app password, or skip and connect later." }) + "</div>";
  }

  // ================================================================ page: connections
  async function pageConnections(main) {
    const [h, c] = await Promise.all([api(O("/integrations/health")), settle(api(O("/integrations/catalog")))]);
    const items = h.items || [], cat = c.ok ? c.v : { items: [], allowance: 0, connected: items.length };
    const live = items.filter((x) => x.status !== "disconnected"), healthy = items.filter((x) => x.health === "healthy");
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Connections · your tools, your accounts", title: "Connect an inbox or a tool when you are ready.", lead: "Checkout and this portal work without integrations. Connect an inbox when you want Xevrion to read or send through your own account — or skip and return later. Every connection acts only on your own account, and you can disconnect it at any time.",
      meta: chip(live.length + " connected", "violet") + chip(healthy.length + " healthy", "ok") + (cat.allowance ? chip("Allowance " + compact(cat.allowance), "") : ""), viz: "xpConnViz" }) +
      '<div class="xp-g xp-g4">' + kpi("Connected", fmtN(live.length), cat.allowance && cat.allowance < 1e8 ? "of <b>" + fmtN(cat.allowance) + "</b> in your plan" : "No connection limit", { ic: "plug", tone: "violet", meter: cat.allowance && cat.allowance < 1e8 ? live.length / cat.allowance : null }) +
      kpi("Healthy", fmtN(healthy.length), "Verified with the provider", { ic: "check" }) + kpi("Need attention", fmtN(items.filter((x) => x.health && !["healthy", "revoked"].includes(x.health)).length), "Pending verification or failing", { ic: "alert" }) + kpi("Available tools", fmtN((cat.items || []).length), fmtN((cat.items || []).filter((x) => x.available).length) + " ready to connect", { ic: "spark" }) + "</div>" +
      card("Connected providers", table(items, [{ label: "Provider", render: (r) => "<b style=\"font-weight:500\">" + esc(cap(r.key)) + "</b>" }, { label: "Status", render: (r) => status(r.status) }, { label: "Health", render: (r) => status(r.health) }, { label: "Last sync", render: (r) => esc(r.last_sync_at ? ago(r.last_sync_at) : "Not yet") },
        { label: "", render: (r) => (r.status === "disconnected" ? "" : btn("Verify access", "verify", { sm: true, data: { key: r.key } }) + " " + btn("Disconnect", "disconnect", { sm: true, tone: "danger", data: { key: r.key } })) }], { key: "key", emptyText: "No provider connected yet." }), { sub: "Xevrion stores only an opaque credential reference. App passwords and tokens are never shown again." }) +
      '<div class="xp-g xp-g3">' + card("Gmail", field({ name: "gmailScope", label: "Access", type: "select", options: [["read send", "Read and send"], ["read", "Read only"]] }) + '<div class="xp-card-f">' + btn("Connect Gmail", "connect-gmail", { tone: "primary", ic: "mail" }) + "</div>", { sub: "One-click Google authorisation. You leave Xevrion briefly to approve Google permissions." }) +
      card("Other email", '<div class="xp-form">' + field({ name: "oe_email", label: "Email address", type: "email", attrs: ' autocomplete="username"' }) + field({ name: "oe_password", label: "App password", type: "password", attrs: ' autocomplete="new-password"' }) + '<div class="xp-form xp-form-2">' + field({ name: "oe_imap", label: "IMAP host", hint: "optional", placeholder: "imap.example.com" }) + field({ name: "oe_smtp", label: "SMTP host", hint: "optional", placeholder: "smtp.example.com" }) + "</div></div>" +
        '<div class="xp-card-f">' + btn("Save other email", "save-email", { tone: "primary" }) + "</div>", { sub: "An address plus an app password (IMAP): Google Workspace, Zoho, Fastmail, iCloud and most hosts. Microsoft 365 needs Microsoft sign-in instead." }) +
      card("HubSpot", field({ name: "hs_token", label: "Private app token", hint: "optional", type: "password", placeholder: "pat-…", attrs: ' autocomplete="off"' }) + '<div class="xp-card-f">' + btn("Save HubSpot token", "save-hubspot") + "</div>", { sub: "Paste a HubSpot private app token (HubSpot → Settings → Integrations → Private apps), or skip and connect later." }) + "</div>" +
      card("More tools", (cat.items || []).filter((i) => !["gmail", "segment"].includes(i.key)).length ? '<div class="xp-g xp-g3">' + (cat.items || []).filter((i) => !["gmail", "segment"].includes(i.key)).map((i) => { const on = live.find((x) => x.key === i.key);
        return '<div class="xp-card" style="padding:16px;display:grid;gap:10px"><div style="display:flex;align-items:center;gap:12px"><span class="xp-avatar">' + esc(initials(i.name)) + '</span><div style="min-width:0"><b style="font-weight:500">' + esc(i.name) + '</b><p class="xp-note">' + esc(cap(i.category)) + " · " + (i.connects_with === "api_key" ? "API key" : "Sign in") + "</p></div></div>" +
          "<div>" + (on ? status(on.health || on.status) : i.own_app ? chip("Your own app", "violet") : i.available ? chip("Ready", "ok") : chip("Needs your own app", "")) + '</div><div class="xp-card-f" style="margin:0">' + (i.available ? btn("Connect " + i.name, "connect-tool", { sm: true, tone: "primary", data: { key: i.key } }) : "") + (i.supports_own_app ? btn(i.own_app ? "Replace your own app" : "Use your own app", "own-app", { sm: true, data: { key: i.key } }) : "") + "</div></div>"; }).join("") + "</div>" : empty("No catalogue available"),
        { sub: "Microsoft 365, Salesforce, Slack, Zendesk, Intercom, Xero, QuickBooks, Notion and HubSpot. Where Xevrion has no shared app for a tool, your administrator can register one in your own account in a few minutes; it then serves only your organisation." }) + "</div>";
    constellation($("xpConnViz"), { centre: { value: live.length, label: "Connected" }, labelRoom: 96, rings: [(cat.items || []).slice(0, 12).map((i) => { const on = live.find((x) => x.key === i.key); return { id: i.key, label: i.name, sub: on ? cap(on.health) : i.available ? "Ready" : "Available", tone: on ? (on.health === "healthy" ? "ok" : "warn") : "muted", weight: on ? 0.8 : 0.2 }; })],
      links: live.map((x) => [x.key, "c", 0.8, x.health === "healthy" ? "ok" : "warn"]) });
  }
  function ownAppGuide(key) {
    api(O("/integrations/" + key + "/own-app")).then((g) => {
      const OPT = { tenant: "Directory (tenant) ID", subdomain: "Your subdomain (acme in acme.zendesk.com)" };
      drawer({ title: "Use your own app", sub: cap(key) + " · the app lives in your own vendor account and serves only your organisation.", body: '<ol style="display:grid;gap:8px;padding-left:18px;list-style:decimal;color:var(--t2);font-size:13.5px">' + (g.steps || []).map((s) => "<li>" + esc(s) + "</li>").join("") + "</ol>" +
        '<div class="xp-form">' + field({ name: "redirect", label: "Redirect URI to register", value: g.redirect_uri, readonly: true }) + field({ name: "client_id", label: "Client ID", attrs: ' autocomplete="off"' }) + field({ name: "client_secret", label: "Client secret", type: "password", attrs: ' autocomplete="new-password"' }) + (g.required_options || []).map((o) => field({ name: "opt_" + o, label: OPT[o] || cap(o) })).join("") + "</div><p class=\"xp-note\">Xevrion seals the secret and never shows it again.</p>",
        submitLabel: "Save app", submit: async (v) => { const body = { client_id: String(v.client_id || "").trim(), client_secret: String(v.client_secret || "").trim() }; (g.required_options || []).forEach((o) => { if (String(v["opt_" + o] || "").trim()) body[o] = String(v["opt_" + o]).trim(); });
          await api(O("/integrations/" + key + "/own-app"), { method: "PUT", body: JSON.stringify(body) }); toast("Saved. You can now connect.", "ok"); reload(); } });
    }).catch((e) => toast(e.message, "risk"));
  }

  // ================================================================ page: team & access
  async function pageTeam(main) {
    const t = await api(O("/team")); const members = t.members || [], invites = t.invitations || [], active = members.filter((m) => m.status === "active");
    const roles = {}; active.forEach((m) => (roles[m.role] = (roles[m.role] || 0) + 1));
    const others = active.filter((m) => m.role !== "OWNER"), owner = S.grants.includes("*");
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Team & access · who can do what", title: active.length + " people with access.", lead: "Members only see and do what their role allows. Every change is recorded in the audit trail.", meta: chip(active.length + " active", "violet") + chip(invites.length + " invitations pending", invites.length ? "warn" : "") + chip(Object.keys(roles).length + " roles in use", ""), actions: btn("Invite a team member", "scroll", { tone: "primary", ic: "plus", data: { to: "xpInvite" } }), viz: "xpTeamViz" }) +
      '<div class="xp-g xp-g-main">' + card("People with access", '<div class="xp-list">' + members.map((m) => '<div class="xp-li"' + (m.status === "active" && m.role !== "OWNER" ? ' data-row data-act="member" data-id="' + esc(m.account_id) + '"' : "") + '><span class="xp-avatar">' + esc(initials(m.display_name)) + "</span><div><b>" + esc(m.display_name || m.account_id) + "</b><small>" + esc(m.joined_at ? "Joined " + ago(m.joined_at) : "Member") + "</small></div>" + chip(cap(m.role), m.role === "OWNER" ? "violet" : "", false) + status(m.status) + "</div>").join("") + "</div>", { sub: "Select a member to change their role or remove them." }) +
      card("Roles in use", donut(Object.entries(roles).map(([k, v], i) => ({ label: cap(k), value: v, color: ["violet", "info", "ok", "pale", "warn", "white", "muted"][i % 7] })), { centre: fmtN(active.length), sub: "MEMBERS" })) + "</div>" +
      '<div class="xp-g xp-g2">' + card("Invite a team member", '<div class="xp-form">' + field({ name: "inv_email", label: "Email", type: "email" }) + field({ name: "inv_role", label: "Role", type: "select", options: ["ANALYST", "OPERATOR", "APPROVER", "BILLING", "READ_ONLY", "ADMIN"].map((r) => [r, cap(r) + " · " + ROLES[r].join(", ")]) }) + '</div><div class="xp-card-f">' + btn("Send invitation", "invite", { tone: "primary", ic: "mail" }) + "</div>", { id: "xpInvite", sub: "The invitation expires in 7 days." }) +
      card("Pending invitations", invites.length ? '<div class="xp-list">' + invites.map((i) => '<div class="xp-li"><span class="xp-ico">' + icon("mail") + "</span><div><b>" + esc(i.email) + "</b><small>" + esc(cap(i.role)) + " · expires " + esc(ago(i.expires_at)) + "</small></div>" + btn("Resend", "inv-resend", { sm: true, data: { id: inviteId(i) } }) + btn("Revoke", "inv-revoke", { sm: true, tone: "danger", data: { id: inviteId(i) } }) + "</div>").join("") + "</div>" : empty("No invitations pending"),
        { actions: btn("Accept an invitation", "inv-accept", { sm: true }) }) + "</div>" +
      card("Roles and permissions", '<div class="xp-table-wrap"><table class="xp-table"><thead><tr><th>Permission</th>' + Object.keys(ROLES).map((r) => "<th>" + esc(cap(r)) + "</th>").join("") + "</tr></thead><tbody>" + PERMS.map(([p, l]) => "<tr><td>" + esc(l) + "</td>" + Object.keys(ROLES).map((r) => { const has = ROLE_PERMS[r].includes("*") || ROLE_PERMS[r].includes(p) || p === "dashboard.read"; return "<td>" + (has ? '<span style="color:var(--ok)">' + icon("check", 16) + "</span>" : '<span style="color:var(--t3)">—</span>') + "</td>"; }).join("") + "</tr>").join("") + "</tbody></table></div>", { sub: "What each role can do, exactly as the platform enforces it." }) +
      (owner && others.length ? card("Transfer organisation ownership", '<p class="xp-note">Your role becomes administrator. The new owner receives all organisation permissions.</p><div class="xp-card-f">' + btn("Transfer ownership", "transfer", { tone: "danger", ic: "key" }) + "</div>") : "") + "</div>";
    S.team = { members, invites };
    constellation($("xpTeamViz"), { centre: { value: active.length, label: "Members" }, labelRoom: 100, rings: [active.slice(0, 12).map((m) => ({ id: m.account_id, label: m.display_name || "Member", sub: cap(m.role), tone: m.role === "OWNER" ? "violet" : m.role === "ADMIN" ? "pale" : "info", weight: m.role === "OWNER" ? 1 : 0.5 }))], links: active.slice(0, 12).map((m) => [m.account_id, "c", 0.5, "violet"]) });
  }
  const inviteId = (i) => i.invite_id || i.id || "";

  // ================================================================ page: account security
  async function pageSecurity(main) {
    const s = await api("/v1/customer/saas/sessions"); const rows = (s.items || []).slice().sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    const live = rows.filter((r) => !r.revoked && (!r.expires_at || dateOf(r.expires_at) > new Date()));
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Account security · your own account", title: "Protect your account.", lead: "Set up an authenticator for your own sign-in regardless of your organisation role, and see every session signed in as you.", meta: chip(live.length + " active sessions", "violet"), solo: true }) +
      '<div class="xp-g xp-g2">' + card("Authenticator (MFA)", '<div id="xpMfa"><p class="xp-note">Scan the setup secret into an authenticator app, then confirm a six-digit code. Save the recovery codes offline.</p><div class="xp-card-f">' + btn("Set up authenticator", "mfa-begin", { tone: "primary", ic: "shield" }) + btn("Disable authenticator", "mfa-disable", { tone: "danger" }) + btn("Cancel unfinished setup", "mfa-cancel", { tone: "ghost" }) + "</div></div>", { sub: "The setup secret is shown once." }) +
      card("Sessions", '<div class="xp-list">' + rows.map((r) => '<div class="xp-li"><span class="xp-ico" data-tone="' + (r.revoked ? "" : "ok") + '">' + icon(r.revoked ? "lock" : "user") + "</span><div><b>Signed in " + esc(ago(r.created_at)) + "</b><small>" + esc(r.revoked ? "Signed out " + ago(r.revoked_at) : "Expires " + ago(r.expires_at)) + "</small></div>" + (r.revoked ? chip("Signed out", "") : chip("Active", "ok")) + "</div>").join("") + "</div>" +
        '<div class="xp-card-f">' + btn("Sign out other sessions", "revoke-others", { ic: "logout" }) + "</div>", { sub: "Every session for your account, newest first." }) + "</div></div>";
  }

  // ================================================================ page: billing
  // How to pay an open invoice, by rail: a standing order shows the receiving account and the fixed reference and has
  // no link; a payment-link invoice shows its link only when it really is a Monzo HTTPS link.
  function payHow(x) {
    const pi = x.payment_instructions || {}, url = String(x.payment_url || pi.url || ""), link = /^https:\/\/(www\.)?monzo\.com\//.test(url) ? url : "";
    if (pi.method === "standing_order") return { link: "", text: "Set up " + (pi.frequency === "annual" ? "an annual" : "a monthly") + " standing order to " + (pi.account_name || "the account on your invoice") + " · sort code " + (pi.sort_code || "on your invoice") + " · account number " + (pi.account_number || "on your invoice") + " · reference " + (pi.reference || x.reference) };
    return { link, text: link ? "Pay with the Monzo payment link and keep the reference shown." : "Quote this reference when you pay." };
  }
  async function pageBilling(main) {
    const sub = S.dash.subscription || {}, ent = sub.entitlements || {}, owner = sub.plan === "OWNER";
    const inv = await settle(api(O("/invoices"))); const items = inv.ok ? inv.v.items || [] : [];
    const open = items.filter((x) => x.status === "open");
    const PLANS = [["START", "Start", "1 service · 3 people · 3 tools"], ["GROWTH", "Growth", "2 services · 15 people · 12 tools"], ["SCALE", "Scale", "4 services · 50 people · 50 tools · scenarios"]];
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Billing · plan and invoices", title: owner ? "Owner organisation: every service included." : sub.plan ? cap(sub.plan) + " plan." : "Choose a plan to begin.", lead: owner ? "This is the owner's own organisation: every service with no plan limits and nothing to bill or renew." : "Payment is completed only through the configured billing provider. Xevrion never collects card or bank credentials.",
      meta: status(sub.status || "not_subscribed") + (sub.billing_cycle ? chip(cap(sub.billing_cycle) + " billing", "") : "") + (sub.paid_through ? chip("Paid through " + dayLabel(sub.paid_through), "ok") : "") + (open.length ? chip(open.length + " open invoice" + (open.length > 1 ? "s" : ""), "warn") : ""), solo: true }) +
      '<div class="xp-g xp-g-main">' + card("Your plan", statsRow([["Plan", esc(cap(sub.plan || "None"))], ["Status", status(sub.status || "not_subscribed")], ["Services", fmtN((sub.modules || []).length) + "<small style=\"font-size:13px;color:var(--t3)\"> of " + fmtN(ent.modules || 4) + "</small>"]]) +
        '<div class="xp-card-f">' + (sub.modules || []).map((m) => chip(modLabel(m), "violet")).join("") + "</div>" + '<div style="margin-top:18px">' + statsRow([["People", ent.team], ["Connected tools", ent.integrations], ["Workflows", ent.workflows], ["AI calls a day", ent.ai_calls_per_day]].filter((x) => x[1] !== undefined).map(([l, v]) => [l, esc(compact(v))])) + "</div>", { sub: "Purchased entitlements. Plan changes start at the next paid period." }) +
      card("Invoices", '<div style="display:grid;justify-items:center">' + donut(["open", "paid", "void"].map((k, i) => ({ label: cap(k), value: items.filter((x) => x.status === k).length, color: ["warn", "ok", "muted"][i] })), { centre: fmtN(items.length), sub: "INVOICES" }) + "</div>") + "</div>" +
      (open.length ? card("Payment due", open.map((x) => { const how = payHow(x); return '<div class="xp-li" style="align-items:flex-start"><span class="xp-ico" data-tone="warn">' + icon("card") + "</span><div><b>Pay " + esc(money(num(x.amount_pence) / 100, x.currency)) + " using reference " + esc(x.reference) + "</b><small>" + esc(how.text) + "</small></div>" + (how.link ? '<a class="xp-btn xp-btn--primary xp-btn--sm" href="' + esc(how.link) + '" target="_blank" rel="noopener noreferrer">' + icon("external", 16) + "Open Monzo payment</a>" : "") + "</div>"; }).join("") + '<p class="xp-note" style="margin-top:10px">Payment is confirmed against money received. Cancel standing orders in your banking app.</p>', { sub: "Open invoices and how to pay them." }) : "") +
      card("Invoice history", table(items.slice().reverse(), [{ label: "Reference", render: (r) => '<span class="xp-mono">' + esc(r.reference) + "</span>" }, { label: "Amount", num: true, render: (r) => esc(money(num(r.amount_pence) / 100, r.currency)) }, { label: "Status", render: (r) => status(r.status) }, { label: "Service period ends", render: (r) => esc(dayLabel(r.period_end)) },
        { label: "Documents", render: (r) => (r.commercial_document ? '<a class="xp-btn xp-btn--sm" href="' + esc(S.demo ? "#" : O("/invoices/" + encodeURIComponent(r.id) + "/document")) + '" target="_blank" rel="noopener noreferrer">Invoice ' + esc(r.commercial_document.number) + "</a>" : '<span class="xp-note">Tax review pending</span>') + (r.adjustments || []).filter((c) => c.kind === "credit_note" && c.commercial_document).map((c) => ' <a class="xp-btn xp-btn--sm" href="' + esc(S.demo ? "#" : O("/invoices/" + encodeURIComponent(r.id) + "/document?credit_note_id=" + encodeURIComponent(c.id))) + '" target="_blank" rel="noopener noreferrer">Credit note ' + esc(c.number) + "</a>").join("") }], { key: "id", emptyText: "No invoices yet." }),
        { sub: "Refunds are not automatic; disputes need operator review." }) +
      (owner ? "" : card("Change plan or services", (S.wantPlan && !sub.plan ? '<p class="xp-note" style="margin-bottom:12px">' + chip("You chose " + PLAN_NAMES[S.wantPlan] + " on the website", "violet") + "</p>" : "") + '<div class="xp-form"><div class="xp-options">' + PLANS.map(([k, l, d]) => '<label class="xp-option"><input type="radio" name="plan" value="' + k + '"' + ((sub.plan || S.wantPlan || "GROWTH") === k ? " checked" : "") + "><span><b>" + esc(l) + "</b><small>" + esc(d) + "</small></span></label>").join("") + "</div>" +
        field({ name: "cycle", label: "Billing cycle", type: "select", options: [["monthly", "Monthly"], ["annual", "Annual"]], value: sub.billing_cycle || "monthly" }) + '<div class="xp-options">' + MODULE_IDS.map((m) => '<label class="xp-option"><input type="checkbox" name="modules" data-multi="1" value="' + m + '"' + ((sub.modules || ["revenue"]).includes(m) ? " checked" : "") + "><span><b>" + esc(MODULES[m].label) + "</b><small>" + esc(CONFIGS[m].intro.split(".")[0]) + "</small></span></label>").join("") + "</div></div>" +
        '<div class="xp-card-f">' + btn("Review payment", "plan-change", { tone: "primary", ic: "card" }) + btn("Cancel service", "cancel-service", { tone: "danger" }) + "</div>", { id: "xpPlan", sub: "Changing services creates a Monzo invoice; access starts only after settlement is confirmed." })) + "</div>";
  }

  // ================================================================ page: notifications
  async function pageNotifications(main) {
    const [r, pref] = await Promise.all([api(O("/notifications")), settle(api(O("/notification-preferences")))]); const items = (r.items || []).slice().reverse(), p = pref.ok ? pref.v : { email: true, in_app: true, minimum_priority: "normal" };
    const groups = {}; items.forEach((n) => (groups[dayLabel(n.at)] = groups[dayLabel(n.at)] || []).push(n));
    const pr = {}; items.forEach((n) => (pr[n.priority || "normal"] = (pr[n.priority || "normal"] || 0) + 1));
    store.set("xevrion.seen", new Date().toISOString()); updateBadges({ notifications: { n: 0 } });
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Notifications · what happened and when", title: items.length + " recent notifications.", lead: "Operations completing, approvals requested and decided, billing events and support replies — filtered by your own preferences.", meta: Object.entries(pr).map(([k, v]) => chip(v + " " + k, k === "critical" || k === "high" ? "warn" : "")).join(""), solo: true }) +
      '<div class="xp-g xp-g-main">' + card("Timeline", Object.keys(groups).length ? Object.entries(groups).map(([dname, ns]) => '<p class="xp-tag" style="margin:14px 0 4px;font:500 10.5px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--t3)">' + esc(dname) + '</p><div class="xp-list">' + ns.map((n) => '<div class="xp-li"><span class="xp-ico" data-tone="' + (["high", "critical"].includes(n.priority) ? "warn" : "") + '">' + icon(/approval/.test(n.event) ? "approve" : /billing|subscription/.test(n.event) ? "card" : /support/.test(n.event) ? "chat" : /operation/.test(n.event) ? "flow" : "bell") + "</span><div><b>" + esc(cap(n.event)) + "</b><small>" + esc(when(n.at)) + "</small></div>" + chip(cap(n.priority || "normal"), ["high", "critical"].includes(n.priority) ? "warn" : "") + "</div>").join("") + "</div>").join("") : empty("Nothing to show", "Notifications appear here as your services run.")) +
      card("Your preferences", '<div class="xp-form">' + field({ name: "email", label: "Email", type: "checkbox", value: p.email }) + field({ name: "in_app", label: "In-app", type: "checkbox", value: p.in_app }) + field({ name: "minimum_priority", label: "Minimum priority", type: "select", options: ["low", "normal", "high", "critical"], value: p.minimum_priority }) + '</div><div class="xp-card-f">' + btn("Save preferences", "prefs", { tone: "primary" }) + "</div>", { id: "xpPrefs", sub: "Applies to your own account only." }) + "</div></div>";
  }

  // ================================================================ page: support
  async function pageSupport(main) {
    const r = await api(O("/support")); const items = (r.items || []).slice().sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    const openN = items.filter((x) => !["resolved", "confirmed", "closed"].includes(x.status)).length; updateBadges({ support: { n: openN, t: "violet" } });
    const sel = items.find((x) => x.id === S.supportSel) || items[0];
    const thread = (x) => { if (!x) return empty("Choose a conversation");
      const msgs = [{ by: x.created_by === "operator" ? "op" : "me", message: x.message, at: x.created_at }].concat((x.messages || []).map((m) => ({ by: m.by === "operator" ? "op" : "me", message: m.message, at: m.at })), (x.history || []).map((h) => ({ by: "event", message: cap(h.status) + ": " + h.note, at: h.at }))).sort((a, b) => String(a.at).localeCompare(String(b.at)));
      return '<div class="xp-card-h"><div><h3>' + esc(x.subject) + "</h3><p>" + esc(cap(x.priority || "normal")) + " priority · response due within " + esc(x.response_due_hours || 24) + " hours · opened " + esc(ago(x.created_at)) + "</p></div>" + status(x.status) + '</div><div class="xp-thread">' + msgs.map((m) => '<div class="xp-msg" data-by="' + (m.by === "me" ? "me" : m.by === "event" ? "event" : "op") + '"><small>' + (m.by === "me" ? "You" : m.by === "event" ? "Update" : "Xevrion support") + " · " + esc(when(m.at)) + "</small>" + esc(m.message) + "</div>").join("") + "</div>" +
        (["closed", "confirmed"].includes(x.status) ? '<p class="xp-note" style="margin-top:14px">This conversation is closed. Start a new request if you need more help.</p>' : '<div class="xp-form" style="margin-top:16px">' + field({ name: "reply", label: "Reply", type: "textarea", rows: 3 }) + '<div class="xp-card-f" style="margin:0">' + btn("Send reply", "reply", { tone: "primary", data: { id: x.id } }) + btn("Confirm resolution", "confirm-support", { data: { id: x.id }, disabled: x.status !== "resolved" }) + "</div></div>"); };
    S.support = items;
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Support · answered in writing", title: openN ? openN + " open conversation" + (openN > 1 ? "s" : "") + "." : "No open conversations.", lead: "Every request is recorded against this organisation so the team works from the right context. Urgent requests alert the team straight away.", meta: chip(items.length + " conversations", "violet"), actions: btn("Ask Xevrion support", "support-new", { tone: "primary", ic: "chat" }), solo: true }) +
      '<div class="xp-split"><section class="xp-card" style="padding:10px"><div class="xp-list">' + (items.length ? items.map((x) => '<div class="xp-li" data-row data-act="support-open" data-id="' + esc(x.id) + '" style="padding:12px;border-radius:9px;' + (sel && x.id === sel.id ? "background:rgba(128,86,255,.12)" : "") + '"><div><b>' + esc(x.subject) + "</b><small>" + esc(ago(x.created_at)) + " · " + ((x.messages || []).length + 1) + " messages</small></div>" + status(x.status) + "</div>").join("") : empty("No conversations yet", "Ask a question and it appears here.")) + "</div></section>" +
      '<section class="xp-card" id="xpThread">' + thread(sel) + "</section></div></div>";
  }

  // ================================================================ page: data & closure
  async function pageData(main) {
    const [ret, inv] = await Promise.all([settle(api(O("/retention-policy"))), settle(api(O("/privacy-inventory")))]); const R = ret.ok ? ret.v : {}, INV = inv.ok ? inv.v : null;
    const cats = INV ? Object.entries(INV).filter(([k, v]) => Array.isArray(v) && k !== "tombstones").slice(0, 8) : [];
    main.innerHTML = '<div class="xp-page">' + hero({ eyebrow: "Data & closure · your records, your control", title: "Export, retention and closure.", lead: "Download everything available to your organisation, see how long each kind of record is kept, and close the organisation when you choose. Legal holds override expiry; this is not a complete-erasure guarantee.", meta: chip(R.approved ? "Policy approved" : "Policy awaiting review", R.approved ? "ok" : "warn") + chip("Backup erasure not verified", ""), solo: true }) +
      '<div class="xp-g xp-g3">' + kpi("Financial records", fmtN(R.financial_years) + "<small>years</small>", "After the accounting year end", { ic: "card", tone: "violet" }) + kpi("Operational recovery", fmtN(R.operational_recovery_days) + "<small>days</small>", "Recovery target", { ic: "refresh" }) + kpi("Backups", fmtN(R.backup_max_days) + "<small>days</small>", "Backup retention target", { ic: "archive" }) + "</div>" +
      (cats.length ? card("What is held", bars(cats.map(([k, v]) => ({ label: cap(k), value: v.length, text: v.length + " kinds" }))), { sub: "From the privacy inventory." }) : "") +
      '<div class="xp-g xp-g2">' + card("Export your organisation", '<p class="xp-note">Includes domain records and accounting history available to this organisation, as JSON.</p><div class="xp-card-f">' + btn("Download organisation export", "export", { tone: "primary", ic: "download" }) + "</div>") +
      // closure stops billing, so it needs billing.manage (the owner); completing deletion needs the owner role itself
      card("Close the organisation", may("billing.manage") ? '<p class="xp-note">Only the owner can complete deletion. Cancel any bank standing order separately. Backups follow the declared retention policy.</p><div class="xp-form" style="margin-top:12px">' + field({ name: "closure_id", label: "Offboarding request ID", value: S.closureId || "" }) + '</div><div class="xp-card-f">' + btn("Request offboarding", "close-start", { tone: "danger" }) + btn("Check closure status", "close-status") + (S.grants.includes("*") ? btn("Complete deletion after retention review", "close-delete", { tone: "danger" }) : "") + '</div><div id="xpClosure"></div>'
        : '<p class="xp-note">Closing the organisation stops billing, so only the organisation owner can request it. Ask your owner if this organisation should close.</p>') + "</div></div>";
  }

  const RENDER = { home: pageHome, systems: pageSystems, revenue: pageService, customer_operations: pageService, business_intelligence: pageService, business_operations: pageBusiness, value: pageValue, optimisation: pageOptimisation, usage: pageUsage, setup: pageSetup, connections: pageConnections, team: pageTeam, security: pageSecurity, billing: pageBilling, notifications: pageNotifications, support: pageSupport, data: pageData };

  // ================================================================ actions (delegated)
  const val = (name, scope) => { const el = (scope || S.root).querySelector('[name="' + name + '"]'); return el ? (el.type === "checkbox" ? el.checked : el.value) : ""; };
  const ACT = {
    menu() { const x = S.root.querySelector(".xp"); x.dataset.nav = x.dataset.nav === "open" ? "closed" : "open"; },
    cmd: () => palette(),
    refresh: async (b) => { b.dataset.spin = ""; try { await reload(); toast("Up to date.", "ok", 1800); } finally { delete b.dataset.spin; } },
    retry: () => reload(),
    scroll: (b) => { const el = $(b.dataset.to); if (el) el.scrollIntoView({ behavior: reduced() ? "auto" : "smooth", block: "start" }); },
    op: (b) => operationDetail(b.dataset.id),
    launcher: (b) => { const m = b.dataset.module, cfg = CONFIGS[m]; const o = drawer({ title: "New " + MODULES[m].label + " action", sub: "Choose what you want Xevrion to do.", body: '<div class="xp-list">' + cfg.actions.map((a) => '<div class="xp-li" data-row data-pick="' + a[0] + '"><span class="xp-ico">' + icon(MODULES[m].icon) + "</span><div><b>" + esc(a[1]) + "</b><small>" + esc(a[2]) + "</small></div>" + icon("arrow") + "</div>").join("") + "</div>" }); o.el.addEventListener("click", (e) => { const r = e.target.closest("[data-pick]"); if (!r) return; o.close(); launch(m, r.dataset.pick); }); },
    launch: (b) => launch(b.dataset.module, b.dataset.action, { program_id: b.dataset.program || "", case_id: b.dataset.case || "" }),
    filter: (b) => { S.filter = { module: b.dataset.module, status: b.dataset.status }; reload(); },
    decide: async (b) => { const approved = b.dataset.ok === "1"; const v = await ask({ title: approved ? "Approve this request?" : "Decline this request?", text: "Your decision and reason are recorded in the audit trail.", confirm: approved ? "Approve" : "Decline", t: approved ? "primary" : "danger", fields: field({ name: "note", label: "Decision reason", type: "textarea", rows: 3 }) }); if (!v) return;
      if (String(v.note || "").trim().length < 3) throw Error("Give a reason of at least three characters"); await post(O("/approvals/" + encodeURIComponent(b.dataset.id)), { approved, note: String(v.note).trim() }); toast(approved ? "Approved." : "Declined.", "ok"); reload(); },
    "proc-edit": (b) => processDesigner(+b.dataset.i),
    "proc-run": (b) => processRun(+b.dataset.i),
    "run-open": (b) => runReview(b.dataset.id),
    "exc-open": (b) => exceptionReview(b.dataset.id),
    "value-new": () => valueNew(),
    "value-outcome": () => valueOutcome(),
    "value-open": (b) => { const x = (S.dash.value_items || []).find((y) => String(y.id) === String(b.dataset.id)); if (x) drawer({ title: x.title || "Outcome", sub: modLabel(x.service) + " · " + cap(x.status), body: evidence(x) }); },
    activate: async () => { await post(O("/activate")); toast("Services activated.", "ok"); go("home"); },
    "setup-save": async () => { const s = $("xpSetup"), v = collect(s), modules = (S.dash.subscription || {}).modules || [];
      const steps = { business: { legal_name: v.legal, industry: v.industry }, goals: { primary_outcome: v.goal }, metrics: { primary_metric: v.metric }, integrations: { selected: String(v.providers || "").split(",").map((x) => x.trim()).filter(Boolean) }, permissions: { confirmed: !!v.authority }, services: { modules }, automation: { schedule: v.schedule }, approvals: { policy: v.policy } };
      for (const [step, values] of Object.entries(steps)) await post(O("/onboarding"), { step, values }); toast("Setup saved. Verify your connections and activate services.", "ok"); reload(); },
    "connect-gmail": async () => { const x = await post(O("/integrations/begin"), { key: "gmail", permissions: String(val("gmailScope")).split(" "), return_url: location.origin + "/app" }); if (S.demo) return toast("Presentation mode: Google sign-in would open here.", "violet"); location.href = x.authorization_url; },
    "connect-tool": async (b) => { const k = b.dataset.key; const x = await post(O("/integrations/begin"), { key: k, permissions: k === "microsoft" ? ["read", "send"] : ["read"], return_url: location.origin + "/app" }); if (S.demo) return toast("Presentation mode: the provider's sign-in would open here.", "violet"); location.href = x.authorization_url; },
    "save-email": async () => { await post(O("/integrations/credential"), { key: "other-email", email: val("oe_email"), app_password: val("oe_password"), imap_host: val("oe_imap") || null, smtp_host: val("oe_smtp") || null, permissions: ["read", "send"] }); toast("Mailbox saved. Verify access to finish.", "ok"); reload(); },
    "save-hubspot": async () => { const t = String(val("hs_token")).trim(); if (!t) throw Error("Paste a HubSpot private app token, or skip for now."); await post(O("/integrations/credential"), { key: "hubspot", private_app_token: t, permissions: ["read"] }); toast("HubSpot saved.", "ok"); reload(); },
    "own-app": (b) => ownAppGuide(b.dataset.key),
    verify: async (b) => { await post(O("/integrations/" + b.dataset.key + "/verify"), { verified: true, evidence: "Customer requested a live provider access check" }); toast("Access verified.", "ok"); reload(); },
    disconnect: async (b) => { if (!(await ask({ title: "Disconnect " + cap(b.dataset.key) + "?", text: "The stored credential is revoked. Consent on the provider's side may still need your action.", confirm: "Disconnect", t: "danger" }))) return;
      const r = await api(O("/integrations/" + b.dataset.key), { method: "DELETE" }); await reload();
      drawer({ title: "Disconnect receipt", sub: cap(b.dataset.key), body: statsRow([["Provider token", esc(cap((r.provider_revocation || {}).status || "not verified"))], ["Consent removed", r.provider_consent_revoked ? "Confirmed" : "Not confirmed"]]) + '<p class="xp-note">' + esc(r.instructions || "") + "</p>" + evidence(r) }); },
    invite: async () => { await post(O("/team/invitations"), { email: val("inv_email"), role: val("inv_role") }); toast("Invitation sent.", "ok"); reload(); },
    "inv-resend": async (b) => { await post(O("/team/invitations/" + encodeURIComponent(b.dataset.id) + "/resend")); toast("Invitation resent.", "ok"); },
    "inv-revoke": async (b) => { if (!(await ask({ title: "Revoke this invitation?", confirm: "Revoke", t: "danger" }))) return; await api(O("/team/invitations/" + encodeURIComponent(b.dataset.id)), { method: "DELETE" }); toast("Invitation revoked.", "ok"); reload(); },
    "inv-accept": async () => { const v = await ask({ title: "Accept an invitation", text: "Paste the invitation code from your email.", confirm: "Accept", fields: field({ name: "code", label: "Invitation code" }) }); if (!v) return; await post("/v1/public/saas/invitations/" + encodeURIComponent(String(v.code).trim()) + "/accept"); await openOrganisations(); },
    member: (b) => { const m = S.team.members.find((x) => x.account_id === b.dataset.id); if (!m) return;
      const o = drawer({ title: m.display_name || m.account_id, sub: "Currently " + cap(m.role), body: field({ name: "role", label: "New role", type: "select", options: ["ADMIN", "OPERATOR", "APPROVER", "ANALYST", "BILLING", "READ_ONLY"].map((r) => [r, cap(r) + " · " + ROLES[r].join(", ")]), value: m.role }), submitLabel: "Change role", secondary: '<button type="button" class="xp-btn xp-btn--danger" data-y="remove">Remove member</button>',
        submit: async (v) => { await api(O("/team/" + encodeURIComponent(m.account_id)), { method: "PATCH", body: JSON.stringify({ role: v.role }) }); toast("Role changed.", "ok"); reload(); } });
      o.el.addEventListener("click", async (e) => { if (!e.target.closest('[data-y="remove"]')) return; if (!(await ask({ title: "Remove this member?", confirm: "Remove", t: "danger" }))) return; try { await api(O("/team/" + encodeURIComponent(m.account_id)), { method: "DELETE" }); o.close(); toast("Member removed.", "ok"); reload(); } catch (err) { toast(err.message, "risk"); } }); },
    transfer: () => { const others = S.team.members.filter((x) => x.status === "active" && x.role !== "OWNER");
      drawer({ title: "Transfer organisation ownership", sub: "Your role becomes administrator. The new owner receives all organisation permissions.", body: field({ name: "account", label: "New owner", type: "select", options: [["", "Choose an active member"]].concat(others.map((x) => [x.account_id, (x.display_name || x.account_id) + " — " + cap(x.role)])) }) + field({ name: "confirm", label: "Type TRANSFER to confirm", attrs: ' autocomplete="off"' }), submitLabel: "Confirm transfer", submitTone: "danger",
        submit: async (v) => { if (!v.account || v.confirm !== "TRANSFER") throw Error("Choose the new owner and type TRANSFER to confirm."); await post(O("/team/transfer-ownership"), { account_id: v.account }); await openOrganisations(); } }); },
    "mfa-begin": async () => { const r = await post("/v1/customer/saas/mfa/enrol");
      $("xpMfa").innerHTML = '<p class="xp-note">Add this secret to your authenticator app. It is shown once.</p><p class="xp-mono" style="padding:12px;border:1px dashed var(--line3);border-radius:9px;word-break:break-all;color:#fff">' + esc(r.mfa_setup_secret) + '</p><div class="xp-form" style="margin-top:12px">' + field({ name: "mfa_code", label: "Six-digit code", attrs: ' inputmode="numeric" maxlength="6"' }) + '</div><div class="xp-card-f">' + btn("Confirm MFA", "mfa-confirm", { tone: "primary" }) + "</div>"; },
    "mfa-confirm": async () => { const r = await post("/v1/customer/saas/mfa/confirm/" + encodeURIComponent(val("mfa_code")));
      drawer({ title: "Save your recovery codes", sub: "MFA is on. Keep these codes offline; each works once.", body: '<div class="xp-json">' + (r.recovery_codes || []).map((c) => "<div>" + esc(c) + "</div>").join("") + "</div>" }); reload(); },
    "mfa-disable": async () => { const v = await ask({ title: "Disable your authenticator?", text: "Confirm with your password and a fresh code. Other sessions are signed out.", confirm: "Disable", t: "danger", fields: field({ name: "password", label: "Password", type: "password" }) + field({ name: "code", label: "Authenticator code or unused recovery code" }) }); if (!v) return;
      const body = { password: v.password }; body[/^\d{6}$/.test(String(v.code)) ? "mfa_code" : "recovery_code"] = v.code; await post("/v1/customer/saas/mfa/disable", body); toast("MFA disabled. Other sessions have been signed out.", "ok"); reload(); },
    "mfa-cancel": async () => { await post("/v1/customer/saas/mfa/cancel-enrolment"); toast("Unfinished setup cancelled.", "ok"); reload(); },
    "revoke-others": async () => { const r = await post("/v1/customer/saas/sessions/revoke-others"); toast(r.revoked + " other session(s) signed out.", "ok"); reload(); },
    "plan-change": async () => { const v = collect($("xpPlan")); if (!(v.modules || []).length) throw Error("Choose at least one service"); await post(O("/subscription"), { plan: v.plan, modules: v.modules, billing_cycle: v.cycle, return_url: location.origin + "/app" }); S.wantPlan = ""; clearPlanQuery(); toast("Invoice created. Pay it to start the new period.", "ok"); reload(); },
    "cancel-service": async () => { if (!(await ask({ title: "Stop Xevrion services?", text: "Automation stops and connections are revoked. You must also cancel any standing order in your banking app.", confirm: "Cancel service", t: "danger" }))) return; const r = await post(O("/cancel")); toast(r.bank_instructions || "Service cancelled. Review your bank standing orders.", "ok", 7000); reload(); },
    prefs: async () => { const v = collect($("xpPrefs")); await post(O("/notification-preferences"), { email: !!v.email, in_app: !!v.in_app, minimum_priority: v.minimum_priority }); toast("Preferences saved.", "ok"); },
    "support-new": () => drawer({ title: "Ask Xevrion support", sub: "Your request is recorded against this organisation so the team can work from the right context.", body: '<div class="xp-form">' + field({ name: "subject", label: "Subject" }) + field({ name: "priority", label: "Priority", type: "select", options: [["low", "Low"], ["normal", "Normal"], ["high", "High"], ["urgent", "Urgent"]], value: "normal" }) + field({ name: "message", label: "What do you need help with?", type: "textarea", rows: 6 }) + "</div>", submitLabel: "Send request",
      submit: async (v) => { const r = await post(O("/support"), { subject: v.subject, message: v.message, priority: v.priority }); S.supportSel = r.id; toast("Request sent.", "ok"); reload(); } }),
    "support-open": (b) => { S.supportSel = b.dataset.id; reload(); },
    reply: async (b) => { const x = S.support.find((y) => y.id === b.dataset.id), message = String(val("reply")).trim(); if (!message) throw Error("Write a reply first"); const identity = x.id + message; if (!S.replyKey || S.replyKey.identity !== identity) S.replyKey = { identity, key: uid() };
      await api(O("/support/" + encodeURIComponent(x.id) + "/messages"), { method: "POST", headers: { "Idempotency-Key": S.replyKey.key }, body: JSON.stringify({ message }) }); S.replyKey = null; toast("Reply sent.", "ok"); reload(); },
    "confirm-support": async (b) => { if (!(await ask({ title: "Does this resolution solve your request?", confirm: "Yes, confirm" }))) return; await post(O("/support/" + encodeURIComponent(b.dataset.id)), { status: "confirmed", note: "Customer reviewed and confirmed the resolution" }); toast("Resolution confirmed.", "ok"); reload(); },
    export: async () => { const r = await api(O("/export")); const url = URL.createObjectURL(new Blob([JSON.stringify(r, null, 2)], { type: "application/json" })); const a = document.createElement("a"); a.href = url; a.download = "xevrion-export.json"; a.click(); URL.revokeObjectURL(url); },
    "close-start": async () => { if (!(await ask({ title: "Stop services and begin offboarding?", text: "Services stop and your connections are revoked. Deletion follows the retention review.", confirm: "Begin offboarding", t: "danger" }))) return; const r = await post(O("/offboarding")); S.closureId = r.id; const f = S.root.querySelector('[name="closure_id"]'); if (f) f.value = r.id; await ACT["close-status"](); },
    "close-status": async () => { const id = String(val("closure_id")).trim(); if (!id) throw Error("Enter the offboarding request ID"); const r = await api(O("/offboarding/" + encodeURIComponent(id))); $("xpClosure").innerHTML = '<div style="margin-top:14px">' + statsRow([["Status", status(r.status)], ["Requested", esc(when(r.requested_at))]]) + '<div class="xp-flow" style="margin-top:12px">' + (r.steps || []).map((s, i) => (i ? '<span class="xp-flow-a"></span>' : "") + '<div class="xp-flow-n"><b>' + esc(cap(s)) + "</b></div>").join("") + "</div>" + evidence(r) + "</div>"; },
    "close-delete": async () => { const v = await ask({ title: "Permanently delete eligible data?", text: "Only after the retention review. This cannot be undone.", confirm: "Delete", t: "danger", fields: field({ name: "reason", label: "Reason for deletion", type: "textarea", rows: 2 }) }); if (!v) return;
      const id = String(val("closure_id")).trim(); const r = await post(O("/offboarding/" + encodeURIComponent(id) + "/complete-deletion"), { reason: v.reason }); $("xpClosure").innerHTML = evidence(r); },
  };
  async function guard(el, fn) { if (el.dataset.busy !== undefined) return; el.dataset.busy = ""; try { await fn(); } catch (e) { toast(e.message || String(e), "risk", 6000); } finally { delete el.dataset.busy; } }

  // ================================================================ sign in, create account, recover
  function renderAuth(tab = "signin", message = "") {
    stopViz();
    S.root.innerHTML = '<div class="xp"><div class="xp-grid-bg"></div><div class="xp-auth"><section class="xp-auth-viz"><div class="xp-viz" id="xpAuthViz"></div><div class="xp-auth-copy"><p class="xp-eyebrow">Xevrion Ops · Customer portal</p><h2>Your business, running in one place.</h2><p>Revenue, customers, operations and decisions — every action, approval and result recorded with its evidence.</p></div></section>' +
      '<section class="xp-auth-panel"><div class="xp-auth-card"><a class="xp-brand" style="padding:0;border:0;height:auto" href="#">' + MARK + "<b>XEVRION</b><span>OPS</span></a>" +
      '<div class="xp-tabs" role="tablist">' + [["signin", "Sign in"], ["create", "Create account"], ["recover", "Recover"]].map(([k, l]) => '<button type="button" role="tab" data-act="auth-tab" data-tab="' + k + '" aria-selected="' + (k === tab) + '">' + l + "</button>").join("") + "</div>" +
      '<div id="xpAuthBody" class="xp-form"></div><p class="xp-err" id="xpAuthErr" role="alert">' + esc(message) + '</p><p class="xp-note">Private to your organisation. Sessions use secure cookies; nothing is kept in this browser\'s storage except your chosen organisation.</p><div class="xp-toasts" id="xpToasts"></div></div></section></div></div>';
    authBody(tab);
    constellation($("xpAuthViz"), { mark: true, cy: 0.5, coreSize: 0.13, floorEl: S.root.querySelector(".xp-auth-copy"), labelRoom: 110, maxPulses: 20, rings: [MODULE_IDS.map((m) => ({ id: m, label: MODULES[m].label, sub: MODULES[m].verb, tone: "violet", weight: 0.7 })), ["Approvals", "Value ledger", "Connections", "Evidence", "Support", "Billing"].map((l, i) => ({ id: "s" + i, label: l, tone: ["warn", "ok", "info", "pale", "pale", "info"][i], weight: 0.35 }))],
      links: MODULE_IDS.map((m) => [m, "c", 0.8, "violet"]).concat([0, 1, 2, 3, 4, 5].map((i) => ["s" + i, MODULE_IDS[i % 4], 0.4, "pale"])) });
  }
  function authBody(tab) {
    const b = $("xpAuthBody"); if (!b) return; S.authTab = tab;
    if (tab === "signin") b.innerHTML = "<h1>Sign in to your workspace</h1>" + planNote() + field({ name: "email", label: "Email", type: "email", placeholder: "you@company.com", attrs: ' autocomplete="email"' }) + field({ name: "password", label: "Password", type: "password", attrs: ' autocomplete="current-password"' }) + field({ name: "mfa", label: "Extra code", hint: "only if you turned this on", placeholder: "6-digit or recovery code", attrs: ' autocomplete="one-time-code"' }) +
      '<button type="button" class="xp-btn xp-btn--primary" data-click="signin()" style="height:44px">Sign in</button>';
    if (tab === "create") b.innerHTML = "<h1>Create your account</h1>" + planNote() + field({ name: "name", label: "Your name", attrs: ' autocomplete="name"' }) + field({ name: "email", label: "Email", type: "email", attrs: ' autocomplete="email"' }) + field({ name: "password", label: "Password", hint: "at least 12 characters", type: "password", attrs: ' autocomplete="new-password"' }) +
      btn("Create account", "signup", { tone: "primary" }) + field({ name: "verify", label: "Email verification code", placeholder: "From the email we send" }) + '<div class="xp-form xp-form-2">' + btn("Verify email", "verify-email") + btn("Send a new code", "verify-resend", { tone: "ghost" }) + "</div>" +
      '<p class="xp-note">No code, or it has expired? Enter your email above and send a new one.</p>';    if (tab === "recover") b.innerHTML = "<h1>Recover your account</h1>" + field({ name: "email", label: "Email", type: "email", attrs: ' autocomplete="email"' }) + btn("Email a password reset code", "reset-send", { tone: "primary" }) + field({ name: "reset", label: "Password reset code" }) + field({ name: "password", label: "New password", hint: "at least 12 characters", type: "password", attrs: ' autocomplete="new-password"' }) + btn("Set the new password", "reset-finish");
    setTimeout(() => { const f = b.querySelector("input"); if (f) f.focus(); }, 30);
  }
  const authErr = (m, ok) => { const e = $("xpAuthErr"); if (e) { e.textContent = m; e.style.color = ok ? "var(--ok)" : ""; } };
  // the plan chosen on the website, carried through sign-up, verification, sign-in and organisation creation
  const planNote = () => (S.wantPlan ? '<p class="xp-note">' + chip("You chose " + PLAN_NAMES[S.wantPlan] + " on the website", "violet") + " You confirm it in Billing once your organisation exists.</p>" : "");
  const switchAuth = (tab) => { S.root.querySelectorAll("[data-tab]").forEach((x) => x.setAttribute("aria-selected", String(x.dataset.tab === tab))); authErr(""); authBody(tab); };
  Object.assign(ACT, {
    "auth-tab": (b) => switchAuth(b.dataset.tab),
    signup: async () => { try { await post("/v1/public/saas/signup", { email: val("email"), password: val("password"), name: val("name") }); authErr("Check your email for the verification code.", true); } catch (e) { authErr(e.message); } },
    "verify-email": async () => { const email = String(val("email") || "").trim(), code = String(val("verify") || "").trim(); if (!code) return authErr("Enter the verification code from the email we sent.");
      try { await post("/v1/public/saas/verify-email/" + encodeURIComponent(code)); } catch (e) { return authErr(e.message); }
      switchAuth("signin"); const f = S.root.querySelector('#xpAuthBody [name="email"]'); if (f && email) { f.value = email; setTimeout(() => { const p = S.root.querySelector('#xpAuthBody [name="password"]'); if (p) p.focus(); }, 60); }
      authErr("Email verified. Sign in to continue" + (S.wantPlan ? " with the " + PLAN_NAMES[S.wantPlan] + " plan." : "."), true); },
    // POST /v1/public/saas/verify-email/resend always answers 202 {sent: true}, whether or not the account exists
    "verify-resend": async () => { const email = String(val("email") || "").trim(); if (!email) return authErr("Enter the email address you signed up with, then send a new code.");
      try { await post("/v1/public/saas/verify-email/resend", { email }); authErr("If that account is waiting for verification, a new code is on its way. Use the newest code.", true); } catch (e) { authErr(e.message); } },
    "reset-send": async () => { try { await post("/v1/public/saas/password-reset", { email: val("email") }); authErr("If the account exists, a reset code has been emailed.", true); } catch (e) { authErr(e.message); } },
    "reset-finish": async () => { try { await post("/v1/public/saas/password-reset/" + encodeURIComponent(val("reset")), { password: val("password") }); authErr("Password updated. Sign in again.", true); } catch (e) { authErr(e.message); } },
    org: (el) => { store.set("xevrion.org", el.value); openOrganisations(); },
    "create-org": async () => { const r = await post("/v1/customer/saas/organizations", { name: val("org_name"), website: val("org_site") || null }); store.set("xevrion.org", r.id); await openOrganisations(); },
    "create-accept": async () => { await post("/v1/public/saas/invitations/" + encodeURIComponent(String(val("org_invite")).trim()) + "/accept"); await openOrganisations(); },
  });
  async function signin() {
    const body = { email: val("email"), password: val("password") }, code = String(val("mfa") || "").trim(); if (code) body[/^\d{6}$/.test(code) ? "mfa_code" : "recovery_code"] = code;
    try { await api("/v1/public/saas/login", { method: "POST", headers: { "X-Xevrion-Browser": "1" }, body: JSON.stringify(body) }); await openOrganisations(); }
    catch (e) { authErr(e.status === 403 && /verif/i.test(e.message || "") ? "Verify your email first: open Create account, enter the code we emailed you, or send a new code." : e.message); }
  }
  async function logout() { if (S.demo) return toast("Presentation mode: signing out is disabled.", "violet"); try { await post("/v1/customer/saas/logout"); } finally { location.reload(); } }
  function renderCreateOrg() {
    stopViz();
    S.root.innerHTML = '<div class="xp"><div class="xp-grid-bg"></div><div class="xp-auth"><section class="xp-auth-viz"><div class="xp-viz" id="xpAuthViz"></div><div class="xp-auth-copy"><p class="xp-eyebrow">One more step</p><h2>Create your organisation.</h2><p>Everything in Xevrion belongs to an organisation: its services, people, connections and records.</p></div></section><section class="xp-auth-panel"><div class="xp-auth-card">' +
      "<h1>Your business</h1>" + planNote() + field({ name: "org_name", label: "Organisation name" }) + field({ name: "org_site", label: "Website", hint: "optional", type: "url" }) + btn("Create organisation", "create-org", { tone: "primary" }) + '<p class="xp-note">Invited to someone else\'s organisation?</p>' + field({ name: "org_invite", label: "Invitation code" }) + btn("Accept invitation", "create-accept") +
      '<div class="xp-card-f" style="margin:0"><button type="button" class="xp-btn xp-btn--ghost xp-btn--sm" data-click="logout()">Sign out</button></div><div class="xp-toasts" id="xpToasts"></div></div></section></div></div>';
    constellation($("xpAuthViz"), { mark: true, coreSize: 0.13, labels: false, floorEl: S.root.querySelector(".xp-auth-copy"), rings: [[0, 1, 2, 3, 4, 5].map((i) => ({ id: "n" + i, label: "", tone: "violet", weight: 0.5 }))], links: [0, 1, 2, 3, 4, 5].map((i) => ["n" + i, "c", 0.6, "violet"]) });
  }
  async function openOrganisations() {
    const r = await api("/v1/customer/saas/organizations"); S.orgs = r.items || [];
    if (!S.orgs.length) return renderCreateOrg();
    const saved = store.get("xevrion.org"), sel = S.orgs.find((x) => x.id === saved) || S.orgs[0]; S.org = sel.id; S.role = sel.role || "";
    const caps = await api(O("/capabilities")); S.grants = caps.permissions || []; S.role = caps.role || S.role;
    renderShell();
    let want = S.startPage || (!S.demo && location.hash.startsWith("#/") ? location.hash.slice(2) : "home");
    // arriving with a plan from the website and no page named: an organisation without a plan opens Billing with it chosen
    if (S.wantPlan && !S.startPage && !location.hash.startsWith("#/") && pageOf("billing")) {
      const d = await settle(api(O("/dashboard"))), sub = d.ok ? d.v.subscription || {} : {};
      if (d.ok && (!sub.plan || ["not_subscribed", "cancelled"].includes(sub.status))) want = "billing";
    }
    await go(pageOf(want) ? want : "home");
    if (S.page === "billing" && S.wantPlan) { const el = $("xpPlan"); if (el) el.scrollIntoView({ block: "start" }); }
  }

  // ================================================================ boot
  P.boot = async function (root, opts = {}) {
    S.root = root; S.api = opts.api || P.fetchApi(); S.demo = !!opts.demo; S.startPage = opts.page || "";
    // Website sign-up links: /app?plan=<start|growth|scale>#signup (or ?signup=1) open Create account with that plan
    // chosen. Read only on the real portal: the website's presentation copy runs this code on pages with other queries.
    if (!S.demo) { const intent = signupIntent(location.search, location.hash); S.wantPlan = intent.plan; S.wantSignup = intent.signup; }
    root.addEventListener("click", (e) => {
      const shell = S.root.querySelector(".xp"); // on phones the side panel is a drawer: a tap outside it closes it
      if (shell && shell.dataset.nav === "open" && !e.target.closest(".xp-side,[data-act=menu]")) { shell.dataset.nav = "closed"; e.preventDefault(); return; }
      const g = e.target.closest("[data-go]"); if (g) { e.preventDefault(); if (g.dataset.go) go(g.dataset.go); return; }
      const a = e.target.closest("[data-act]"); if (a && !a.disabled && ACT[a.dataset.act]) { e.preventDefault(); guard(a, () => ACT[a.dataset.act](a, e)); return; }
      if (S.demo) { const c = e.target.closest("[data-click]"); if (c) { e.preventDefault(); const m = /^(\w+)\(/.exec(c.getAttribute("data-click") || ""); if (m && m[1] === "signin") signin(); if (m && m[1] === "logout") logout(); } }
    });
    root.addEventListener("change", (e) => { const s = e.target.closest("[data-act-change]"); if (s && ACT[s.dataset.actChange]) guard(s, () => ACT[s.dataset.actChange](s)); });
    root.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.closest("#xpAuthBody") && S.authTab === "signin" && e.target.tagName === "INPUT") { e.preventDefault(); signin(); } });
    document.addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k" && S.org && S.root.querySelector(".xp-side") && (!S.demo || S.root.contains(document.activeElement))) { e.preventDefault(); e.stopPropagation(); palette(); } }, true);
    if (!S.demo) window.addEventListener("hashchange", () => { const id = location.hash.slice(2); if (S.org && pageOf(id) && id !== S.page) go(id); });
    if (!S.demo) setInterval(() => { if (S.org && !document.hidden && S.page === "home" && !S.root.querySelector(".xp-drawer,.xp-dialog")) reload(); }, 60000);
    try { await openOrganisations(); } catch (e) { renderAuth(S.wantSignup ? "create" : "signin", e.status === 401 || e.status === 403 ? "" : e.message); }
  };
  // open a page from outside (the website presentation lists every screen)
  P.go = (id) => (S.org ? go(id) : Promise.resolve());
  // the page's dispatcher (portal_security.py) calls these by name for data-click="signin()" / "logout()"
  window.signin = signin;
  window.logout = logout;

})();
