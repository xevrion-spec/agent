// Customer Operations: the Customer Intelligence Orbit. One fictional customer at the centre, seven dimensions
// in orbit. Play or scrub 45 days: signals change -> health changes -> risk emerges -> an intervention is
// recommended and approved -> the outcome is measured. Shape and colour both carry state (triangle = risk).
import { C, clamp, glow, lerp, lifecycle, loop, rgba, stageCanvas } from "./viz-kit.88725e7ff9.js";

const DIMS = ["Usage", "Support", "Goals", "Billing", "Sentiment", "Outcomes", "Renewal"];
const KEYS = ["usage", "support", "goals", "billing", "sentiment", "outcomes", "renewal"];
const FRAMES = [ // day, values (0..1, higher is healthier), health, event, tone
  [0, { usage: 0.8, support: 0.85, goals: 0.72, billing: 0.95, sentiment: 0.78, outcomes: 0.7, renewal: 0.6 }, 82, "Healthy. Nothing needs attention.", "neutral"],
  [3, { usage: 0.7, support: 0.55, goals: 0.7, billing: 0.95, sentiment: 0.6, outcomes: 0.66, renewal: 0.55 }, 74, "Tickets rising and replies slowing. Xevrion is watching.", "neutral"],
  [4, { usage: 0.64, support: 0.28, goals: 0.66, billing: 0.95, sentiment: 0.36, outcomes: 0.6, renewal: 0.5 }, 61, "At risk: tickets tripled, replies slowed to 2 days, renewal in 41 days.", "risk"],
  [5, { usage: 0.64, support: 0.28, goals: 0.66, billing: 0.95, sentiment: 0.36, outcomes: 0.6, renewal: 0.5 }, 61, "Recommended: fix the recurring issue and book a success call. Approved by the account manager.", "risk"],
  [12, { usage: 0.72, support: 0.55, goals: 0.7, billing: 0.95, sentiment: 0.55, outcomes: 0.68, renewal: 0.6 }, 70, "Fix shipped. Tickets falling, replies back to same day.", "neutral"],
  [20, { usage: 0.82, support: 0.86, goals: 0.78, billing: 0.95, sentiment: 0.8, outcomes: 0.8, renewal: 0.85 }, 84, "Recovered. The customer confirms they will renew.", "ok"],
  [45, { usage: 0.83, support: 0.88, goals: 0.8, billing: 0.96, sentiment: 0.82, outcomes: 0.82, renewal: 1 }, 84, "Renewed on time. £7,300 recorded in the Value Ledger as revenue protected.", "ok"],
];

function at(day) {
  let i = 0;
  while (i < FRAMES.length - 1 && FRAMES[i + 1][0] <= day) i++;
  const a = FRAMES[i], b = FRAMES[Math.min(i + 1, FRAMES.length - 1)];
  const t = b[0] === a[0] ? 0 : clamp((day - a[0]) / (b[0] - a[0]));
  const v = {};
  KEYS.forEach((k) => { v[k] = lerp(a[1][k], b[1][k], t); });
  return { v, health: Math.round(lerp(a[2], b[2], t)), event: a[3], tone: a[4], intervention: day >= 5 && day < 20 };
}

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const q = (s) => host.querySelector(s);
  const out = { day: q('[data-o="day"]'), health: q('[data-o="health"]'), event: q('[data-o="event"]') };
  const readout = q("[data-readout]"), slider = q("[data-day]"), sliderOut = q("[data-day-out]"), play = q("[data-play]");
  let day = 0, playing = false, spin = 0;

  const setDay = (d, fromUser) => {
    day = clamp(d, 0, 45);
    const s = at(day);
    slider.value = String(Math.round(day)); sliderOut.textContent = String(Math.round(day));
    out.day.textContent = `Day ${Math.round(day)} of 45`;
    out.health.textContent = String(s.health);
    if (out.event.textContent !== s.event) out.event.textContent = s.event;
    readout.dataset.tone = s.tone;
    if (fromUser) { playing = false; play.querySelector("span").textContent = "Play 45 days"; }
    if (reduced) frame(0, 0);
  };
  slider.addEventListener("input", () => { setDay(+slider.value, true); track?.("viz_interact:orbit", true); });
  play.addEventListener("click", () => {
    playing = !playing;
    if (playing && day >= 45) day = 0;
    play.querySelector("span").textContent = playing ? "Pause" : "Play 45 days";
    track?.("viz_interact:orbit", true);
    if (reduced && playing) { setDay(45); playing = false; play.querySelector("span").textContent = "Play 45 days"; }
  });

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    if (playing) { setDay(day + dt * 3.2); if (day >= 45) { playing = false; play.querySelector("span").textContent = "Replay"; } }
    spin += reduced ? 0 : dt * 0.05;
    const s = at(day);
    const cx = w * (w < 640 ? 0.5 : 0.56), cy = h * 0.47, R = Math.min(w * 0.36, h * 0.34);
    ctx.clearRect(0, 0, w, h);
    // orbit path
    ctx.strokeStyle = rgba(C.text1, 0.07); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.ellipse(cx, cy, R, R * 0.82, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(cx, cy, R * 0.55, R * 0.45, 0, 0, Math.PI * 2); ctx.stroke();
    // centre: the customer, ring = health
    const hcol = s.health < 66 ? C.risk : s.health >= 80 ? C.text1 : C.violetPale;
    glow(ctx, cx, cy, 70, s.tone === "risk" ? C.risk : C.violet, 0.55);
    ctx.fillStyle = rgba(C.bg, 0.9); ctx.beginPath(); ctx.arc(cx, cy, 38, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = rgba(C.text1, 0.12); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, cy, 38, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = hcol; ctx.beginPath(); ctx.arc(cx, cy, 38, -Math.PI / 2, -Math.PI / 2 + (s.health / 100) * Math.PI * 2); ctx.stroke();
    ctx.fillStyle = C.text1; ctx.font = "500 20px Geist, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(String(s.health), cx, cy - 3);
    ctx.fillStyle = C.text3; ctx.font = "500 8.5px 'Geist Mono', monospace"; ctx.fillText("HEALTH", cx, cy + 14);
    // dimensions
    DIMS.forEach((name, i) => {
      const a = -Math.PI / 2 + (i / DIMS.length) * Math.PI * 2 + spin;
      const x = cx + Math.cos(a) * R, y = cy + Math.sin(a) * R * 0.82;
      const val = s.v[KEYS[i]];
      const risk = val < 0.45, watch = !risk && val < 0.66;
      const col = risk ? C.risk : watch ? "#f2c46b" : C.text2;
      // link: thicker and brighter when this dimension is driving the change
      ctx.strokeStyle = rgba(col, risk ? 0.55 : 0.18); ctx.lineWidth = risk ? 1.6 : 1;
      ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * 40, cy + Math.sin(a) * 40 * 0.82); ctx.lineTo(x, y); ctx.stroke();
      if (s.intervention && (KEYS[i] === "support" || KEYS[i] === "sentiment")) { // the approved action reaching the problem
        const p = reduced ? 0.6 : (time * 0.6 + i * 0.3) % 1;
        const px = lerp(cx, x, p), py = lerp(cy, y, p);
        glow(ctx, px, py, 14, C.violet, 1); ctx.fillStyle = C.violetPale; ctx.beginPath(); ctx.arc(px, py, 2.4, 0, Math.PI * 2); ctx.fill();
      }
      if (risk) glow(ctx, x, y, 26, C.risk, 0.6);
      ctx.fillStyle = rgba(C.bg, 0.95); ctx.strokeStyle = col; ctx.lineWidth = 1.5;
      ctx.beginPath();
      if (risk) { ctx.moveTo(x, y - 9); ctx.lineTo(x + 8.5, y + 6); ctx.lineTo(x - 8.5, y + 6); ctx.closePath(); }
      else if (watch) ctx.arc(x, y, 7, 0, Math.PI * 2);
      else ctx.rect(x - 6.5, y - 6.5, 13, 13);
      ctx.fill(); ctx.stroke();
      ctx.font = "500 12.5px Geist, sans-serif"; ctx.fillStyle = C.text1; ctx.textAlign = Math.cos(a) > 0.2 ? "left" : Math.cos(a) < -0.2 ? "right" : "center";
      const off = Math.cos(a) > 0.2 ? 16 : Math.cos(a) < -0.2 ? -16 : 0, voff = Math.abs(Math.cos(a)) <= 0.2 ? (Math.sin(a) > 0 ? 22 : -22) : 0;
      ctx.fillText(name, x + off, y + voff - 6);
      ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillStyle = risk ? "#ff8f9a" : watch ? "#f2c46b" : C.text3;
      ctx.fillText(risk ? "AT RISK" : watch ? "WATCH" : "FINE", x + off, y + voff + 9);
    });
    if (day >= 45) { // outcome measured
      ctx.strokeStyle = rgba(C.text1, 0.35); ctx.lineWidth = 1; ctx.setLineDash([3, 5]);
      ctx.beginPath(); ctx.arc(cx, cy, 58, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    }
  }

  setDay(0);
  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
