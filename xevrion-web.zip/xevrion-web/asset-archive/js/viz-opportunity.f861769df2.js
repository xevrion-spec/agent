// Revenue: the Opportunity Field. 120 fictional companies; depth = how far through the funnel each got,
// size = expected value, brightness = priority, violet = strength of buying intent. Hover or tap explains WHY.
import { C, clamp, ease, gbp, glow, lerp, lifecycle, loop, mulberry, rgba, stageCanvas, tooltip, rel, panelOf } from "./viz-kit.0fe0c83bce.js";

const STAGES = [["Discovered", 120], ["Fit your ideal customer", 47], ["Meaningful signals", 14], ["High expected value", 6], ["Conversations", 3], ["Customer", 1]];
const TOP = [ // stage, name, sector, likely value, chance, signal: the same six as the page's table
  [5, "Northgate Logistics", "Transport and storage", 18400, 0.55, "Asked for a quote through your website"],
  [4, "Harbour Freight Ltd", "Transport and storage", 24000, 0.62, "Opening a second depot; hiring 4 drivers"],
  [4, "Aldgate Build Partners", "Construction", 31000, 0.41, "Published a tender for site reporting"],
  [3, "Clearline Networks", "Information and communications", 16000, 0.48, "Hiring an operations manager"],
  [3, "Brightwell Civils", "Construction", 22000, 0.33, "Won a council framework contract"],
  [3, "Tamar Data Services", "Information and communications", 12000, 0.52, "Replied to a newsletter asking about pricing"],
];
const WHY = [
  ["Outside your usual company size", "A sector you rarely win in", "Already handled by another supplier you lost to twice", "Too far from the areas you serve"],
  ["Fits your ideal customer, but no buying signal yet", "Right size and sector; nothing suggests they need you now"],
  ["A signal was found, but the expected value is below the top six", "Hiring activity, but in a department you do not serve"],
];
const A = ["North", "Harbour", "Ald", "Bright", "Clear", "Tamar", "Kings", "Stone", "Fairway", "Oak", "Mere", "Ridge", "Wey", "Castle", "Tyne", "Severn", "Pennine", "Marsh", "Heath", "Vale"];
const B = ["gate", "well", "line", "field", "mark", "wood", "bridge", "ford", "stead", "moor"];
const S = [["Logistics", "Transport and storage"], ["Freight", "Transport and storage"], ["Build", "Construction"], ["Civils", "Construction"], ["Networks", "Information and communications"], ["Data", "Information and communications"], ["Haulage", "Transport and storage"], ["Construction", "Construction"]];

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const tip = tooltip(host);
  const rand = mulberry(42);
  // companies: the named six first, then 114 generated ones, spread across the funnel as in the example
  const counts = STAGES.map(([, n], i) => n - (STAGES[i + 1]?.[1] || 0)); // how many stopped at each stage
  const cos = TOP.map(([stage, name, sector, value, p, signal]) => ({ stage, name, sector, value, p, signal, intent: 0.75 + rand() * 0.25 }));
  for (let st = 0; st < 3; st++) {
    for (let k = 0; k < counts[st]; k++) {
      const [suffix, sector] = S[Math.floor(rand() * S.length)];
      const name = `${A[Math.floor(rand() * A.length)]}${B[Math.floor(rand() * B.length)]} ${suffix}`;
      const value = Math.round((6 + rand() * 26) * 1000 / 100) * 100;
      const p = st === 0 ? 0.03 + rand() * 0.08 : st === 1 ? 0.08 + rand() * 0.14 : 0.18 + rand() * 0.2;
      cos.push({ stage: st, name, sector, value, p, signal: st === 2 ? WHY[2][Math.floor(rand() * 2)] : null,
                 why: WHY[Math.min(st, 2)][Math.floor(rand() * WHY[Math.min(st, 2)].length)], intent: st === 2 ? 0.35 + rand() * 0.3 : rand() * 0.15 });
    }
  }
  cos.forEach((c) => { c.ev = c.value * c.p; c.x = 0.08 + rand() * 0.86; c.j = (rand() - 0.5); c.phase = rand() * 6.28; c.a = 1; });
  const maxEv = Math.max(...cos.map((c) => c.ev));

  // stage filter: auto-plays the narrowing until the visitor takes over
  const nav = document.createElement("div");
  nav.className = "viz__controls";
  const short = ["discovered", "fit", "signals", "high value", "talking", "customer"];
  nav.innerHTML = `<div class="pill-nav" role="group" aria-label="Show companies that reached">${STAGES.map(([n, c], i) =>
    `<button type="button" aria-pressed="${i === 0}" data-s="${i}" aria-label="${c} ${n}">${c}<span class="quiet">${short[i]}</span></button>`).join("")}</div>`;
  panelOf(host).append(nav);
  const buttons = [...nav.querySelectorAll("button")];
  let filter = 0, auto = !reduced, lastSwitch = 0, hover = null;
  const setFilter = (s, user) => {
    filter = s;
    buttons.forEach((b, i) => b.setAttribute("aria-pressed", String(i === s)));
    if (user) { auto = false; track?.(`viz_interact:opportunity:${s}`); }
    if (reduced) frame(0);
  };
  buttons.forEach((b) => b.addEventListener("click", () => setFilter(+b.dataset.s, true)));

  // the stage labels get their own column on the left; companies and planes are drawn only to the right of it, so no
  // dot ever sits on a label
  const LABELS = STAGES.map(([n, c]) => `${c} · ${n.toUpperCase()}`);
  const field = () => {
    const { w } = state;
    if (w < 560) return { x0: 12, x1: w - 12 };
    ctx.font = "500 10.5px 'Geist Mono', monospace";
    const lw = Math.max(...LABELS.map((t) => ctx.measureText(t).width));
    return { x0: 16 + lw + 28, x1: w - 16 };
  };
  const place = (c) => {
    const { w, h } = state;
    const narrow = w < 560, { x0, x1 } = field();
    const depth = c.stage / 5;                                   // back (discovered) to front (customer)
    const y = lerp(h * 0.14, h * (narrow ? 0.7 : 0.74), depth) + c.j * h * 0.07;
    const spread = lerp(0.62, 1, depth);                          // perspective: the back rows are narrower
    const x = x0 + (x1 - x0) * (0.5 + (c.x - 0.5) * spread * 0.92);
    const scale = 0.55 + depth * 0.7;
    const r = (2 + Math.sqrt(c.ev / maxEv) * 13) * scale * (narrow ? 0.8 : 1);
    return { x, y, r };
  };

  function frame(time = 0) {
    const { w, h } = state;
    ctx.clearRect(0, 0, w, h);
    if (auto && time - lastSwitch > 2.6) { lastSwitch = time; setFilter((filter + 1) % STAGES.length, false); }
    const F = field();
    // depth planes with stage labels
    for (let i = 0; i < STAGES.length; i++) {
      const y = lerp(h * 0.14, h * (w < 560 ? 0.7 : 0.74), i / 5);
      const spread = lerp(0.62, 1, i / 5);
      const mid = (F.x0 + F.x1) / 2, half = (F.x1 - F.x0) * 0.5 * spread;
      const x0 = mid - half, x1 = mid + half;
      ctx.strokeStyle = rgba(i === filter ? C.violetPale : C.text1, i === filter ? 0.22 : 0.06);
      ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
      if (w >= 560) {
        ctx.font = "500 10.5px 'Geist Mono', monospace"; ctx.textAlign = "left"; ctx.textBaseline = "middle";
        ctx.fillStyle = i <= filter ? (i === filter ? C.text1 : C.text3) : rgba(C.text3, 0.6);
        ctx.fillText(LABELS[i], 16, y);
      }
    }
    // companies, back to front
    for (const c of cos) {
      const { x, y, r } = place(c);
      const on = c.stage >= filter;
      c.a = lerp(c.a, on ? 1 : 0.12, reduced ? 1 : 0.08);
      const bob = reduced ? 0 : Math.sin(time * 0.8 + c.phase) * 1.2;
      const prio = Math.sqrt(c.ev / maxEv);
      if (c.stage >= 3 && on) glow(ctx, x, y + bob, r * 3, c.stage === 5 ? C.text1 : C.violet, 0.7 * c.a);
      ctx.beginPath(); ctx.arc(x, y + bob, r, 0, Math.PI * 2);
      const base = c.stage === 5 ? C.text1 : c.intent > 0.3 ? (c.intent > 0.7 ? C.violetBright : C.violetPale) : C.text2;
      ctx.fillStyle = rgba(base, (0.25 + prio * 0.75) * c.a);
      ctx.fill();
      if (hover === c) { ctx.strokeStyle = C.text1; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y + bob, r + 4, 0, Math.PI * 2); ctx.stroke(); }
    }
  }

  const pick = (px, py) => {
    let best = null, bd = 18;
    for (const c of cos) {
      if (c.stage < filter) continue;
      const { x, y, r } = place(c);
      const d = Math.hypot(px - x, py - y) - r;
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  };
  const explainCo = (c) => {
    const reached = STAGES[c.stage][0];
    const why = c.stage >= 3 ? c.signal : c.why;
    return `<strong>${c.name}</strong><br><span class="quiet">${c.sector} · fictional</span>
      <dl><dt>Reached</dt><dd>${reached}</dd><dt>Likely value</dt><dd>${gbp(c.value)}</dd><dt>Chance</dt><dd>${Math.round(c.p * 100)}%</dd><dt>Expected value</dt><dd>${gbp(c.ev)}</dd></dl>
      <p style="margin-top:8px;color:var(--text-1)">${c.stage >= 3 ? "Why it is here: " : "Why it stopped: "}${why}</p>`;
  };
  const onMove = (e) => {
    const r = rel(host, e);
    const px = r.x, py = r.y;
    const c = pick(px, py);
    hover = c;
    if (c) { const p = place(c); tip.show(explainCo(c), p.x, p.y); host.style.cursor = "pointer"; auto = false; }
    else { tip.hide(); host.style.cursor = ""; }
    if (reduced) frame(0);
  };
  host.addEventListener("pointermove", onMove);
  host.addEventListener("pointerdown", onMove);
  host.addEventListener("pointerleave", () => { hover = null; tip.hide(); if (reduced) frame(0); });

  const run = loop(frame);
  run.renderStatic = () => frame(0);
  if (reduced) { state.onResize = () => frame(0); frame(0); }
  return lifecycle(run, { reduced });
}
