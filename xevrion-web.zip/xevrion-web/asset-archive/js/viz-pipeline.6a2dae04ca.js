// "How it works": the eight stages drawn as one closed loop. The stage being read lights up; stages already covered
// stay white (done), later ones stay grey (to come). Signals travel round the loop, because the last stage feeds the
// first. Clicking a node scrolls to that stage's explanation.
import { C, clamp, glow, lifecycle, loop, rgba, stageCanvas, rel } from "./viz-kit.0fe0c83bce.js";

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const sections = [...document.querySelectorAll("[data-stage]")];
  const names = sections.map((s) => s.dataset.stage);
  const n = names.length;
  const centre = { n: host.querySelector("[data-n]"), t: host.querySelector("[data-t]"), s: host.querySelector("[data-s]") };
  let active = 0, shown = 0; // shown eases towards active for smooth progress
  const signals = Array.from({ length: 14 }, (_, i) => ({ a: i / 14, v: 0.035 + (i % 5) * 0.006 }));

  const geom = () => {
    const R = Math.min(state.w, state.h) * 0.36;
    return { R, cx: state.w / 2, cy: state.h / 2, at: (i) => -Math.PI / 2 + (i / n) * Math.PI * 2 };
  };

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    const { R, cx, cy, at } = geom();
    shown += (active - shown) * (reduced ? 1 : clamp(dt * 6));
    ctx.clearRect(0, 0, w, h);
    // track
    ctx.lineWidth = 1.2; ctx.strokeStyle = rgba(C.text1, 0.09);
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke();
    // progress
    const end = at(shown);
    const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
    g.addColorStop(0, rgba(C.violetPale, 0.9)); g.addColorStop(1, rgba(C.violet, 0.9));
    ctx.strokeStyle = g; ctx.lineWidth = 2.2; ctx.lineCap = "round";
    ctx.beginPath(); ctx.arc(cx, cy, R, at(0), end + 0.0001); ctx.stroke();
    // signals travelling round the loop
    if (!reduced) {
      signals.forEach((s) => {
        s.a = (s.a + s.v * dt) % 1;
        const ang = -Math.PI / 2 + s.a * Math.PI * 2;
        const x = cx + Math.cos(ang) * R, y = cy + Math.sin(ang) * R;
        ctx.fillStyle = rgba(C.text1, 0.55); ctx.beginPath(); ctx.arc(x, y, 1.4, 0, Math.PI * 2); ctx.fill();
      });
    }
    // nodes
    for (let i = 0; i < n; i++) {
      const ang = at(i), x = cx + Math.cos(ang) * R, y = cy + Math.sin(ang) * R;
      const isActive = i === active, done = i < active;
      if (isActive) {
        const pulse = reduced ? 1 : 0.85 + Math.sin(time * 2.4) * 0.15;
        glow(ctx, x, y, 34 * pulse, C.violet, 1);
        ctx.strokeStyle = rgba(C.violetPale, 0.5); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(x, y, 14 + 4 * pulse, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.beginPath(); ctx.arc(x, y, isActive ? 7 : 5, 0, Math.PI * 2);
      ctx.fillStyle = isActive ? C.violetBright : done ? C.text1 : C.bg; ctx.fill();
      ctx.lineWidth = 1.2; ctx.strokeStyle = isActive ? C.text1 : done ? C.text1 : rgba(C.text1, 0.35); ctx.stroke();
      // label outside the ring
      const lx = cx + Math.cos(ang) * (R + 26), ly = cy + Math.sin(ang) * (R + 26);
      ctx.font = `500 ${isActive ? 12 : 11}px 'Geist Mono', monospace`;
      ctx.textAlign = Math.abs(Math.cos(ang)) < 0.2 ? "center" : Math.cos(ang) > 0 ? "left" : "right";
      ctx.textBaseline = "middle";
      ctx.fillStyle = isActive ? C.text1 : done ? C.text2 : C.text3;
      ctx.fillText(`${String(i + 1).padStart(2, "0")} ${names[i].toUpperCase()}`, lx, ly);
    }
  }

  function setActive(i) {
    if (i === active && centre.t.textContent) return;
    active = i;
    const sec = sections[i];
    centre.n.textContent = `STAGE ${String(i + 1).padStart(2, "0")} OF ${String(n).padStart(2, "0")}`;
    centre.t.textContent = sec.dataset.stage;
    centre.s.textContent = sec.dataset.summary || "";
    if (reduced) frame();
  }

  const io = new IntersectionObserver((entries) => {
    const vis = entries.filter((e) => e.isIntersecting).map((e) => sections.indexOf(e.target));
    if (vis.length) { setActive(Math.max(...vis)); track?.(`walk_stage:${names[Math.max(...vis)]}`, true); }
  }, { rootMargin: "-40% 0px -55% 0px" });
  sections.forEach((s) => io.observe(s));

  host.addEventListener("click", (e) => {
    const r = rel(host, e), { R, cx, cy, at } = geom();
    const px = r.x, py = r.y;
    for (let i = 0; i < n; i++) {
      const x = cx + Math.cos(at(i)) * R, y = cy + Math.sin(at(i)) * R;
      if (Math.hypot(px - x, py - y) < 22) { sections[i].scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "start" }); return; }
    }
  });
  host.addEventListener("pointermove", (e) => {
    const r = rel(host, e), { R, cx, cy, at } = geom();
    const hit = [...Array(n).keys()].some((i) => Math.hypot(r.x - (cx + Math.cos(at(i)) * R), r.y - (cy + Math.sin(at(i)) * R)) < 22);
    host.style.cursor = hit ? "pointer" : "";
  });

  setActive(0);
  const run = loop(frame);
  run.renderStatic = () => frame();
  if (reduced) { state.onResize = () => frame(); frame(); }
  return lifecycle(run, { reduced });
}
