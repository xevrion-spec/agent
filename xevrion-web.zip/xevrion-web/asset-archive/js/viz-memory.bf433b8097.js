// Learning and memory. Memories (customers, deals, tickets, invoices, decisions, lessons) appear on a timeline and
// connect to what they concern. Every few seconds a forecast is scored against the actual result: the error is shown,
// and the trust Xevrion places in that forecast adjusts (trust = 1 - error, bounded 0.25..1), as on the page.
// Interactive: hover a memory to see what it is joined to; choose a cycle to replay its scoring.
import { C, clamp, ease, glow, lerp, lifecycle, loop, mulberry, rgba, stageCanvas, tooltip } from "./viz-kit.88725e7ff9.js";

const TYPES = [["Customer", C.text1], ["Deal", C.violetPale], ["Ticket", "#f2c46b"], ["Invoice", C.text2], ["Decision", C.violetBright], ["Lesson", "#4fd69c"]];
const ABOUT = ["A customer: the record other memories attach to.", "A deal: what was offered, when and at what value.", "A support ticket and how it was resolved.",
  "An invoice and whether it was paid on time.", "A decision: what was decided, by whom and why.", "A lesson: what a scored forecast or recommendation taught."];
const CYCLES = [31, 26, 19, 13, 9];     // forecast error per cycle, % (matches the page's chart)

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const tip = tooltip(host);
  const rand = mulberry(11);
  const out = { phase: host.querySelector('[data-o="phase"]'), big: host.querySelector('[data-o="big"]'), sub: host.querySelector('[data-o="sub"]') };
  const nodes = [], edges = [];
  let born = 0, cycle = 0, cycleT = 0, trust = 0.69, shownTrust = 0.69, phaseName = "", hover = null, now = 0, used = false;
  const hubs = []; // customers act as hubs other memories attach to
  const bar = document.createElement("div");
  bar.className = "viz-choices viz-choices--row"; bar.setAttribute("role", "group"); bar.setAttribute("aria-label", "Replay a learning cycle");
  bar.innerHTML = `<span class="label">Replay a cycle</span>` + CYCLES.map((e, i) => `<button type="button" data-c="${i}" aria-pressed="${i === 0}">${i + 1} · ${e}%</button>`).join("");
  host.append(bar);
  const markCycle = () => bar.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(+b.dataset.c === cycle)));

  const add = (t) => {
    const type = hubs.length < 5 && rand() < 0.35 ? 0 : 1 + Math.floor(rand() * 5);
    const n = { type, x: 0.12 + rand() * 0.8, y: 0.18 + rand() * 0.55, t, r: type === 0 ? 5.5 : 3.2 };
    nodes.push(n);
    if (type === 0) hubs.push(n);
    else if (hubs.length) {
      const hub = hubs.reduce((b, h) => (Math.hypot(h.x - n.x, h.y - n.y) < Math.hypot(b.x - n.x, b.y - n.y) ? h : b));
      edges.push([hub, n, t]);
      if (rand() < 0.3 && nodes.length > 3) edges.push([nodes[Math.floor(rand() * (nodes.length - 1))], n, t]);
    }
    if (nodes.length > 70) { const gone = nodes.shift(); for (let i = edges.length - 1; i >= 0; i--) if (edges[i][0] === gone || edges[i][1] === gone) edges.splice(i, 1); }
  };
  const setOut = (phase, big, sub) => {
    if (phase !== phaseName) { phaseName = phase; out.phase.textContent = phase; out.sub.textContent = sub; }
    if (out.big.textContent !== big) out.big.textContent = big;
  };

  function frame(time = 0, dt = 0.016) {
    now = time;
    const { w, h } = state;
    ctx.clearRect(0, 0, w, h);
    if (!reduced && time - born > 0.35) { born = time; add(time); }
    // timeline
    const ty = h * 0.86;
    ctx.strokeStyle = rgba(C.text1, 0.12); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(w * 0.06, ty); ctx.lineTo(w * 0.94, ty); ctx.stroke();
    ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillStyle = C.text3; ctx.textAlign = "left"; ctx.fillText("MEMORY TIMELINE", w * 0.06, ty + 18);
    ctx.textAlign = "right"; ctx.fillText("NOW", w * 0.94, ty + 18);
    // edges and nodes
    edges.forEach(([a, b, t]) => {
      const k = reduced ? 1 : ease(clamp((time - t) / 0.8));
      const mine = hover && (a === hover || b === hover);
      ctx.strokeStyle = rgba(mine ? C.violetBright : C.violetPale, (mine ? 0.9 : hover ? 0.06 : 0.16) * k); ctx.lineWidth = mine ? 1.6 : 1; ctx.beginPath();
      ctx.moveTo(a.x * w, a.y * h); ctx.lineTo(lerp(a.x, b.x, k) * w, lerp(a.y, b.y, k) * h); ctx.stroke(); ctx.lineWidth = 1;
    });
    nodes.forEach((n, i) => {
      const k = reduced ? 1 : ease(clamp((time - n.t) / 0.5));
      const [, col] = TYPES[n.type];
      if (n.type === 0) glow(ctx, n.x * w, n.y * h, 22, C.violet, 0.45 * k);
      if (n === hover) { glow(ctx, n.x * w, n.y * h, 30, C.violet, 1); ctx.strokeStyle = C.text1; ctx.beginPath(); ctx.arc(n.x * w, n.y * h, n.r + 4, 0, Math.PI * 2); ctx.stroke(); }
      ctx.fillStyle = rgba(col, 0.85 * k); ctx.beginPath(); ctx.arc(n.x * w, n.y * h, n.r * k, 0, Math.PI * 2); ctx.fill();
      // its tick on the timeline
      const tx = w * 0.06 + (i / Math.max(1, nodes.length - 1)) * w * 0.88;
      ctx.fillStyle = rgba(col, 0.5); ctx.fillRect(tx - 0.5, ty - 6, 1, 6);
    });
    // legend
    if (w > 560) TYPES.forEach(([name, col], i) => {
      const x = w - 150, y = h * 0.14 + i * 18;
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, i === 0 ? 4.5 : 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = C.text2; ctx.textAlign = "left"; ctx.font = "500 11.5px Geist, sans-serif"; ctx.fillText(name, x + 12, y + 4);
    });
    // learning cycle: a forecast is scored, then trust adjusts
    cycleT += reduced ? 0 : dt;
    const e = CYCLES[cycle];
    if (cycleT < 2.2) setOut("Remembering", `${nodes.length} memories`, "Events, decisions and lessons, joined to the customers and processes they concern.");
    else if (cycleT < 4.4) {
      setOut(`Cycle ${cycle + 1}: scoring a forecast`, `error ${e}%`, e > 25 ? "Above 25%: flagged for recalibration." : e < 10 ? "Below 10%: kept as a strong model." : "Moderate: keep collecting actual results.");
      const k = ease(clamp((cycleT - 2.2) / 1.2));
      const fx = w * 0.5, fy = h * 0.1;
      ctx.strokeStyle = rgba(C.text1, 0.35); ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(fx - 90, fy); ctx.lineTo(fx + 90, fy); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = C.violetBright; ctx.beginPath(); ctx.arc(fx - 90 + 180 * 0.5, fy, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(fx - 90 + 180 * (0.5 + (e / 100) * k), fy, 5, 0, Math.PI * 2); ctx.fill();
      ctx.font = "500 10px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = C.text3; ctx.fillText("FORECAST · ACTUAL", fx, fy - 12);
    } else if (cycleT < 6.4) {
      trust = clamp(1 - e / 100, 0.25, 1);
      shownTrust = lerp(shownTrust, trust, 0.06);
      setOut("Adjusting trust", `trust ${shownTrust.toFixed(2)}`, `Trust = 1 − error, kept between 0.25 and 1. Error ${e}% gives ${trust.toFixed(2)}.`);
    } else { cycleT = 0; cycle = (cycle + 1) % CYCLES.length; markCycle(); if (cycle === 0) track?.("viz_loop:memory", true); }
  }

  const nodeAt = (e) => {
    const r = host.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    let best = null, bd = 14;
    nodes.forEach((n) => { const d = Math.hypot(n.x * state.w - x, n.y * state.h - y); if (d < bd) { bd = d; best = n; } });
    return best;
  };
  const use = (what) => { if (!used) { used = true; track?.(`viz_interact:memory:${what}`, true); } };
  host.addEventListener("pointermove", (e) => {
    if (e.target.closest(".viz-choices")) return;
    const n = nodeAt(e);
    hover = n;
    const r = host.getBoundingClientRect();
    if (n) {
      const links = edges.filter(([a, b]) => a === n || b === n).length;
      tip.show(`<span class="label">${TYPES[n.type][0]}</span><p style="margin-top:6px">${ABOUT[n.type]}</p><p class="quiet" style="margin-top:6px">Joined to ${links} other ${links === 1 ? "memory" : "memories"}.</p>`, e.clientX - r.left, e.clientY - r.top);
      use("hover");
    } else tip.hide();
    if (reduced) frame(now, 0);
  });
  host.addEventListener("pointerleave", () => { hover = null; tip.hide(); if (reduced) frame(now, 0); });
  bar.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-c]");
    if (!b) return;
    cycle = +b.dataset.c; cycleT = 2.2; phaseName = ""; markCycle(); use("cycle");
    if (reduced) {
      const err = CYCLES[cycle], tr = clamp(1 - err / 100, 0.25, 1);
      out.phase.textContent = `Cycle ${cycle + 1}: scored`; out.big.textContent = `error ${err}% · trust ${tr.toFixed(2)}`;
      out.sub.textContent = err > 25 ? "Above 25%: flagged for recalibration." : err < 10 ? "Below 10%: kept as a strong model." : "Moderate: keep collecting actual results.";
    }
  });

  const run = loop(frame);
  run.renderStatic = () => {
    while (nodes.length < 48) add(0);
    frame(0, 0);
    out.phase.textContent = "Cycle 5: learned"; out.big.textContent = "trust 0.91"; out.sub.textContent = "Error fell from 31% to 9% over five cycles; trust rose from 0.69 to 0.91.";
  };
  if (reduced) { state.onResize = run.renderStatic; run.renderStatic(); }
  return lifecycle(run, { reduced });
}
