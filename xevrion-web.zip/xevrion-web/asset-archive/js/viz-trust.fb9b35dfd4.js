// Security: five concentric layers of protection. Requests arrive from outside and must pass every ring to reach your
// data at the centre. Most pass; some are stopped at the ring whose check they fail. Interactive: hover a ring to read
// its check; click a ring to send a request that fails exactly there; click the centre to send one that passes.
import { C, clamp, glow, lerp, lifecycle, loop, mulberry, rgba, stageCanvas, tooltip } from "./viz-kit.88725e7ff9.js";

// i = 0 innermost. [name, what it checks, what happens when a request fails it, tone]
const RINGS = [
  ["Lifecycle", "Deleted data stays deleted: it is not served again.", "Nothing returned: that data was deleted", "info"],
  ["Actions", "Consequential actions (money, customers, data) wait for a named approver.", "Held for a person to approve", "hold"],
  ["Connections", "Each connected tool can do only what you granted it: read and write separately.", "Refused: not a permission you granted", "risk"],
  ["Access", "The request must belong to your organisation and be allowed for your role.", "Refused: wrong organisation or role", "risk"],
  ["Identity", "A valid, unexpired session and, where set, a two-factor code.", "Refused: no valid session or two-factor code", "risk"],
];
const TONE = { risk: C.risk, hold: C.violetBright, info: C.text2 };

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const tip = tooltip(host);
  const rand = mulberry(3);
  const reqs = [];
  const tally = { passed: 0, stopped: RINGS.map(() => 0) };
  let spawn = 0, notice = null, hoverRing = -1, now = 0, touched = false;

  const geom = () => { const { w, h } = state; return { cx: w / 2, cy: h / 2 - 10, R: Math.min(w, h - 40) * 0.44 }; };
  const ringR = (i, R) => R * (0.3 + i * 0.16);
  const send = (stop, manual) => { reqs.push({ a: manual ? Math.random() * Math.PI * 2 : rand() * Math.PI * 2, t: 0, stop, manual }); };

  function frame(time = 0, dt = 0.016) {
    now = time;
    const { w, h } = state, { cx, cy, R } = geom();
    ctx.clearRect(0, 0, w, h);
    RINGS.forEach(([name], i) => {
      const r = ringR(i, R), on = i === hoverRing;
      ctx.strokeStyle = on ? rgba(C.violetPale, 0.8) : rgba(C.text1, 0.1 + i * 0.03); ctx.lineWidth = on ? 2 : 1;
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      if (on) { ctx.strokeStyle = rgba(C.violet, 0.18); ctx.lineWidth = 12; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke(); }
      const a = (reduced ? 0 : time * (0.08 + i * 0.03)) * (i % 2 ? 1 : -1);
      for (let k = 0; k < 3; k++) {
        const ang = a + (k * Math.PI * 2) / 3;
        ctx.save(); ctx.translate(cx + Math.cos(ang) * r, cy + Math.sin(ang) * r); ctx.rotate(ang + Math.PI / 4);
        ctx.fillStyle = rgba(C.text1, on ? 0.9 : 0.55); ctx.fillRect(-2, -2, 4, 4); ctx.restore();
      }
      ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = on ? C.text1 : C.text3;
      ctx.fillText(name.toUpperCase() + (tally.stopped[i] ? ` · ${tally.stopped[i]}` : ""), cx, cy - r - 5);
    });
    glow(ctx, cx, cy, R * 0.3, C.text1, hoverRing === -2 ? 0.6 : 0.35);
    ctx.fillStyle = C.text1; ctx.font = "500 11px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillText("YOUR DATA", cx, cy + 4);
    if (!reduced || reqs.length) {
      spawn += dt;
      if (!reduced && spawn > 0.55 && reqs.length < 16) {
        spawn = 0;
        send(rand() < 0.28 ? 4 - Math.floor(rand() * 3) : -1, false);
      }
      reqs.forEach((q) => {
        if (q.dead) return;
        q.t += dt * (q.manual ? 0.5 : 0.32);
        const r = lerp(R * 1.08, R * 0.28, clamp(q.t));
        if (q.stop >= 0 && r <= ringR(q.stop, R) + 2) {
          q.dead = time; tally.stopped[q.stop]++;
          notice = { text: RINGS[q.stop][2], tone: RINGS[q.stop][3], at: time };
          return;
        }
        const x = cx + Math.cos(q.a) * r, y = cy + Math.sin(q.a) * r;
        if (q.manual) glow(ctx, x, y, 16, C.violet, 1);
        ctx.fillStyle = q.stop >= 0 ? rgba(C.text1, 0.8) : C.violetPale; ctx.beginPath(); ctx.arc(x, y, q.manual ? 3.4 : 2.4, 0, Math.PI * 2); ctx.fill();
        if (q.t >= 1) { q.dead = time; tally.passed++; if (q.manual) notice = { text: "Passed every check: the request reached your data", tone: "ok", at: time }; }
      });
      for (let i = reqs.length - 1; i >= 0; i--) {
        const q = reqs[i];
        if (!q.dead) continue;
        if (q.stop >= 0 && time - q.dead < 0.8) {
          const r = ringR(q.stop, R), x = cx + Math.cos(q.a) * r, y = cy + Math.sin(q.a) * r;
          ctx.strokeStyle = rgba(TONE[RINGS[q.stop][3]], 1 - (time - q.dead) / 0.8); ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(x, y, q.manual ? 10 : 7, 0, Math.PI * 2); ctx.stroke();
        } else reqs.splice(i, 1);
      }
    }
    if (notice && time - notice.at < 2.2) {
      const fade = 1 - (time - notice.at) / 2.2;
      ctx.font = "500 12.5px Geist, sans-serif"; ctx.textAlign = "center";
      ctx.fillStyle = rgba(notice.tone === "risk" ? "#ff8f9a" : notice.tone === "ok" ? C.ok : notice.tone === "hold" ? C.violetPale : C.text2, fade);
      ctx.fillText(notice.text, cx, h - 34);
    }
    ctx.font = "500 10px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = C.text3;
    ctx.fillText(`REACHED YOUR DATA ${tally.passed}   ·   STOPPED ${tally.stopped.reduce((a, b) => a + b, 0)}`, cx, h - 12);
  }

  const which = (e) => {
    const r = host.getBoundingClientRect(), { cx, cy, R } = geom();
    const d = Math.hypot(e.clientX - r.left - cx, e.clientY - r.top - cy);
    if (d < ringR(0, R) - 10) return -2;                        // the centre
    let best = -1, bd = R * 0.07;
    RINGS.forEach((_, i) => { const dd = Math.abs(d - ringR(i, R)); if (dd < bd) { bd = dd; best = i; } });
    return best;
  };
  host.addEventListener("pointermove", (e) => {
    const i = which(e);
    hoverRing = i;
    host.style.cursor = i !== -1 ? "pointer" : "";
    const r = host.getBoundingClientRect();
    if (i >= 0) tip.show(`<strong>${RINGS[i][0]}</strong><p style="margin-top:6px">${RINGS[i][1]}</p><p class="quiet" style="margin-top:6px">Click to send a request that fails this check.</p>`, e.clientX - r.left, e.clientY - r.top);
    else if (i === -2) tip.show(`<strong>Your data</strong><p style="margin-top:6px">Click to send a request that passes every check.</p>`, e.clientX - r.left, e.clientY - r.top);
    else tip.hide();
    if (reduced) frame(now, 0);
  });
  host.addEventListener("pointerleave", () => { hoverRing = -1; tip.hide(); if (reduced) frame(now, 0); });
  host.addEventListener("click", (e) => {
    const i = which(e);
    if (i === -1) return;
    send(i === -2 ? -1 : i, true);
    if (!touched) { touched = true; track?.("viz_interact:trust", true); }
    if (reduced) { run.start(); setTimeout(() => run.stop(), 4000); }
  });

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
