// Decision Intelligence: the Scenario Field. Today sits on the left; four possible next quarters branch out as cones
// whose width is the uncertainty range. Moving one input (pipeline conversion) updates every scenario. Nothing here is
// a prediction: every value is a range with a stated confidence, and ranges widen further from today's evidence.
import { C, clamp, glow, lerp, lifecycle, loop, rgba, stageCanvas } from "./viz-kit.0fe0c83bce.js";

const BASE = 18; // today's conversion rate, %
const SCEN = [ // name, expected at 18%, £K per point of conversion, half-range at 18%, confidence
  ["Current path", 382, 6.5, 24, "Medium"],
  ["Faster follow-up", 397, 7.0, 26, "Medium"],
  ["Second product line", 411, 6.0, 53, "Low"],
  ["Lose the largest customer", 351, 6.0, 14, "High"],
];

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const slider = host.querySelector("[data-conv]"), sliderOut = host.querySelector("[data-conv-out]");
  const live = document.createElement("p"); live.className = "sr-only"; live.setAttribute("aria-live", "polite"); host.append(live);
  let conv = BASE, shown = SCEN.map((s) => ({ e: s[1], lo: s[1] - s[3], hi: s[1] + s[3] }));

  const model = (c) => SCEN.map(([name, e, slope, half, conf]) => {
    const exp = e + (c - BASE) * slope;
    const widen = 1 + Math.abs(c - BASE) * 0.07; // further from today's evidence = less certain
    return { name, conf, e: exp, lo: exp - half * widen, hi: exp + half * widen };
  });
  slider.addEventListener("input", () => {
    conv = +slider.value; sliderOut.textContent = `${conv}%`;
    const m = model(conv);
    live.textContent = `At ${conv}% conversion: ` + m.map((s) => `${s.name} about £${Math.round(s.e)}K, range £${Math.round(s.lo)}K to £${Math.round(s.hi)}K`).join("; ");
    track?.("viz_interact:scenario", true);
    if (reduced) frame(0, 0);
  });

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    const target = model(conv);
    shown = shown.map((s, i) => ({ e: lerp(s.e, target[i].e, reduced ? 1 : clamp(dt * 6)), lo: lerp(s.lo, target[i].lo, reduced ? 1 : clamp(dt * 6)), hi: lerp(s.hi, target[i].hi, reduced ? 1 : clamp(dt * 6)) }));
    const narrow = w < 620;
    const lo = 300, hi = 490, top = h * 0.1, bottom = h * 0.86;
    const Y = (v) => lerp(bottom, top, (v - lo) / (hi - lo));
    // the value axis sits on the left and the cones end at x1, so the scenario names have the right-hand column to
    // themselves
    const x0 = narrow ? 70 : Math.max(104, w * 0.13), x1 = w * (narrow ? 0.46 : 0.56);
    const nowV = 318; // this quarter so far, £K
    ctx.clearRect(0, 0, w, h);
    ctx.font = "500 10px 'Geist Mono', monospace"; ctx.textAlign = "left"; ctx.textBaseline = "middle";
    for (let v = 320; v <= 480; v += 40) {
      ctx.strokeStyle = rgba(C.text1, 0.05); ctx.beginPath(); ctx.moveTo(58, Y(v)); ctx.lineTo(x1 + 8, Y(v)); ctx.stroke();
      ctx.fillStyle = C.text3; ctx.fillText(`£${v}K`, 12, Y(v));
    }
    // today
    const oy = Y(nowV);
    glow(ctx, x0, oy, 40, C.violet, 1);
    ctx.fillStyle = C.violetBright; ctx.beginPath(); ctx.arc(x0, oy, 6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = C.text1; ctx.font = "500 12px Geist, sans-serif"; ctx.textAlign = "left";
    ctx.fillText("Today", x0 - 10, oy + 24);
    ctx.fillStyle = C.text3; ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillText(`£${nowV}K SO FAR`, x0 - 10, oy + 38);
    // scenario cones
    shown.forEach((s, i) => {
      const [, , , , conf] = SCEN[i];
      const alpha = conf === "High" ? 0.2 : conf === "Medium" ? 0.14 : 0.08;
      const col = i === 0 ? C.violetPale : i === 3 ? C.risk : C.text1;
      const grad = ctx.createLinearGradient(x0, 0, x1, 0);
      grad.addColorStop(0, rgba(col, 0)); grad.addColorStop(1, rgba(col, alpha));
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.moveTo(x0, oy); ctx.lineTo(x1, Y(s.hi)); ctx.lineTo(x1, Y(s.lo)); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = rgba(col, conf === "Low" ? 0.35 : 0.6); ctx.lineWidth = 1.2;
      if (conf === "Low") ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(x0, oy); ctx.lineTo(x1, Y(s.e)); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = rgba(col, 0.7); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x1, Y(s.hi)); ctx.lineTo(x1, Y(s.lo)); ctx.stroke();
      ctx.fillStyle = C.bg; ctx.strokeStyle = C.text1; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x1, Y(s.e), 5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    });
    // names: in value order, each at least one label-height below the one above (moved up together if they would
    // run off the bottom), joined to its point by a leader line when moved
    const LH = narrow ? 32 : 36, lx = x1 + 22, room = w - 12 - lx;
    const L = shown.map((s, i) => ({ i, at: Y(s.e), y: Y(s.e) })).sort((a, b) => a.at - b.at);
    for (let k = 1; k < L.length; k++) L[k].y = Math.max(L[k].y, L[k - 1].y + LH);
    if (L.at(-1).y > h - 26) { L.at(-1).y = h - 26; for (let k = L.length - 2; k >= 0; k--) L[k].y = Math.min(L[k].y, L[k + 1].y - LH); }
    for (const { i, at, y } of L) {
      const s = shown[i], [name, , , , conf] = SCEN[i];
      ctx.strokeStyle = rgba(C.text1, 0.22); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x1 + 7, at); ctx.lineTo(lx - 6, y - 6); ctx.stroke();
      let fs = narrow ? 12 : 13;
      ctx.font = `500 ${fs}px Geist, sans-serif`;
      while (fs > 10.5 && ctx.measureText(name).width > room) { fs -= 0.5; ctx.font = `500 ${fs}px Geist, sans-serif`; }
      ctx.textAlign = "left"; ctx.fillStyle = C.text1; ctx.fillText(name, lx, y - 7);
      ctx.fillStyle = C.text3; ctx.font = "500 9.5px 'Geist Mono', monospace";
      ctx.fillText(narrow ? `£${Math.round(s.e)}K · ${conf.toUpperCase()}` : `£${Math.round(s.e)}K · RANGE £${Math.round(s.lo)}–${Math.round(s.hi)}K · ${conf.toUpperCase()}`, lx, y + 9);
    }    void time;
  }

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
