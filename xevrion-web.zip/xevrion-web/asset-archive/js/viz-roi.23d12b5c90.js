// Pricing: return estimator. Uses only the visitor's inputs and the published plan prices; every assumption is a
// visible slider. Monthly value = hours removed x hourly cost + (extra customers per quarter x first-year value / 3).
const PLANS = { start: [2500, 2000], growth: [5000, 3500], scale: [10000, 7000] };
const gbp = (v) => "£" + Math.round(v).toLocaleString("en-GB");

export function mount(host, { track }) {
  const inp = (k) => host.querySelector(`[data-in="${k}"]`);
  const out = (k) => host.querySelector(`[data-out="${k}"]`);
  const res = (k) => host.querySelector(`[data-r="${k}"]`);
  const plans = [...host.querySelectorAll("[data-plan]")];
  let plan = "growth", touched = false;

  const calc = () => {
    const hours = +inp("hours").value, rate = +inp("rate").value, share = +inp("share").value / 100, value = +inp("value").value, wins = +inp("wins").value;
    out("hours").textContent = String(hours); out("rate").textContent = gbp(rate); out("share").textContent = `${Math.round(share * 100)}%`;
    out("value").textContent = gbp(value); out("wins").textContent = String(wins);
    const hoursMonth = hours * 52 / 12 * share;
    const cost = hoursMonth * rate;
    const rev = wins * value / 3;
    const total = cost + rev;
    const [monthly, setup] = PLANS[plan];
    const net = total - monthly;
    res("value").textContent = gbp(total);
    res("hours").textContent = `${Math.round(hoursMonth)} hrs a month`;
    res("cost").textContent = `${gbp(cost)} a month`;
    res("rev").textContent = `${gbp(rev)} a month`;
    res("plan").textContent = `${gbp(monthly)} a month`;
    res("payback").textContent = net <= 0 ? "not at these inputs" : setup / net < 1 ? "within the first month" : `about ${Math.ceil(setup / net)} months`;
    res("roi").textContent = `${(total / monthly).toFixed(1)}×`;
    res("roi").style.color = total >= monthly ? "var(--violet-200)" : "var(--text-3)";
  };
  host.querySelectorAll("[data-in]").forEach((el) => el.addEventListener("input", () => { calc(); if (!touched) { touched = true; track?.("roi_used", true); } }));
  plans.forEach((b) => b.addEventListener("click", () => {
    plan = b.dataset.plan; plans.forEach((x) => x.setAttribute("aria-pressed", String(x === b))); calc(); track?.(`roi_plan:${plan}`);
  }));
  calc();
  return { visible() {} };
}
