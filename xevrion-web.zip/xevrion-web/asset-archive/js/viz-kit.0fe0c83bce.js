// Shared plumbing for Xevrion visuals: crisp canvas, a render loop that sleeps when unseen, restrained pointer
// response, easing and the semantic palette. Colour carries meaning: violet = Xevrion is acting, white = verified,
// grey = passive information, red = risk. Nothing else.
export const C = {
  bg: "#08090d", text1: "#f8f8fb", text2: "#b7b8c2", text3: "#8e909d",
  violet: "#8056ff", violetBright: "#a477ff", violetPale: "#c6b5ff", risk: "#ff5c6c", ok: "#4fd69c",
  line: "rgba(255,255,255,0.10)", lineStrong: "rgba(255,255,255,0.22)",
};

export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const ease = (t) => 1 - Math.pow(1 - clamp(t), 3);
export const easeInOut = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
export const rgba = (hex, a) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
export function mulberry(seed) { // deterministic "randomness" so every visitor sees the same example
  return () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
export const gbp = (v, digits = 0) => "£" + Math.round(v).toLocaleString("en-GB", { maximumFractionDigits: digits });
export const gbpK = (v) => v >= 1000 ? `£${(v / 1000).toFixed(v >= 100000 ? 0 : 1).replace(/\.0$/, "")}K` : gbp(v);

// Pointer position inside an element, in the element's own layout pixels. The page may be scaled up on very large
// screens (CSS zoom), so screen pixels are converted rather than used directly.
export function rel(el, e) {
  const r = el.getBoundingClientRect();
  const kx = el.clientWidth && r.width ? el.clientWidth / r.width : 1, ky = el.clientHeight && r.height ? el.clientHeight / r.height : 1;
  return { x: (e.clientX - r.left) * kx, y: (e.clientY - r.top) * ky };
}

// A canvas that fills its host, drawn at the screen's full resolution: device pixels x any page zoom, capped to protect
// battery and GPU (`maxDpr`; cached visuals can afford more). Resizing clears a canvas, so `state.onResize` (set by the
// visual) redraws when nothing is animating.
export function stageCanvas(host, { maxDpr = 2 } = {}) {
  // a stage with a panel draws only inside its canvas box (the box is the stage's first cell, so pointer positions
  // measured from the stage are also positions in the box)
  const box = host.querySelector(":scope > .viz__canvas") || host;
  const canvas = document.createElement("canvas");
  canvas.setAttribute("aria-hidden", "true");
  box.prepend(canvas);
  const ctx = canvas.getContext("2d", { alpha: true });
  const state = { w: 0, h: 0, dpr: 1 };
  const resize = () => {
    const r = box.getBoundingClientRect();
    state.w = Math.max(1, box.clientWidth); state.h = Math.max(1, box.clientHeight);
    const zoom = r.width / state.w || 1;
    state.dpr = Math.min(maxDpr, (window.devicePixelRatio || 1) * zoom);
    canvas.width = Math.round(state.w * state.dpr); canvas.height = Math.round(state.h * state.dpr);
    canvas.style.width = `${state.w}px`; canvas.style.height = `${state.h}px`;
    ctx.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
    state.onResize?.();
  };
  new ResizeObserver(resize).observe(box);
  resize();
  return { canvas, ctx, state };
}

// Where a visual puts anything made of words: its panel if the stage has one, otherwise the stage itself.
export const panelOf = (host) => host.querySelector("[data-viz-panel]") || host;

// A static layer for visuals whose structure changes rarely (rings, labels, hundreds of links): drawn once into an
// offscreen canvas when something changes, then copied each frame, so animation costs one blit plus what moves.
export function layer(state) {
  const c = document.createElement("canvas"), g = c.getContext("2d");
  return {
    dirty: true,
    draw(ctx, paint) {
      const W = Math.round(state.w * state.dpr), H = Math.round(state.h * state.dpr);
      if (c.width !== W || c.height !== H) { c.width = W; c.height = H; this.dirty = true; }
      if (this.dirty) { g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H); g.setTransform(state.dpr, 0, 0, state.dpr, 0, 0); paint(g); this.dirty = false; }
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(c, 0, 0); ctx.restore();
    },
  };
}

// requestAnimationFrame loop that runs only while visible; time is paused, not skipped, when hidden.
export function loop(frame) {
  let raf = 0, running = false, last = 0, t = 0;
  const tick = (now) => {
    const dt = Math.min(0.05, (now - last) / 1000 || 0.016);
    last = now; t += dt;
    frame(t, dt);
    if (running) raf = requestAnimationFrame(tick);
  };
  return {
    start() { if (!running) { running = true; last = performance.now(); raf = requestAnimationFrame(tick); } },
    stop() { running = false; cancelAnimationFrame(raf); },
    get time() { return t; },
    set time(v) { t = v; },
  };
}

// Pointer position in -1..1 with slow smoothing: small perspective shifts, never chasing the cursor.
export function pointer(host) {
  const p = { x: 0, y: 0, tx: 0, ty: 0, inside: false, px: -1, py: -1 };
  host.addEventListener("pointermove", (e) => {
    const q = rel(host, e);
    p.px = q.x; p.py = q.y;
    p.tx = (p.px / (host.clientWidth || 1)) * 2 - 1; p.ty = (p.py / (host.clientHeight || 1)) * 2 - 1; p.inside = true;
  });
  host.addEventListener("pointerleave", () => { p.tx = 0; p.ty = 0; p.inside = false; p.px = -1; p.py = -1; });
  p.update = (k = 0.06) => { p.x = lerp(p.x, p.tx, k); p.y = lerp(p.y, p.ty, k); };
  return p;
}

// Simple perspective projection for "spatial" canvas scenes without a 3D engine.
export function project(x, y, z, cam) {
  const cy = Math.cos(cam.ry), sy = Math.sin(cam.ry), cx = Math.cos(cam.rx), sx = Math.sin(cam.rx);
  let X = x * cy - z * sy; let Z = x * sy + z * cy;
  let Y = y * cx - Z * sx; Z = y * sx + Z * cx;
  const s = cam.f / (cam.f + Z + cam.d);
  return { x: cam.cx + X * s, y: cam.cy + Y * s, s, z: Z };
}

export function glow(ctx, x, y, r, color, a = 1) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, rgba(color, 0.55 * a)); g.addColorStop(0.4, rgba(color, 0.16 * a)); g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
}

export function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

// Quadratic point along a curve, for signals travelling along paths.
export function qpoint(a, c, b, t) {
  const u = 1 - t;
  return { x: u * u * a.x + 2 * u * t * c.x + t * t * b.x, y: u * u * a.y + 2 * u * t * c.y + t * t * b.y };
}

// Floating tooltip rendered as HTML so it is crisp, selectable and readable by assistive technology on focus. It
// lives inside the drawing box, so it can never cover the panel's words beside or below the drawing.
export function tooltip(host) {
  const box = host.querySelector(":scope > .viz__canvas") || host;
  const el = document.createElement("div");
  el.className = "tooltip";
  el.setAttribute("role", "status");
  box.append(el);
  return {
    show(html, x, y) {
      el.innerHTML = html;
      const W = box.clientWidth, H = box.clientHeight;
      const w = el.offsetWidth || 240, h = el.offsetHeight || 120;
      // beside the pointer, flipping to the other side near an edge, never covering the point itself
      const left = x + 18 + w > W - 8 ? x - 18 - w : x + 18;
      el.style.left = `${Math.min(Math.max(8, left), W - w - 8)}px`;
      el.style.top = `${Math.min(Math.max(8, y - h / 2), H - h - 8)}px`;
      el.dataset.show = "true";
    },
    hide() { el.dataset.show = "false"; },
  };
}

// Mount helper: every visual returns { visible(bool) } so the page can pause it offscreen.
export function lifecycle(run, { reduced }) {
  let on = false;
  return {
    visible(v) {
      if (reduced) { run.renderStatic?.(); return; }
      if (v && !on) { on = true; run.start(); } else if (!v && on) { on = false; run.stop(); }
    },
  };
}
