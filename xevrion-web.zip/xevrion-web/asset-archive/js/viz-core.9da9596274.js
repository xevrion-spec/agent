// The Xevrion Intelligence Core: business data enters a layered structure, relationships form, an opportunity is
// identified, possible actions branch, one is chosen and executed, the outcome returns and value is recorded.
import { C, clamp, ease, easeInOut, glow, lerp, lifecycle, loop, mulberry, pointer, project, qpoint, rgba, stageCanvas } from "./viz-kit.88725e7ff9.js";

const PHASES = [ // [name, start, end] in seconds of a 14 s cycle
  ["connect", 0, 2.4], ["understand", 2.4, 4.4], ["identify", 4.4, 6], ["decide", 6, 8],
  ["act", 8, 9.6], ["verify", 9.6, 11.2], ["value", 11.2, 13.4],
];
const CYCLE = 14;
const STREAMS = ["Revenue data", "Customer data", "Process data", "Business metrics"];

export function mount(host, { reduced, track }) {
  const stage = host.querySelector(".core__stage") || host;
  const { ctx, state } = stageCanvas(stage);
  const p = pointer(stage);
  const rand = mulberry(7);
  const phaseEls = [...host.querySelectorAll("[data-phase]")];
  // floating cards declare the phases in which they are the thing being explained, e.g. data-card-phases="2,3"
  const cards = [...host.querySelectorAll("[data-card-phases]")].map((el) => [el, el.dataset.cardPhases.split(",").map(Number)]);

  // nodes live on the middle plane, in plane units (-1..1)
  const nodes = Array.from({ length: 30 }, (_, i) => {
    const a = rand() * Math.PI * 2, r = 0.25 + Math.sqrt(rand()) * 0.62;
    return { x: Math.cos(a) * r, y: Math.sin(a) * r, z: (rand() - 0.5) * 0.3, w: 0.6 + rand() * 0.8, i };
  });
  const edges = [];
  nodes.forEach((n, i) => {
    const near = nodes.map((m, j) => [j, Math.hypot(n.x - m.x, n.y - m.y)]).filter(([j]) => j !== i).sort((a, b) => a[1] - b[1]).slice(0, 2);
    near.forEach(([j, d]) => { if (d < 0.55 && !edges.some((e) => (e[0] === j && e[1] === i))) edges.push([i, j, rand()]); });
  });
  const opportunities = [3, 11, 19]; // the identified nodes; 11 becomes the chosen one
  const particles = Array.from({ length: 96 }, () => ({ s: Math.floor(rand() * 4), t: rand(), v: 0.18 + rand() * 0.22, o: (rand() - 0.5) * 0.18 }));
  let lastPhase = -1;

  function frame(time) {
    const t = time % CYCLE;
    const { w, h } = state;
    const R = Math.min(w, h) * 0.33;
    p.update();
    const cam = { rx: -0.62 + p.y * 0.08, ry: 0.78 + p.x * 0.14, f: 900, d: 0, cx: w * 0.52, cy: h * 0.5 };
    const phaseIndex = PHASES.findIndex(([, a, b]) => t >= a && t < b);
    const k = (name) => { const ph = PHASES.find((x) => x[0] === name); return clamp((t - ph[1]) / (ph[2] - ph[1])); };
    const after = (name) => t >= PHASES.find((x) => x[0] === name)[1];
    if (phaseIndex !== lastPhase) {
      lastPhase = phaseIndex;
      phaseEls.forEach((el, i) => el.setAttribute("aria-current", i === phaseIndex ? "step" : "false"));
      cards.forEach(([el, phases]) => el.toggleAttribute("data-active", phases.includes(phaseIndex)));
    }
    ctx.clearRect(0, 0, w, h);

    // ---------- input streams: curved paths from the left edge into the core
    const core = project(0, 0, 0, cam);
    const entries = STREAMS.map((_, i) => ({ x: w * 0.03, y: h * (0.16 + i * 0.22) }));
    const ctrl = entries.map((e) => ({ x: lerp(e.x, core.x, 0.55), y: lerp(e.y, core.y, 0.05) }));
    const connectBoost = t < 2.6 ? 1 : 0.35;
    entries.forEach((e, i) => {
      ctx.strokeStyle = rgba(C.text1, 0.05 + 0.05 * connectBoost);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.quadraticCurveTo(ctrl[i].x, ctrl[i].y, core.x, core.y); ctx.stroke();
      ctx.fillStyle = rgba(C.text2, 0.85);
      ctx.font = "500 10.5px 'Geist Mono', monospace";
      ctx.fillText(STREAMS[i].toUpperCase(), e.x + 2, e.y - 9);
      ctx.fillStyle = rgba(C.text1, 0.6); ctx.beginPath(); ctx.arc(e.x, e.y, 2, 0, Math.PI * 2); ctx.fill();
    });
    particles.forEach((pt) => {
      pt.t += pt.v * 0.016 * (0.6 + connectBoost);
      if (pt.t > 1) pt.t -= 1;
      const q = qpoint(entries[pt.s], { x: ctrl[pt.s].x, y: ctrl[pt.s].y + pt.o * h }, core, pt.t);
      const a = Math.sin(pt.t * Math.PI) * (0.25 + 0.55 * connectBoost);
      ctx.fillStyle = rgba(pt.t > 0.7 ? C.violetPale : C.text1, a);
      ctx.fillRect(q.x - 0.9, q.y - 0.9, 1.8, 1.8);
    });

    // ---------- glass planes (three layers: data, understanding, decision)
    [-0.34, 0, 0.34].forEach((zOff, li) => {
      const s = 1 - li * 0.14;
      const pts = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([x, y]) => project(x * R * s, y * R * s, zOff * R, cam));
      ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.closePath();
      const g = ctx.createLinearGradient(pts[0].x, pts[0].y, pts[2].x, pts[2].y);
      g.addColorStop(0, rgba(C.text1, 0.035)); g.addColorStop(0.5, rgba(C.violet, 0.045 + li * 0.01)); g.addColorStop(1, rgba(C.text1, 0.012));
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = rgba(li === 1 ? C.violetPale : C.text1, li === 1 ? 0.22 : 0.12); ctx.lineWidth = 1; ctx.stroke();
      if (li === 1) { // faint structural grid on the understanding plane
        ctx.strokeStyle = rgba(C.text1, 0.035);
        for (let gx = -0.5; gx <= 0.5; gx += 0.5) {
          const a = project(gx * R * s, -R * s, 0, cam), b = project(gx * R * s, R * s, 0, cam);
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          const c2 = project(-R * s, gx * R * s, 0, cam), d = project(R * s, gx * R * s, 0, cam);
          ctx.beginPath(); ctx.moveTo(c2.x, c2.y); ctx.lineTo(d.x, d.y); ctx.stroke();
        }
      }
    });

    // ---------- relationships form (understand) and nodes
    const P = nodes.map((n) => project(n.x * R, n.y * R, n.z * R, cam));
    const understand = after("understand") ? (t < PHASES[1][2] ? ease(k("understand")) : 1) : 0;
    const fade = t > 13.2 ? 1 - clamp((t - 13.2) / 0.8) : 1;
    edges.forEach(([i, j, r]) => {
      const a = clamp(understand * 1.4 - r * 0.4) * fade;
      if (a <= 0) return;
      ctx.strokeStyle = rgba(C.violetPale, 0.18 * a); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(P[i].x, P[i].y); ctx.lineTo(P[j].x, P[j].y); ctx.stroke();
    });
    const identify = after("identify") ? ease(k("identify")) : 0;
    P.forEach((q, i) => {
      const near = p.px >= 0 ? clamp(1 - Math.hypot(q.x - p.px, q.y - p.py) / 70) : 0;
      const isOpp = opportunities.includes(i);
      const hi = isOpp ? identify * fade : 0;
      const r = (1.4 + nodes[i].w) * q.s * (1 + hi * 0.8 + near * 0.6);
      if (hi > 0) {
        glow(ctx, q.x, q.y, 22 * hi * (i === 11 && after("decide") ? 1.4 : 1), C.violet, hi);
        ctx.strokeStyle = rgba(C.violetPale, 0.7 * hi); ctx.beginPath(); ctx.arc(q.x, q.y, 7 + 3 * hi, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = rgba(hi > 0.2 ? C.text1 : C.text2, 0.55 + 0.35 * Math.max(hi, near));
      ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, Math.PI * 2); ctx.fill();
    });

    // ---------- the core
    const breathe = 0.85 + Math.sin(time * 1.3) * 0.15;
    glow(ctx, core.x, core.y, R * 0.55 * breathe, C.violet, 0.9);
    glow(ctx, core.x, core.y, R * 0.16, C.violetPale, 0.9);
    ctx.fillStyle = rgba(C.text1, 0.95); ctx.beginPath(); ctx.arc(core.x, core.y, 3.2, 0, Math.PI * 2); ctx.fill();

    // ---------- decide: three possible actions branch out, one becomes dominant
    const branchEnd = [0.38, 0.56, 0.74].map((fy) => ({ x: w * 0.96, y: h * fy }));
    const branchCtl = branchEnd.map((b) => ({ x: lerp(core.x, b.x, 0.5), y: lerp(core.y, b.y, 0.15) }));
    const decide = after("decide") ? ease(k("decide") * 1.2) : 0;
    const chosen = 1;
    branchEnd.forEach((b, i) => {
      if (decide <= 0) return;
      const dominant = i === chosen;
      const resolve = clamp((k("decide") - 0.55) / 0.45);
      const a = (dominant ? 0.5 + 0.5 * resolve : 0.5 * (1 - 0.75 * resolve)) * fade;
      const steps = 40, upto = Math.floor(steps * clamp(decide));
      ctx.lineWidth = dominant ? 1.2 + resolve : 1;
      ctx.strokeStyle = dominant ? rgba(C.violetPale, 0.65 * a + 0.2) : rgba(C.text2, 0.3 * a);
      ctx.setLineDash(dominant ? [] : [3, 4]);
      ctx.beginPath();
      for (let s = 0; s <= upto; s++) { const q = qpoint(core, branchCtl[i], b, s / steps); s ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
      ctx.stroke(); ctx.setLineDash([]);
      if (decide >= 1) {
        ctx.fillStyle = dominant ? rgba(C.text1, 0.9 * a + 0.1) : rgba(C.text3, 0.7 * a);
        ctx.font = "500 10.5px 'Geist Mono', monospace";
        const lbl = dominant ? "CHOSEN ACTION" : "ALTERNATIVE";
        ctx.fillText(lbl, b.x - ctx.measureText(lbl).width - 4, b.y - 10);
      }
    });

    // ---------- act: a signal leaves along the chosen path; verify: feedback returns underneath
    if (after("act") && t < 13.4) {
      const ka = clamp((t - PHASES[4][1]) / 1.4);
      const q = qpoint(core, branchCtl[chosen], branchEnd[chosen], easeInOut(ka));
      glow(ctx, q.x, q.y, 18, C.violetPale, 1 - ka * 0.3);
      ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(q.x, q.y, 2.6, 0, Math.PI * 2); ctx.fill();
    }
    if (after("verify") && t < 13.4) {
      const kv = clamp((t - PHASES[5][1]) / 1.5);
      const from = branchEnd[chosen], back = { x: lerp(from.x, core.x, 0.5), y: core.y + R * 0.95 };
      ctx.strokeStyle = rgba(C.text1, 0.18 * fade); ctx.setLineDash([2, 5]);
      ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.quadraticCurveTo(back.x, back.y, core.x, core.y); ctx.stroke(); ctx.setLineDash([]);
      const q = qpoint(from, back, core, easeInOut(kv));
      ctx.fillStyle = rgba(C.text1, 0.95); ctx.beginPath(); ctx.arc(q.x, q.y, 2.4, 0, Math.PI * 2); ctx.fill();
      glow(ctx, q.x, q.y, 14, C.text1, 0.5);
    }
    // ---------- value: a verified ring expands from the core
    if (after("value")) {
      const kv = clamp((t - PHASES[6][1]) / 1.6);
      ctx.strokeStyle = rgba(C.text1, 0.5 * (1 - kv) * fade); ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(core.x, core.y, 10 + kv * R * 0.9, 0, Math.PI * 2); ctx.stroke();
    }
  }

  const run = loop(frame);
  // reduced motion: one composed frame with every stage drawn and every card fully readable
  run.renderStatic = () => {
    frame(12.4);
    phaseEls.forEach((el) => el.setAttribute("aria-current", "false"));
    cards.forEach(([el]) => el.toggleAttribute("data-active", true));
  };
  stage.addEventListener("pointerenter", () => track?.("viz_interact:core", true), { once: true });
  if (reduced) { state.onResize = run.renderStatic; run.renderStatic(); }
  return lifecycle(run, { reduced });
}
