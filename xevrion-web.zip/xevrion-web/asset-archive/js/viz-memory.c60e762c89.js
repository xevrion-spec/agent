// Learning and memory. Memories (customers, deals, tickets, invoices, decisions, lessons) appear on a timeline and
// connect to what they concern. Every few seconds a forecast is scored against the actual result: the error is shown,
// and the trust Xevrion places in that forecast adjusts (trust = 1 - error, bounded 0.25..1), as on the page.
import { C, clamp, ease, glow, lerp, lifecycle, loop, mulberry, rgba, stageCanvas } from "./viz-kit.88725e7ff9.js";

const TYPES = [["Customer", C.text1], ["Deal", C.violetPale], ["Ticket", "#f2c46b"], ["Invoice", C.text2], ["Decision", C.violetBright], ["Lesson", "#4fd69c"]];
const CYCLES = [31, 26, 19, 13, 9];     // forecast error per cycle, % (matches the page's chart)

export function mount(host, { reduced, track }) {
  const { ctx, state } = stageCanvas(host);
  const rand = mulberry(11);
  const out = { phase: host.querySelector('[data-o="phase"]'), big: host.querySelector('[data-o="big"]'), sub: host.querySelector('[data-o="sub"]') };
  const nodes = [], edges = [];
  let born = 0, cycle = 0, cycleT = 0, trust = 0.69, shownTrust = 0.69, phaseName = "";
  const hubs = []; // customers act as hubs other memories attach to

  const add = (t) => {
    const type = hubs.length < 5 && rand() < 0.35 ? 0 : 1 + Math.floor(rand() * 5);
    const n = { type, x: 0.12 + rand() * 0.8, y: 0.18 + rand() * 0.55, t, r: type === 0 ? 5.5 : 3.2 };
    nodes.push(n);
    if (type === 0) hubs.push(n);
    else if (hubs.length) {
      const hub = hubs.reduce((b, h) => (Math.hypot(h.x - n.x, h.y - n.y) < Math.hypot(b.x - n.x, b.y - n.y) ? h : b));
      edges.push([hub, n, t]);
      if (rand() < 0.3 && nodes.length > 3) edges.push([nodes[Math.floor(rand() * (nodes.length - 1))], n, t]);
    }
    if (nodes.length > 70) { const gone = nodes.shift(); for (let i = edges.length - 1; i >= 0; i--) if (edges[i][0] === gone || edges[i][1] === gone) edges.splice(i, 1); }
  };
  const setOut = (phase, big, sub) => {
    if (phase !== phaseName) { phaseName = phase; out.phase.textContent = phase; out.sub.textContent = sub; }
    if (out.big.textContent !== big) out.big.textContent = big;
  };

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    ctx.clearRect(0, 0, w, h);
    if (!reduced && time - born > 0.35) { born = time; add(time); }
    // timeline
    const ty = h * 0.86;
    ctx.strokeStyle = rgba(C.text1, 0.12); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(w * 0.06, ty); ctx.lineTo(w * 0.94, ty); ctx.stroke();
    ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillStyle = C.text3; ctx.textAlign = "left"; ctx.fillText("MEMORY TIMELINE", w * 0.06, ty + 18);
    ctx.textAlign = "right"; ctx.fillText("NOW", w * 0.94, ty + 18);
    // edges and nodes
    edges.forEach(([a, b, t]) => {
      const k = reduced ? 1 : ease(clamp((time - t) / 0.8));
      ctx.strokeStyle = rgba(C.violetPale, 0.16 * k); ctx.beginPath();
      ctx.moveTo(a.x * w, a.y * h); ctx.lineTo(lerp(a.x, b.x, k) * w, lerp(a.y, b.y, k) * h); ctx.stroke();
    });
    nodes.forEach((n, i) => {
      const k = reduced ? 1 : ease(clamp((time - n.t) / 0.5));
      const [, col] = TYPES[n.type];
      if (n.type === 0) glow(ctx, n.x * w, n.y * h, 22, C.violet, 0.45 * k);
      ctx.fillStyle = rgba(col, 0.85 * k); ctx.beginPath(); ctx.arc(n.x * w, n.y * h, n.r * k, 0, Math.PI * 2); ctx.fill();
      // its tick on the timeline
      const tx = w * 0.06 + (i / Math.max(1, nodes.length - 1)) * w * 0.88;
      ctx.fillStyle = rgba(col, 0.5); ctx.fillRect(tx - 0.5, ty - 6, 1, 6);
    });
    // legend
    if (w > 560) TYPES.forEach(([name, col], i) => {
      const x = w - 150, y = h * 0.14 + i * 18;
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, i === 0 ? 4.5 : 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = C.text2; ctx.textAlign = "left"; ctx.font = "500 11.5px Geist, sans-serif"; ctx.fillText(name, x + 12, y + 4);
    });
    // learning cycle: a forecast is scored, then trust adjusts
    cycleT += reduced ? 0 : dt;
    const e = CYCLES[cycle];
    if (cycleT < 2.2) setOut("Remembering", `${nodes.length} memories`, "Events, decisions and lessons, joined to the customers and processes they concern.");
    else if (cycleT < 4.4) {
      setOut(`Cycle ${cycle + 1}: scoring a forecast`, `error ${e}%`, e > 25 ? "Above 25%: flagged for recalibration." : e < 10 ? "Below 10%: kept as a strong model." : "Moderate: keep collecting actual results.");
      const k = ease(clamp((cycleT - 2.2) / 1.2));
      const fx = w * 0.5, fy = h * 0.1;
      ctx.strokeStyle = rgba(C.text1, 0.35); ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(fx - 90, fy); ctx.lineTo(fx + 90, fy); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = C.violetBright; ctx.beginPath(); ctx.arc(fx - 90 + 180 * 0.5, fy, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = C.text1; ctx.beginPath(); ctx.arc(fx - 90 + 180 * (0.5 + (e / 100) * k), fy, 5, 0, Math.PI * 2); ctx.fill();
      ctx.font = "500 10px 'Geist Mono', monospace"; ctx.textAlign = "center"; ctx.fillStyle = C.text3; ctx.fillText("FORECAST · ACTUAL", fx, fy - 12);
    } else if (cycleT < 6.4) {
      trust = clamp(1 - e / 100, 0.25, 1);
      shownTrust = lerp(shownTrust, trust, 0.06);
      setOut("Adjusting trust", `trust ${shownTrust.toFixed(2)}`, `Trust = 1 − error, kept between 0.25 and 1. Error ${e}% gives ${trust.toFixed(2)}.`);
    } else { cycleT = 0; cycle = (cycle + 1) % CYCLES.length; if (cycle === 0) track?.("viz_loop:memory", true); }
  }

  const run = loop(frame);
  run.renderStatic = () => {
    while (nodes.length < 48) add(0);
    frame(0, 0);
    out.phase.textContent = "Cycle 5: learned"; out.big.textContent = "trust 0.91"; out.sub.textContent = "Error fell from 31% to 9% over five cycles; trust rose from 0.69 to 0.91.";
  };
  if (reduced) { state.onResize = run.renderStatic; run.renderStatic(); }
  return lifecycle(run, { reduced });
}
