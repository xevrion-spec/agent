// Atlas: every page across the three Xevrion sites on one ring (grouped by site, then section) and every link in the
// pages' content drawn as a curve through the centre. Violet curves cross between sites. Hover a page to see what it
// links to (violet) and what links to it (white); click to open it. Search and the site switches dim everything else.
// The data (atlas.json) is generated from the built pages at every release, so the map is always the real site.
import { C, clamp, glow, lerp, lifecycle, loop, rgba, stageCanvas } from "./viz-kit.88725e7ff9.js";

const SITE = { parent: { name: "Group", col: C.text1 }, ops: { name: "Ops", col: C.violetPale }, portal: { name: "Portal", col: C.text2 } };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function mount(host, { reduced, track }) {
  const assets = JSON.parse(document.getElementById("xw-assets")?.textContent || "{}");
  const root = host.closest("section") || document;
  const tools = root.querySelector("[data-atlas-tools]");
  const input = root.querySelector("[data-atlas-q]");
  const chips = [...root.querySelectorAll("[data-atlas-site]")];
  const readout = host.querySelector("[data-atlas-readout]");
  const { ctx, state } = stageCanvas(host);
  let data = null, pos = [], out = [], inn = [], hover = -1, query = "", site = "all", used = false, pulses = [];

  const use = (what) => { if (!used) { used = true; track?.(`viz_interact:atlas:${what}`, true); } };
  const matches = (n) => (site === "all" || n.s === site) && (!query || (n.t + " " + n.u + " " + n.g).toLowerCase().includes(query));
  const href = (n) => (location.origin === data.origins[n.s] ? "" : data.origins[n.s]) + n.u;

  function layout() {
    const { w, h } = state;
    const n = data.nodes.length;
    const groups = new Set(data.nodes.map((x) => x.s + "|" + x.g)).size;
    const slots = n + 3 * 4 + groups * 1.2;             // gaps: 4 slots between sites, 1.2 between sections
    const step = (Math.PI * 2) / slots;
    // wide: room outside the ring for page names (≤ 22 characters) and the site arcs; narrow: names on hover only
    state.labelsOn = w > 820;
    // narrow screens: the readout sits above the ring rather than over it
    const top = state.labelsOn ? 0 : 118;
    state.cx = w / 2; state.cy = top + (h - top) / 2;
    const R = Math.max(60, state.labelsOn ? Math.min(w * 0.28, h / 2 - 156) : Math.min(w * 0.42, (h - top) / 2 - 34));
    state.ring = R + (state.labelsOn ? 136 : 14);
    let a = -Math.PI / 2 + step * 2, prev = null;
    pos = data.nodes.map((node) => {
      const key = node.s + "|" + node.g;
      if (prev && prev.split("|")[0] !== node.s) a += step * 4;
      else if (prev && prev !== key) a += step * 1.2;
      prev = key;
      const p = { a, x: state.cx + Math.cos(a) * R, y: state.cy + Math.sin(a) * R, R };
      a += step;
      return p;
    });
    state.step = step; state.R = R;
  }

  function label(i, strong) {
    const n = data.nodes[i], p = pos[i];
    const left = Math.cos(p.a) < 0;
    const text = n.t.length > 22 ? n.t.slice(0, 21) + "…" : n.t;
    ctx.save(); ctx.translate(state.cx + Math.cos(p.a) * (p.R + 12), state.cy + Math.sin(p.a) * (p.R + 12));
    ctx.rotate(left ? p.a + Math.PI : p.a);
    ctx.textAlign = left ? "right" : "left"; ctx.textBaseline = "middle";
    ctx.font = `${strong ? 600 : 500} ${strong ? 12 : 10}px Geist, sans-serif`;
    ctx.fillStyle = strong ? C.text1 : rgba(C.text2, 0.8);
    ctx.fillText(text, 0, 0);
    ctx.restore();
  }

  function frame(time = 0, dt = 0.016) {
    if (!data) return;
    const { w, h, cx, cy } = state;
    ctx.clearRect(0, 0, w, h);
    const focus = hover >= 0 ? new Set([hover, ...out[hover], ...inn[hover]]) : null;
    const lit = data.nodes.map((n, i) => (focus ? focus.has(i) : matches(n)));
    // site arcs and section ticks around the outside
    const labelsOn = state.labelsOn, ring = state.ring;
    let start = 0;
    data.nodes.forEach((n, i) => {
      const last = i === data.nodes.length - 1 || data.nodes[i + 1].s !== n.s;
      if (!last) return;
      const a0 = pos[start].a - state.step * 0.5, a1 = pos[i].a + state.step * 0.5;
      ctx.strokeStyle = rgba(SITE[n.s].col, site === "all" || site === n.s ? 0.55 : 0.15); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(cx, cy, ring, a0, a1); ctx.stroke();
      const am = (a0 + a1) / 2, lx = cx + Math.cos(am) * (ring + 12), ly = cy + Math.sin(am) * (ring + 12);
      ctx.font = "500 10.5px 'Geist Mono', monospace"; ctx.textAlign = Math.cos(am) > 0.2 ? "left" : Math.cos(am) < -0.2 ? "right" : "center";
      ctx.fillStyle = rgba(SITE[n.s].col, 0.9); ctx.fillText(`${SITE[n.s].name.toUpperCase()} · ${i - start + 1}`, lx, ly + 4);
      start = i + 1;
    });
    // links, bundled through the centre
    data.edges.forEach(([a, b]) => {
      const pa = pos[a], pb = pos[b];
      const cross = data.nodes[a].s !== data.nodes[b].s;
      let alpha, col = cross ? C.violetBright : C.text1, width = 1;
      if (focus) {
        if (a === hover) { alpha = 0.85; col = C.violetBright; width = 1.6; }
        else if (b === hover) { alpha = 0.7; col = C.text1; width = 1.3; }
        else alpha = 0.025;
      } else alpha = lit[a] && lit[b] ? (cross ? 0.3 : 0.075) : 0.02;
      const mx = (pa.x + pb.x) / 2, my = (pa.y + pb.y) / 2;
      ctx.strokeStyle = rgba(col, alpha); ctx.lineWidth = width;
      ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.quadraticCurveTo(lerp(cx, mx, 0.22), lerp(cy, my, 0.22), pb.x, pb.y); ctx.stroke();
    });
    // signals travelling along links that cross between sites
    if (!reduced && !focus) {
      if (pulses.length < 18 && Math.random() < 0.08) {
        const crossEdges = data.edges.filter(([a, b]) => data.nodes[a].s !== data.nodes[b].s && lit[a] && lit[b]);
        if (crossEdges.length) pulses.push({ e: crossEdges[Math.floor(Math.random() * crossEdges.length)], t: 0 });
      }
      pulses = pulses.filter((p) => (p.t += dt * 0.55) < 1);
      pulses.forEach(({ e: [a, b], t }) => {
        const pa = pos[a], pb = pos[b], c = { x: lerp(cx, (pa.x + pb.x) / 2, 0.22), y: lerp(cy, (pa.y + pb.y) / 2, 0.22) }, u = 1 - t;
        const x = u * u * pa.x + 2 * u * t * c.x + t * t * pb.x, y = u * u * pa.y + 2 * u * t * c.y + t * t * pb.y;
        glow(ctx, x, y, 10, C.violet, Math.sin(t * Math.PI));
        ctx.fillStyle = rgba(C.text1, Math.sin(t * Math.PI)); ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
      });
    }
    // pages
    data.nodes.forEach((n, i) => {
      const p = pos[i], on = lit[i], me = i === hover;
      const r = me ? 5 : 2.4 + Math.min(2.4, inn[i].length * 0.18);
      if (me) glow(ctx, p.x, p.y, 26, C.violet, 1);
      ctx.fillStyle = rgba(SITE[n.s].col, on ? 0.95 : 0.18);
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
      if (labelsOn && (on || me)) label(i, me);
    });
    // the centre: a quiet core readout
    ctx.textAlign = "center"; ctx.fillStyle = C.text3; ctx.font = "500 10px 'Geist Mono', monospace";
    ctx.fillText(focus ? "" : `${data.nodes.filter(matches).length} PAGES · ${data.edges.length} LINKS`, cx, cy + 4);
  }

  function describe(i) {
    if (i < 0) {
      const cross = data.edges.filter(([a, b]) => data.nodes[a].s !== data.nodes[b].s).length;
      readout.innerHTML = `<span class="label label--violet">Atlas</span><strong>${data.nodes.length} pages · ${data.edges.length} links</strong><span>${cross} links cross between Xevrion sites. Hover or tap a page to trace its links; click it, or tap it again, to open it.</span>`;
      return;
    }
    const n = data.nodes[i];
    readout.innerHTML = `<span class="label label--violet">${esc(SITE[n.s].name)} · ${esc(n.g)}</span><strong>${esc(n.t)}</strong>` +
      `<span class="mono small">${esc(n.u)}</span><span>${esc(n.d)}</span><span class="atlas__deg"><b>${out[i].length}</b> links out · <b>${inn[i].length}</b> links in</span>`;
  }

  function hit(e) {
    const r = host.getBoundingClientRect(), x = e.clientX - r.left - state.cx, y = e.clientY - r.top - state.cy;
    const d = Math.hypot(x, y);
    if (d < state.R - 36 || d > state.ring) return -1;
    const a = Math.atan2(y, x);
    let best = -1, bd = state.step * 0.8;
    pos.forEach((p, i) => {
      const diff = Math.abs(Math.atan2(Math.sin(a - p.a), Math.cos(a - p.a)));
      if (diff < bd && (site === "all" || data.nodes[i].s === site)) { bd = diff; best = i; }
    });
    return best;
  }

  host.addEventListener("pointermove", (e) => {
    if (!data || e.pointerType !== "mouse") return;
    const i = hit(e);
    if (i !== hover) { hover = i; describe(i); host.style.cursor = i >= 0 ? "pointer" : ""; if (i >= 0) use("hover"); if (reduced) frame(); }
  });
  host.addEventListener("pointerleave", (e) => { if (e.pointerType !== "mouse") return; hover = -1; if (data) describe(-1); if (reduced) frame(); });
  // touch has no hover: the first tap on a page shows it, a second tap on the same page opens it
  let lastType = "mouse";
  host.addEventListener("pointerdown", (e) => { lastType = e.pointerType; });
  host.addEventListener("click", (e) => {
    const i = data ? hit(e) : -1;
    if (i < 0) return;
    if (lastType !== "mouse" && hover !== i) { hover = i; describe(i); use("tap"); if (reduced) frame(); return; }
    track?.(`atlas_open:${data.nodes[i].s}${data.nodes[i].u}`); location.href = href(data.nodes[i]);
  });
  input?.addEventListener("input", () => { query = input.value.trim().toLowerCase(); use("search"); if (reduced) frame(); });
  chips.forEach((c) => c.addEventListener("click", () => {
    site = c.dataset.atlasSite; chips.forEach((x) => x.setAttribute("aria-pressed", String(x === c))); use("site"); if (reduced) frame();
  }));

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  fetch(assets["atlas.json"]).then((r) => r.json()).then((d) => {
    data = d;
    out = d.nodes.map(() => []); inn = d.nodes.map(() => []);
    d.edges.forEach(([a, b]) => { out[a].push(b); inn[b].push(a); });
    if (tools) tools.hidden = false;
    state.onResize = () => { layout(); if (reduced) frame(); };
    layout(); describe(-1); frame();
  }).catch(() => { host.dataset.failed = "1"; });
  return lifecycle(run, { reduced });
}
