// The customer portal presentation (/customer-portal): the real portal (portal-app.js and portal.css, copied from the
// gateway by tools/sync_portal.py) booted on an illustrative example company (portal-demo.js). It loads only when the
// frame approaches the viewport; the screen list below the frame opens any screen in it.
import { demoApi } from "./portal-demo.72adab30df.js";

export function mount(host, { track }) {
  const assets = JSON.parse(document.getElementById("xw-assets")?.textContent || "{}");
  if (assets["portal.css"] && !document.querySelector("link[data-portal-css]")) {
    const link = document.createElement("link");
    link.rel = "stylesheet"; link.href = assets["portal.css"]; link.dataset.portalCss = "";
    document.head.append(link);
  }
  let ready = null;
  const boot = () => (ready ||= (async () => {
    await import(assets["portal-app.js"]);
    host.replaceChildren();
    await window.XevrionPortal.boot(host, { api: demoApi(), demo: true });
    track?.("portal_demo:open", true);
  })());
  const smooth = () => (matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth");
  document.querySelectorAll("[data-portal-go]").forEach((b) => b.addEventListener("click", async () => {
    await boot();
    host.closest("figure")?.scrollIntoView({ behavior: smooth(), block: "start" });
    await window.XevrionPortal.go(b.dataset.portalGo);
    track?.(`portal_demo:${b.dataset.portalGo}`);
  }));
  return { visible(v) { if (v) boot(); } };
}
