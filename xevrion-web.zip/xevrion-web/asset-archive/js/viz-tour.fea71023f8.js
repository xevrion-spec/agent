// Guided tour player. Each step shows for 3 seconds, then the next one; after a system's last step the tour carries
// on into the next system. Back, Next and the step dots move freely at any time. Autoplay stops while the tour is
// off screen or the tab is hidden, can be paused (WCAG 2.2.2), and never starts when reduced motion is requested.
const STEP_MS = 3000;

export function mount(host, { reduced, track }) {
  const tabs = [...host.querySelectorAll("[role=tab]")];
  const panels = [...host.querySelectorAll("[role=tabpanel]")];
  const bar = host.querySelector("[data-bar]");
  const where = bar.querySelector("[data-where]");
  const dots = bar.querySelector("[data-dots]");
  const toggle = bar.querySelector("[data-toggle]");
  let t = 0, s = 0, playing = !reduced, visible = false, timer = 0;
  const seen = new Set();
  host.classList.add("is-live");
  bar.hidden = false;

  const steps = () => [...panels[t].querySelectorAll(".tour__step")];
  const schedule = () => {
    clearTimeout(timer);
    if (playing && visible && document.visibilityState === "visible") timer = setTimeout(advance, STEP_MS);
  };
  const render = () => {
    panels.forEach((p, i) => { p.hidden = i !== t; });
    tabs.forEach((b, i) => { b.setAttribute("aria-selected", String(i === t)); b.tabIndex = i === t ? 0 : -1; });
    const list = steps();
    list.forEach((li, i) => li.toggleAttribute("data-on", i === s));
    dots.innerHTML = list.map((_, i) => `<button type="button" class="tour__dot" aria-label="Step ${i + 1}"${i === s ? ' aria-current="step"' : ""} data-dot="${i}"></button>`).join("");
    where.textContent = `${tabs[t].textContent.trim()} · step ${s + 1} of ${list.length}`;
    toggle.querySelector("span").textContent = playing ? "Pause" : "Play";
    toggle.setAttribute("aria-label", playing ? "Pause the tour" : "Play the tour");
    schedule();
  };
  const go = (track_, step, user) => {
    t = (track_ + tabs.length) % tabs.length;
    const n = steps().length;
    s = Math.max(0, Math.min(n - 1, step));
    if (s === n - 1 && !seen.has(t)) { seen.add(t); track?.(`tour_complete:${tabs[t].dataset.track}`, true); }
    if (user) track?.(`tour_step:${tabs[t].dataset.track}:${s + 1}`);
    render();
  };
  function advance() {
    if (s < steps().length - 1) go(t, s + 1);
    else go(t + 1, 0);                                        // carry on into the next system
  }
  const back = () => (s > 0 ? go(t, s - 1, true) : go(t - 1, 99, true));
  const next = () => (s < steps().length - 1 ? go(t, s + 1, true) : go(t + 1, 0, true));

  tabs.forEach((b, i) => {
    b.addEventListener("click", () => go(i, 0, true));
    b.addEventListener("keydown", (e) => {
      const n = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (n === undefined) return;
      e.preventDefault(); go(n, 0, true); tabs[t].focus();
    });
  });
  bar.querySelector("[data-prev]").addEventListener("click", back);
  bar.querySelector("[data-next]").addEventListener("click", next);
  dots.addEventListener("click", (e) => { const d = e.target.closest("[data-dot]"); if (d) go(t, +d.dataset.dot, true); });
  toggle.addEventListener("click", () => { playing = !playing; render(); track?.(`tour_${playing ? "play" : "pause"}`); });
  host.addEventListener("keydown", (e) => {
    if (e.target.closest("[role=tab]") || e.target.closest("input,textarea,select")) return;
    if (e.key === "ArrowRight") { e.preventDefault(); next(); }
    if (e.key === "ArrowLeft") { e.preventDefault(); back(); }
  });
  document.addEventListener("visibilitychange", schedule);
  go(0, 0);
  return { visible(v) { visible = v; schedule(); } };
}
