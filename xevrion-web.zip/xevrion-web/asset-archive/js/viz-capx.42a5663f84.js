// Capability explorer: filters the server-rendered specification by text, and shows one group at a time. Matches are
// highlighted in place. Without this module every group and capability is simply listed, which is complete on its own.
export function mount(host, { track }) {
  const bar = host.querySelector("[data-cx-bar]");
  const input = host.querySelector("[data-cx-q]");
  const chips = [...host.querySelectorAll("[data-cx-g]")];
  const groups = [...host.querySelectorAll("[data-cx-group]")];
  const items = [...host.querySelectorAll(".cx__item")];
  const count = host.querySelector("[data-cx-count]");
  const empty = host.querySelector("[data-cx-empty]");
  const original = new Map(items.map((li) => [li, [...li.querySelectorAll(".cx__name,.cx__desc")].map((el) => el.textContent)]));
  let group = "all", used = false;
  bar.hidden = false;

  const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const mark = (text, q) => {
    if (!q) return esc(text);
    const i = text.toLowerCase().indexOf(q);
    return i < 0 ? esc(text) : esc(text.slice(0, i)) + "<mark>" + esc(text.slice(i, i + q.length)) + "</mark>" + esc(text.slice(i + q.length));
  };

  function apply() {
    const q = input.value.trim().toLowerCase();
    let shown = 0;
    groups.forEach((g) => {
      const inGroup = group === "all" || g.dataset.cxGroup === group;
      let visible = 0;
      g.querySelectorAll(".cx__item").forEach((li) => {
        const hit = inGroup && (!q || li.dataset.cxText.includes(q));
        li.hidden = !hit;
        const [name, desc] = original.get(li);
        const [nEl, dEl] = li.querySelectorAll(".cx__name,.cx__desc");
        nEl.innerHTML = mark(name, q); dEl.innerHTML = mark(desc, q);
        if (hit) visible++;
      });
      g.hidden = visible === 0;
      shown += visible;
    });
    count.textContent = shown;
    empty.hidden = shown > 0;
    if (!used && (q || group !== "all")) { used = true; track?.("capx_filter", true); }
  }

  input.addEventListener("input", apply);
  input.addEventListener("keydown", (e) => { if (e.key === "Escape" && input.value) { input.value = ""; apply(); } });
  chips.forEach((c) => c.addEventListener("click", () => {
    group = c.dataset.cxG;
    chips.forEach((x) => x.setAttribute("aria-pressed", String(x === c)));
    apply();
    const top = host.getBoundingClientRect().top;
    if (top < 0) host.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
  }));
  return { visible() {} };
}
