// Group homepage: the Xevrion constellation. The mark sits at the centre on the shared foundation ring; ventures orbit
// it. Live ventures are solid and bright, planned ones dashed; faint points are future ventures. Signals flow from the
// foundation to every venture. Hover a venture for its status; click to open its page.
import { C, glow, lerp, lifecycle, loop, pointer, rgba, stageCanvas, tooltip, rel } from "./viz-kit.0fe0c83bce.js";

const FOUNDATION = ["Infrastructure", "Security", "AI governance", "Reliability", "Measurement", "Brand"];
const VENTURES = [
  { name: "Xevrion Ops", tag: "OPS · LIVE", live: true, href: "/ventures/ops", r: 0.62, a: -0.55, speed: 0.035, moons: ["Revenue", "Customers", "Operations", "Decisions"] },
  { name: "Xevrion Cyber", tag: "CYBER · PLANNED", live: false, href: "/ventures/cyber", r: 0.82, a: 2.35, speed: 0.022, moons: [] },
];
const FUTURE = [{ r: 0.9, a: 0.9 }, { r: 0.74, a: 3.9 }, { r: 0.95, a: 5.1 }];

// The Xevrion mark (xw/html.py MARK_PATHS) on a 32-unit grid: a ring, and a blade cutting out through it.
const MARK = ["M27.37 9.71A13 13 0 1 1 22.29 4.63L19.71 8.02A8.8 8.8 0 1 0 23.98 12.29Z",
  "M13.45 18.55L28.87 6.81L25.19 3.13Z"].map((d) => new Path2D(d));
// The chrome finish, as in xw/html.py CHROME_STOPS: canvas gradients are drawn in the current (scaled) space, so the
// same 32-unit coordinates give the same metal at any size.
const CHROME = [[0, "#ffffff"], [0.24, "#e9ecf2"], [0.45, "#9ba1af"], [0.5, "#4f5463"], [0.53, "#cfd4de"], [0.72, "#ffffff"], [1, "#a9afbc"]];
function mark(ctx, x, y, s, alpha) { // drawn at scale s (units of a 32px box), in chrome
  ctx.save(); ctx.translate(x - 16 * s, y - 16 * s); ctx.scale(s, s); ctx.globalAlpha = alpha;
  const metal = ctx.createLinearGradient(16, 3, 16, 29); CHROME.forEach(([o, c]) => metal.addColorStop(o, c));
  ctx.fillStyle = metal; MARK.forEach((p) => ctx.fill(p));
  const sheen = ctx.createLinearGradient(5, 5, 27, 27);
  sheen.addColorStop(0.38, "rgba(255,255,255,0)"); sheen.addColorStop(0.5, "rgba(255,255,255,0.6)"); sheen.addColorStop(0.62, "rgba(255,255,255,0)");
  ctx.fillStyle = sheen; MARK.forEach((p) => ctx.fill(p));
  ctx.restore();
}

export function mount(host, { reduced, track }) {
  const stage = host.querySelector(".constellation__stage") || host;
  const { ctx, state } = stageCanvas(stage);
  const tip = tooltip(stage);
  const p = pointer(stage);
  const signals = Array.from({ length: 22 }, (_, i) => ({ v: i % VENTURES.length, t: i / 22, s: 0.12 + (i % 5) * 0.03 }));
  let hover = null, positions = [];
  // words never overlap: each foundation name has a box, and it fades out while that box would touch the mark, a
  // venture, its moons or tag, or another name, then fades back in once it is clear again
  const FONT_F = "500 9.5px 'Geist Mono', monospace", FONT_V = "500 10.5px 'Geist Mono', monospace";
  const fade = FOUNDATION.map(() => 1);
  let widths = new Map();
  const tw = (t, font) => { const k = font + t; if (!widths.has(k)) { ctx.font = font; widths.set(k, ctx.measureText(t).width); } return widths.get(k); };
  document.fonts?.ready.then(() => { widths = new Map(); });
  const PAD = 6;   // clear space kept around every word
  const touches = (a, b) => a.x0 - PAD < b.x1 && b.x0 - PAD < a.x1 && a.y0 - PAD < b.y1 && b.y0 - PAD < a.y1;
  const around = (x, y, r) => ({ x0: x - r, x1: x + r, y0: y - r, y1: y + r });

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    p.update();
    const cx = w / 2 + p.x * 8, cy = h / 2 + p.y * 6, R = Math.min(w * 0.47, h * 0.6), FR = 0.3;
    const ms = Math.max(1.4, R / 110);
    ctx.clearRect(0, 0, w, h);
    // where the ventures are this frame (their space is reserved before any name is placed)
    positions = VENTURES.map((v) => {
      const a = v.a + (reduced ? 0 : time * v.speed);
      return { v, x: cx + Math.cos(a) * R * v.r, y: cy + Math.sin(a) * R * v.r * 0.62 };
    });
    const taken = [around(cx, cy, 15 * ms + 6)];
    positions.forEach(({ v, x, y }) => {
      const tw_ = tw(v.tag, FONT_V);
      taken.push(around(x, y, v.moons.length ? 36 : 22), { x0: x - tw_ / 2 - 6, x1: x + tw_ / 2 + 6, y0: y + 24, y1: y + 39 });
    });
    // orbits
    [FR, ...VENTURES.map((v) => v.r), ...FUTURE.map((f) => f.r)].forEach((r, i) => {
      ctx.strokeStyle = rgba(C.text1, i === 0 ? 0.16 : 0.06); ctx.lineWidth = 1;
      if (i > VENTURES.length) ctx.setLineDash([2, 6]);
      ctx.beginPath(); ctx.ellipse(cx, cy, R * r, R * r * 0.62, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    });
    // the foundation ring with its six layers; each name sits outward from its point
    const names = [];
    FOUNDATION.forEach((f, i) => {
      const a = (i / FOUNDATION.length) * Math.PI * 2 + (reduced ? 0 : time * 0.04), c = Math.cos(a), s = Math.sin(a);
      const x = cx + c * R * FR, y = cy + s * R * FR * 0.62;
      ctx.fillStyle = rgba(C.violetPale, 0.9); ctx.beginPath(); ctx.arc(x, y, 2.6, 0, Math.PI * 2); ctx.fill();
      if (w <= 520) return;
      const text = f.toUpperCase(), wd = tw(text, FONT_F);
      const align = c > 0.35 ? "left" : c < -0.35 ? "right" : "center";
      const bx = align === "left" ? x + 9 : align === "right" ? x - 9 : x;
      const by = align === "center" ? y + (s > 0 ? 16 : -9) : y + 3.5 + s * 6;
      const box = { x0: align === "left" ? bx : align === "right" ? bx - wd : bx - wd / 2, y0: by - 9, y1: by + 3 };
      box.x1 = box.x0 + wd;
      const clear = !taken.some((o) => touches(box, o));
      if (clear) taken.push(box);
      fade[i] = reduced ? +clear : lerp(fade[i], clear ? 1 : 0, clear ? 0.08 : 0.3);
      names.push({ text, bx, by, align, alpha: fade[i] });
    });
    glow(ctx, cx, cy, R * 0.34, C.violet, 0.75);
    mark(ctx, cx, cy, ms, 0.98);
    ctx.font = FONT_F;
    names.forEach((n) => { if (n.alpha > 0.02) { ctx.textAlign = n.align; ctx.fillStyle = rgba(C.text3, 0.95 * n.alpha); ctx.fillText(n.text, n.bx, n.by); } });
    // ventures
    positions.forEach(({ v, x, y }) => {
      const on = hover === v;
      if (v.live) glow(ctx, x, y, 46, C.violet, on ? 1 : 0.7);
      ctx.lineWidth = 1.6; ctx.strokeStyle = v.live ? C.text1 : rgba(C.text1, 0.55);
      if (!v.live) ctx.setLineDash([3, 4]);
      ctx.fillStyle = v.live ? rgba(C.bg, 0.9) : rgba(C.bg, 0.6);
      ctx.beginPath(); ctx.arc(x, y, on ? 17 : 15, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.setLineDash([]);
      mark(ctx, x, y, 0.62, v.live ? 0.95 : 0.55);
      v.moons.forEach((m, k) => {
        const ma = (k / v.moons.length) * Math.PI * 2 + (reduced ? 0 : time * 0.5);
        const mx = x + Math.cos(ma) * 30, my = y + Math.sin(ma) * 30 * 0.7;
        ctx.fillStyle = rgba(C.violetPale, 0.85); ctx.beginPath(); ctx.arc(mx, my, 2.2, 0, Math.PI * 2); ctx.fill();
      });
      ctx.font = FONT_V; ctx.textAlign = "center";
      ctx.fillStyle = v.live ? C.text1 : C.text3; ctx.fillText(v.tag, x, y + 34);
    });
    FUTURE.forEach((f) => {
      const a = f.a + (reduced ? 0 : time * 0.015);
      ctx.fillStyle = rgba(C.text1, 0.18); ctx.beginPath(); ctx.arc(cx + Math.cos(a) * R * f.r, cy + Math.sin(a) * R * f.r * 0.62, 3, 0, Math.PI * 2); ctx.fill();
    });
    // signals from the foundation out to each venture
    if (!reduced) signals.forEach((s) => {
      s.t = (s.t + s.s * dt) % 1;
      const target = positions[s.v];
      const x = lerp(cx, target.x, s.t), y = lerp(cy, target.y, s.t);
      ctx.fillStyle = rgba(target.v.live ? C.violetPale : C.text2, Math.sin(s.t * Math.PI) * (target.v.live ? 0.9 : 0.35));
      ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
    });
  }
  const hit = (e) => {
    const r = rel(stage, e), px = r.x, py = r.y;
    return positions.find((q) => Math.hypot(q.x - px, q.y - py) < 24);
  };
  stage.addEventListener("pointermove", (e) => {
    const q = hit(e);
    hover = q?.v || null;
    stage.style.cursor = q ? "pointer" : "";
    if (q) tip.show(`<strong>${q.v.name}</strong><br><span class="quiet">${q.v.live ? "Live" : "Planned"}</span><p style="margin-top:6px">${q.v.live ? "Four systems: " + q.v.moons.join(", ") : "Security for growing businesses"}. Click to learn more.</p>`, q.x, q.y);
    else tip.hide();
    if (reduced) frame(0, 0);
  });
  stage.addEventListener("pointerleave", () => { hover = null; tip.hide(); });
  stage.addEventListener("click", (e) => { const q = hit(e); if (q) { track?.(`constellation:${q.v.href}`); location.href = q.v.href; } });

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
