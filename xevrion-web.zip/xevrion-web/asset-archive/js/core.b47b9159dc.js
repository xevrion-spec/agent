// Xevrion site runtime. Progressive enhancement only: every page is complete HTML without this file.
const API = "https://api.xevrion.co.uk";
const ASSETS = JSON.parse(document.getElementById("xw-assets")?.textContent || "{}");
const reduced = matchMedia("(prefers-reduced-motion: reduce)");
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

// ------------------------------------------------------------------------------------------------ analytics
// Cookieless and first-party. No identifier is stored: events are counted, and only the first-touch source of this
// browser session (UTM or referring site) is kept in sessionStorage so sign-ups and enquiries can be counted by channel.
// Global Privacy Control, Do Not Track and the opt-out on /legal/cookies all switch it off entirely.
const Analytics = (() => {
  const off = () => {
    try { if (localStorage.getItem("xev_analytics_off") === "1") return true; } catch { /* storage blocked */ }
    return navigator.globalPrivacyControl === true || navigator.doNotTrack === "1";
  };
  const site = document.documentElement.dataset.site;
  let queue = [];
  const source = (() => {
    try {
      const saved = sessionStorage.getItem("xev_src");
      if (saved) return JSON.parse(saved);
      const q = new URLSearchParams(location.search);
      const ref = document.referrer ? new URL(document.referrer).hostname : "";
      const internal = /(^|\.)xevrion\.co\.uk$/.test(ref);
      const src = {
        source: q.get("utm_source") || (ref && !internal ? ref : "direct"),
        medium: q.get("utm_medium") || (ref && !internal ? "referral" : "none"),
        campaign: q.get("utm_campaign") || "",
        landing: location.pathname,
      };
      if (!off()) sessionStorage.setItem("xev_src", JSON.stringify(src));
      return src;
    } catch { return { source: "unknown", medium: "", campaign: "", landing: location.pathname }; }
  })();
  const seen = new Set();
  function track(name, once = false) {
    if (off()) return;
    if (once) { if (seen.has(name)) return; seen.add(name); }
    queue.push({ n: String(name).slice(0, 80), p: location.pathname, s: site });
    if (queue.length >= 12) flush();
  }
  function flush() {
    if (!queue.length || off()) { queue = []; return; }
    const body = JSON.stringify({ v: 1, events: queue.splice(0, 20), source });
    // text/plain keeps this a CORS "simple" request: no preflight, and keepalive lets it outlive the page.
    fetch(`${API}/v1/public/events`, { method: "POST", body, keepalive: true, mode: "cors", credentials: "omit",
      headers: { "Content-Type": "text/plain;charset=UTF-8" } }).catch(() => {});
  }
  addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") flush(); });
  setInterval(flush, 8000);
  return { track, flush, source, off };
})();
window.xevTrack = Analytics.track;

Analytics.track(`page_view:${document.documentElement.dataset.env}`);
document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-event]");
  if (el) Analytics.track(el.dataset.event);
});
{
  let marks = [50, 90];
  addEventListener("scroll", () => {
    const depth = (scrollY + innerHeight) / document.documentElement.scrollHeight * 100;
    marks = marks.filter((m) => { if (depth >= m) { Analytics.track(`scroll_${m}`, true); return false; } return true; });
  }, { passive: true });
}

// ------------------------------------------------------------------------------------------------ navigation
const navEl = $("[data-nav]");
const onScroll = () => navEl?.setAttribute("data-scrolled", String(scrollY > 8));
addEventListener("scroll", onScroll, { passive: true });
onScroll();

function closeMenus(except) {
  $$("[data-menu]").forEach((b) => {
    if (b === except) return;
    b.setAttribute("aria-expanded", "false");
    $(`#${b.getAttribute("aria-controls")}`)?.setAttribute("data-open", "false");
  });
}
$$("[data-menu]").forEach((btn) => {
  const panel = $(`#${btn.getAttribute("aria-controls")}`);
  const set = (open) => {
    closeMenus(btn);
    btn.setAttribute("aria-expanded", String(open));
    panel.setAttribute("data-open", String(open));
    if (open) Analytics.track(`menu_open:${btn.textContent.trim()}`);
  };
  btn.addEventListener("click", () => set(btn.getAttribute("aria-expanded") !== "true"));
  // Hover intent for pointer users; keyboard and touch use click.
  let timer;
  const item = btn.parentElement;
  item.addEventListener("pointerenter", (e) => { if (e.pointerType === "mouse") { clearTimeout(timer); timer = setTimeout(() => set(true), 90); } });
  item.addEventListener("pointerleave", (e) => { if (e.pointerType === "mouse") { clearTimeout(timer); timer = setTimeout(() => set(false), 160); } });
  panel.addEventListener("keydown", (e) => {
    const links = $$("a", panel);
    const i = links.indexOf(document.activeElement);
    if (e.key === "ArrowDown") { e.preventDefault(); links[(i + 1) % links.length].focus(); }
    if (e.key === "ArrowUp") { e.preventDefault(); links[(i - 1 + links.length) % links.length].focus(); }
  });
  btn.addEventListener("keydown", (e) => { if (e.key === "ArrowDown") { e.preventDefault(); set(true); $("a", panel)?.focus(); } });
});
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  const open = $("[data-menu][aria-expanded=true]");
  if (open) { closeMenus(); open.focus(); }
  if ($("[data-drawer]")?.dataset.open === "true") closeDrawer();
});
document.addEventListener("click", (e) => { if (!e.target.closest(".nav__item")) closeMenus(); });
document.addEventListener("focusin", (e) => { if (!e.target.closest(".nav__item")) closeMenus(); });

// mobile drawer: modal dialog with focus trap and scroll lock
const drawerEl = $("[data-drawer]");
const openBtn = $("[data-drawer-open]");
function openDrawer() {
  drawerEl.dataset.open = "true";
  openBtn.setAttribute("aria-expanded", "true");
  document.documentElement.style.overflow = "hidden";
  setTimeout(() => $("[data-drawer-close]", drawerEl)?.focus(), 30);
}
function closeDrawer() {
  drawerEl.dataset.open = "false";
  openBtn.setAttribute("aria-expanded", "false");
  document.documentElement.style.overflow = "";
  openBtn.focus();
}
openBtn?.addEventListener("click", openDrawer);
$("[data-drawer-close]")?.addEventListener("click", closeDrawer);
drawerEl?.addEventListener("keydown", (e) => {
  if (e.key !== "Tab") return;
  const f = $$("a,button", drawerEl).filter((x) => x.offsetParent !== null);
  if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f.at(-1).focus(); }
  else if (!e.shiftKey && document.activeElement === f.at(-1)) { e.preventDefault(); f[0].focus(); }
});
$$("[data-drawer-group]").forEach((b) => b.addEventListener("click", () => {
  const open = b.getAttribute("aria-expanded") !== "true";
  b.setAttribute("aria-expanded", String(open));
  $(`#${b.getAttribute("aria-controls")}`).hidden = !open;
}));

// ------------------------------------------------------------------------------------------------ reveal + counters
// Only elements that start below the fold are hidden (data-pending), so nothing above the fold ever flickers.
const counters = new WeakSet();
function countUp(el) {
  if (counters.has(el) || reduced.matches) return;
  counters.add(el);
  const final = el.textContent;
  const target = parseFloat(el.dataset.count);
  if (!Number.isFinite(target)) return;
  const decimals = (el.dataset.count.split(".")[1] || "").length;
  const t0 = performance.now();
  const dur = 1100;
  const step = (t) => {
    const k = Math.min(1, (t - t0) / dur);
    const eased = 1 - Math.pow(1 - k, 3);
    el.textContent = final.replace(/[\d,]+(\.\d+)?/, (target * eased).toLocaleString("en-GB", { minimumFractionDigits: decimals, maximumFractionDigits: decimals }));
    if (k < 1) requestAnimationFrame(step); else el.textContent = final;
  };
  requestAnimationFrame(step);
}
const revealIO = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (!en.isIntersecting) return;
    en.target.removeAttribute("data-pending");
    $$("[data-count]", en.target).forEach(countUp);
    if (en.target.matches("[data-count]")) countUp(en.target);
    revealIO.unobserve(en.target);
  });
}, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
$$("[data-reveal]").forEach((el) => {
  if (!reduced.matches && el.getBoundingClientRect().top > innerHeight * 0.92) el.setAttribute("data-pending", "");
  revealIO.observe(el);
});
$$("[data-count]").forEach((el) => { if (!el.closest("[data-reveal]")) revealIO.observe(el); });

// ------------------------------------------------------------------------------------------------ flow stages (tabs)
$$("[data-flow]").forEach((block) => {
  const tabs = $$("[role=tab]", block);
  const panels = $$("[role=tabpanel]", block);
  panels.forEach((p, i) => { p.hidden = i !== 0; p.removeAttribute("data-flow-hidden"); });
  const select = (i, focus) => {
    tabs.forEach((t, j) => { t.setAttribute("aria-selected", String(i === j)); t.tabIndex = i === j ? 0 : -1; });
    panels.forEach((p, j) => { p.hidden = i !== j; });
    if (focus) tabs[i].focus();
    block.dispatchEvent(new CustomEvent("flowchange", { detail: { index: i }, bubbles: true }));
    Analytics.track(`flow_stage:${tabs[i].textContent.trim().slice(2)}`);
  };
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => select(i));
    t.addEventListener("keydown", (e) => {
      const next = { ArrowRight: i + 1, ArrowDown: i + 1, ArrowLeft: i - 1, ArrowUp: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (next === undefined) return;
      e.preventDefault();
      select((next + tabs.length) % tabs.length, true);
    });
  });
});

// ------------------------------------------------------------------------------------------------ section rail
const rail = $("[data-rail]");
if (rail) {
  const links = $$("a", rail);
  const targets = links.map((a) => $(a.getAttribute("href"))).filter(Boolean);
  const railIO = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      links.forEach((a) => a.setAttribute("aria-current", String(a.getAttribute("href") === `#${en.target.id}`)));
    });
  }, { rootMargin: "-35% 0px -60% 0px" });
  targets.forEach((t) => railIO.observe(t));
}

// ------------------------------------------------------------------------------------------------ lazy visualisations
// Each explanatory visual loads only when it approaches the viewport, pauses offscreen and in hidden tabs, and falls
// back to its HTML description (already in the page) if the module or canvas is unavailable.
const vizIO = new IntersectionObserver((entries) => {
  entries.forEach(async (en) => {
    const el = en.target;
    if (en.isIntersecting && !el.dataset.loaded) {
      el.dataset.loaded = "1";
      const file = ASSETS[`viz-${el.dataset.viz}.js`];
      if (!file) return;
      try {
        const mod = await import(file);
        el._viz = mod.mount(el, { reduced: reduced.matches, track: Analytics.track });
        el.classList.add("is-live");
      } catch (err) {
        el.dataset.failed = "1";
      }
    }
    el._viz?.visible?.(en.isIntersecting);
  });
}, { rootMargin: "300px 0px" });
$$("[data-viz]").forEach((el) => vizIO.observe(el));
document.addEventListener("visibilitychange", () => {
  $$("[data-viz]").forEach((el) => el._viz?.visible?.(document.visibilityState === "visible" && el.getBoundingClientRect().bottom > 0));
});

// ------------------------------------------------------------------------------------------------ enquiry form
function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
  const h = [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
// Written enquiries go to the Xevrion backend (POST /v1/public/briefs on api.xevrion.co.uk). The endpoint accepts
// exactly these fields and nothing else, is idempotent on submission_id, rate-limited and returns a reference.
$$("[data-brief-form]").forEach((form) => {
  const status = $(".form__status", form);
  const submit = $("button[type=submit]", form);
  let submissionId = uuid();
  let started = false;
  form.addEventListener("focusin", () => { if (!started) { started = true; Analytics.track(`form_start:${form.dataset.source}`); } });
  const rules = {
    name: (v) => v.trim().length >= 2,
    email: (v) => /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]{2,}$/.test(v.trim()),
    company: (v) => v.trim().length >= 2,
    service: (v) => v !== "",
    brief: (v) => v.trim().length >= 20,
  };
  const validate = (input) => {
    const rule = rules[input.name];
    if (!rule) return true;
    const ok = rule(input.value);
    const field = input.closest(".field");
    field.dataset.invalid = String(!ok);
    input.setAttribute("aria-invalid", String(!ok));
    const err = $(".error", field);
    if (err) { err.id ||= `${input.id}-err`; input.setAttribute("aria-describedby", [input.getAttribute("aria-describedby"), err.id].filter(Boolean).join(" ")); }
    return ok;
  };
  Object.keys(rules).forEach((n) => {
    const input = form.elements[n];
    input?.addEventListener("blur", () => { if (input.value) validate(input); });
    input?.addEventListener("input", () => { if (input.closest(".field").dataset.invalid === "true") validate(input); });
  });
  // An unchanged retry keeps its id, so a request that did reach us cannot be recorded twice; an edit after an
  // attempt is a different request and gets a new id (the server refuses one id with two different payloads).
  let attempted = false;
  form.addEventListener("input", () => { if (attempted) { submissionId = uuid(); attempted = false; } });
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const inputs = Object.keys(rules).map((n) => form.elements[n]);
    const bad = inputs.filter((i) => !validate(i));
    const consent = form.elements.consent;
    $("[data-consent-error]", form).hidden = consent.checked;
    if (bad.length || !consent.checked) {
      (bad[0] || consent).focus();
      Analytics.track(`form_error:${form.dataset.source}`);
      return;
    }
    submit.disabled = true;
    attempted = true;
    const label = submit.textContent;
    submit.innerHTML = '<span class="spinner" aria-hidden="true"></span> Sending';
    const val = (n) => (form.elements[n]?.value || "").trim();
    const data = {
      submission_id: submissionId, name: val("name"), email: val("email"), company: val("company"),
      service: val("service"), brief: val("brief"), outcome: val("outcome"), consent: true, website: form.elements.website.value,
    };
    try {
      const res = await fetch(`${API}/v1/public/briefs`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "omit" });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw Object.assign(new Error(typeof body.detail === "string" ? body.detail : "unavailable"), { status: res.status });
      status.className = "form__status form__status--ok";
      status.innerHTML = `<strong>Thank you, ${escapeHtml(data.name.split(" ")[0])}.</strong> Your reference is <span class="mono">${escapeHtml(body.reference || "received")}</span>. We reply in writing to ${escapeHtml(data.email)}, from outreach@ops.xevrion.co.uk.`;
      status.hidden = false;
      $$(".field, .check, button[type=submit]", form).forEach((el) => { el.hidden = true; });
      Analytics.track(`form_complete:${form.dataset.source}`);
      Analytics.flush();
      status.focus?.();
    } catch (err) {
      submit.disabled = false;
      submit.textContent = label;
      const busy = err.status === 429;
      const msg = busy ? "We have received a lot of requests from your network. Please try again in a few minutes." :
        "We could not send your request just now.";
      status.className = "form__status form__status--error";
      status.innerHTML = `${msg} You can also email <a class="link" href="mailto:outreach@ops.xevrion.co.uk?subject=${encodeURIComponent("Enquiry: " + data.company)}">outreach@ops.xevrion.co.uk</a> and we will reply in writing.`;
      status.hidden = false;
      Analytics.track(`form_failure:${err.status || "network"}`);
    }
  });
});
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

// ------------------------------------------------------------------------------------------------ analytics opt-out control (cookies page)
$$("[data-analytics-toggle]").forEach((btn) => {
  const render = () => {
    let off = false;
    try { off = localStorage.getItem("xev_analytics_off") === "1"; } catch { /* storage blocked */ }
    btn.textContent = off ? "Turn usage measurement back on" : "Turn off usage measurement";
    $("[data-analytics-state]").textContent = off || Analytics.off() ? "Off in this browser." : "On (cookieless, no identifiers).";
  };
  btn.addEventListener("click", () => {
    try {
      const off = localStorage.getItem("xev_analytics_off") === "1";
      if (off) localStorage.removeItem("xev_analytics_off"); else { localStorage.setItem("xev_analytics_off", "1"); sessionStorage.removeItem("xev_src"); }
    } catch { /* storage blocked: measurement cannot persist either */ }
    render();
  });
  render();
});

// ------------------------------------------------------------------------------------------------ live status (status page)
$$("[data-live-status]").forEach(async (el) => {
  const set = (state, text) => { el.dataset.state = state; $("[data-status-text]", el).textContent = text; };
  const t0 = performance.now();
  try {
    const res = await fetch(`${API}/health`, { credentials: "omit", cache: "no-store" });
    const ms = Math.round(performance.now() - t0);
    const body = await res.json();
    if (res.ok && body.status === "ok") set("ok", `Operational. The API answered in ${ms} ms from your browser just now.`);
    else set("risk", "The API responded but reported a problem. We are looking at it.");
  } catch {
    set("unknown", "We could not reach the API from your browser. This can be your network; the check runs again when you reload.");
  }
});

// ------------------------------------------------------------------------------------------------ command palette
// Ctrl/Cmd+K, "/" or any [data-palette-open] button. The module and its search index load only on first use.
let palette = null;
async function openPalette() {
  if (!palette) {
    const mod = await import(ASSETS["viz-palette.js"]);
    palette = mod.mount(null, { track: Analytics.track, indexUrl: ASSETS["search.json"] });
  }
  $("[data-drawer-close]")?.closest("[data-open=true]") && $("[data-drawer-close]").click();
  palette.open();
}
document.addEventListener("keydown", (e) => {
  if ((e.key === "k" || e.key === "K") && (e.ctrlKey || e.metaKey)) { e.preventDefault(); openPalette(); }
  else if (e.key === "/" && !e.target.closest("input,textarea,select,[contenteditable=true]")) { e.preventDefault(); openPalette(); }
});
$$("[data-palette-open]").forEach((b) => b.addEventListener("click", openPalette));
