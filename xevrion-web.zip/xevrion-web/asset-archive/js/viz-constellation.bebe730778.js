// Group homepage: the Xevrion constellation. The mark sits at the centre on the shared foundation ring; ventures orbit
// it. Live ventures are solid and bright, planned ones dashed; faint points are future ventures. Signals flow from the
// foundation to every venture. Hover a venture for its status; click to open its page.
import { C, glow, lerp, lifecycle, loop, pointer, rgba, stageCanvas, tooltip } from "./viz-kit.88725e7ff9.js";

const FOUNDATION = ["Infrastructure", "Security", "AI governance", "Reliability", "Measurement", "Brand"];
const VENTURES = [
  { name: "Xevrion Ops", tag: "OPS · LIVE", live: true, href: "/ventures/ops", r: 0.62, a: -0.55, speed: 0.035, moons: ["Revenue", "Customers", "Operations", "Decisions"] },
  { name: "Xevrion Cyber", tag: "CYBER · PLANNED", live: false, href: "/ventures/cyber", r: 0.82, a: 2.35, speed: 0.022, moons: [] },
];
const FUTURE = [{ r: 0.9, a: 0.9 }, { r: 0.74, a: 3.9 }, { r: 0.95, a: 5.1 }];

// The Xevrion mark (xw/html.py MARK_PATHS) on a 32-unit grid: a heavy ring and a clean X, one arm breaking out.
const MARK = ["M25.21 10.18A12 12 0 1 1 21.82 6.79L19.2 9.41A8.4 8.4 0 1 0 22.59 12.8Z",
  "M9.24 12.75L19.25 22.76L21.16 20.85L11.15 10.84Z", "M9.24 20.85L25.7 4.39L27.61 6.3L11.15 22.76Z"].map((d) => new Path2D(d));
function mark(ctx, x, y, s, alpha) { // drawn at scale s (units of a 32px box), in white
  ctx.save(); ctx.translate(x - 16 * s, y - 16 * s); ctx.scale(s, s);
  ctx.fillStyle = rgba(C.text1, alpha);
  MARK.forEach((p) => ctx.fill(p));
  ctx.restore();
}

export function mount(host, { reduced, track }) {
  const stage = host.querySelector(".constellation__stage") || host;
  const { ctx, state } = stageCanvas(stage);
  const tip = tooltip(stage);
  const p = pointer(stage);
  const signals = Array.from({ length: 22 }, (_, i) => ({ v: i % VENTURES.length, t: i / 22, s: 0.12 + (i % 5) * 0.03 }));
  let hover = null, positions = [];

  function frame(time = 0, dt = 0.016) {
    const { w, h } = state;
    p.update();
    const cx = w / 2 + p.x * 8, cy = h / 2 + p.y * 6, R = Math.min(w, h) * 0.46;
    ctx.clearRect(0, 0, w, h);
    // orbits
    [0.28, ...VENTURES.map((v) => v.r), ...FUTURE.map((f) => f.r)].forEach((r, i) => {
      ctx.strokeStyle = rgba(C.text1, i === 0 ? 0.16 : 0.06); ctx.lineWidth = 1;
      if (i > VENTURES.length) ctx.setLineDash([2, 6]);
      ctx.beginPath(); ctx.ellipse(cx, cy, R * r, R * r * 0.62, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    });
    // the foundation ring with its six layers
    FOUNDATION.forEach((f, i) => {
      const a = (i / FOUNDATION.length) * Math.PI * 2 + (reduced ? 0 : time * 0.04);
      const x = cx + Math.cos(a) * R * 0.28, y = cy + Math.sin(a) * R * 0.28 * 0.62;
      ctx.fillStyle = rgba(C.violetPale, 0.9); ctx.beginPath(); ctx.arc(x, y, 2.6, 0, Math.PI * 2); ctx.fill();
      if (w > 520) { ctx.font = "500 9.5px 'Geist Mono', monospace"; ctx.fillStyle = rgba(C.text3, 0.95); ctx.textAlign = "center"; ctx.fillText(f.toUpperCase(), x, y + (Math.sin(a) > 0 ? 16 : -10)); }
    });
    glow(ctx, cx, cy, R * 0.34, C.violet, 0.75);
    mark(ctx, cx, cy, Math.max(1.4, R / 110), 0.98, reduced ? 0 : Math.sin(time * 0.6) * 0.5 + p.x * 0.5);
    // ventures
    positions = [];
    VENTURES.forEach((v, i) => {
      const a = v.a + (reduced ? 0 : time * v.speed);
      const x = cx + Math.cos(a) * R * v.r, y = cy + Math.sin(a) * R * v.r * 0.62;
      positions.push({ v, x, y });
      const on = hover === v;
      if (v.live) glow(ctx, x, y, 46, C.violet, on ? 1 : 0.7);
      ctx.lineWidth = 1.6; ctx.strokeStyle = v.live ? C.text1 : rgba(C.text1, 0.55);
      if (!v.live) ctx.setLineDash([3, 4]);
      ctx.fillStyle = v.live ? rgba(C.bg, 0.9) : rgba(C.bg, 0.6);
      ctx.beginPath(); ctx.arc(x, y, on ? 17 : 15, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.setLineDash([]);
      mark(ctx, x, y, 0.62, v.live ? 0.95 : 0.55);
      v.moons.forEach((m, k) => {
        const ma = (k / v.moons.length) * Math.PI * 2 + (reduced ? 0 : time * 0.5);
        const mx = x + Math.cos(ma) * 30, my = y + Math.sin(ma) * 30 * 0.7;
        ctx.fillStyle = rgba(C.violetPale, 0.85); ctx.beginPath(); ctx.arc(mx, my, 2.2, 0, Math.PI * 2); ctx.fill();
      });
      ctx.font = "500 10.5px 'Geist Mono', monospace"; ctx.textAlign = "center";
      ctx.fillStyle = v.live ? C.text1 : C.text3; ctx.fillText(v.tag, x, y + 34);
    });
    FUTURE.forEach((f) => {
      const a = f.a + (reduced ? 0 : time * 0.015);
      ctx.fillStyle = rgba(C.text1, 0.18); ctx.beginPath(); ctx.arc(cx + Math.cos(a) * R * f.r, cy + Math.sin(a) * R * f.r * 0.62, 3, 0, Math.PI * 2); ctx.fill();
    });
    // signals from the foundation out to each venture
    if (!reduced) signals.forEach((s) => {
      s.t = (s.t + s.s * dt) % 1;
      const target = positions[s.v];
      const x = lerp(cx, target.x, s.t), y = lerp(cy, target.y, s.t);
      ctx.fillStyle = rgba(target.v.live ? C.violetPale : C.text2, Math.sin(s.t * Math.PI) * (target.v.live ? 0.9 : 0.35));
      ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
    });
  }

  const hit = (e) => {
    const r = stage.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
    return positions.find((q) => Math.hypot(q.x - px, q.y - py) < 24);
  };
  stage.addEventListener("pointermove", (e) => {
    const q = hit(e);
    hover = q?.v || null;
    stage.style.cursor = q ? "pointer" : "";
    if (q) tip.show(`<strong>${q.v.name}</strong><br><span class="quiet">${q.v.live ? "Live" : "Planned"}</span><p style="margin-top:6px">${q.v.live ? "Four systems: " + q.v.moons.join(", ") : "Security for growing businesses"}. Click to learn more.</p>`, q.x, q.y);
    else tip.hide();
    if (reduced) frame(0, 0);
  });
  stage.addEventListener("pointerleave", () => { hover = null; tip.hide(); });
  stage.addEventListener("click", (e) => { const q = hit(e); if (q) { track?.(`constellation:${q.v.href}`); location.href = q.v.href; } });

  const run = loop(frame);
  run.renderStatic = () => frame(0, 0);
  if (reduced) { state.onResize = () => frame(0, 0); frame(0, 0); }
  return lifecycle(run, { reduced });
}
