// Integration library search: filters the (already complete, server-rendered) list by text and category.
// Without JavaScript the full list is shown and the controls stay hidden.
export function mount(host, { track }) {
  const input = host.querySelector("[data-search]");
  const pills = [...host.querySelectorAll("[data-cat]")];
  const items = [...host.querySelectorAll("[data-item]")];
  const count = host.querySelector("[data-count-out]");
  const empty = host.querySelector("[data-empty]");
  host.querySelector("[data-controls]").hidden = false;
  let cat = "all", typed = false;
  const norm = (s) => s.toLowerCase().normalize("NFKD").replace(/[^\w\s]/g, "");
  const apply = () => {
    const words = norm(input.value).split(/\s+/).filter(Boolean);
    let shown = 0;
    items.forEach((el) => {
      const hay = norm(el.dataset.item);
      const ok = (cat === "all" || el.dataset.category === cat) && words.every((w) => hay.includes(w));
      (el.closest("[role=listitem]") || el).hidden = !ok;
      if (ok) shown++;
    });
    count.textContent = `${shown} of ${items.length}`;
    empty.hidden = shown !== 0;
  };
  input.addEventListener("input", () => { apply(); if (!typed) { typed = true; track?.("integration_search", true); } });
  pills.forEach((p) => p.addEventListener("click", () => {
    cat = p.dataset.cat;
    pills.forEach((q) => q.setAttribute("aria-pressed", String(q === p)));
    apply();
    track?.(`integration_filter:${cat}`);
  }));
  apply();
  return { visible() {} };
}
