"""Deploy dist/ to Cloudflare Workers with static assets, using the Cloudflare API directly (no Node or wrangler).

    python tools/deploy.py --preview      -> Worker "xevrion-websites-preview" on workers.dev (noindex, opens on ops)
    python tools/deploy.py --production   -> Worker "xevrion-websites" (xevrion.co.uk, ops., portal.ops.)

Needs CLOUDFLARE_API_TOKEN in the environment. Run it through scripts/deploy-websites.ps1, which decrypts the token
you stored with scripts/set-cloudflare-token.ps1 for this process only. The token is never printed.

Steps (Cloudflare "upload static assets via API"):
  1. POST assets-upload-session with a manifest of every file's hash and size; Cloudflare replies with the buckets of
     files it does not already have.
  2. Upload those buckets (base64, multipart) with the session JWT; the last upload returns a completion JWT.
  3. PUT the Worker script with the assets binding ASSETS, exact html handling and the completion JWT.
Cloudflare keeps every Worker version, so a production deploy can be rolled back from the dashboard.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import mimetypes
import os
import sys
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
CF = "https://api.cloudflare.com/client/v4"
TARGETS = {
    "preview": {"script": "xevrion-websites-preview", "vars": {"DEFAULT_SITE": "ops", "NOINDEX": "1"}},
    "production": {"script": "xevrion-websites", "vars": {"WEBSITE_INTAKE_ENABLED": "true"}},
}
TYPES = {".html": "text/html", ".css": "text/css", ".js": "application/javascript", ".png": "image/png", ".svg": "image/svg+xml",
         ".woff2": "font/woff2", ".xml": "application/xml", ".txt": "text/plain", ".json": "application/json"}


def die(msg: str) -> None:
    raise SystemExit(f"deploy: {msg}")


def api(client: httpx.Client, method: str, path: str, **kw) -> dict:
    r = client.request(method, CF + path, **kw)
    try:
        body = r.json()
    except ValueError:
        die(f"{method} {path} -> HTTP {r.status_code} (non-JSON)")
    if not body.get("success", False):
        errs = "; ".join(f'{e.get("code")}: {e.get("message")}' for e in body.get("errors", []))
        die(f"{method} {path} -> HTTP {r.status_code}: {errs}")
    return body.get("result") or {}


def manifest() -> dict[str, dict]:
    files = {}
    for p in sorted(DIST.rglob("*")):
        if not p.is_file() or p.name == "_worker.js":
            continue
        rel = "/" + p.relative_to(DIST).as_posix()
        data = p.read_bytes()
        digest = hashlib.sha256(base64.b64encode(data) + p.suffix.lstrip(".").encode()).hexdigest()[:32]
        files[rel] = {"hash": digest, "size": len(data), "path": p}
    return files


def main() -> None:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--preview", action="store_true")
    g.add_argument("--production", action="store_true")
    args = ap.parse_args()
    target = TARGETS["production" if args.production else "preview"]
    token = os.environ.get("CLOUDFLARE_API_TOKEN", "")
    if len(token) < 20:
        die("CLOUDFLARE_API_TOKEN is not set; run scripts\\deploy-websites.ps1")
    worker = ROOT / "worker-dist" / "worker.js"
    if not worker.exists():
        die("dist/ is not built; run python build.py --strict first")

    with httpx.Client(headers={"Authorization": f"Bearer {token}"}, timeout=120) as client:
        accounts = api(client, "GET", "/accounts")
        account = os.environ.get("CLOUDFLARE_ACCOUNT_ID") or (accounts[0]["id"] if len(accounts) == 1 else "")
        if not account:
            die("several Cloudflare accounts are visible; set CLOUDFLARE_ACCOUNT_ID")
        script = target["script"]
        files = manifest()
        print(f"{script}: {len(files)} files, {sum(f['size'] for f in files.values()) / 1024:.0f} KB")

        # 1. upload session
        session = api(client, "POST", f"/accounts/{account}/workers/scripts/{script}/assets-upload-session",
                      json={"manifest": {k: {"hash": v["hash"], "size": v["size"]} for k, v in files.items()}})
        jwt, buckets = session.get("jwt"), session.get("buckets") or []
        by_hash = {v["hash"]: v for v in files.values()}
        completion = jwt
        # 2. upload only what Cloudflare does not already have
        for i, bucket in enumerate(buckets, 1):
            parts = []
            for h in bucket:
                f = by_hash[h]
                mime = TYPES.get(f["path"].suffix) or mimetypes.guess_type(f["path"].name)[0] or "application/octet-stream"
                parts.append((h, (h, base64.b64encode(f["path"].read_bytes()), mime)))
            r = client.post(f"{CF}/accounts/{account}/workers/assets/upload?base64=true", files=parts, headers={"Authorization": f"Bearer {jwt}"})
            body = r.json()
            if not body.get("success"):
                die(f"asset upload bucket {i} failed: HTTP {r.status_code}")
            completion = (body.get("result") or {}).get("jwt") or completion
            print(f"  uploaded bucket {i}/{len(buckets)} ({len(bucket)} files)")
        if not buckets:
            print("  every file was already on Cloudflare")

        # 3. the Worker, bound to the uploaded assets
        metadata = {
            "main_module": "worker.js",
            "compatibility_date": "2025-09-01",
            "assets": {"jwt": completion, "config": {"html_handling": "none", "not_found_handling": "none", "run_worker_first": True}},
            "bindings": [{"type": "assets", "name": "ASSETS"}] + [{"type": "plain_text", "name": k, "text": v} for k, v in target["vars"].items()],
            "observability": {"enabled": True},
        }
        api(client, "PUT", f"/accounts/{account}/workers/scripts/{script}", files={
            "metadata": (None, json.dumps(metadata), "application/json"),
            "worker.js": ("worker.js", worker.read_bytes(), "application/javascript+module"),
        })
        print(f"  deployed Worker {script}")
        if args.preview:
            api(client, "POST", f"/accounts/{account}/workers/scripts/{script}/subdomain", json={"enabled": True, "previews_enabled": False})
            sub = api(client, "GET", f"/accounts/{account}/workers/subdomain").get("subdomain")
            print(f"PREVIEW https://{script}.{sub}.workers.dev/  (ops site; /parent/ and /portal/ for the others)")
        else:
            print("PRODUCTION https://xevrion.co.uk/  https://ops.xevrion.co.uk/  https://portal.ops.xevrion.co.uk/")


if __name__ == "__main__":
    sys.exit(main())
