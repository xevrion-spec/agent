"""Render the social-sharing cards and app icons with the locally installed Microsoft Edge (headless, offline).

    python tools/render_images.py

Writes src/og/{ops,parent,portal}.png (1200x630 layout, rendered at 2x: 2400x1260), src/brand/{apple-touch-180,xevrion-mark-512}.png,
the favicons src/brand/favicon-{48,96,192}.png and src/brand/favicon.ico (16, 32 and 48 px PNGs in one icon file).
Everything is drawn from HTML templates using the self-hosted Geist fonts; nothing is fetched from the internet.
"""
from __future__ import annotations

import struct
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from xw.html import mark_standalone  # noqa: E402

EDGE = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
FONTS = (ROOT / "src" / "fonts").as_uri()

BASE_CSS = f"""
@font-face{{font-family:Geist;src:url({FONTS}/geist-latin.woff2) format("woff2");font-weight:300 700}}
@font-face{{font-family:"Geist Mono";src:url({FONTS}/geist-mono-latin.woff2) format("woff2");font-weight:400 600}}
*{{margin:0;box-sizing:border-box}} html,body{{width:100%;height:100%;overflow:hidden;background:#08090d;color:#f8f8fb;font-family:Geist,sans-serif}}
"""

CARDS = {
    "ops": ("XEVRION OPS", "Your business,<br>continuously improving.", "Connect your data · Find opportunities · Act with approval · Measure value"),
    "parent": ("XEVRION", "Focused ventures.<br>One foundation.", "Xevrion Ops · live   ·   Xevrion Cyber · planned"),
    "portal": ("XEVRION PORTAL", "Sign in to<br>Xevrion Ops.", "Customer app · Access and roles · Help"),
}


def card_html(eyebrow: str, title: str, sub: str) -> str:
    mark = mark_standalone("m", ' class="m"')
    big = mark_standalone("b", ' style="width:100%;height:100%"')
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{BASE_CSS}
body{{background:radial-gradient(900px 520px at 78% 18%,rgba(128,86,255,.30),transparent 62%),radial-gradient(700px 500px at 0% 100%,rgba(90,70,190,.12),transparent 70%),#08090d}}
.grid{{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);background-size:60px 60px;
  -webkit-mask-image:radial-gradient(ellipse 70% 70% at 75% 25%,#000,transparent 75%)}}
.wrap{{position:absolute;inset:72px 80px;display:flex;flex-direction:column;justify-content:space-between}}
.top{{display:flex;align-items:center;gap:16px;font-weight:600;letter-spacing:.16em;font-size:22px}} .m{{width:44px;height:44px}}
h1{{font-weight:500;font-size:84px;line-height:.98;letter-spacing:-.05em;background:linear-gradient(100deg,#fff 0%,#e4e6ec 38%,#9ea2b0 52%,#f3f4f8 60%,#c9ccd6 100%);-webkit-background-clip:text;color:transparent}}
p{{font:500 18px/1.3 "Geist Mono",monospace;letter-spacing:.03em;color:#b7b8c2;text-transform:uppercase;white-space:nowrap}}
.frame{{position:absolute;right:72px;top:64px;width:236px;height:236px;clip-path:polygon(22px 0,100% 0,100% calc(100% - 22px),calc(100% - 22px) 100%,0 100%,0 22px);
  background:linear-gradient(140deg,rgba(255,255,255,.07),rgba(128,86,255,.05))}}
.corner{{position:absolute;width:22px;height:22px;border:0 solid rgba(236,237,242,.7)}}
.c1{{right:58px;top:50px;border-top-width:2px;border-right-width:2px}} .c2{{right:58px;top:292px;border-bottom-width:2px;border-right-width:2px}}
.c3{{right:300px;top:50px;border-top-width:2px;border-left-width:2px}} .c4{{right:300px;top:292px;border-bottom-width:2px;border-left-width:2px}}
.big{{position:absolute;right:113px;top:105px;width:154px;height:154px;filter:drop-shadow(0 0 40px rgba(128,86,255,.55))}}
.tag{{position:absolute;right:74px;top:326px;font:500 12px/1 "Geist Mono",monospace;letter-spacing:.12em;color:#8e909d}}
</style></head><body><div class="grid"></div><div class="frame"></div><i class="corner c1"></i><i class="corner c2"></i><i class="corner c3"></i><i class="corner c4"></i>
<div class="big">{big}</div><span class="tag">XV · 32U</span>
<div class="wrap"><div class="top">{mark}<span>{eyebrow}</span></div><h1>{title}</h1><p>{sub}</p></div></body></html>"""


def icon_html(size: int) -> str:
    # the page is pinned to the icon's size: headless windows are never narrower than about 500px, and a page that
    # fills the window would centre the mark outside a small icon's crop
    mark = mark_standalone("m", ' class="m"')
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{BASE_CSS}
html,body{{width:{size}px;height:{size}px}} body{{display:grid;place-items:center;background:#000}} .m{{width:{int(size * .62)}px;height:{int(size * .62)}px}}</style></head><body>{mark}</body></html>"""


def shoot(html: str, out: Path, w: int, h: int, scale: int = 1) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "page.html"
        page.write_text(html, "utf-8")
        subprocess.run([str(EDGE), "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--force-device-scale-factor={scale}",
                        f"--user-data-dir={tmp}\\profile", "--virtual-time-budget=3000", f"--window-size={w},{h}",
                        f"--screenshot={out}", page.as_uri()], check=True, capture_output=True, timeout=60)
    print(f"wrote {out.relative_to(ROOT)} ({out.stat().st_size // 1024} KB)")


def main() -> None:
    if not EDGE.exists():
        raise SystemExit("Microsoft Edge not found; OG images not rendered")
    for key, (eyebrow, title, sub) in CARDS.items():
        # drawn at twice the size (2400x1260) so the card stays sharp on high-density screens and large previews
        shoot(card_html(eyebrow, title, sub), ROOT / "src" / "og" / f"{key}.png", 1200, 630, scale=2)
    shoot(icon_html(180), ROOT / "src" / "brand" / "apple-touch-180.png", 180, 180)
    shoot(icon_html(512), ROOT / "src" / "brand" / "xevrion-mark-512.png", 512, 512)
    for size in (16, 32, 48, 96, 192):          # search engines and browsers ask for these; 48 and up for Google
        shoot(icon_html(size), ROOT / "src" / "brand" / f"favicon-{size}.png", size, size)
    ico(ROOT / "src" / "brand" / "favicon.ico", [ROOT / "src" / "brand" / f"favicon-{s}.png" for s in (16, 32, 48)])


def ico(out: Path, pngs: list[Path]) -> None:
    """An .ico file holding PNG images (supported everywhere since Windows Vista): a header, one directory entry
    per image, then the PNG bytes."""
    data = [p.read_bytes() for p in pngs]
    head = struct.pack("<HHH", 0, 1, len(data))
    offset, entries = 6 + 16 * len(data), b""
    for p, b in zip(pngs, data):
        size = int(p.stem.rsplit("-", 1)[1])
        entries += struct.pack("<BBBBHHII", size % 256, size % 256, 0, 0, 1, 32, len(b), offset)
        offset += len(b)
    out.write_bytes(head + entries + b"".join(data))
    print(f"wrote {out.relative_to(ROOT)} ({out.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
