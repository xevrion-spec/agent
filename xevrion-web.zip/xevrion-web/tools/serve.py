"""Local preview that behaves like the Worker: one port per site, same path mapping, same security headers (CSP).

    python tools/serve.py          ops on :8802, parent on :8801, portal on :8803
"""
from __future__ import annotations

import http.server
import re
import sys
import threading
from functools import partial
from pathlib import Path

DIST = Path(__file__).resolve().parent.parent / "dist"
PORTS = {"parent": 8801, "ops": 8802, "portal": 8803}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self'; img-src 'self' data:; "
       "connect-src 'self' https://api.xevrion.co.uk; frame-ancestors 'none'; base-uri 'self'; form-action 'self' mailto:; object-src 'none'")
TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".svg": "image/svg+xml", ".png": "image/png",
         ".woff2": "font/woff2", ".xml": "application/xml", ".txt": "text/plain; charset=utf-8", ".json": "application/json"}


class Handler(http.server.BaseHTTPRequestHandler):
    def __init__(self, *a, site: str, **k):
        self.site = site
        super().__init__(*a, **k)

    def log_message(self, fmt, *args):  # quiet
        pass

    def do_GET(self):
        path = self.path.split("?")[0].split("#")[0]
        if path.startswith("/shared/"):
            f = DIST / path.lstrip("/")
        else:
            p = path + "index.html" if path.endswith("/") else (path if re.search(r"\.[a-z0-9]+$", path) else path + ".html")
            f = DIST / self.site / p.lstrip("/")
        status = 200
        if not f.is_file() or DIST not in f.resolve().parents:
            f, status = DIST / self.site / "404.html", 404
            if not f.is_file():
                self.send_error(404)
                return
        body = f.read_bytes()
        self.send_response(status)
        self.send_header("Content-Type", TYPES.get(f.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if f.suffix == ".html":
            self.send_header("Content-Security-Policy", CSP)
        self.end_headers()
        self.wfile.write(body)


def main():
    servers = []
    for site, port in PORTS.items():
        srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), partial(Handler, site=site))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        servers.append(srv)
        print(f"{site:7s} http://127.0.0.1:{port}/", flush=True)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
