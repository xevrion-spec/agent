// Checks for the websites Worker, run against the built script with a fake asset binding (no network):
//     python build.py && node tools/test_worker.mjs
// Covers: no open redirect through "//host" or "/\host" paths, HTTP to HTTPS, the old portal/manage hosts, tidy URLs,
// the redirect maps and the security headers.
import assert from "node:assert/strict";
import worker from "../worker-dist/worker.js";

const PAGES = new Set(["/ops/index.html", "/ops/pricing.html", "/parent/index.html", "/portal/index.html", "/ops/404.html", "/parent/404.html", "/portal/404.html"]);
const env = {
  ASSETS: {
    fetch: async (req) => {
      const path = new URL(typeof req === "string" || req instanceof URL ? req : req.url).pathname;
      const ok = PAGES.has(path);
      return new Response(ok ? "<!doctype html><title>x</title>" : "missing", { status: ok ? 200 : 404, headers: { "Content-Type": ok ? "text/html; charset=utf-8" : "text/plain" } });
    },
  },
};

const get = (url, method = "GET") => worker.fetch(new Request(url, { method, redirect: "manual" }), env);
const where = async (url) => {
  const res = await get(url);
  assert.ok([301, 302].includes(res.status), `${url}: expected a redirect, got ${res.status}`);
  return res.headers.get("Location");
};
let n = 0;
const check = async (name, fn) => { await fn(); n += 1; console.log(`ok  ${name}`); };

await check("double-slash and backslash paths stay on the same host", async () => {
  for (const [url, host] of [["https://ops.xevrion.co.uk//example.com/", "ops.xevrion.co.uk"], ["https://ops.xevrion.co.uk/\\example.com/", "ops.xevrion.co.uk"],
                             ["https://xevrion.co.uk//example.com/x.html", "xevrion.co.uk"], ["https://portal.ops.xevrion.co.uk//example.com/", "portal.ops.xevrion.co.uk"],
                             ["https://ops.xevrion.co.uk///example.com", "ops.xevrion.co.uk"], ["https://ops.xevrion.co.uk//example.com", "ops.xevrion.co.uk"],
                             ["https://www.xevrion.co.uk//example.com/", "xevrion.co.uk"], ["https://portal.xevrion.co.uk//example.com/", "portal.ops.xevrion.co.uk"]]) {
    const loc = await where(url);
    assert.equal(new URL(loc).host, host, `${url} -> ${loc}`);
  }
  assert.equal(await where("https://ops.xevrion.co.uk//example.com/"), "https://ops.xevrion.co.uk/example.com/");
});

await check("tidy URLs and the redirect maps still work", async () => {
  assert.equal(await where("https://ops.xevrion.co.uk/pricing/"), "https://ops.xevrion.co.uk/pricing");
  assert.equal(await where("https://ops.xevrion.co.uk/pricing.html?x=1"), "https://ops.xevrion.co.uk/pricing?x=1");
  assert.equal(await where("https://ops.xevrion.co.uk/atlas"), "https://xevrion.co.uk/atlas");
  assert.equal(await where("https://ops.xevrion.co.uk/product/optimization"), "https://ops.xevrion.co.uk/how-it-works#learn");
  assert.equal(await where("https://portal.ops.xevrion.co.uk/customer"), "https://api.xevrion.co.uk/portal");
  assert.equal((await get("https://ops.xevrion.co.uk/pricing")).status, 200);
});

await check("plain HTTP goes to HTTPS (local development is left alone)", async () => {
  assert.equal(await where("http://ops.xevrion.co.uk/pricing?x=1"), "https://ops.xevrion.co.uk/pricing?x=1");
  assert.equal(await where("http://xevrion.co.uk/"), "https://xevrion.co.uk/");
  assert.equal(await where("http://portal.ops.xevrion.co.uk//example.com/"), "https://portal.ops.xevrion.co.uk//example.com/");
  assert.equal((await get("http://127.0.0.1:8787/ops/pricing")).status, 200);
});

await check("portal.xevrion.co.uk and manage.xevrion.co.uk reach a working page", async () => {
  assert.equal(await where("https://portal.xevrion.co.uk/"), "https://api.xevrion.co.uk/portal");
  assert.equal(await where("https://portal.xevrion.co.uk/portal/"), "https://api.xevrion.co.uk/portal");
  assert.equal(await where("https://portal.xevrion.co.uk/app?plan=scale"), "https://api.xevrion.co.uk/app?plan=scale");
  assert.equal(await where("https://portal.xevrion.co.uk/access"), "https://portal.ops.xevrion.co.uk/access");
  assert.equal(await where("https://manage.xevrion.co.uk/"), "https://api.xevrion.co.uk/console");
  assert.equal(await where("https://manage.xevrion.co.uk/manage/"), "https://api.xevrion.co.uk/console");
});

await check("security headers on pages and redirects; POST is refused with a way to write", async () => {
  const page = await get("https://ops.xevrion.co.uk/");
  assert.equal(page.headers.get("Strict-Transport-Security"), "max-age=31536000");
  assert.match(page.headers.get("Content-Security-Policy"), /form-action 'self' mailto:/);
  assert.equal((await get("https://ops.xevrion.co.uk/pricing/")).headers.get("Strict-Transport-Security"), "max-age=31536000");
  const post = await get("https://ops.xevrion.co.uk/contact", "POST");
  assert.equal(post.status, 405);
  assert.match(await post.text(), /outreach@ops\.xevrion\.co\.uk/);
});

console.log(`${n} worker checks passed`);
