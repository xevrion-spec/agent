// Checks for the site script's measurement (src/js/core.js) in a minimal fake browser, no network:
//     node tools/test_core_analytics.mjs
// A new arrival sends start:true once; a hop to another Xevrion site carries the first-touch source in the link and the
// next site adopts it (start:false) and removes it from the address; local and preview hosts send nothing.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

// core.js is a classic-looking module (no imports or exports): run a fresh copy for every visit, in strict mode
const CORE = readFileSync(new URL("../src/js/core.js", import.meta.url), "utf8");

function storage() {
  const m = new Map();
  return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) };
}

async function boot({ url, referrer = "", site = "ops", session = storage() }) {
  const u = new URL(url);
  const sent = [], handlers = {}, docHandlers = {}, replaced = [];
  const on = (bag) => (type, fn) => { (bag[type] ||= []).push(fn); };
  const g = globalThis;
  Object.assign(g, {
    location: { href: u.href, hostname: u.hostname, host: u.host, pathname: u.pathname, search: u.search, hash: u.hash },
    history: { state: null, replaceState: (_s, _t, to) => replaced.push(to) },
    sessionStorage: session, localStorage: storage(),
    matchMedia: () => ({ matches: true }), scrollY: 0, innerHeight: 800, innerWidth: 1200,
    addEventListener: on(handlers), setInterval: () => 0, requestAnimationFrame: () => 0, cancelAnimationFrame: () => {},
    IntersectionObserver: class { observe() {} unobserve() {} },
    fetch: async (to, opts) => { sent.push({ to, body: JSON.parse(opts.body) }); return { ok: true, json: async () => ({}) }; },
  });
  Object.defineProperty(g, "navigator", { value: { doNotTrack: null, globalPrivacyControl: false }, configurable: true, writable: true });
  g.window = g;
  g.document = {
    referrer, visibilityState: "visible", documentElement: { dataset: { site, env: "default" }, style: {}, scrollHeight: 1000, clientWidth: 1200 },
    getElementById: () => null, querySelector: () => null, querySelectorAll: () => [], addEventListener: on(docHandlers), fonts: null,
  };
  new Function(`"use strict";\n${CORE}`)();
  const hide = () => { g.document.visibilityState = "hidden"; (handlers.visibilitychange || []).forEach((f) => f()); g.document.visibilityState = "visible"; };
  const click = (href) => {
    const a = { href };
    const e = { target: { closest: (sel) => (sel === "a[href]" ? a : null) } };
    (docHandlers.click || []).forEach((f) => f(e));
    return a.href;
  };
  return { sent, hide, click, replaced, session, track: g.xevTrack };
}

// 1. A visitor arrives on xevrion.co.uk from Google: the first payload starts the visit, later ones do not.
const parent = await boot({ url: "https://xevrion.co.uk/", referrer: "https://www.google.com/", site: "parent" });
parent.hide();
parent.track("scroll_50");
parent.hide();
assert.equal(parent.sent.length, 2);
assert.equal(parent.sent[0].to, "https://api.xevrion.co.uk/v1/public/events");
assert.deepEqual(parent.sent[0].body.source, { source: "www.google.com", medium: "referral", campaign: "", landing: "/", start: true });
assert.equal(parent.sent[0].body.events[0].n, "page_view:default");
assert.equal(parent.sent[1].body.source.start, false);
console.log("ok  a new arrival sends start:true once");

// 2. Their click to Xevrion Ops carries the first touch; links on the same site and to the API are left alone.
const hop = parent.click("https://ops.xevrion.co.uk/pricing");
assert.equal(new URL(hop).searchParams.get("xs"), "www.google.com|referral|");
assert.equal(parent.click("https://xevrion.co.uk/ventures"), "https://xevrion.co.uk/ventures");
assert.equal(parent.click("https://api.xevrion.co.uk/app?plan=scale#signup"), "https://api.xevrion.co.uk/app?plan=scale#signup");
console.log("ok  cross-site links carry the source; same-site and app links do not");

// 3. Ops adopts it: the same visit and channel (start:false), and the parameter leaves the address.
const ops = await boot({ url: hop + "#plans", referrer: "https://xevrion.co.uk/" });
ops.hide();
assert.deepEqual(ops.sent[0].body.source, { source: "www.google.com", medium: "referral", campaign: "", landing: "/pricing", start: false });
assert.deepEqual(ops.replaced, ["/pricing#plans"]);
console.log("ok  the next site continues the visit and strips xs");

// 4. A new tab from a Xevrion page without xs is "internal", not a new visit; xs from an outside referrer is ignored.
const tab = await boot({ url: "https://ops.xevrion.co.uk/docs", referrer: "https://ops.xevrion.co.uk/" });
tab.hide();
assert.deepEqual(tab.sent[0].body.source, { source: "internal", medium: "none", campaign: "", landing: "/docs", start: false });
const shared = await boot({ url: "https://ops.xevrion.co.uk/?xs=evil|cpc|x", referrer: "https://news.example/" });
shared.hide();
assert.equal(shared.sent[0].body.source.source, "news.example");
assert.equal(shared.sent[0].body.source.start, true);
console.log("ok  internal tabs are not visits; a shared xs is not adopted");

// 5. A reload of the landing page in the same tab is not a new visit.
const again = await boot({ url: "https://xevrion.co.uk/", referrer: "https://www.google.com/", site: "parent", session: parent.session });
again.hide();
assert.equal(again.sent[0].body.source.start, false);
console.log("ok  a revisit in the same session is not a new visit");

// 6. Local and preview builds send nothing.
for (const url of ["http://127.0.0.1:8802/", "https://xevrion-websites-preview.example.workers.dev/"]) {
  const local = await boot({ url });
  local.track("cta_start:nav");
  local.hide();
  assert.equal(local.sent.length, 0, url);
}
console.log("ok  local and preview hosts send nothing");
console.log("6 core analytics checks passed");
