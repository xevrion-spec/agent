"""Copy the customer portal from the gateway into the website, for the /customer-portal presentation.

    python tools/sync_portal.py            copy the portal stylesheet and script from the gateway repo
    python tools/sync_portal.py --check    exit 1 if the website's copies differ from the gateway's

The gateway (xevrion-platform-1.7.0/platform-gateway/portal-ui) is the source of truth. The portal's script is kit.js
and portal.js wrapped in one strict IIFE, exactly as the gateway's scripts/build_portal_ui.py bundles it for /app, so
the website runs the same code on illustrative data (src/js/portal-demo.js). Run after every portal change.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GATEWAY = ROOT.parent / "xevrion-platform-1.7.0" / "platform-gateway" / "portal-ui"
HEADER = "/* Copied from the gateway (platform-gateway/portal-ui) by tools/sync_portal.py. Edit the gateway copy, not this one. */\n"
TARGETS = {ROOT / "src" / "portal" / "portal.css": ("portal.css",), ROOT / "src" / "js" / "portal-app.js": ("kit.js", "portal.js")}


def expected(parts: tuple[str, ...]) -> str:
    texts = [(GATEWAY / p).read_text("utf-8") for p in parts]
    if len(texts) == 1:
        return HEADER + texts[0]
    # the same wrapping as the gateway's build_portal_ui.bundle()
    return HEADER + '(function () {\n  "use strict";\n' + texts[0] + "\n" + texts[1] + "\n})();\n"


def sources_present() -> bool:
    return all((GATEWAY / p).exists() for parts in TARGETS.values() for p in parts)


def stale() -> list[str]:
    return [dst.name for dst, parts in TARGETS.items() if not dst.exists() or dst.read_text("utf-8") != expected(parts)]


def main(argv: list[str]) -> int:
    if not sources_present():
        print(f"gateway portal sources not found in {GATEWAY}")
        return 1
    if "--check" in argv:
        out = stale()
        if out:
            print("out of date: " + ", ".join(out) + " (run python tools/sync_portal.py)")
            return 1
        print("portal copies are up to date")
        return 0
    for dst, parts in TARGETS.items():
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(expected(parts), "utf-8")
        print(f"wrote {dst.relative_to(ROOT)} from {' + '.join(parts)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
