"""Download the Geist and Geist Mono variable fonts (SIL Open Font License) from Google Fonts for self-hosting.

The site's Content-Security-Policy only allows fonts from its own origin, and self-hosting avoids a third-party
request on the critical path. Only the Latin and Latin-extended subsets are kept (GBP, UK English, accents)."""
import re
import sys
import urllib.request
from pathlib import Path

OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=True)
# A modern user agent makes Google Fonts serve woff2 with unicode-range subsets.
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"
FAMILIES = {"geist": "Geist:wght@300..700", "geist-mono": "Geist+Mono:wght@400..600"}
KEEP = {"latin", "latin-ext"}

for slug, family in FAMILIES.items():
    css = urllib.request.urlopen(urllib.request.Request(
        f"https://fonts.googleapis.com/css2?family={family}&display=swap", headers={"User-Agent": UA}), timeout=30).read().decode()
    blocks = re.findall(r"/\*\s*([\w-]+)\s*\*/\s*@font-face\s*{(.*?)}", css, re.S)
    for subset, body in blocks:
        if subset not in KEEP:
            continue
        url = re.search(r"url\((https://[^)]+\.woff2)\)", body).group(1)
        data = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=30).read()
        target = OUT / f"{slug}-{subset}.woff2"
        target.write_bytes(data)
        unicode_range = re.search(r"unicode-range:\s*([^;]+);", body).group(1).strip()
        (OUT / f"{slug}-{subset}.range").write_text(unicode_range, encoding="utf-8")
        print(f"{target.name}: {len(data) // 1024} KB")
